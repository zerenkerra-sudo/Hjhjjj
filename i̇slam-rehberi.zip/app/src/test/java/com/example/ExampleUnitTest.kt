package com.example

import com.example.data.local.AppStrings
import com.example.data.local.BuiltinQuranData
import com.example.data.local.QuranNavigationData
import com.example.data.model.AppLanguage
import com.example.data.model.PrayerType
import com.example.data.repository.DiyanetCalculator
import org.junit.Assert.*
import org.junit.Test
import java.util.Date
import kotlin.math.*

class ExampleUnitTest {

    @Test
    fun testPrayerTypeAdhanAssets() {
        assertEquals("adhan_fajr.mp3", PrayerType.FAJR.soundAsset)
        assertEquals("adhan.mp3", PrayerType.DHUHR.soundAsset)
        assertEquals("adhan.mp3", PrayerType.ASR.soundAsset)
        assertEquals("adhan.mp3", PrayerType.MAGHRIB.soundAsset)
        assertEquals("adhan.mp3", PrayerType.ISHA.soundAsset)
        assertFalse("Sunrise should not have an adhan", PrayerType.SUNRISE.hasAdhan)
    }

    @Test
    fun testBilingualTranslations() {
        assertEquals("İslam Rehberi", AppStrings.appTitle(AppLanguage.TURKISH))
        assertEquals("Rêbera Îslamê", AppStrings.appTitle(AppLanguage.KURMANJI))

        assertEquals("Sabah (İmsak)", PrayerType.FAJR.getName(AppLanguage.TURKISH))
        assertEquals("Berbanga Sibê", PrayerType.FAJR.getName(AppLanguage.KURMANJI))

        assertEquals("Öğle", PrayerType.DHUHR.getName(AppLanguage.TURKISH))
        assertEquals("Nîvro", PrayerType.DHUHR.getName(AppLanguage.KURMANJI))

        assertEquals("İkindi", PrayerType.ASR.getName(AppLanguage.TURKISH))
        assertEquals("Esir (Êvarî)", PrayerType.ASR.getName(AppLanguage.KURMANJI))

        assertEquals("Akşam", PrayerType.MAGHRIB.getName(AppLanguage.TURKISH))
        assertEquals("Şam (Meẍrîb)", PrayerType.MAGHRIB.getName(AppLanguage.KURMANJI))

        assertEquals("Yatsı", PrayerType.ISHA.getName(AppLanguage.TURKISH))
        assertEquals("Êşa (Derengî)", PrayerType.ISHA.getName(AppLanguage.KURMANJI))
    }

    @Test
    fun testQuranFullStats() {
        // 114 Surahs
        assertEquals(114, BuiltinQuranData.SURAH_LIST.size)

        // 6,236 Ayahs total
        val totalAyahs = BuiltinQuranData.SURAH_LIST.sumOf { it.versesCount }
        assertEquals(6236, totalAyahs)

        // 30 Juz
        assertEquals(30, QuranNavigationData.JUZ_LIST.size)
        assertEquals(1, QuranNavigationData.JUZ_LIST.first().number)
        assertEquals(30, QuranNavigationData.JUZ_LIST.last().number)

        // 604 Pages
        assertEquals(1, QuranNavigationData.JUZ_LIST.first().startPage)
        assertEquals(604, QuranNavigationData.JUZ_LIST.last().endPage)
    }

    @Test
    fun testDiyanetAstronomicalCalculator() {
        val times = DiyanetCalculator.calculateTimes(41.0082, 28.9784, Date(), "İstanbul")
        assertNotNull(times)
        assertTrue(times.fajr.contains(":"))
        assertTrue(times.sunrise.contains(":"))
        assertTrue(times.dhuhr.contains(":"))
        assertTrue(times.asr.contains(":"))
        assertTrue(times.maghrib.contains(":"))
        assertTrue(times.isha.contains(":"))
        assertTrue(times.isOffline)
    }

    @Test
    fun testQiblaAzimuthFromIstanbul() {
        val lat1 = Math.toRadians(41.0082)
        val lon1 = Math.toRadians(28.9784)
        val lat2 = Math.toRadians(21.422487)
        val lon2 = Math.toRadians(39.826206)

        val dLon = lon2 - lon1
        val y = sin(dLon) * cos(lat2)
        val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)
        val qiblaBearing = (Math.toDegrees(atan2(y, x)) + 360.0) % 360.0

        assertTrue("Qibla bearing from Istanbul should be between 145 and 160 degrees", qiblaBearing in 145.0..160.0)
    }

    @Test
    fun testQuranDuasData() {
        // Authentic Quran Duas
        val duas = com.example.data.local.QuranDuasData.DUAS_LIST
        assertTrue("Duas list should not be empty", duas.isNotEmpty())
        assertEquals(10, duas.size)

        for (dua in duas) {
            assertTrue("Arabic text must be present", dua.arabicText.isNotBlank())
            assertTrue("Turkish translation must be present", dua.translationTr.isNotBlank())
            assertTrue("Kurmanji Latin translation must be present", dua.translationKuLatin.isNotBlank())
            assertTrue("Ayah reference must be valid", dua.ayahReference.contains(":"))
        }

        // Daily rotating dua
        val todayDua = com.example.data.local.QuranDuasData.getTodayDua()
        assertNotNull("Today's dua should not be null", todayDua)
        assertTrue(todayDua.arabicText.isNotBlank())
    }

    @Test
    fun testHutbeData() {
        val hutbes = com.example.data.local.HutbeData.HUTBE_LIST
        assertTrue("Hutbe list should not be empty", hutbes.isNotEmpty())

        for (hutbe in hutbes) {
            assertTrue("Title must be present", hutbe.titleTr.isNotBlank())
            assertTrue("Arabic verse or hadith must be present", hutbe.arabicVerseOrHadith.isNotBlank())
            assertTrue("Turkish full text must be present", hutbe.fullTextTr.isNotBlank())
            assertTrue("Kurmanji full text must be present", hutbe.fullTextKu.isNotBlank())
        }

        val activeHutbe = com.example.data.local.HutbeData.getCurrentWeekHutbe()
        assertNotNull(activeHutbe)
    }

    @Test
    fun testNoYezdanInKurdishTranslations() {
        for ((_, ayahs) in BuiltinQuranData.DETAILS_MAP) {
            for (ayah in ayahs) {
                assertFalse("Yezdan must never be used in Kurdish translations: ${ayah.translationKuLatin}",
                    ayah.translationKuLatin.contains("Yezdan", ignoreCase = true))
            }
        }
    }

    @Test
    fun testReligiousDaysData() {
        val days = com.example.data.local.ReligiousDaysData.RELIGIOUS_DAYS
        assertTrue("Religious days list should contain major Islamic events", days.size >= 10)

        // Verify key Islamic days exist
        assertTrue(days.any { it.nameTr.contains("Regaip") })
        assertTrue(days.any { it.nameTr.contains("Miraç") })
        assertTrue(days.any { it.nameTr.contains("Berat") })
        assertTrue(days.any { it.nameTr.contains("Ramazan") })
        assertTrue(days.any { it.nameTr.contains("Kadir") })
        assertTrue(days.any { it.nameTr.contains("Kurban") })
        assertTrue(days.any { it.nameTr.contains("Aşure") })
        assertTrue(days.any { it.nameTr.contains("Mevlid") })

        for (day in days) {
            assertTrue("Must have Turkish name", day.nameTr.isNotBlank())
            assertTrue("Must have Kurmanji name", day.nameKu.isNotBlank())
            assertTrue("Must have Gregorian date YYYY-MM-DD", day.gregorianDateStr.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
            assertTrue("Must have Hijri date", day.hijriDate.isNotBlank())
            assertTrue("Must have Turkish spiritual significance", day.significanceTr.isNotBlank())
            assertTrue("Must have Kurmanji spiritual significance", day.significanceKu.isNotBlank())
            assertTrue("Must have Turkish celebration message", day.celebrationMessageTr.isNotBlank())
            assertTrue("Must have Kurmanji celebration message", day.celebrationMessageKu.isNotBlank())
        }
    }

    @Test
    fun testQuranPageDetail() = kotlinx.coroutines.runBlocking {
        val repo = com.example.data.repository.QuranRepository()
        val page1 = repo.getPageDetail(1)
        assertNotNull(page1)
        assertEquals(1, page1.pageNumber)
        assertEquals(1, page1.juzNumber)
        assertEquals(1, page1.mainSurahNumber)
        assertTrue(page1.ayahs.isNotEmpty())

        val page604 = repo.getPageDetail(604)
        assertNotNull(page604)
        assertEquals(604, page604.pageNumber)
        assertEquals(30, page604.juzNumber)
        assertTrue(page604.ayahs.isNotEmpty())
    }

    @Test
    fun testWorldwideCitiesCoverage() {
        val cities = com.example.data.model.City.DEFAULT_CITIES
        assertTrue("Cities list should contain over 100 cities worldwide", cities.size > 100)

        // Turkey provinces
        assertTrue(cities.any { it.nameTr == "Diyarbakır" && it.country == "Türkiye" })
        assertTrue(cities.any { it.nameTr == "İstanbul" && it.country == "Türkiye" })

        // Kurdish and Middle Eastern cities
        assertTrue(cities.any { it.nameTr == "Erbil" && it.country == "Irak" })
        assertTrue(cities.any { it.nameTr == "Süleymaniye" && it.country == "Irak" })
        assertTrue(cities.any { it.nameTr == "Mekke-i Mükerreme" && it.country == "Suudi Arabistan" })

        // European diaspora hubs
        assertTrue(cities.any { it.nameTr == "Köln" && it.country == "Almanya" })
        assertTrue(cities.any { it.nameTr == "Frankfurt am Main" && it.country == "Almanya" })
        assertTrue(cities.any { it.nameTr == "Amsterdam" && it.country == "Hollanda" })
        assertTrue(cities.any { it.nameTr == "Londra" && it.country == "İngiltere" })
        assertTrue(cities.any { it.nameTr == "Paris" && it.country == "Fransa" })
    }

    @Test
    fun testPrayerTimesTimezoneCalculations() {
        val nyTimes = com.example.data.model.PrayerTimes(
            fajr = "05:00",
            sunrise = "06:30",
            dhuhr = "12:00",
            asr = "15:00",
            maghrib = "18:00",
            isha = "19:30",
            dateReadable = "06 November 2026",
            hijriDate = "1448",
            cityName = "New York",
            latitude = 40.7128,
            longitude = -74.0060,
            timezone = "America/New_York"
        )

        assertEquals("America/New_York", nyTimes.timezone)
        val fajrMillis = nyTimes.getPrayerMillis(PrayerType.FAJR, forTomorrowIfPassed = false)
        assertTrue("Fajr millis should be positive", fajrMillis > 0L)
    }

    @Test
    fun testDiyanetKurdishQuranTranslations() {
        val fatiha = BuiltinQuranData.DETAILS_MAP[1]
        assertNotNull(fatiha)
        assertEquals(7, fatiha?.size)
        assertEquals("Bi Navê Xwedayê Reḥman ê Reḥîm.", fatiha?.first()?.translationKuLatin)
        assertEquals("Rahmân ve rahîm olan Allah’ın adıyla", fatiha?.first()?.translationTr)

        val ikhlas = BuiltinQuranData.DETAILS_MAP[112]
        assertNotNull(ikhlas)
        assertEquals("Bibêje: Xwedê her yek e, tek e.", ikhlas?.first()?.translationKuLatin)

        val fil = BuiltinQuranData.DETAILS_MAP[105]
        assertNotNull(fil)
        assertTrue(fil?.first()?.translationKuLatin?.contains("Eshabu’l-Fîl") == true)

        for ((surahNum, ayahs) in BuiltinQuranData.DETAILS_MAP) {
            assertTrue("Surah $surahNum ayahs should not be empty", ayahs.isNotEmpty())
            for (ayah in ayahs) {
                assertTrue("Arabic text must be present", ayah.textArabic.isNotBlank())
                assertTrue("Turkish translation must be present", ayah.translationTr.isNotBlank())
                assertTrue("Kurdish Latin translation must be present", ayah.translationKuLatin.isNotBlank())
            }
        }
    }

    @Test
    fun test5IslamicAppThemes() {
        val themes = com.example.data.model.AppTheme.entries
        assertEquals("App must provide exactly 5 themes", 5, themes.size)

        val expectedIds = setOf(
            "emerald_gold",
            "midnight_blue",
            "kaaba_black_gold",
            "rose_burgundy",
            "seljuk_turquoise"
        )
        assertEquals(expectedIds, themes.map { it.id }.toSet())

        for (theme in themes) {
            assertTrue("Turkish title required", theme.titleTr.isNotBlank())
            assertTrue("Kurmanji title required", theme.titleKu.isNotBlank())
            assertTrue("Turkish subtitle required", theme.subtitleTr.isNotBlank())
            assertTrue("Kurmanji subtitle required", theme.subtitleKu.isNotBlank())
            assertNotNull("Primary color must exist", theme.primary)
            assertNotNull("Accent color must exist", theme.accent)
            assertNotNull("Background color must exist", theme.background)
        }
    }

    @Test
    fun testFridayDynamicDateAndFullSermon() {
        val trFriday = com.example.data.local.HutbeData.getCurrentFridayDate(AppLanguage.TURKISH)
        val kuFriday = com.example.data.local.HutbeData.getCurrentFridayDate(AppLanguage.KURMANJI)

        assertTrue("Turkish Friday date must contain Cuma", trFriday.startsWith("Cuma"))
        assertTrue("Kurmanji Friday date must contain Roja Înê", kuFriday.startsWith("Roja Înê"))

        val trHutbe = com.example.data.local.HutbeData.getCurrentWeekHutbe(AppLanguage.TURKISH)
        assertTrue("Sermon date should be dynamic", trHutbe.date.startsWith("Cuma"))
        assertTrue("Full sermon must contain multiple paragraphs", trHutbe.fullTextTr.split("\n\n").size >= 3)
        assertTrue("Kurmanji full sermon must contain multiple paragraphs", trHutbe.fullTextKu.split("\n\n").size >= 3)
    }

    @Test
    fun testPreAdhan30MinuteReminder() {
        val nyTimes = com.example.data.model.PrayerTimes(
            fajr = "05:00",
            sunrise = "06:30",
            dhuhr = "12:00",
            asr = "15:00",
            maghrib = "18:00",
            isha = "19:30",
            dateReadable = "07 November 2026",
            hijriDate = "1448",
            cityName = "İstanbul",
            latitude = 41.0082,
            longitude = 28.9784,
            timezone = "Europe/Istanbul"
        )

        val dhuhrMillis = nyTimes.getPrayerMillis(PrayerType.DHUHR, forTomorrowIfPassed = true)
        val preReminderMillis = nyTimes.getPreAdhanReminderMillis(PrayerType.DHUHR, minutesBefore = 30)

        assertTrue("Pre-reminder trigger time must be positive", preReminderMillis > 0L)

        // Verify pre-reminder localized notification messages
        val trTitle = AppStrings.preAdhanNotificationTitle("Öğle", AppLanguage.TURKISH)
        val trText = AppStrings.preAdhanNotificationContent("Öğle", "12:00", AppLanguage.TURKISH)
        assertTrue(trTitle.contains("Yaklaşıyor"))
        assertTrue(trTitle.contains("Ezana Az Kaldı"))
        assertTrue(trText.contains("30 dakika"))

        val kuTitle = AppStrings.preAdhanNotificationTitle("Nîvro", AppLanguage.KURMANJI)
        val kuText = AppStrings.preAdhanNotificationContent("Nîvro", "12:00", AppLanguage.KURMANJI)
        assertTrue(kuTitle.contains("Nêzîk Dibe"))
        assertTrue(kuText.contains("30 xulek"))
        assertEquals("prayer_reminder_30min_max_v3", com.example.notification.PrayerNotificationManager.CHANNEL_PRE_ADHAN_ID)
        assertEquals(3000L, com.example.service.AdhanPlayerService.PRE_ADHAN_ALERT_DURATION_MS)
    }

    @Test
    fun testMedinaMushaf604PagesStructure() {
        val pages = com.example.data.local.QuranPageMetadata.PAGES
        assertEquals(604, pages.size)

        // Sum of all verses across 604 pages must equal exactly 6236 verses
        val totalAyahs = pages.sumOf { it.ayahCount }
        assertEquals(6236, totalAyahs)

        // Page 1: Fatiha (7 ayahs)
        val page1 = com.example.data.local.QuranPageMetadata.getPage(1)
        assertEquals(1, page1.juz)
        assertEquals(1, page1.startSurah)
        assertEquals(1, page1.startAyah)
        assertEquals(1, page1.endSurah)
        assertEquals(7, page1.endAyah)
        assertEquals(7, page1.ayahCount)

        // Page 2: Baqarah 1..5 (5 ayahs)
        val page2 = com.example.data.local.QuranPageMetadata.getPage(2)
        assertEquals(1, page2.juz)
        assertEquals(2, page2.startSurah)
        assertEquals(1, page2.startAyah)
        assertEquals(2, page2.endSurah)
        assertEquals(5, page2.endAyah)
        assertEquals(5, page2.ayahCount)

        // Page 3: Baqarah 6..16 (11 ayahs)
        val page3 = com.example.data.local.QuranPageMetadata.getPage(3)
        assertEquals(1, page3.juz)
        assertEquals(2, page3.startSurah)
        assertEquals(6, page3.startAyah)
        assertEquals(2, page3.endSurah)
        assertEquals(16, page3.endAyah)
        assertEquals(11, page3.ayahCount)

        // Page 604: Ikhlas (4), Falaq (5), Nas (6) -> 15 ayahs
        val page604 = com.example.data.local.QuranPageMetadata.getPage(604)
        assertEquals(30, page604.juz)
        assertEquals(112, page604.startSurah)
        assertEquals(1, page604.startAyah)
        assertEquals(114, page604.endSurah)
        assertEquals(6, page604.endAyah)
        assertEquals(15, page604.ayahCount)

        // Verify Juz mapping across all 30 Juz
        assertEquals(1, com.example.data.local.QuranNavigationData.getJuzForPage(1))
        assertEquals(2, com.example.data.local.QuranNavigationData.getJuzForPage(22))
        assertEquals(3, com.example.data.local.QuranNavigationData.getJuzForPage(42))
        assertEquals(30, com.example.data.local.QuranNavigationData.getJuzForPage(582))
        assertEquals(30, com.example.data.local.QuranNavigationData.getJuzForPage(604))
    }

    @Test
    fun testKurdishNormalizationReplacesYezdan() {
        val repo = com.example.data.repository.QuranRepository()
        val text1 = "Bi navê Yezdanê Dilovan ê Dilovîn"
        val normalized1 = repo.normalizeDiyanetKurmanji(text1)
        assertFalse("Must not contain Yezdan", normalized1.contains("Yezdan", ignoreCase = true))
        assertTrue("Must contain Xwedayê Dilovan", normalized1.contains("Xwedayê Dilovan"))

        val text2 = "perestiya yezdan bikin"
        val normalized2 = repo.normalizeDiyanetKurmanji(text2)
        assertFalse("Must not contain yezdan", normalized2.contains("yezdan", ignoreCase = true))
        assertTrue("Must contain xwedê", normalized2.contains("xwedê", ignoreCase = true))

        val text3 = "Sûreya Îxlas: Bêje ku Ew Yezdan Yek e."
        val normalized3 = repo.normalizeDiyanetKurmanji(text3)
        assertFalse("Must not contain Yezdan", normalized3.contains("Yezdan", ignoreCase = true))
        assertTrue("Must contain Xwedê", normalized3.contains("Xwedê"))
    }

    @Test
    fun testExactPageAyahsMatchMedinaMushaf() {
        val repo = com.example.data.repository.QuranRepository()
        kotlinx.coroutines.runBlocking {
            val p1Detail = repo.getPageDetail(1)
            assertEquals(1, p1Detail.juzNumber)
            assertEquals(7, p1Detail.ayahs.size)

            val p2Detail = repo.getPageDetail(2)
            assertEquals(1, p2Detail.juzNumber)
            assertEquals(5, p2Detail.ayahs.size)

            val p604Detail = repo.getPageDetail(604)
            assertEquals(30, p604Detail.juzNumber)
            assertEquals(15, p604Detail.ayahs.size)
        }
    }

    @Test
    fun testAyahToPageMapping() {
        // Fatiha Ayah 1 -> Page 1
        assertEquals(1, com.example.data.local.QuranPageMetadata.getPageForVerse(1, 1))

        // Bakara Ayah 1 -> Page 2
        assertEquals(2, com.example.data.local.QuranPageMetadata.getPageForVerse(2, 1))

        // Bakara Ayah 255 (Ayet-el Kürsi) -> Page 42
        assertEquals(42, com.example.data.local.QuranPageMetadata.getPageForVerse(2, 255))

        // Yasin Ayah 1 -> Page 440
        assertEquals(440, com.example.data.local.QuranPageMetadata.getPageForVerse(36, 1))

        // Mulk Ayah 1 -> Page 562
        assertEquals(562, com.example.data.local.QuranPageMetadata.getPageForVerse(67, 1))

        // Ikhlas Ayah 1 -> Page 604
        assertEquals(604, com.example.data.local.QuranPageMetadata.getPageForVerse(112, 1))
    }

    @Test
    fun testQuranRtlLayoutStrings() {
        val tr = AppStrings.rtlMushafMode(AppLanguage.TURKISH)
        val ku = AppStrings.rtlMushafMode(AppLanguage.KURMANJI)
        assertTrue(tr.contains("Sağdan Sola"))
        assertTrue(ku.contains("Rast bo Çep"))

        val trHint = AppStrings.rtlSwipeHint(AppLanguage.TURKISH)
        val kuHint = AppStrings.rtlSwipeHint(AppLanguage.KURMANJI)
        assertTrue(trHint.contains("sağdan sola"))
        assertTrue(kuHint.contains("rastê ber bi çepê"))
    }

    @Test
    fun testElifba60PagesAndNavigation() {
        val pages = com.example.data.local.Elifba60Data.PAGES
        assertEquals(60, pages.size)

        val page1 = com.example.data.local.Elifba60Data.getPage(1)
        assertEquals(1, page1.pageNumber)
        assertTrue(page1.items.isNotEmpty())

        val page60 = com.example.data.local.Elifba60Data.getPage(60)
        assertEquals(60, page60.pageNumber)
        assertTrue(page60.items.isNotEmpty())
    }

    @Test
    fun testElifbaAudioPronunciationUnderLetters() {
        // Page 1: Isolated letters -> vocalized classical Arabic letter names
        val p1Items = com.example.data.local.Elifba60Data.getPage(1).items
        assertEquals("أَلِفْ", com.example.ui.viewmodel.ElifbaViewModel.formatSpeechText(p1Items[0])) // ا
        assertEquals("بَاءْ", com.example.ui.viewmodel.ElifbaViewModel.formatSpeechText(p1Items[1])) // ب
        assertEquals("تَاءْ", com.example.ui.viewmodel.ElifbaViewModel.formatSpeechText(p1Items[2])) // ت
        assertEquals("ثَاءْ", com.example.ui.viewmodel.ElifbaViewModel.formatSpeechText(p1Items[3])) // ث

        // Verify all 28 isolated Arabic letters from Lesson 1 produce vocalized Arabic names
        val lesson1Items = com.example.data.local.DiyanetElifbaData.lessons[0].items
        assertEquals(28, lesson1Items.size)
        val expectedNames = listOf(
            "أَلِفْ", "بَاءْ", "تَاءْ", "ثَاءْ", "جِيمْ", "حَاءْ", "خَاءْ",
            "دَالْ", "ذَالْ", "رَاءْ", "زَايْ", "سِينْ", "شِينْ", "صَادْ",
            "ضَادْ", "طَاءْ", "ظَاءْ", "عَيْنْ", "غَيْنْ", "فَاءْ", "قَافْ",
            "كَافْ", "لَامْ", "مِيمْ", "نُونْ", "وَاوْ", "هَاءْ", "يَاءْ"
        )
        lesson1Items.forEachIndexed { idx, item ->
            val payload = com.example.ui.viewmodel.ElifbaViewModel.getSpeechPayload(item, arabicAvailable = true)
            assertTrue("Letter ${item.arabicText} must use Arabic TTS", payload.useArabic)
            assertEquals("Letter ${item.arabicText} mismatch", expectedNames[idx], payload.textToSpeak)
        }

        // Joining forms (tatweel stripped) -> vocalized Arabic letter name(s)
        assertEquals("بَاءْ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("بـ ـبـ ـب"))
        assertEquals(
            "أَلِفْ، دَالْ، ذَالْ، رَاءْ، زَايْ، وَاوْ",
            com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("ا د ذ ر ز و")
        )

        // Harakat, Hamzatul-Qat & Quranic dagger-alif normalization -> 1-to-1 authentic Arabic
        assertEquals("أَ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اَ"))
        assertEquals("إِ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اِ"))
        assertEquals("أُ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اُ"))
        assertEquals("أَبْ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اَبْ"))
        assertEquals("إِنَّ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اِنَّ"))
        assertEquals("كَتَبَ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("كَتَبَ"))
        assertEquals("الصَّلَاةُ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("الصَّلٰوةُ"))
        assertEquals("اَلْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("اَلْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِينَ"))
        assertEquals("بِسْمِ اللَّهِ الرَّحْمَانِ الرَّحِيمِ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ"))

        // Exhaustively verify all 60 pages and all 7 lessons produce clean non-blank Arabic speech
        val allItems = com.example.data.local.Elifba60Data.PAGES.flatMap { it.items } +
            com.example.data.local.DiyanetElifbaData.lessons.flatMap { it.items }
        for (item in allItems) {
            val payload = com.example.ui.viewmodel.ElifbaViewModel.getSpeechPayload(item, arabicAvailable = true)
            assertTrue("Item ${item.id} must use Arabic TTS", payload.useArabic)
            assertTrue("Item ${item.id} must have non-blank speech", payload.textToSpeak.isNotBlank())
            assertFalse("Item ${item.id} must strip tatweel", payload.textToSpeak.contains('\u0640'))
            assertFalse("Item ${item.id} must normalize dagger alif", payload.textToSpeak.contains('\u0670'))
            assertTrue("Item ${item.id} must have Turkish Latin pronunciation", item.getPronunciation(AppLanguage.TURKISH).isNotBlank())
            assertTrue("Item ${item.id} must have Kurmanji Latin pronunciation", item.getPronunciation(AppLanguage.KURMANJI).isNotBlank())
        }

        // Verify default Elifba reading and page-flipping direction is Right-to-Left (Sağdan Sola)
        assertTrue(com.example.ui.viewmodel.ElifbaUiState().isRtlMode)
    }

    @Test
    fun testQuranKurdishAssetIntegrityAndZeroYezdan() {
        val repo = com.example.data.repository.QuranRepository()

        // 1. Test normalization eliminates all Yezdan/Yezden forms
        val raw1 = "Bi navê Yezdanê Dilovan"
        val normalized1 = repo.normalizeDiyanetKurmanji(raw1)
        assertEquals("Bi navê Xwedayê Dilovan", normalized1)
        assertFalse(normalized1.contains("yezdan", ignoreCase = true))

        val raw2 = "ji bona Yezden ra"
        val normalized2 = repo.normalizeDiyanetKurmanji(raw2)
        assertEquals("ji bona Xwedê ra", normalized2)
        assertFalse(normalized2.contains("yezd", ignoreCase = true))

        // 2. Read and verify official Diyanet Kurdish & Turkish assets directly from disk
        val kuAssetFile = java.io.File("app/src/main/assets/quran_ku_latin.json")
        val trAssetFile = java.io.File("app/src/main/assets/quran_tr_diyanet.json")
        val arAssetFile = java.io.File("app/src/main/assets/quran_ar.json")
        if (kuAssetFile.exists() && trAssetFile.exists() && arAssetFile.exists()) {
            val kuJson = org.json.JSONObject(kuAssetFile.readText(Charsets.UTF_8))
            val trJson = org.json.JSONObject(trAssetFile.readText(Charsets.UTF_8))
            val arJson = org.json.JSONObject(arAssetFile.readText(Charsets.UTF_8))

            // Must contain all 6,236 ayahs verbatim from Diyanet
            assertEquals("Kurdish Quran asset must have all 6236 ayahs", 6236, kuJson.length())
            assertEquals("Turkish Quran asset must have all 6236 ayahs", 6236, trJson.length())
            assertEquals("Arabic Quran asset must have all 6236 ayahs", 6236, arJson.length())

            // Must contain key verses verbatim from Diyanet
            assertEquals("Bi Navê Xwedayê Reḥman ê Reḥîm.", kuJson.getString("1:1"))
            assertEquals("Rahmân ve rahîm olan Allah’ın adıyla", trJson.getString("1:1"))
            assertEquals("Bibêje: Xwedê her yek e, tek e.", kuJson.getString("112:1"))
            assertTrue(kuJson.has("2:255"))
            assertTrue(kuJson.has("114:6"))

            // Check zero HTML tags, zero [1] footnote markers, zero Yezdan, and exact 114 surah / 6236 ayah alignment
            var yezdanCount = 0
            val expectedKeys = LinkedHashSet<String>(6236)
            for (surah in BuiltinQuranData.SURAH_LIST) {
                for (v in 1..surah.versesCount) {
                    expectedKeys.add("${surah.number}:$v")
                }
            }
            assertEquals("Expected 6236 canonical ayah keys", 6236, expectedKeys.size)

            val pageMappedKeys = LinkedHashSet<String>(6236)
            for (p in 1..604) {
                for (ref in com.example.data.local.QuranPageMetadata.getVersesForPage(p)) {
                    pageMappedKeys.add("${ref.surah}:${ref.ayah}")
                }
            }
            assertEquals("604 Mushaf pages must cover all 6236 ayahs uniquely", expectedKeys, pageMappedKeys)

            for (k in expectedKeys) {
                assertTrue("AR missing $k", arJson.has(k))
                assertTrue("TR missing $k", trJson.has(k))
                assertTrue("KU missing $k", kuJson.has(k))

                val arText = arJson.getString(k)
                val kuText = kuJson.getString(k)
                val trText = trJson.getString(k)
                assertTrue("AR verse $k must be non-blank", arText.isNotBlank())
                assertTrue("KU verse $k must be non-blank", kuText.isNotBlank())
                assertTrue("TR verse $k must be non-blank", trText.isNotBlank())
                assertFalse("AR verse $k must not contain replacement char", arText.contains("\uFFFD"))
                assertFalse("KU verse $k must not contain replacement char", kuText.contains("\uFFFD"))
                assertFalse("TR verse $k must not contain replacement char", trText.contains("\uFFFD"))
                assertFalse("AR verse $k must not contain soft hyphen", arText.contains("\u00AD"))
                assertFalse("KU verse $k must not contain soft hyphen", kuText.contains("\u00AD"))
                assertFalse("TR verse $k must not contain soft hyphen", trText.contains("\u00AD"))
                assertFalse("KU verse $k must not contain HTML tags", kuText.contains("<") || kuText.contains(">"))
                assertFalse("TR verse $k must not contain HTML tags", trText.contains("<") || trText.contains(">"))
                assertFalse("KU verse $k must not contain footnote markers", Regex("\\[\\d+\\]").containsMatchIn(kuText))
                assertFalse("TR verse $k must not contain footnote markers", Regex("\\[\\d+\\]").containsMatchIn(trText))
                assertFalse("KU verse $k must not contain Diyanet label", kuText.contains("diyanet", ignoreCase = true))
                assertFalse("TR verse $k must not contain Diyanet label", trText.contains("diyanet", ignoreCase = true))
                assertFalse("KU verse $k must not start with stray verse number", Regex("^\\d+[\\.\\-\\s]+").containsMatchIn(kuText.trim()))
                if (kuText.contains("yezd", ignoreCase = true)) {
                    yezdanCount++
                }
            }
            assertEquals("There must be zero occurrences of Yezdan across all 6,236 ayahs", 0, yezdanCount)
        }
    }

    @Test
    fun testFullOfflineQuranAssetsAndAudioMirrors() {
        // Verify all 3 language Quran assets exist with 6236 ayahs when running locally
        val arFile = java.io.File("app/src/main/assets/quran_ar.json")
        val trFile = java.io.File("app/src/main/assets/quran_tr_diyanet.json")
        val kuFile = java.io.File("app/src/main/assets/quran_ku_latin.json")
        if (arFile.exists() && trFile.exists() && kuFile.exists()) {
            val arJson = org.json.JSONObject(arFile.readText(Charsets.UTF_8))
            val trJson = org.json.JSONObject(trFile.readText(Charsets.UTF_8))
            val kuJson = org.json.JSONObject(kuFile.readText(Charsets.UTF_8))
            assertEquals(6236, arJson.length())
            assertEquals(6236, trJson.length())
            assertEquals(6236, kuJson.length())
        }

        // Verify multi-mirror URLs for all 5 reciters across Surahs 1..114
        for (reciter in com.example.data.model.QuranReciter.entries) {
            val urls1 = reciter.getSurahAudioUrls(1)
            val urls114 = reciter.getSurahAudioUrls(114)
            assertEquals(2, urls1.size)
            assertTrue(urls1[0].endsWith("001.mp3"))
            assertTrue(urls114[0].endsWith("114.mp3"))
            assertTrue(urls1[1].contains("cdn.islamic.network"))
        }

        // Verify OfflineDownloadState progress and storage size formatting
        val dlState = com.example.data.local.OfflineDownloadState(
            isDownloading = true,
            completedCount = 57,
            totalCount = 114,
            currentSurahProgress = 0.0f
        )
        assertEquals(0.5f, dlState.overallProgress, 0.001f)
        assertEquals("0 MB", com.example.data.local.QuranOfflineAudioManager.formatStorageSize(0L))
        assertTrue(com.example.data.local.QuranOfflineAudioManager.formatStorageSize(5 * 1024 * 1024L).contains("5.0"))
    }

    @Test
    fun testQiblaTrueNorthDeclinationMath() {
        // Istanbul (~41.0082, 28.9784) Qibla azimuth is roughly ~151.6 deg (SSE)
        val istanbulAzimuth = com.example.sensor.QiblaSensorManager.calculateQiblaAzimuth(41.0082, 28.9784)
        assertTrue("Istanbul Qibla azimuth must be in 145..160 range", istanbulAzimuth in 145f..160f)

        // Diyarbakir (~37.9144, 40.2306) Qibla azimuth is roughly ~181.5 deg (almost due South)
        val diyarbakirAzimuth = com.example.sensor.QiblaSensorManager.calculateQiblaAzimuth(37.9144, 40.2306)
        assertTrue("Diyarbakir Qibla azimuth must be in 175..188 range", diyarbakirAzimuth in 175f..188f)

        // Distance from Istanbul to Kaaba is roughly ~2398 km
        val distIstanbul = com.example.sensor.QiblaSensorManager.calculateDistanceToKaaba(41.0082, 28.9784)
        assertTrue("Istanbul distance to Kaaba must be ~2300-2500 km", distIstanbul in 2300.0..2500.0)

        // Magnetic to True North wraparound math
        assertEquals(2f, com.example.sensor.QiblaSensorManager.magneticToTrueNorth(356f, 6f), 0.01f)
        assertEquals(357f, com.example.sensor.QiblaSensorManager.magneticToTrueNorth(2f, -5f), 0.01f)
    }

    @Test
    fun testWeatherModelsAndWorldDistricts() {
        // 1. WMO weather code classification (day vs night)
        assertEquals(
            com.example.data.model.WeatherConditionType.CLEAR_DAY,
            com.example.data.model.WeatherInfo.classifyWmoCode(0, isDay = true)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.CLEAR_NIGHT,
            com.example.data.model.WeatherInfo.classifyWmoCode(0, isDay = false)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.PARTLY_CLOUDY,
            com.example.data.model.WeatherInfo.classifyWmoCode(2, isDay = true)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.FOG,
            com.example.data.model.WeatherInfo.classifyWmoCode(45, isDay = true)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.RAIN,
            com.example.data.model.WeatherInfo.classifyWmoCode(63, isDay = true)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.SNOW,
            com.example.data.model.WeatherInfo.classifyWmoCode(73, isDay = false)
        )
        assertEquals(
            com.example.data.model.WeatherConditionType.THUNDERSTORM,
            com.example.data.model.WeatherInfo.classifyWmoCode(95, isDay = true)
        )

        // 2. Bilingual TR/KU condition descriptions
        assertEquals(
            "Açık ve Güneşli",
            com.example.data.model.WeatherInfo.describeWmoCode(0, isDay = true, com.example.data.model.AppLanguage.TURKISH)
        )
        assertEquals(
            "Sayan û Tavî",
            com.example.data.model.WeatherInfo.describeWmoCode(0, isDay = true, com.example.data.model.AppLanguage.KURMANJI)
        )
        assertEquals(
            "Baran",
            com.example.data.model.WeatherInfo.describeWmoCode(61, isDay = true, com.example.data.model.AppLanguage.KURMANJI)
        )

        // 3. Offline WorldDistrictsData verification
        val diyarbakirDistricts = com.example.data.local.WorldDistrictsData.getDistrictsForCity("diyarbakir")
        assertEquals(17, diyarbakirDistricts.size)
        val silvan = diyarbakirDistricts.find { it.id == "diyarbakir_silvan" }
        assertNotNull(silvan)
        assertTrue(silvan!!.isDistrict)
        assertEquals("Diyarbakır", silvan.provinceTr)
        assertEquals("Silvan, Diyarbakır", silvan.getDisplayName(com.example.data.model.AppLanguage.TURKISH))
        assertEquals("Farqîn, Amed", silvan.getDisplayName(com.example.data.model.AppLanguage.KURMANJI))

        val istanbulDistricts = com.example.data.local.WorldDistrictsData.getDistrictsForCity("istanbul")
        assertTrue(istanbulDistricts.any { it.nameTr.contains("Kadıköy") })
        val berlinDistricts = com.example.data.local.WorldDistrictsData.getDistrictsForCity("berlin")
        assertTrue(berlinDistricts.any { it.nameTr.contains("Kreuzberg") })
        val nyDistricts = com.example.data.local.WorldDistrictsData.getDistrictsForCity("newyork")
        assertTrue(nyDistricts.any { it.nameTr.contains("Brooklyn") })

        // 4. City GPS resolved vs unresolved display names
        assertEquals(
            "GPS (Otomatik Konum)",
            com.example.data.model.City.GPS.getDisplayName(com.example.data.model.AppLanguage.TURKISH)
        )
        val resolvedGps = com.example.data.model.City.GPS.copy(
            nameTr = "Kayapınar, Diyarbakır",
            nameKu = "Kayapınar, Diyarbakır",
            provinceTr = "Diyarbakır",
            isDistrict = true
        )
        assertEquals(
            "Kayapınar, Diyarbakır",
            resolvedGps.getDisplayName(com.example.data.model.AppLanguage.TURKISH)
        )

        // 5. 7-day DailyForecastDay model and localized day/date helpers
        val day0 = com.example.data.model.DailyForecastDay(
            dateIso = "2026-11-14", // Saturday
            weatherCode = 61,
            minTempC = 7.2,
            maxTempC = 14.8,
            precipitationChancePercent = 70
        )
        assertEquals(com.example.data.model.WeatherConditionType.RAIN, day0.conditionType)
        assertEquals("Yağmurlu", day0.getConditionLabel(com.example.data.model.AppLanguage.TURKISH))
        assertEquals("Baran", day0.getConditionLabel(com.example.data.model.AppLanguage.KURMANJI))

        assertEquals(
            "Bugün",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-14", 0, com.example.data.model.AppLanguage.TURKISH)
        )
        assertEquals(
            "Îro",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-14", 0, com.example.data.model.AppLanguage.KURMANJI)
        )
        assertEquals(
            "Yarın",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-15", 1, com.example.data.model.AppLanguage.TURKISH)
        )
        assertEquals(
            "Sibê",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-15", 1, com.example.data.model.AppLanguage.KURMANJI)
        )
        assertEquals(
            "Pzt",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-16", 2, com.example.data.model.AppLanguage.TURKISH)
        )
        assertEquals(
            "Duş",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-16", 2, com.example.data.model.AppLanguage.KURMANJI)
        )
        assertEquals(
            "14 Kas",
            com.example.data.model.WeatherInfo.formatShortDate("2026-11-14", com.example.data.model.AppLanguage.TURKISH)
        )
        assertEquals(
            "14 Mij",
            com.example.data.model.WeatherInfo.formatShortDate("2026-11-14", com.example.data.model.AppLanguage.KURMANJI)
        )
    }

    @Test
    fun testAppThemesDynamicPalettes() {
        val themes = com.example.data.model.AppTheme.entries
        assertEquals(5, themes.size)
        assertEquals(5, themes.map { it.id }.toSet().size)
        assertEquals(5, themes.map { it.background }.toSet().size)
        assertEquals(5, themes.map { it.primary }.toSet().size)
        assertEquals(5, themes.map { it.accent }.toSet().size)

        themes.forEach { theme ->
            assertTrue(theme.getDisplayName(AppLanguage.TURKISH).isNotBlank())
            assertTrue(theme.getDisplayName(AppLanguage.KURMANJI).isNotBlank())
            assertTrue(theme.getDisplaySubtitle(AppLanguage.TURKISH).isNotBlank())
            assertTrue(theme.getDisplaySubtitle(AppLanguage.KURMANJI).isNotBlank())

            assertTrue(theme.deepTint.alpha == 1f)
            assertTrue(theme.darkTint.alpha == 1f)
            assertTrue(theme.lightTint.alpha == 1f)
            assertTrue(theme.containerTint.alpha == 1f)
            assertTrue(theme.strongBorder.alpha == 1f)
            assertTrue(theme.accentWarm.alpha == 1f)
            assertTrue(theme.accentDark.alpha == 1f)
            assertTrue(theme.accentContainer.alpha == 1f)
            assertTrue(theme.accentMuted.alpha == 1f)
            assertTrue(theme.translationPrimary.alpha == 1f)
            assertTrue(theme.translationSecondary.alpha == 1f)
        }
    }

    @Test
    fun testWordDocxAndOle2Extractor() {
        // 1. Test OOXML .docx extraction with Turkish UTF-8 text and footnotes
        val docXml = """<?xml version="1.0" encoding="UTF-8"?>
            <w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:body>
                <w:p><w:r><w:t>Tarih: 13.11.2026</w:t></w:r></w:p>
                <w:p><w:r><w:t>DİJİTAL MECRADA AHLAK</w:t></w:r></w:p>
                <w:p><w:r><w:t>Muhterem Müslümanlar!</w:t></w:r></w:p>
                <w:p><w:r><w:t>İyi söz gönül alır</w:t></w:r><w:r><w:footnoteReference w:id="1"/></w:r><w:r><w:t>.</w:t></w:r></w:p>
              </w:body>
            </w:document>""".trimIndent().toByteArray(Charsets.UTF_8)
        val footnotesXml = """<?xml version="1.0" encoding="UTF-8"?>
            <w:footnotes xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
              <w:footnote w:id="1"><w:p><w:r><w:t>Ebû Dâvûd, Edeb, 80.</w:t></w:r></w:p></w:footnote>
            </w:footnotes>""".trimIndent().toByteArray(Charsets.UTF_8)

        val samplePngHeader = ByteArray(3100).apply {
            this[0] = 0x89.toByte(); this[1] = 0x50; this[2] = 0x4E; this[3] = 0x47
            this[4] = 0x0D; this[5] = 0x0A; this[6] = 0x1A; this[7] = 0x0A
            // Width 800, Height 420 big-endian in PNG IHDR (offsets 16..23)
            this[16] = 0x00; this[17] = 0x00; this[18] = 0x03; this[19] = 0x20
            this[20] = 0x00; this[21] = 0x00; this[22] = 0x01; this[23] = 0xA4.toByte()
        }

        val baos = java.io.ByteArrayOutputStream()
        java.util.zip.ZipOutputStream(baos).use { zos ->
            zos.putNextEntry(java.util.zip.ZipEntry("word/document.xml"))
            zos.write(docXml)
            zos.closeEntry()
            zos.putNextEntry(java.util.zip.ZipEntry("word/footnotes.xml"))
            zos.write(footnotesXml)
            zos.closeEntry()
            zos.putNextEntry(java.util.zip.ZipEntry("word/media/image1.png"))
            zos.write(samplePngHeader)
            zos.closeEntry()
        }
        val extractedDocx = com.example.util.WordDocTextExtractor.extract(baos.toByteArray())
        assertNotNull(extractedDocx)
        assertEquals("13.11.2026", extractedDocx!!.dateDisplay)
        assertEquals("DİJİTAL MECRADA AHLAK", extractedDocx.title)
        assertEquals(2, extractedDocx.paragraphs.size)
        assertTrue(extractedDocx.fullBodyText.contains("İyi söz gönül alır[1]."))
        assertTrue(extractedDocx.footnotes.contains("Ebû Dâvûd, Edeb, 80."))
        assertNotNull("DOCX embedded Arabic header banner must be extracted", extractedDocx.headerImageBytes)
        assertEquals(3100, extractedDocx.headerImageBytes!!.size)

        // 2. Test Word 97-2003 OLE2 .doc binary extraction (UTF-16LE + endnotes)
        val oleBytes = buildMinimalOle2WordDoc(
            bodyText = "Tarih: 06.11.2026\r\u0001\rİBADET\rMuhterem Müslümanlar!\rŞükür ve dua edelim.\u0002\r",
            endnoteText = "\u0002 Ebû Dâvûd, Tatavvu’, 12.\rDin Hizmetleri Genel Müdürlüğü\r",
            useCompressedWindows1254 = false
        )
        val extractedOle = com.example.util.WordDocTextExtractor.extract(oleBytes)
        assertNotNull("OLE2 .doc must parse cleanly", extractedOle)
        assertEquals("06.11.2026", extractedOle!!.dateDisplay)
        assertEquals("İBADET", extractedOle.title)
        assertTrue(extractedOle.fullBodyText.contains("Muhterem Müslümanlar!"))
        assertTrue(extractedOle.fullBodyText.contains("Şükür ve dua edelim. [1]"))
        assertTrue(extractedOle.footnotes.contains("[1]"))
        assertTrue(extractedOle.footnotes.contains("Din Hizmetleri Genel Müdürlüğü"))

        // 3. Test OLE2 .doc compressed windows-1254 piece table (Turkish characters)
        val compressedOle = buildMinimalOle2WordDoc(
            bodyText = "Tarih: 13.11.2026\rDİJİTAL MECRADA AHLAK\rGüzel ahlak, doğruluk ve şefkat önemlidir.\r",
            endnoteText = "\u0002 İsrâ, 17/36.\rDin Hizmetleri Genel Müdürlüğü\r",
            useCompressedWindows1254 = true
        )
        val extractedCompressed = com.example.util.WordDocTextExtractor.extract(compressedOle)
        assertNotNull("Compressed windows-1254 OLE2 .doc must parse cleanly", extractedCompressed)
        assertEquals("13.11.2026", extractedCompressed!!.dateDisplay)
        assertEquals("DİJİTAL MECRADA AHLAK", extractedCompressed.title)
        assertTrue(extractedCompressed.fullBodyText.contains("Güzel ahlak, doğruluk ve şefkat önemlidir."))
    }

    private fun buildMinimalOle2WordDoc(
        bodyText: String,
        endnoteText: String,
        useCompressedWindows1254: Boolean = false
    ): ByteArray {
        val sectorSize = 512
        val combinedText = bodyText + endnoteText
        val cpCount = combinedText.length
        val cp1254 = java.nio.charset.Charset.forName("windows-1254")
        val encodedTextBytes = if (useCompressedWindows1254) {
            combinedText.toByteArray(cp1254)
        } else {
            combinedText.toByteArray(Charsets.UTF_16LE)
        }

        // Build WordDocument stream (>= 4096 bytes so stored in FAT directly)
        val fibSize = 512
        val textOffset = fibSize
        val wordDocTotal = ((textOffset + encodedTextBytes.size + 4095) / 4096) * 4096
        val wordDoc = ByteArray(wordDocTotal)
        val wdBuf = java.nio.ByteBuffer.wrap(wordDoc).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        wdBuf.putShort(0x0A, 0x0200.toShort()) // bit 0x0200 -> 1Table
        wdBuf.putInt(0x4C, bodyText.length)    // ccpText
        wdBuf.putInt(0x60, endnoteText.length) // ccpEdn

        // Build PlcPcd clx inside 1Table: [0x02][lcbPcd:4][cp0=0, cp1=cpCount][8-byte PCD]
        val plcPcd = java.nio.ByteBuffer.allocate(4 + 4 + 8).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        plcPcd.putInt(0)
        plcPcd.putInt(cpCount)
        plcPcd.putShort(0) // PCD flags
        val fcRaw = if (useCompressedWindows1254) {
            (textOffset * 2) or 0x40000000
        } else {
            textOffset
        }
        plcPcd.putInt(fcRaw)
        plcPcd.putShort(0)
        val clx = ByteArray(5 + plcPcd.capacity())
        val clxBuf = java.nio.ByteBuffer.wrap(clx).order(java.nio.ByteOrder.LITTLE_ENDIAN)
        clxBuf.put(0, 2.toByte())
        clxBuf.putInt(1, plcPcd.capacity())
        System.arraycopy(plcPcd.array(), 0, clx, 5, plcPcd.capacity())

        wdBuf.putInt(0x01A2, 0)         // fcClx
        wdBuf.putInt(0x01A6, clx.size)  // lcbClx
        System.arraycopy(encodedTextBytes, 0, wordDoc, textOffset, encodedTextBytes.size)

        val tableStream = ByteArray(((clx.size + 4095) / 4096) * 4096)
        System.arraycopy(clx, 0, tableStream, 0, clx.size)

        val wdSectors = wordDoc.size / sectorSize
        val tblSectors = tableStream.size / sectorSize
        val fatSector = 0
        val dirSector = 1
        val wdStart = 2
        val tblStart = wdStart + wdSectors
        val totalSectors = tblStart + tblSectors

        val totalBytes = 512 + totalSectors * sectorSize
        val ole = ByteArray(totalBytes)
        byteArrayOf(
            0xD0.toByte(), 0xCF.toByte(), 0x11.toByte(), 0xE0.toByte(),
            0xA1.toByte(), 0xB1.toByte(), 0x1A.toByte(), 0xE1.toByte()
        ).copyInto(ole, 0)
        val hdr = java.nio.ByteBuffer.wrap(ole, 0, 512).slice().order(java.nio.ByteOrder.LITTLE_ENDIAN)
        hdr.putShort(0x1E, 9) // 512-byte sectors
        hdr.putShort(0x20, 6) // 64-byte mini sectors
        hdr.putInt(0x2C, 1)   // numFatSectors
        hdr.putInt(0x30, dirSector)
        hdr.putInt(0x38, 4096) // miniSectorCutoff
        hdr.putInt(0x3C, 0xFFFFFFFE.toInt()) // firstMiniFat
        hdr.putInt(0x40, 0)
        hdr.putInt(0x44, 0xFFFFFFFE.toInt()) // firstDifat
        hdr.putInt(0x48, 0)
        hdr.putInt(0x4C, fatSector)
        for (i in 1 until 109) hdr.putInt(0x4C + i * 4, 0xFFFFFFFF.toInt())

        // Write FAT
        val fatBuf = java.nio.ByteBuffer.wrap(ole, 512 + fatSector * sectorSize, sectorSize)
            .slice()
            .order(java.nio.ByteOrder.LITTLE_ENDIAN)
        for (i in 0 until 128) fatBuf.putInt(i * 4, 0xFFFFFFFF.toInt())
        fatBuf.putInt(fatSector * 4, 0xFFFFFFFD.toInt()) // FATSECT
        fatBuf.putInt(dirSector * 4, 0xFFFFFFFE.toInt()) // ENDOFCHAIN
        for (i in 0 until wdSectors) {
            val s = wdStart + i
            fatBuf.putInt(s * 4, if (i + 1 < wdSectors) s + 1 else 0xFFFFFFFE.toInt())
        }
        for (i in 0 until tblSectors) {
            val s = tblStart + i
            fatBuf.putInt(s * 4, if (i + 1 < tblSectors) s + 1 else 0xFFFFFFFE.toInt())
        }

        // Write Directory Entries (Root Entry, WordDocument, 1Table)
        fun writeDirEntry(slot: Int, name: String, objType: Int, startSec: Int, size: Int) {
            val off = 512 + dirSector * sectorSize + slot * 128
            val nameBytes = (name + "\u0000").toByteArray(Charsets.UTF_16LE)
            System.arraycopy(nameBytes, 0, ole, off, nameBytes.size)
            val dBuf = java.nio.ByteBuffer.wrap(ole, off, 128).slice().order(java.nio.ByteOrder.LITTLE_ENDIAN)
            dBuf.putShort(0x40, nameBytes.size.toShort())
            ole[off + 0x42] = objType.toByte()
            dBuf.putInt(0x74, startSec)
            dBuf.putInt(0x78, size)
        }
        writeDirEntry(0, "Root Entry", 5, 0xFFFFFFFE.toInt(), 0)
        writeDirEntry(1, "WordDocument", 2, wdStart, wordDoc.size)
        writeDirEntry(2, "1Table", 2, tblStart, tableStream.size)

        // Write streams
        System.arraycopy(wordDoc, 0, ole, 512 + wdStart * sectorSize, wordDoc.size)
        System.arraycopy(tableStream, 0, ole, 512 + tblStart * sectorSize, tableStream.size)
        return ole
    }

    @Test
    fun testDiyanetHutbeRepositoryParsingAndFridaySchedule() {
        val sampleHomeHtml = """
            <a href="https://dinhizmetleri.diyanet.gov.tr/Detay/1344/dhys-toplantisi">Haber</a>
            <a href="https://dinhizmetleri.diyanet.gov.tr/Detay/1337/06112026-cuma-hutbesi-ibadet">Eski</a>
            <a href="https://dinhizmetleri.diyanet.gov.tr/Detay/1342/13112026-cuma-hutbesi-dijital-mecrada-ahlak-(sesli-hutbe-t&#252;rk&#231;e-ingilizce-arap&#231;a)">Yeni</a>
        """.trimIndent()
        val links = com.example.data.repository.DiyanetHutbeRepository.parseHutbeLinksFromHtml(sampleHomeHtml)
        assertEquals(2, links.size)
        assertEquals(1342, links[0].detayId)
        assertEquals("2026-11-13", links[0].dateIso)
        assertEquals(1337, links[1].detayId)
        assertEquals("2026-11-06", links[1].dateIso)

        val sampleDetailHtml = """
            <h1>13.11.2026 Cuma Hutbesi: Dijital Mecrada Ahlak</h1>
            <ul class="document-ul-list">
              <li><a href="/Documents/Sesli Hutbe (Dijital Mecrada Ahlak).mp3">Sesli</a></li>
              <li><a href="/Documents/Dijital Mecrada Ahlak.pdf">PDF</a></li>
              <li><a href="/Documents/Dijital Mecrada Ahlak.doc">Word</a></li>
              <li><a href="/Documents/الْأَخْلَاقُ فِي الْفَضَاءِ الرَّقْمِيِّ.doc">Arapça</a></li>
            </ul>
            <footer class="footer"><a href="/Documents/Rapor.pdf">Rapor</a></footer>
        """.trimIndent()
        val docs = com.example.data.repository.DiyanetHutbeRepository.parseDocumentLinksFromDetailHtml(sampleDetailHtml)
        assertEquals(
            "https://dinhizmetleri.diyanet.gov.tr/Documents/Dijital Mecrada Ahlak.doc",
            docs.turkishDocUrl
        )
        assertTrue(docs.arabicDocUrl!!.endsWith(".doc"))
        assertEquals(
            "https://dinhizmetleri.diyanet.gov.tr/Documents/Sesli Hutbe (Dijital Mecrada Ahlak).mp3",
            docs.audioUrl
        )

        val encoded = com.example.data.repository.DiyanetHutbeRepository.encodeDiyanetUrl(
            "https://dinhizmetleri.diyanet.gov.tr/Documents/Sesli Hutbe (İbadet).mp3"
        )
        assertNotNull(encoded)
        assertFalse(encoded!!.contains(" "))
        assertTrue(encoded.contains("%20"))

        // Friday check: Saturday 2026-11-14 UTC+3 -> most recent Friday must be 2026-11-13
        val calSat = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Istanbul")).apply {
            set(2026, java.util.Calendar.NOVEMBER, 14, 10, 0, 0)
        }
        assertEquals(
            "2026-11-13",
            com.example.data.repository.DiyanetHutbeRepository.computeMostRecentFridayIso(calSat.timeInMillis)
        )
        // Friday itself -> returns same Friday
        val calFri = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Istanbul")).apply {
            set(2026, java.util.Calendar.NOVEMBER, 20, 9, 30, 0)
        }
        assertEquals(
            "2026-11-20",
            com.example.data.repository.DiyanetHutbeRepository.computeMostRecentFridayIso(calFri.timeInMillis)
        )
    }

    @Test
    fun testDiyanetOfficialFallbackIntegrity() {
        val arabicIntro = com.example.data.local.HutbeData.DIYANET_ARABIC_HUTBE_INTRO
        assertTrue(arabicIntro.contains("اَلْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِينَ"))
        assertTrue(arabicIntro.contains("أَمَّا بَعْدُ"))
        assertTrue(com.example.data.local.HutbeData.DIYANET_ARABIC_BESMELE.contains("بِسْمِ اللّٰهِ"))

        val list = com.example.data.local.HutbeData.HUTBE_LIST
        assertTrue(list.size >= 5)
        val distinctHeaders = list.map { it.arabicVerseOrHadith }.toSet()
        assertEquals("Each weekly Hutbe must have its own distinct Arabic Ayah & Hadith header", list.size, distinctHeaders.size)

        val headersDir = java.io.File("app/src/main/assets/hutbe_headers")
        for (h in list) {
            assertTrue("Source must be official Diyanet", h.source.contains("dinhizmetleri.diyanet.gov.tr"))
            assertTrue("Official URL must point to diyanet.gov.tr", h.officialUrl.startsWith("https://dinhizmetleri.diyanet.gov.tr/Detay/"))
            assertTrue("ISO date required", h.dateIso.matches(Regex("\\d{4}-\\d{2}-\\d{2}")))
            assertTrue("Full Diyanet Turkish sermon required", h.fullTextTr.length > 1000)
            assertTrue("Arabic official Diyanet text required", h.arabicFullText.length > 500)
            assertFalse("No stray control chars allowed", h.fullTextTr.any { it.code < 32 && it != '\n' })

            assertTrue("Per-Hutbe Arabic header must start with Besmele", h.arabicVerseOrHadith.startsWith("بِسْمِ اللّٰهِ"))
            assertTrue("Per-Hutbe Arabic header must include Hadith line", h.arabicVerseOrHadith.contains("وَقَالَ رَسُولُ اللّٰهِ"))

            val cleanedTr = com.example.data.local.HutbeData.cleanHutbeBodyText(h.fullTextTr)
            val cleanedAr = com.example.data.local.HutbeData.cleanHutbeBodyText(h.arabicFullText)
            assertFalse("Clean Turkish sermon must strip footnote markers", Regex("\\[\\d+\\]").containsMatchIn(cleanedTr))
            assertFalse("Clean Turkish sermon must strip Diyanet footer/source", cleanedTr.contains("Din Hizmetleri Genel Müdürlüğü", ignoreCase = true))
            assertFalse("Clean Turkish sermon must strip Kaynak line", cleanedTr.contains("Kaynak:", ignoreCase = true))
            assertFalse("Clean Arabic sermon must strip bottom source", cleanedAr.contains("الْمُدِيرِيَّةُ العَامَّةُ"))
            assertFalse("Clean Arabic sermon must strip footnote lines", Regex("\\[\\d+\\]").containsMatchIn(cleanedAr))

            if (headersDir.exists()) {
                val hasJpg = java.io.File(headersDir, "${h.id}.jpg").exists()
                val hasPng = java.io.File(headersDir, "${h.id}.png").exists()
                assertTrue("Bundled calligraphic Arabic header asset required for ${h.id}", hasJpg || hasPng)
            }
        }

        // Verify both Adhan audio assets exist when running locally
        val regularAdhan = java.io.File("app/src/main/assets/adhan.mp3")
        val fajrAdhan = java.io.File("app/src/main/assets/adhan_fajr.mp3")
        if (regularAdhan.exists() && fajrAdhan.exists()) {
            assertTrue("Regular Adhan MP3 must be full-length (>1 MB)", regularAdhan.length() > 1_000_000L)
            assertTrue("Fajr Adhan MP3 must be full-length (>1 MB)", fajrAdhan.length() > 1_000_000L)
        }
    }

    @Test
    fun testSeparateQuranLanguageModesDefaultArabic() {
        val defaultState = com.example.ui.viewmodel.QuranUiState()
        assertEquals("Default Quran language mode must be Arabic (AR)", "AR", defaultState.translationMode)
        assertNotEquals("Combined 3-language mode BOTH must not be default", "BOTH", defaultState.translationMode)

        // Verify Quran & Hutbe UI strings expose zero Diyanet/Kaynak labels
        for (lang in listOf(AppLanguage.TURKISH, AppLanguage.KURMANJI)) {
            val samples = listOf(
                AppStrings.navQuran(lang),
                AppStrings.turkishTranslation(lang),
                AppStrings.kurmanjiTranslation(lang),
                AppStrings.bothTranslations(lang),
                AppStrings.quranHeaderStats(lang),
                AppStrings.weeklyHutbeTitle(lang)
            )
            for (s in samples) {
                assertFalse("UI string must not contain Diyanet: $s", s.contains("diyanet", ignoreCase = true))
                assertFalse("UI string must not contain Kaynak: $s", s.contains("kaynak", ignoreCase = true))
                assertFalse("UI string must not contain Çavkanî: $s", s.contains("çavkan", ignoreCase = true))
            }
        }
    }

    @Test
    fun testQibla3DRotationMatrixNoTiltFlip() {
        // Build 3x3 world rotation matrix from device axis basis vectors expressed in (East, North, Up)
        fun matrixFromAxes(
            xWorld: FloatArray,
            yWorld: FloatArray,
            zWorld: FloatArray
        ): FloatArray = floatArrayOf(
            xWorld[0], yWorld[0], zWorld[0],
            xWorld[1], yWorld[1], zWorld[1],
            xWorld[2], yWorld[2], zWorld[2]
        )

        // 1. Flat on table: screen (+Z) points Up, top edge (+Y) faces N/E/S/W
        val flatNorth = matrixFromAxes(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f))
        val flatEast = matrixFromAxes(floatArrayOf(0f, -1f, 0f), floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 0f, 1f))
        val flatSouth = matrixFromAxes(floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f))
        val flatWest = matrixFromAxes(floatArrayOf(0f, 1f, 0f), floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 0f, 1f))

        assertEquals(0f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(flatNorth), 0.1f)
        assertEquals(90f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(flatEast), 0.1f)
        assertEquals(180f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(flatSouth), 0.1f)
        assertEquals(270f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(flatWest), 0.1f)

        // 2. Upright vertical: top (+Y) points Up, rear camera (-Z) points forward (so +Z points backward toward chest)
        // Must NOT flip 180 degrees backwards when held upright!
        val uprightNorth = matrixFromAxes(floatArrayOf(1f, 0f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, -1f, 0f))
        val uprightEast = matrixFromAxes(floatArrayOf(0f, -1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(-1f, 0f, 0f))
        val uprightSouth = matrixFromAxes(floatArrayOf(-1f, 0f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(0f, 1f, 0f))
        val uprightWest = matrixFromAxes(floatArrayOf(0f, 1f, 0f), floatArrayOf(0f, 0f, 1f), floatArrayOf(1f, 0f, 0f))

        assertEquals(0f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(uprightNorth), 0.1f)
        assertEquals(90f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(uprightEast), 0.1f)
        assertEquals(180f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(uprightSouth), 0.1f)
        assertEquals(270f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(uprightWest), 0.1f)

        // 3. Moderate 45-degree hand tilt facing East (y = [sin(45), 0, cos(45)] in East-Up, z = [-cos(45), 0, sin(45)])
        val s45 = sqrt(0.5f)
        val tiltedEast = matrixFromAxes(
            floatArrayOf(0f, -1f, 0f),
            floatArrayOf(s45, 0f, s45),
            floatArrayOf(-s45, 0f, s45)
        )
        assertEquals(90f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(tiltedEast), 0.1f)

        // 4. Steep tilt slightly leaned back past vertical (95 degrees) facing North -> must still point ~0 deg North!
        val cos95 = cos(Math.toRadians(95.0)).toFloat()
        val sin95 = sin(Math.toRadians(95.0)).toFloat()
        val leanedBackNorth = matrixFromAxes(
            floatArrayOf(1f, 0f, 0f),
            floatArrayOf(0f, cos95, sin95),
            floatArrayOf(0f, -sin95, cos95)
        )
        assertEquals(0f, com.example.sensor.QiblaSensorManager.computeAzimuthFromRotationMatrix(leanedBackNorth), 0.1f)
    }

    @Test
    fun testElifbaCompletenessAndCleanKurmanji() {
        val pages = com.example.data.local.Elifba60Data.PAGES
        assertEquals(60, pages.size)

        // Verify Sections 3 (Üstün: pages 13..18), 4 (Esre: pages 19..24), 5 (Ötre: pages 25..30) each cover all 28 Arabic letters
        val baseLetters = listOf(
            'ا', 'ب', 'ت', 'ث', 'ج', 'ح', 'خ', 'د', 'ذ', 'ر', 'ز', 'س', 'ش', 'ص',
            'ض', 'ط', 'ظ', 'ع', 'غ', 'ف', 'ق', 'ك', 'ل', 'م', 'ن', 'و', 'ه', 'ي'
        )
        for ((sectionStartPage, harakaMark) in listOf(13 to '\u064E', 19 to '\u0650', 25 to '\u064F')) {
            val sectionItems = (sectionStartPage until sectionStartPage + 6)
                .flatMap { com.example.data.local.Elifba60Data.getPage(it).items }
                .map { it.arabicText }
                .toSet()
            for (letter in baseLetters) {
                assertTrue(
                    "Missing $letter with haraka $harakaMark in Elifba60Data starting page $sectionStartPage",
                    sectionItems.contains("$letter$harakaMark")
                )
            }
        }

        // Verify Section 2 (pages 7..12) includes all joining letters + Lamelif + non-joining group
        val section2Text = (7..12)
            .flatMap { com.example.data.local.Elifba60Data.getPage(it).items }
            .joinToString(" ") { it.arabicText }
        for (letter in listOf('ض', 'ظ', 'ن', 'ه', 'ي')) {
            assertTrue("Section 2 missing joining forms for $letter", section2Text.contains(letter))
        }
        assertTrue("Section 2 must teach Lamelif (لا)", section2Text.contains("لا"))

        // Verify zero Turkish loanwords/typos inside Kurmanji Elifba or Qibla strings
        val allElifbaKuTexts = pages.flatMap { page ->
            listOf(page.titleKu, page.subtitleKu, page.descriptionKu, page.ruleNoteKu) +
                page.items.flatMap { listOf(it.letterNameKu, it.pronunciationKu, it.noteKu) }
        } + com.example.data.local.DiyanetElifbaData.lessons.flatMap { l ->
            listOf(l.titleKu, l.subtitleKu, l.descriptionKu) +
                l.items.flatMap { listOf(it.letterNameKu, it.pronunciationKu, it.noteKu) }
        }
        for (txt in allElifbaKuTexts) {
            assertFalse("Kurmanji Elifba must not contain 'Dudak': $txt", txt.contains("Dudak", ignoreCase = true))
            assertFalse("Kurmanji Elifba must not contain 'Ortê': $txt", txt.contains("Ortê", ignoreCase = true))
            assertFalse("Kurmanji Elifba must not contain typo 'tevgir': $txt", txt.contains("tevgir", ignoreCase = true))
            assertFalse("Kurmanji Elifba must not translate نَعْبُدُ as 'Perwerde dikin': $txt", txt.contains("Perwerde dikin", ignoreCase = true))
        }

        val kuQiblaTitle = AppStrings.quickQiblaTitle(AppLanguage.KURMANJI)
        val kuQiblaDesc = AppStrings.quickQiblaDesc(AppLanguage.KURMANJI)
        assertFalse(kuQiblaTitle.contains("Pusleya", ignoreCase = true))
        assertFalse(kuQiblaDesc.contains("Yönê", ignoreCase = true))
        assertEquals("لَامْ أَلِفْ", com.example.ui.viewmodel.ElifbaViewModel.toAuthenticArabicSpeech("لا ـلا"))
    }

    @Test
    fun testDiyanetExactPrayerTimesAccuracyWorldwideAndCacheValidation() {
        fun makeDate(year: Int, month: Int, day: Int, tzId: String): Date {
            return java.util.Calendar.getInstance(DiyanetCalculator.getTimeZoneForId(tzId)).apply {
                set(year, month - 1, day, 12, 0, 0)
                set(java.util.Calendar.MILLISECOND, 0)
            }.time
        }

        fun assertWithinOneMinute(label: String, expected: String, actual: String) {
            val expMin = com.example.data.repository.PrayerRepository.parseMinutesOfDay(expected)!!
            val actMin = com.example.data.repository.PrayerRepository.parseMinutesOfDay(actual)
            assertNotNull("$label invalid format: $actual", actMin)
            val diff = kotlin.math.abs(expMin - actMin!!)
            assertTrue("$label expected ~$expected (±1 min), got $actual", diff <= 1)
        }

        // 1. Istanbul Nov 16, 2026 official diyanet.gov.tr: 06:17, 07:45, 12:54, 15:28, 17:52, 19:15 (UTC+3 Europe/Istanbul)
        val istNov = DiyanetCalculator.calculateTimes(
            latitude = 41.0082,
            longitude = 28.9784,
            date = makeDate(2026, 11, 16, "Europe/Istanbul"),
            cityName = "İstanbul",
            country = "Türkiye"
        )
        assertEquals("Europe/Istanbul", istNov.timezone)
        assertEquals("2026-11-16", istNov.dateIso)
        assertWithinOneMinute("Istanbul Nov Fajr", "06:17", istNov.fajr)
        assertWithinOneMinute("Istanbul Nov Sunrise", "07:45", istNov.sunrise)
        assertWithinOneMinute("Istanbul Nov Dhuhr", "12:54", istNov.dhuhr)
        assertWithinOneMinute("Istanbul Nov Asr", "15:28", istNov.asr)
        assertWithinOneMinute("Istanbul Nov Maghrib", "17:52", istNov.maghrib)
        assertWithinOneMinute("Istanbul Nov Isha", "19:15", istNov.isha)
        assertTrue(com.example.data.repository.PrayerRepository.areTimesValidChronological(istNov))

        // 2. Diyarbakir Nov 16, 2026 official diyanet.gov.tr: 05:29, 06:53, 12:09, 14:51, 17:14, 18:33
        val diyNov = DiyanetCalculator.calculateTimes(
            latitude = 37.9144,
            longitude = 40.2306,
            date = makeDate(2026, 11, 16, "Europe/Istanbul"),
            cityName = "Diyarbakır",
            country = "Türkiye"
        )
        assertEquals("Europe/Istanbul", diyNov.timezone)
        assertWithinOneMinute("Diyarbakir Nov Fajr", "05:29", diyNov.fajr)
        assertWithinOneMinute("Diyarbakir Nov Sunrise", "06:53", diyNov.sunrise)
        assertWithinOneMinute("Diyarbakir Nov Dhuhr", "12:09", diyNov.dhuhr)
        assertWithinOneMinute("Diyarbakir Nov Asr", "14:51", diyNov.asr)
        assertWithinOneMinute("Diyarbakir Nov Maghrib", "17:14", diyNov.maghrib)
        assertWithinOneMinute("Diyarbakir Nov Isha", "18:33", diyNov.isha)

        // 3. Istanbul Jun 21, 2026 official diyanet.gov.tr: 03:25, 05:25, 13:10, 17:10, 20:46, 22:37
        val istJun = DiyanetCalculator.calculateTimes(
            latitude = 41.0082,
            longitude = 28.9784,
            date = makeDate(2026, 6, 21, "Europe/Istanbul"),
            cityName = "İstanbul",
            country = "Türkiye"
        )
        assertWithinOneMinute("Istanbul Jun Fajr", "03:25", istJun.fajr)
        assertWithinOneMinute("Istanbul Jun Sunrise", "05:25", istJun.sunrise)
        assertWithinOneMinute("Istanbul Jun Dhuhr", "13:10", istJun.dhuhr)
        assertWithinOneMinute("Istanbul Jun Asr", "17:10", istJun.asr)
        assertWithinOneMinute("Istanbul Jun Maghrib", "20:46", istJun.maghrib)
        assertWithinOneMinute("Istanbul Jun Isha", "22:37", istJun.isha)

        // 4. Izmir & Ankara even without explicit country (GPS bounding box must resolve Europe/Istanbul UTC+3, NOT UTC+2!)
        val izmirGps = DiyanetCalculator.calculateTimes(
            latitude = 38.4192,
            longitude = 27.1287,
            date = makeDate(2026, 11, 16, "Europe/Istanbul"),
            cityName = "GPS Konumu",
            country = ""
        )
        assertEquals("Europe/Istanbul", izmirGps.timezone)
        assertWithinOneMinute("Izmir Dhuhr", "13:01", izmirGps.dhuhr)

        // 5. High-latitude summer (Stockholm Jun 21, DST UTC+2) must stay chronological and never collapse to midnight
        val stockholmJun = DiyanetCalculator.calculateTimes(
            latitude = 59.3293,
            longitude = 18.0686,
            date = makeDate(2026, 6, 21, "Europe/Stockholm"),
            cityName = "Stockholm",
            country = "İsveç"
        )
        assertEquals("Europe/Stockholm", stockholmJun.timezone)
        assertTrue(com.example.data.repository.PrayerRepository.areTimesValidChronological(stockholmJun))

        // 6. Berlin DST check (Jun 21 UTC+2 vs Nov 16 UTC+1)
        val berlinSummer = DiyanetCalculator.calculateTimes(52.5200, 13.4050, makeDate(2026, 6, 21, "Europe/Berlin"), "Berlin", "Almanya")
        val berlinWinter = DiyanetCalculator.calculateTimes(52.5200, 13.4050, makeDate(2026, 11, 16, "Europe/Berlin"), "Berlin", "Almanya")
        assertEquals("Europe/Berlin", berlinSummer.timezone)
        val summerDhuhrMin = com.example.data.repository.PrayerRepository.parseMinutesOfDay(berlinSummer.dhuhr)!!
        val winterDhuhrMin = com.example.data.repository.PrayerRepository.parseMinutesOfDay(berlinWinter.dhuhr)!!
        assertTrue("Summer Berlin Dhuhr should be ~1h later due to DST", summerDhuhrMin - winterDhuhrMin in 50..85)

        // 7. Reconcile untuned Aladhan method=13 response (raw astronomical without -7/+5/+4/+7 temkin)
        val istTz = DiyanetCalculator.getTimeZoneForId("Europe/Istanbul")
        val rawIst = DiyanetCalculator.calculateRawAstronomicalMinutes(41.0082, 28.9784, makeDate(2026, 11, 16, "Europe/Istanbul"), istTz)
        val rawUntunedOnline = istNov.copy(
            sunrise = String.format(java.util.Locale.US, "%02d:%02d", rawIst.sunriseMin / 60, rawIst.sunriseMin % 60),
            dhuhr = String.format(java.util.Locale.US, "%02d:%02d", rawIst.dhuhrMin / 60, rawIst.dhuhrMin % 60),
            asr = String.format(java.util.Locale.US, "%02d:%02d", rawIst.asrMin / 60, rawIst.asrMin % 60),
            maghrib = String.format(java.util.Locale.US, "%02d:%02d", rawIst.maghribMin / 60, rawIst.maghribMin % 60),
            hijriDate = "6 Cemaziyelahir 1448",
            isOffline = false
        )
        val reconciled = com.example.data.repository.PrayerRepository.reconcileOnlineWithDiyanet(rawUntunedOnline, istNov, rawIst)
        assertEquals("17:52", reconciled.maghrib) // Never early raw sunset 17:45!
        assertEquals(istNov.sunrise, reconciled.sunrise) // Honors -7 sunrise temkin!
        assertWithinOneMinute("Reconciled Istanbul Nov Sunrise", "07:45", reconciled.sunrise)
        assertEquals("12:54", reconciled.dhuhr)   // Honors +5 dhuhr temkin!
        assertEquals("15:28", reconciled.asr)     // Honors +4 asr temkin!
        assertEquals("6 Cemaziyelahir 1448", reconciled.hijriDate)
        assertFalse(reconciled.isOffline)

        // 8. Stale cache rejection: yesterday's cache must NEVER pass isMatchingFreshCache
        val yesterdayCache = istNov.copy(dateIso = "2026-11-15")
        assertFalse(com.example.data.repository.PrayerRepository.isMatchingFreshCache(yesterdayCache, "İstanbul", 41.0082, 28.9784, "2026-11-16"))
        assertTrue(com.example.data.repository.PrayerRepository.isMatchingFreshCache(istNov, "İstanbul", 41.0082, 28.9784, "2026-11-16"))
        assertFalse(com.example.data.repository.PrayerRepository.isMatchingFreshCache(istNov, "Ankara", 39.9334, 32.8597, "2026-11-16"))
    }

    @Test
    fun testQuranLargeFontAndMushafSectionGrouping() {
        val defaultState = com.example.ui.viewmodel.QuranUiState()
        assertEquals("AR", defaultState.translationMode)
        assertTrue("Default Quran font size should be ultra-large (>= 58f)", defaultState.fontSize >= 58f)

        val sampleAyahs = listOf(
            com.example.data.model.PageAyah(112, "الإخلاص", "İhlâs", "Îxlas", 4, "وَلَمْ يَكُن لَّهُ كُفُوًا أَحَدٌ", "tr", "ku"),
            com.example.data.model.PageAyah(113, "الفلق", "Felak", "Feleq", 1, "قُلْ أَعُوذُ بِرَبِّ الْفَلَقِ", "tr", "ku"),
            com.example.data.model.PageAyah(113, "الفلق", "Felak", "Feleq", 2, "مِن شَرِّ مَا خَلَقَ", "tr", "ku"),
            com.example.data.model.PageAyah(114, "الناس", "Nâs", "Nas", 1, "قُلْ أَعُوذُ بِرَبِّ النَّاسِ", "tr", "ku")
        )
        val sections = com.example.ui.components.groupAyahsIntoMushafSections(sampleAyahs)
        assertEquals(3, sections.size)
        assertFalse("Continuing surah mid-page must not show banner", sections[0].startsSurah)
        assertEquals(listOf(4), sections[0].ayahs.map { it.numberInSurah })
        assertTrue("New surah starting at ayah 1 must show banner", sections[1].startsSurah)
        assertEquals(listOf(1, 2), sections[1].ayahs.map { it.numberInSurah })
        assertTrue(sections[2].startsSurah)
        assertEquals(114, sections[2].surahNumber)
    }

    @Test
    fun testLiveWeatherParsingAndReconciliation() {
        // 1. Open-Meteo null-element safety + today alignment (skipping yesterday, clamping min/max)
        val utcRef = java.util.Calendar.getInstance(java.util.TimeZone.getTimeZone("Europe/Istanbul")).apply {
            set(2026, java.util.Calendar.NOVEMBER, 16, 14, 20, 0)
            set(java.util.Calendar.MILLISECOND, 0)
        }.timeInMillis

        val omResp = com.example.data.remote.OpenMeteoForecastResponse(
            latitude = 37.9144,
            longitude = 40.2306,
            timezone = "Europe/Istanbul",
            current = com.example.data.remote.OpenMeteoCurrent(
                time = "2026-11-16T14:15",
                temperature2m = 16.5,
                relativeHumidity2m = 48,
                apparentTemperature = 15.8,
                isDay = 1,
                weatherCode = 2,
                windSpeed10m = 12.6
            ),
            hourly = com.example.data.remote.OpenMeteoHourly(
                time = listOf("2026-11-16T14:00", "2026-11-16T15:00", "2026-11-16T16:00"),
                temperature2m = listOf(16.2, 16.8, 15.1),
                weatherCode = listOf(2, null, 3),
                isDay = listOf(1, 1, 1)
            ),
            daily = com.example.data.remote.OpenMeteoDaily(
                time = listOf("2026-11-15", "2026-11-16", "2026-11-17"),
                weatherCode = listOf(61, 2, null),
                temperature2mMax = listOf(14.0, 15.0, 17.5),
                temperature2mMin = listOf(5.0, 6.4, 7.0),
                precipitationProbabilityMax = listOf(80, null, 20)
            )
        )
        val omParsed = com.example.data.repository.WeatherRepository.parseOpenMeteoForecast(
            response = omResp,
            latitude = 37.9144,
            longitude = 40.2306,
            locationName = "Diyarbakır",
            country = "Türkiye",
            nowMillis = utcRef
        )
        assertNotNull(omParsed)
        assertEquals("2026-11-16", omParsed!!.dailyForecast.first().dateIso)
        assertEquals(2, omParsed.dailyForecast.size) // Skipped 2026-11-15!
        assertTrue("Current temp must not exceed today's max", omParsed.maxTempC >= omParsed.temperatureC)
        assertEquals(2, omParsed.hourlyForecast.size)
        assertEquals("15:00", omParsed.hourlyForecast.first().hourLabel)
        assertEquals("14:20", omParsed.getUpdatedClockLabel())

        // 2. MET Norway JSON parsing (UTC -> Europe/Istanbul, m/s -> km/h, symbol_code -> WMO)
        val metJson = """
            {
              "properties": {
                "timeseries": [
                  {
                    "time": "2026-11-16T11:00:00Z",
                    "data": {
                      "instant": { "details": { "air_temperature": 11.0, "relative_humidity": 62.0, "wind_speed": 5.0 } },
                      "next_1_hours": { "summary": { "symbol_code": "clearsky_day" }, "details": { "precipitation_amount": 0.0 } }
                    }
                  },
                  {
                    "time": "2026-11-16T12:00:00Z",
                    "data": {
                      "instant": { "details": { "air_temperature": 12.0, "relative_humidity": 58.0, "wind_speed": 4.0 } },
                      "next_1_hours": { "summary": { "symbol_code": "rain_day" }, "details": { "precipitation_amount": 1.2 } }
                    }
                  },
                  {
                    "time": "2026-11-17T12:00:00Z",
                    "data": {
                      "instant": { "details": { "air_temperature": 14.0, "relative_humidity": 50.0, "wind_speed": 3.0 } },
                      "next_6_hours": { "summary": { "symbol_code": "partlycloudy_day" }, "details": { "precipitation_amount": 0.0 } }
                    }
                  }
                ]
              }
            }
        """.trimIndent()
        val metParsed = com.example.data.repository.WeatherRepository.parseMetNorwayJson(
            rawJson = metJson,
            latitude = 37.9144,
            longitude = 40.2306,
            locationName = "Diyarbakır",
            country = "Türkiye",
            nowMillis = utcRef
        )
        assertNotNull(metParsed)
        assertEquals(11.0, metParsed!!.temperatureC, 0.01) // 11:00Z = 14:00 Europe/Istanbul
        assertEquals(18.0, metParsed.windSpeedKmh, 0.01) // 5.0 m/s * 3.6 = 18.0 km/h
        assertEquals(0, metParsed.weatherCode)
        assertEquals(2, metParsed.dailyForecast.size)

        // 3. Reconcile divergent sources + fallback to MET Norway when Open-Meteo is null
        val fallback = com.example.data.repository.WeatherRepository.reconcileWeatherSources(null, metParsed)
        assertEquals(metParsed, fallback)
        val blended = com.example.data.repository.WeatherRepository.reconcileWeatherSources(omParsed, metParsed)!!
        assertTrue(blended.temperatureC < omParsed.temperatureC && blended.temperatureC > metParsed.temperatureC)
        assertTrue(blended.maxTempC >= blended.temperatureC)

        // 4. Date-aware formatDayLabel never labels stale cache days as "Bugün"
        assertEquals(
            "Cum",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-13", 0, AppLanguage.TURKISH, todayIso = "2026-11-16")
        )
        assertEquals(
            "Bugün",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-16", 0, AppLanguage.TURKISH, todayIso = "2026-11-16")
        )
        assertEquals(
            "Yarın",
            com.example.data.model.WeatherInfo.formatDayLabel("2026-11-17", 1, AppLanguage.TURKISH, todayIso = "2026-11-16")
        )
    }

    @Test
    fun testTesbihatSequenceAndZikirPresets() {
        val steps = com.example.data.local.TesbihatData.NAMAZ_TESBIHATI_STEPS
        assertEquals(8, steps.size)
        assertEquals(listOf(1, 2, 3, 4, 5, 6, 7, 8), steps.map { it.stepNumber })
        assertEquals(33, steps[4].targetCount) // Sübhanallah
        assertEquals(33, steps[5].targetCount) // Elhamdülillah
        assertEquals(33, steps[6].targetCount) // Allahu Ekber
        assertEquals(104, steps.sumOf { it.targetCount })

        for (step in steps) {
            assertTrue(step.arabicText.isNotBlank())
            assertTrue(step.transliteration.isNotBlank())
            assertTrue(step.getTitle(AppLanguage.TURKISH).isNotBlank())
            assertTrue(step.getTitle(AppLanguage.KURMANJI).isNotBlank())
            assertTrue(step.getMeaning(AppLanguage.TURKISH).isNotBlank())
            assertTrue(step.getMeaning(AppLanguage.KURMANJI).isNotBlank())
            assertFalse(step.getMeaning(AppLanguage.KURMANJI).contains("Yezdan", ignoreCase = true))
        }

        val presets = com.example.data.local.TesbihatData.ZIKIR_PRESETS
        assertTrue(presets.size >= 10)
        for (preset in presets) {
            assertTrue(preset.id.isNotBlank())
            assertTrue(preset.arabicText.isNotBlank())
            assertTrue(preset.transliteration.isNotBlank())
            assertTrue(preset.defaultTarget > 0)
            assertFalse(preset.getMeaning(AppLanguage.KURMANJI).contains("Yezdan", ignoreCase = true))
        }
    }

    @Test
    fun testNotificationSingleLineAndHmsCountdown() {
        val sampleTimes = com.example.data.model.PrayerTimes(
            fajr = "05:32",
            sunrise = "07:03",
            dhuhr = "12:48",
            asr = "15:30",
            maghrib = "17:52",
            isha = "19:16",
            dateReadable = "17 Kasım 2026",
            hijriDate = "7 Cemaziyelevvel 1448",
            cityName = "İstanbul",
            timezone = "Europe/Istanbul"
        )

        val lineTr = com.example.notification.PrayerNotificationManager.formatSingleLinePrayerTimes(
            sampleTimes,
            AppLanguage.TURKISH
        )
        assertFalse("Notification prayer times line must be strictly single-line", lineTr.contains("\n"))
        assertTrue(lineTr.contains("05:32"))
        assertTrue(lineTr.contains("07:03"))
        assertTrue(lineTr.contains("12:48"))
        assertTrue(lineTr.contains("15:30"))
        assertTrue(lineTr.contains("17:52"))
        assertTrue(lineTr.contains("19:16"))

        val lineKu = com.example.notification.PrayerNotificationManager.formatSingleLinePrayerTimes(
            sampleTimes,
            AppLanguage.KURMANJI
        )
        assertFalse("Kurmanji notification line must be strictly single-line", lineKu.contains("\n"))
        assertTrue(lineKu.contains("19:16"))

        assertEquals("00:00:00", com.example.notification.PrayerNotificationManager.formatRemainingHms(-100L))
        assertEquals("00:00:45", com.example.notification.PrayerNotificationManager.formatRemainingHms(45_000L))
        assertEquals("00:59:59", com.example.notification.PrayerNotificationManager.formatRemainingHms(3_599_000L))
        assertEquals("02:14:35", com.example.notification.PrayerNotificationManager.formatRemainingHms((2 * 3600 + 14 * 60 + 35) * 1000L))
        assertEquals("11:05:09", com.example.notification.PrayerNotificationManager.formatRemainingHms((11 * 3600 + 5 * 60 + 9) * 1000L))

        assertEquals("00:%s", com.example.notification.PrayerNotificationManager.formatChronometerPattern(3_599_000L))
        assertEquals("%s", com.example.notification.PrayerNotificationManager.formatChronometerPattern(3_600_000L))

        val combined = com.example.notification.PrayerNotificationManager.buildSingleLineFallbackSummary(
            sampleTimes,
            AppLanguage.TURKISH,
            (2 * 3600 + 14 * 60 + 35) * 1000L
        )
        assertFalse(combined.contains("\n"))
        assertTrue(combined.endsWith("02:14:35"))
    }

    @Test
    fun testEsmaUlHusnaCompletenessAndAccuracy() {
        val list = com.example.data.local.EsmaUlHusnaData.ESMA_LIST
        assertEquals("Esma-ul Husna must contain exactly 99 names", 99, list.size)
        assertEquals((1..99).toList(), list.map { it.number })

        assertEquals(99, list.map { it.arabicName }.distinct().size)
        assertEquals(99, list.map { it.nameTr }.distinct().size)
        assertEquals(99, list.map { it.nameKu }.distinct().size)

        assertEquals("Allah (c.c.)", list.first().nameTr)
        assertEquals("er-Rahmân", list[1].nameTr)
        assertEquals("er-Rahîm", list[2].nameTr)
        assertEquals("es-Sabûr", list.last().nameTr)

        for (item in list) {
            assertTrue("Arabic name missing at #${item.number}", item.arabicName.isNotBlank())
            assertTrue("Turkish name missing at #${item.number}", item.nameTr.isNotBlank())
            assertTrue("Kurmanji name missing at #${item.number}", item.nameKu.isNotBlank())
            assertTrue("Turkish meaning missing at #${item.number}", item.meaningTr.isNotBlank())
            assertTrue("Kurmanji meaning missing at #${item.number}", item.meaningKu.isNotBlank())

            // Strictly no source attribution text ("Diyanet" or "Kaynak") and no "Yezdan"
            val allFields = listOf(item.nameTr, item.nameKu, item.meaningTr, item.meaningKu)
            for (field in allFields) {
                assertFalse("Must not mention Diyanet in Esma UI data: $field", field.contains("diyanet", ignoreCase = true))
                assertFalse("Must not mention Kaynak in Esma UI data: $field", field.contains("kaynak", ignoreCase = true))
                assertFalse("Must not contain Yezdan: $field", field.contains("yezdan", ignoreCase = true))
            }
        }
    }

    @Test
    fun testSystemThemeLightAndDarkBackgrounds() {
        for (theme in com.example.data.model.AppTheme.entries) {
            val darkBg = com.example.ui.theme.ThemePalette.backgroundFor(theme, darkTheme = true)
            val lightBg = com.example.ui.theme.ThemePalette.backgroundFor(theme, darkTheme = false)
            val lightText = com.example.ui.theme.ThemePalette.textPrimaryFor(theme, darkTheme = false)
            val darkText = com.example.ui.theme.ThemePalette.textPrimaryFor(theme, darkTheme = true)

            assertEquals("Dark background must preserve AppTheme color", theme.background, darkBg)
            assertNotEquals("Light background must differ from black/dark background", darkBg, lightBg)
            assertTrue("Light background must be bright in light system theme", androidx.compose.ui.graphics.Color(lightBg.value).red > 0.75f)
            assertTrue("Light text primary must be dark ink for readability", androidx.compose.ui.graphics.Color(lightText.value).red < 0.25f)
            assertTrue("Dark text primary must remain bright", androidx.compose.ui.graphics.Color(darkText.value).red > 0.85f)
        }
        assertNotEquals(
            com.example.ui.theme.ThemePalette.mushafSurfaceFor(darkTheme = true),
            com.example.ui.theme.ThemePalette.mushafSurfaceFor(darkTheme = false)
        )
    }

    @Test
    fun testReadableTypographyScale() {
        val t = com.example.ui.theme.Typography
        assertTrue(t.titleLarge.fontSize.value >= 22f)
        assertTrue(t.titleMedium.fontSize.value >= 19f)
        assertTrue(t.titleSmall.fontSize.value >= 17f)
        assertTrue(t.bodyLarge.fontSize.value >= 18f)
        assertTrue(t.bodyMedium.fontSize.value >= 16f)
        assertTrue(t.bodySmall.fontSize.value >= 14f)
        assertTrue(t.labelLarge.fontSize.value >= 16f)
        assertTrue(t.labelMedium.fontSize.value >= 14f)
        assertTrue(t.labelSmall.fontSize.value >= 13f)

        assertTrue(t.bodyLarge.lineHeight.value > t.bodyLarge.fontSize.value)
        assertTrue(t.bodyMedium.lineHeight.value > t.bodyMedium.fontSize.value)
        assertTrue(t.bodySmall.lineHeight.value > t.bodySmall.fontSize.value)
        assertTrue(t.labelSmall.lineHeight.value > t.labelSmall.fontSize.value)
    }
}
