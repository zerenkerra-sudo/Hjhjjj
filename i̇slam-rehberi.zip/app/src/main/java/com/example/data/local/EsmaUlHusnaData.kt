package com.example.data.local

import com.example.data.model.AppLanguage

data class EsmaUlHusnaItem(
    val number: Int,
    val arabicName: String,
    val nameTr: String,
    val nameKu: String,
    val meaningTr: String,
    val meaningKu: String
) {
    fun getName(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) nameKu else nameTr

    fun getMeaning(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) meaningKu else meaningTr
}

object EsmaUlHusnaData {

    val ESMA_LIST: List<EsmaUlHusnaItem> = listOf(
        EsmaUlHusnaItem(
            number = 1,
            arabicName = "اَللّٰهُ",
            nameTr = "Allah (c.c.)",
            nameKu = "Allah (c.c.)",
            meaningTr = "Varlığı zorunlu olan, bütün kemal sıfatları kendinde toplayan, eşi ve benzeri bulunmayan tek yaratıcı.",
            meaningKu = "Afirînerê tekane ku hebûna Wî pêwîst e, xwediyê hemû sifetên kamil e û tu hevparê Wî tune ye."
        ),
        EsmaUlHusnaItem(
            number = 2,
            arabicName = "اَلرَّحْمٰنُ",
            nameTr = "er-Rahmân",
            nameKu = "Er-Rehman",
            meaningTr = "Dünyada bütün mahlûkata ayrım gözetmeksizin merhamet eden, şefkat gösteren ve nimetler ihsan eden.",
            meaningKu = "Yê ku li dinyayê bê cudahî li hemû mexlûqan rehm dike, dilovanî nîşan dide û nîmetan dide."
        ),
        EsmaUlHusnaItem(
            number = 3,
            arabicName = "اَلرَّحِيمُ",
            nameTr = "er-Rahîm",
            nameKu = "Er-Rehîm",
            meaningTr = "Ahirette yalnızca iman eden kullarına rahmet eden, onları sonsuz nimet ve bağışlamasıyla mükâfatlandıran.",
            meaningKu = "Yê ku li axretê tenê li bendeyên xwe yên bawermend rehm dike û wan bi xêr û bexşînê xelat dike."
        ),
        EsmaUlHusnaItem(
            number = 4,
            arabicName = "اَلْمَلِكُ",
            nameTr = "el-Melik",
            nameKu = "El-Melîk",
            meaningTr = "Bütün kâinatın mutlak sahibi, hükümdarı ve mülkünde dilediği gibi tasarruf eden.",
            meaningKu = "Xwediyê mutleq ê hemû gerdûnê, serwer û desthilatdarê her tiştî."
        ),
        EsmaUlHusnaItem(
            number = 5,
            arabicName = "اَلْقُدُّوسُ",
            nameTr = "el-Kuddûs",
            nameKu = "El-Quddûs",
            meaningTr = "Her türlü eksiklikten, kusurdan ve acizlikten uzak, tertemiz ve yüce olan.",
            meaningKu = "Yê ku ji hemû kêmasî, qisûr û bêhêziyê dûr, pak û pîroz e."
        ),
        EsmaUlHusnaItem(
            number = 6,
            arabicName = "اَلسَّلَامُ",
            nameTr = "es-Selâm",
            nameKu = "Es-Selam",
            meaningTr = "Her türlü tehlike ve kusurdan uzak olan, kullarını selamete ve esenliğe çıkaran.",
            meaningKu = "Yê ku ji her tehlûkeyê pak e û bendeyên xwe digihîne aştî, aramî û selametê."
        ),
        EsmaUlHusnaItem(
            number = 7,
            arabicName = "اَلْمُؤْمِنُ",
            nameTr = "el-Mü'min",
            nameKu = "El-Mu'mîn",
            meaningTr = "Gönüllere iman nuru veren, kullarına güven ve emniyet sağlayan, vaadine sadık olan.",
            meaningKu = "Yê ku ronahiya îmanê dide dilan, ewlehî û aramiyê dide bendeyên xwe û soza Xwe tîne cih."
        ),
        EsmaUlHusnaItem(
            number = 8,
            arabicName = "اَلْمُهَيْمِنُ",
            nameTr = "el-Müheymin",
            nameKu = "El-Muheymîn",
            meaningTr = "Her şeyi görüp gözeten, koruyan ve kâinatın bütün işlerini yönetip denetleyen.",
            meaningKu = "Yê ku her tiştî dibîne, diparêze û hemû karûbarên gerdûnê bi rê ve dibe."
        ),
        EsmaUlHusnaItem(
            number = 9,
            arabicName = "اَلْعَزِيزُ",
            nameTr = "el-Azîz",
            nameKu = "El-Ezîz",
            meaningTr = "Sonsuz izzet ve şeref sahibi, mağlup edilmesi imkânsız olan ve her şeye galip gelen.",
            meaningKu = "Xwediyê rûmet û şerefa bêdawî, yê ku tu kes nikare Wî têk bibe û her tim serkeftî ye."
        ),
        EsmaUlHusnaItem(
            number = 10,
            arabicName = "اَلْجَبَّارُ",
            nameTr = "el-Cebbâr",
            nameKu = "El-Cebbar",
            meaningTr = "Azamet ve kudret sahibi; kırılanları onaran, eksikleri tamamlayan ve dilediğini mutlaka gerçekleştiren.",
            meaningKu = "Xwediyê mezinahî û hêzê; yê ku dilên şikestî derman dike û çi bixwaze pêk tîne."
        ),
        EsmaUlHusnaItem(
            number = 11,
            arabicName = "اَلْمُتَكَبِّرُ",
            nameTr = "el-Mütekebbir",
            nameKu = "El-Mutekebbîr",
            meaningTr = "Büyüklükte eşi ve benzeri bulunmayan, azameti her yaratılmışın üstünde olan.",
            meaningKu = "Yê ku di mezinahiyê de bêhempa ye û bilindahiya Wî li ser hemû afirandiyan e."
        ),
        EsmaUlHusnaItem(
            number = 12,
            arabicName = "اَلْخَالِقُ",
            nameTr = "el-Hâlık",
            nameKu = "El-Xaliq",
            meaningTr = "Her şeyi yoktan var eden, varlıkları ölçülü bir düzenle yaratan.",
            meaningKu = "Yê ku her tiştî ji tunebûnê diafirîne û bi pîvan û nîzamê çêdike."
        ),
        EsmaUlHusnaItem(
            number = 13,
            arabicName = "اَلْبَارِئُ",
            nameTr = "el-Bâri'",
            nameKu = "El-Barî'",
            meaningTr = "Eşyayı ve canlıları kusursuz, birbirine uyumlu ve dengeli biçimde yaratan.",
            meaningKu = "Yê ku hemû hebûnan bê qisûr, lihevhatî û bi hevsengî diafirîne."
        ),
        EsmaUlHusnaItem(
            number = 14,
            arabicName = "اَلْمُصَوِّرُ",
            nameTr = "el-Musavvir",
            nameKu = "El-Musewwîr",
            meaningTr = "Varlıklara en güzel şekli, sureti ve birbirinden ayırt edici özellikleri veren.",
            meaningKu = "Yê ku şêwe, dirûv û taybetmendiyên herî bedew dide hemû afirandiyan."
        ),
        EsmaUlHusnaItem(
            number = 15,
            arabicName = "اَلْغَفَّارُ",
            nameTr = "el-Gaffâr",
            nameKu = "El-Xeffar",
            meaningTr = "Kullarının günahlarını tekrar tekrar örten ve bağışlaması sonsuz olan.",
            meaningKu = "Yê ku gunehên bendeyên Xwe gelek caran dinixumîne û bêdawî dibexşîne."
        ),
        EsmaUlHusnaItem(
            number = 16,
            arabicName = "اَلْقَهَّارُ",
            nameTr = "el-Kahhâr",
            nameKu = "El-Qehhar",
            meaningTr = "Her şeye mutlak surette galip ve hâkim olan, azametine kimsenin karşı koyamadığı.",
            meaningKu = "Yê ku li ser her tiştî serwer û desthilatdarê mutleq e û tu kes nikare li ber Wî bisekine."
        ),
        EsmaUlHusnaItem(
            number = 17,
            arabicName = "اَلْوَهَّابُ",
            nameTr = "el-Vehhâb",
            nameKu = "El-Wehhab",
            meaningTr = "Karşılıksız olarak çokça nimet veren, lütuf ve ihsanı bitmeyen.",
            meaningKu = "Yê ku bê beramber gelek nîmetan dibexşîne û kerema Wî qet naqede."
        ),
        EsmaUlHusnaItem(
            number = 18,
            arabicName = "اَلرَّزَّاقُ",
            nameTr = "er-Razzâk",
            nameKu = "Er-Rezzaq",
            meaningTr = "Bütün canlıların maddi ve manevi rızkını yaratan ve her birine ulaştıran.",
            meaningKu = "Yê ku rizqê madî û manewî yê hemû zindiyan diafirîne û digihîne wan."
        ),
        EsmaUlHusnaItem(
            number = 19,
            arabicName = "اَلْفَتَّاحُ",
            nameTr = "el-Fettâh",
            nameKu = "El-Fettah",
            meaningTr = "Her türlü müşkülü ve kapalı kapıyı açan, hayır, rahmet ve fetih kapılarını aralayan.",
            meaningKu = "Yê ku hemû astengiyan vedike û deriyên xêr, rehm û serkeftinê li ber bendeyan vedike."
        ),
        EsmaUlHusnaItem(
            number = 20,
            arabicName = "اَلْعَلِيمُ",
            nameTr = "el-Alîm",
            nameKu = "El-Elîm",
            meaningTr = "Gizli açık, geçmiş ve gelecek her şeyi en ince ayrıntısına kadar hakkıyla bilen.",
            meaningKu = "Yê ku tiştên eşkere û veşartî, rabirdû û paşerojê bi hemû hûrgiliyan dizane."
        ),
        EsmaUlHusnaItem(
            number = 21,
            arabicName = "اَلْقَابِضُ",
            nameTr = "el-Kâbıd",
            nameKu = "El-Qabid",
            meaningTr = "Hikmeti gereği rızkı ve imkânları daraltan, ruhları kabzeden.",
            meaningKu = "Yê ku li gorî hîkmeta Xwe rizq û derfetan teng dike û ruhê zindiyan distîne."
        ),
        EsmaUlHusnaItem(
            number = 22,
            arabicName = "اَلْبَاسِطُ",
            nameTr = "el-Bâsıt",
            nameKu = "El-Basit",
            meaningTr = "Dilediğinin rızkını, gönlünü ve imkânlarını genişletip ferahlık veren.",
            meaningKu = "Yê ku rizq, dil û derfetên kê bixwaze fireh dike û aramiyê dide."
        ),
        EsmaUlHusnaItem(
            number = 23,
            arabicName = "اَلْخَافِضُ",
            nameTr = "el-Hâfıd",
            nameKu = "El-Xafid",
            meaningTr = "Kibirlenenleri, zalimleri ve inkârcıları alçaltıp değerden düşüren.",
            meaningKu = "Yê ku kesên qure, zalim û înkarker dadixe xwarê û bêqîmet dike."
        ),
        EsmaUlHusnaItem(
            number = 24,
            arabicName = "اَلرَّافِعُ",
            nameTr = "er-Râfi'",
            nameKu = "Er-Rafî'",
            meaningTr = "İman edenleri, ihlaslı ve tevazu sahibi kullarını yükseltip şereflendiren.",
            meaningKu = "Yê ku bawermend û bendeyên dilpak bilind dike û rûmetê dide wan."
        ),
        EsmaUlHusnaItem(
            number = 25,
            arabicName = "اَلْمُعِزُّ",
            nameTr = "el-Muizz",
            nameKu = "El-Muîzz",
            meaningTr = "Dilediğine izzet, şeref, güç ve itibar bahşeden.",
            meaningKu = "Yê ku rûmet, şeref, hêz û qîmetê dide kê bixwaze."
        ),
        EsmaUlHusnaItem(
            number = 26,
            arabicName = "اَلْمُذِلُّ",
            nameTr = "el-Müzill",
            nameKu = "El-Muzîll",
            meaningTr = "Dilediğini zillet ve hakirlik içine düşüren, büyüklük taslayanları zelil kılan.",
            meaningKu = "Yê ku kê bixwaze dixe rewşeke nizim û kesên pozbilind bêrûmet dike."
        ),
        EsmaUlHusnaItem(
            number = 27,
            arabicName = "اَلسَّمِيعُ",
            nameTr = "es-Semî'",
            nameKu = "Es-Semî'",
            meaningTr = "Her sesi, fısıltıyı ve yakarışı işiten, kullarının dualarını kabul eden.",
            meaningKu = "Yê ku her dengî, pistepistê û duayê dibihîze û bersivê dide."
        ),
        EsmaUlHusnaItem(
            number = 28,
            arabicName = "اَلْبَصِيرُ",
            nameTr = "el-Basîr",
            nameKu = "El-Besîr",
            meaningTr = "Aydınlıkta ve karanlıkta her şeyi bütün incelikleriyle eksiksiz gören.",
            meaningKu = "Yê ku di ronahî û tarîtiyê de her tiştî bi hemû hûrgiliyan dibîne."
        ),
        EsmaUlHusnaItem(
            number = 29,
            arabicName = "اَلْحَكَمُ",
            nameTr = "el-Hakem",
            nameKu = "El-Hekem",
            meaningTr = "Mutlak hüküm ve hikmet sahibi olan, hakkı batıldan ayırt edip nihai kararı veren.",
            meaningKu = "Xwediyê hikm û dadweriya mutleq ku rastiyê ji pûçiyê vediqetîne û biryara dawî dide."
        ),
        EsmaUlHusnaItem(
            number = 30,
            arabicName = "اَلْعَدْلُ",
            nameTr = "el-Adl",
            nameKu = "El-Edl",
            meaningTr = "Mutlak adalet sahibi olan, hiçbir kuluna zerre kadar zulmetmeyen.",
            meaningKu = "Xwediyê dadperweriya mutleq ku qet zilmê li tu bendeyekî nake."
        ),
        EsmaUlHusnaItem(
            number = 31,
            arabicName = "اَللَّطِيفُ",
            nameTr = "el-Latîf",
            nameKu = "El-Letîf",
            meaningTr = "En ince ve gizli meseleleri bilen, kullarına sezdirmeden lütuf ve ikramda bulunan.",
            meaningKu = "Yê ku her tiştê nazik û veşartî dizane û bi nermî qenciyê digihîne bendeyên Xwe."
        ),
        EsmaUlHusnaItem(
            number = 32,
            arabicName = "اَلْخَبِيرُ",
            nameTr = "el-Habîr",
            nameKu = "El-Xebîr",
            meaningTr = "Her şeyin iç yüzünden, gizli yönlerinden ve hakikatinden haberdar olan.",
            meaningKu = "Yê ku ji rûyê hundirîn û rastiyên veşartî yên her tiştî agahdar e."
        ),
        EsmaUlHusnaItem(
            number = 33,
            arabicName = "اَلْحَلِيمُ",
            nameTr = "el-Halîm",
            nameKu = "El-Helîm",
            meaningTr = "Yumuşak davranan, suçluları cezalandırmada acele etmeyip tövbe için mühlet veren.",
            meaningKu = "Yê ku nermî nîşan dide, di cezakirinê de lez nake û demê dide ji bo tobeyê."
        ),
        EsmaUlHusnaItem(
            number = 34,
            arabicName = "اَلْعَظِيمُ",
            nameTr = "el-Azîm",
            nameKu = "El-Ezîm",
            meaningTr = "Zatı ve sıfatları bakımından pek ulu, azamet ve yüceliğine akıl ermeyen.",
            meaningKu = "Yê ku di zat û sifetên Xwe de pir mezin û bilind e."
        ),
        EsmaUlHusnaItem(
            number = 35,
            arabicName = "اَلْغَفُورُ",
            nameTr = "el-Gafûr",
            nameKu = "El-Xefûr",
            meaningTr = "Günahları örten, mağfiret ve bağışlaması pek bol olan.",
            meaningKu = "Yê ku gunehan dinixumîne û lêborîna Wî gelek zêde ye."
        ),
        EsmaUlHusnaItem(
            number = 36,
            arabicName = "اَلشَّكُورُ",
            nameTr = "eş-Şekûr",
            nameKu = "Eş-Şekûr",
            meaningTr = "Kendi rızası için yapılan az iyiliğe bile kat kat karşılık ve sevap veren.",
            meaningKu = "Yê ku li hember qenciyên biçûk ên ji bo riza Wî hatine kirin xelatên mezin dide."
        ),
        EsmaUlHusnaItem(
            number = 37,
            arabicName = "اَلْعَلِيُّ",
            nameTr = "el-Aliyy",
            nameKu = "El-Elîyy",
            meaningTr = "Yücelikte üstün olan, şanı, derecesi ve kudreti her şeyin üzerinde bulunan.",
            meaningKu = "Yê ku herî bilind e û qedir, şan û hêza Wî li ser her tiştî ye."
        ),
        EsmaUlHusnaItem(
            number = 38,
            arabicName = "اَلْكَبِيرُ",
            nameTr = "el-Kebîr",
            nameKu = "El-Kebîr",
            meaningTr = "Büyüklüğü sınırsız olan, azameti ve ululuğu bütün kâinatı aşan.",
            meaningKu = "Yê ku mezinahiya Wî bêsînor e û bilindahiya Wî li ser hemû gerdûnê ye."
        ),
        EsmaUlHusnaItem(
            number = 39,
            arabicName = "اَلْحَفِيظُ",
            nameTr = "el-Hafîz",
            nameKu = "El-Hefîz",
            meaningTr = "Yapılan her ameli kayıt altına alan ve bütün varlıkları koruyup gözeten.",
            meaningKu = "Yê ku hemû kiryaran tomar dike û hemû hebûnan ji xeteran diparêze."
        ),
        EsmaUlHusnaItem(
            number = 40,
            arabicName = "اَلْمُقِيتُ",
            nameTr = "el-Mukît",
            nameKu = "El-Muqît",
            meaningTr = "Bütün mahlûkatın gıdasını ve rızkını yaratan, her canlıya ihtiyacı kadarını veren.",
            meaningKu = "Yê ku xwarin û rizqê hemû zindiyan diafirîne û pêdiviyên wan dabîn dike."
        ),
        EsmaUlHusnaItem(
            number = 41,
            arabicName = "اَلْحَسِيبُ",
            nameTr = "el-Hasîb",
            nameKu = "El-Hesîb",
            meaningTr = "Kulların bütün amellerinin hesabını en ince ayrıntısıyla gören ve herkese yeten.",
            meaningKu = "Yê ku hesabê hemû kiryarên bendeyan bi hûrgilî digire û besî her kesî ye."
        ),
        EsmaUlHusnaItem(
            number = 42,
            arabicName = "اَلْجَلِيلُ",
            nameTr = "el-Celîl",
            nameKu = "El-Celîl",
            meaningTr = "Celal, azamet, ululuk ve kemale sahip olan.",
            meaningKu = "Xwediyê mezinahî, şan, heybet û bêqisûriyê."
        ),
        EsmaUlHusnaItem(
            number = 43,
            arabicName = "اَلْكَرِيمُ",
            nameTr = "el-Kerîm",
            nameKu = "El-Kerîm",
            meaningTr = "Lütuf, cömertlik ve ikramı sonsuz olan; istemeden de ihsanda bulunan.",
            meaningKu = "Yê ku comerdî, lutf û kerema Wî bêsînor e û bê xwestek jî dide."
        ),
        EsmaUlHusnaItem(
            number = 44,
            arabicName = "اَلرَّقِيبُ",
            nameTr = "er-Rakîb",
            nameKu = "Er-Reqîb",
            meaningTr = "Her varlığı, her davranışı ve kalpten geçeni her an gözetim altında tutan.",
            meaningKu = "Yê ku her gav çavdêriya hemû hebûn, kiryar û dilan dike."
        ),
        EsmaUlHusnaItem(
            number = 45,
            arabicName = "اَلْمُجِيبُ",
            nameTr = "el-Mücîb",
            nameKu = "El-Mucîb",
            meaningTr = "Kendisine dua edip yönelen kullarının çağrılarına icabet eden ve karşılık veren.",
            meaningKu = "Yê ku bersiva bang û duayên bendeyên Xwe dide û wan qebûl dike."
        ),
        EsmaUlHusnaItem(
            number = 46,
            arabicName = "اَلْوَاسِعُ",
            nameTr = "el-Vâsi'",
            nameKu = "El-Wasî'",
            meaningTr = "İlmi, rahmeti, kudreti ve mağfireti her şeyi kuşatacak kadar geniş olan.",
            meaningKu = "Yê ku zanîn, rehm, hêz û lêborîna Wî ewqas fireh e ku her tiştî digire nav xwe."
        ),
        EsmaUlHusnaItem(
            number = 47,
            arabicName = "اَلْحَكِيمُ",
            nameTr = "el-Hakîm",
            nameKu = "El-Hekîm",
            meaningTr = "Bütün emirleri ve işleri hikmetli olan, her şeyi yerli yerince ve gayesine uygun yaratan.",
            meaningKu = "Yê ku hemû ferman û karên Wî bi hîkmet in û her tiştî li cihê rast diafirîne."
        ),
        EsmaUlHusnaItem(
            number = 48,
            arabicName = "اَلْوَدُودُ",
            nameTr = "el-Vedûd",
            nameKu = "El-Wedûd",
            meaningTr = "İyi kullarını çok seven, onları rahmet ve hoşnutluğuna erdiren ve sevilmeye en layık olan.",
            meaningKu = "Yê ku bendeyên Xwe yên qenc pir hez dike û herî layiqê hezkirinê ye."
        ),
        EsmaUlHusnaItem(
            number = 49,
            arabicName = "اَلْمَجِيدُ",
            nameTr = "el-Mecîd",
            nameKu = "El-Mecîd",
            meaningTr = "Şanı yüce, kadri büyük, kerem ve ihsanı pek bol olan.",
            meaningKu = "Yê ku şan û mezinahiya Wî bilind e û qencî û kerema Wî pir zêde ye."
        ),
        EsmaUlHusnaItem(
            number = 50,
            arabicName = "اَلْبَاعِثُ",
            nameTr = "el-Bâis",
            nameKu = "El-Baîs",
            meaningTr = "Ölüleri kıyamette diriltip kabirlerinden çıkaran ve insanlara peygamberler gönderen.",
            meaningKu = "Yê ku miriyan di roja qiyametê de zindî dike û pêxemberan ji bo mirovan dişîne."
        ),
        EsmaUlHusnaItem(
            number = 51,
            arabicName = "اَلشَّهِيدُ",
            nameTr = "eş-Şehîd",
            nameKu = "Eş-Şehîd",
            meaningTr = "Her zaman ve her yerde hazır bulunan, her olaya bizzat şahitlik eden.",
            meaningKu = "Yê ku li her derê û her demê amade ye û şahidê her bûyerê ye."
        ),
        EsmaUlHusnaItem(
            number = 52,
            arabicName = "اَلْحَقُّ",
            nameTr = "el-Hakk",
            nameKu = "El-Heqq",
            meaningTr = "Varlığı hiç değişmeden gerçek olan, bütün varlığın dayanağı ve hakikatin kaynağı.",
            meaningKu = "Yê ku hebûna Wî rastî û heqîqeta mutleq e û qet nayê guhertin."
        ),
        EsmaUlHusnaItem(
            number = 53,
            arabicName = "اَلْوَكِيلُ",
            nameTr = "el-Vekîl",
            nameKu = "El-Wekîl",
            meaningTr = "Kendisine güvenip tevekkül edenlerin işlerini en güzel biçimde yoluna koyan.",
            meaningKu = "Yê ku karên kesên xwe dispêrin Wî bi awayê herî baş bi rê ve dibe."
        ),
        EsmaUlHusnaItem(
            number = 54,
            arabicName = "اَلْقَوِيُّ",
            nameTr = "el-Kaviyy",
            nameKu = "El-Qewîyy",
            meaningTr = "Kudreti sınırsız olan, hiçbir şekilde yorulmayan ve zayıflık göstermeyen.",
            meaningKu = "Xwediyê hêza bêsînor ku qet naweste û tu carî lawaz nabe."
        ),
        EsmaUlHusnaItem(
            number = 55,
            arabicName = "اَلْمَتِينُ",
            nameTr = "el-Metîn",
            nameKu = "El-Metîn",
            meaningTr = "Kuvveti çok şiddetli ve sarsılmaz olan, iradesi asla gevşemeyen.",
            meaningKu = "Yê ku hêza Wî pir saxlem û nehejok e û îradeya Wî qet sist nabe."
        ),
        EsmaUlHusnaItem(
            number = 56,
            arabicName = "اَلْوَلِيُّ",
            nameTr = "el-Veliyy",
            nameKu = "El-Welîyy",
            meaningTr = "İnananların gerçek dostu, yardımcısı ve koruyucusu.",
            meaningKu = "Dost, alîkar û parêzvanê rastîn ê bawermendan."
        ),
        EsmaUlHusnaItem(
            number = 57,
            arabicName = "اَلْحَمِيدُ",
            nameTr = "el-Hamîd",
            nameKu = "El-Hemîd",
            meaningTr = "Her türlü övgüye, hamde ve senaya yalnızca kendisi layık olan.",
            meaningKu = "Yê ku tenê Ew layiqê hemû hemd, pesin û spasiyê ye."
        ),
        EsmaUlHusnaItem(
            number = 58,
            arabicName = "اَلْمُحْصِي",
            nameTr = "el-Muhsî",
            nameKu = "El-Muhsî",
            meaningTr = "Bütün varlıkların ve yapılan her işin sayısını, ölçüsünü tek tek bilen.",
            meaningKu = "Yê ku hejmar û pîvana hemû hebûn û kiryaran yek bi yek dizane."
        ),
        EsmaUlHusnaItem(
            number = 59,
            arabicName = "اَلْمُبْدِئُ",
            nameTr = "el-Mübdi'",
            nameKu = "El-Mubdî'",
            meaningTr = "Mahlûkatı daha önce hiçbir örneği olmadan ilk baştan yaratan.",
            meaningKu = "Yê ku mexlûqan bêyî nimûneyek berê cara pêşîn diafirîne."
        ),
        EsmaUlHusnaItem(
            number = 60,
            arabicName = "اَلْمُعِيدُ",
            nameTr = "el-Muîd",
            nameKu = "El-Muîd",
            meaningTr = "Varlıkları ölümden sonra tekrar diriltip eski haline iade eden.",
            meaningKu = "Yê ku hebûnan piştî mirinê dîsa zindî dike û vedigerîne."
        ),
        EsmaUlHusnaItem(
            number = 61,
            arabicName = "اَلْمُحْيِي",
            nameTr = "el-Muhyî",
            nameKu = "El-Muhyî",
            meaningTr = "Hayat veren, cansızlara can bahşeden, kalpleri imanla dirilten.",
            meaningKu = "Yê ku jiyanê dide, can dide bêcanan û dilan bi îmanê zindî dike."
        ),
        EsmaUlHusnaItem(
            number = 62,
            arabicName = "اَلْمُمِيتُ",
            nameTr = "el-Mümît",
            nameKu = "El-Mumît",
            meaningTr = "Canlıların ölümünü yaratan, eceli gelenlerin ruhunu kabzeden.",
            meaningKu = "Yê ku mirina zindiyan diafirîne û ruhê kesên dema wan hatî distîne."
        ),
        EsmaUlHusnaItem(
            number = 63,
            arabicName = "اَلْحَيُّ",
            nameTr = "el-Hayy",
            nameKu = "El-Heyy",
            meaningTr = "Ezeli ve ebedi hayat sahibi, daima diri ve bütün hayatın kaynağı.",
            meaningKu = "Yê ku her tim zindî ye, bê destpêk û bê dawî ye û çavkaniya jiyanê ye."
        ),
        EsmaUlHusnaItem(
            number = 64,
            arabicName = "اَلْقَيُّومُ",
            nameTr = "el-Kayyûm",
            nameKu = "El-Qeyyûm",
            meaningTr = "Zatı ile kaim olan, gökleri, yeri ve bütün varlıkları ayakta tutup yöneten.",
            meaningKu = "Yê ku bi Xwe disekine û ezman, erd û hemû hebûnan li ser piyan digire."
        ),
        EsmaUlHusnaItem(
            number = 65,
            arabicName = "اَلْوَاجِدُ",
            nameTr = "el-Vâcid",
            nameKu = "El-Wacîd",
            meaningTr = "Zengin ve hiçbir şeye muhtaç olmayan, dilediğini her an bulan ve var eden.",
            meaningKu = "Yê ku bêhewcî ye û çi bixwaze di her demê de dibîne û pêk tîne."
        ),
        EsmaUlHusnaItem(
            number = 66,
            arabicName = "اَلْمَاجِدُ",
            nameTr = "el-Mâcid",
            nameKu = "El-Macîd",
            meaningTr = "Kadri ve şanı çok yüce, kerem ve cömertliği sonsuz olan.",
            meaningKu = "Yê ku şan û rûmeta Wî pir bilind e û kerem û comerdîya Wî bêsînor e."
        ),
        EsmaUlHusnaItem(
            number = 67,
            arabicName = "اَلْوَاحِدُ",
            nameTr = "el-Vâhid",
            nameKu = "El-Wahîd",
            meaningTr = "Zatında, sıfatlarında, fiillerinde ve isimlerinde ortağı olmayan tek ilah.",
            meaningKu = "Îlahê tekane ku di zat, sifet, kar û navên Xwe de tu şirîkê Wî tune ye."
        ),
        EsmaUlHusnaItem(
            number = 68,
            arabicName = "اَلصَّمَدُ",
            nameTr = "es-Samed",
            nameKu = "Es-Semed",
            meaningTr = "Her şeyin kendisine muhtaç olduğu, fakat kendisi hiçbir şeye muhtaç olmayan.",
            meaningKu = "Yê ku hemû hebûn hewcî Wî ne, lê Ew bi tu awayî hewcî tu tiştî nîne."
        ),
        EsmaUlHusnaItem(
            number = 69,
            arabicName = "اَلْقَادِرُ",
            nameTr = "el-Kâdir",
            nameKu = "El-Qadîr",
            meaningTr = "İstediğini istediği gibi yapmaya gücü yeten, mutlak kudret sahibi.",
            meaningKu = "Yê ku hêza Wî têra kirina her tiştê ku bixwaze heye."
        ),
        EsmaUlHusnaItem(
            number = 70,
            arabicName = "اَلْمُقْتَدِرُ",
            nameTr = "el-Muktedir",
            nameKu = "El-Muqtedîr",
            meaningTr = "Kudret ve kuvvet sahipleri üzerinde dilediği gibi tasarruf eden, her şeye gücü yeten.",
            meaningKu = "Yê ku li ser hemû xwediyên hêzê serwer e û hêza Wî li ser her tiştî heye."
        ),
        EsmaUlHusnaItem(
            number = 71,
            arabicName = "اَلْمُقَدِّمُ",
            nameTr = "el-Mukaddim",
            nameKu = "El-Muqeddîm",
            meaningTr = "Hikmeti gereği dilediğini öne geçiren, ilerleten ve yaklaştıran.",
            meaningKu = "Yê ku li gorî hîkmeta Xwe kê an çi bixwaze derdixe pêş û nêzîk dike."
        ),
        EsmaUlHusnaItem(
            number = 72,
            arabicName = "اَلْمُؤَخِّرُ",
            nameTr = "el-Muahhir",
            nameKu = "El-Muexxîr",
            meaningTr = "Hikmeti gereği dilediğini geri bırakan ve erteleyen.",
            meaningKu = "Yê ku li gorî hîkmeta Xwe kê an çi bixwaze paş dixe û dereng dixe."
        ),
        EsmaUlHusnaItem(
            number = 73,
            arabicName = "اَلْأَوَّلُ",
            nameTr = "el-Evvel",
            nameKu = "El-Ewwel",
            meaningTr = "Ezeli olan, varlığının başlangıcı bulunmayan, her şeyden önce var olan.",
            meaningKu = "Ezelî ye, tu destpêka hebûna Wî tune ye û berî her tiştî hebû."
        ),
        EsmaUlHusnaItem(
            number = 74,
            arabicName = "اَلْآخِرُ",
            nameTr = "el-Âhir",
            nameKu = "El-Axîr",
            meaningTr = "Ebedi olan, varlığının sonu bulunmayan, her şey yok olduktan sonra da bâki kalan.",
            meaningKu = "Ebedî ye, tu dawiya hebûna Wî tune ye û piştî nemana her tiştî jî dimîne."
        ),
        EsmaUlHusnaItem(
            number = 75,
            arabicName = "اَلظَّاهِرُ",
            nameTr = "ez-Zâhir",
            nameKu = "Ez-Zahir",
            meaningTr = "Varlığı ve birliği sayısız delil ve eserleriyle apaçık ortada olan.",
            meaningKu = "Yê ku hebûn û yekîtiya Wî bi nîşaneyên bêhejmar bi eşkereyî diyar e."
        ),
        EsmaUlHusnaItem(
            number = 76,
            arabicName = "اَلْبَاطِنُ",
            nameTr = "el-Bâtın",
            nameKu = "El-Batin",
            meaningTr = "Zatının mahiyeti akıllarla kavranamayan, her şeyin gizli hakikatini bilen.",
            meaningKu = "Yê ku heqîqeta zatê Wî bi aqil nayê dîtin û hemû tiştên veşartî dizane."
        ),
        EsmaUlHusnaItem(
            number = 77,
            arabicName = "اَلْوَالِي",
            nameTr = "el-Vâlî",
            nameKu = "El-Walî",
            meaningTr = "Kâinatı ve bütün hadiseleri tek başına idare edip yöneten.",
            meaningKu = "Yê ku gerdûnê û hemû bûyerên wê bi tena serê Xwe birêve dibe."
        ),
        EsmaUlHusnaItem(
            number = 78,
            arabicName = "اَلْمُتَعَالِي",
            nameTr = "el-Müteâlî",
            nameKu = "El-Mutealî",
            meaningTr = "Yaratılmışlara ait her türlü kusur ve sınırın ötesinde, pek yüce ve münezzeh olan.",
            meaningKu = "Yê ku ji hemû sînor û kêmasiyên mexlûqan bilindtir û pak e."
        ),
        EsmaUlHusnaItem(
            number = 79,
            arabicName = "اَلْبَرُّ",
            nameTr = "el-Berr",
            nameKu = "El-Berr",
            meaningTr = "Kullarına karşı iyilik, şefkat ve ihsanı çok bol olan.",
            meaningKu = "Yê ku qencî, dilovanî û kerema Wî li ser bendeyan pir zêde ye."
        ),
        EsmaUlHusnaItem(
            number = 80,
            arabicName = "اَلتَّوَّابُ",
            nameTr = "et-Tevvâb",
            nameKu = "Et-Tewwab",
            meaningTr = "Tövbeye yönelten ve kullarının tövbelerini çokça kabul eden.",
            meaningKu = "Yê ku rêya tobeyê vedike û tobeyên bendeyên Xwe gelek caran qebûl dike."
        ),
        EsmaUlHusnaItem(
            number = 81,
            arabicName = "اَلْمُنْتَقِمُ",
            nameTr = "el-Müntekim",
            nameKu = "El-Munteqîm",
            meaningTr = "Adaleti gereği zalimlere ve suçlulara hak ettikleri cezayı veren.",
            meaningKu = "Yê ku li gorî dadweriya Xwe cezayê heq dide zalim û sûcdaran."
        ),
        EsmaUlHusnaItem(
            number = 82,
            arabicName = "اَلْعَفُوُّ",
            nameTr = "el-Afüvv",
            nameKu = "El-Efuww",
            meaningTr = "Affetmeyi seven, kullarının günahlarını silip tamamen bağışlayan.",
            meaningKu = "Yê ku efûkirinê hez dike û gunehên bendeyên Xwe bi temamî jê dibe."
        ),
        EsmaUlHusnaItem(
            number = 83,
            arabicName = "اَلرَّؤُوفُ",
            nameTr = "er-Raûf",
            nameKu = "Er-Reûf",
            meaningTr = "Kullarına karşı pek şefkatli, merhamet ve esirgemesi çok derin olan.",
            meaningKu = "Yê ku dilovaniya Wî li ser bendeyan pir kûr û şefqeta Wî bêdawî ye."
        ),
        EsmaUlHusnaItem(
            number = 84,
            arabicName = "مَالِكُ الْمُلْكِ",
            nameTr = "Mâlikü'l-Mülk",
            nameKu = "Malîku'l-Mulk",
            meaningTr = "Mülkün ve bütün varlığın yegâne ve ebedi sahibi.",
            meaningKu = "Xwediyê rastîn û herdemî yê hemû mulk û gerdûnê."
        ),
        EsmaUlHusnaItem(
            number = 85,
            arabicName = "ذُو الْجَلَالِ وَالْإِكْرَامِ",
            nameTr = "Zü'l-Celâli ve'l-İkrâm",
            nameKu = "Zu'l-Celalî we'l-Îkram",
            meaningTr = "Hem sonsuz azamet ve celal sahibi hem de tükenmez ikram ve lütuf sahibi.",
            meaningKu = "Xwediyê mezinahî û heybeta bêdawî û xwediyê kerem û bexşîşa bêsînor."
        ),
        EsmaUlHusnaItem(
            number = 86,
            arabicName = "اَلْمُقْسِطُ",
            nameTr = "el-Muksit",
            nameKu = "El-Muqsît",
            meaningTr = "Bütün işlerini denge, ölçü ve tam bir adaletle yerine getiren.",
            meaningKu = "Yê ku hemû karên Xwe bi hevsengî, pîvan û dadperweriya temam pêk tîne."
        ),
        EsmaUlHusnaItem(
            number = 87,
            arabicName = "اَلْجَامِعُ",
            nameTr = "el-Câmi'",
            nameKu = "El-Camî'",
            meaningTr = "Dilediğini bir araya getiren ve kıyamet gününde bütün insanları hesap için toplayan.",
            meaningKu = "Yê ku çi bixwaze tîne cem hev û di roja qiyametê de hemû mirovan ji bo hesabê kom dike."
        ),
        EsmaUlHusnaItem(
            number = 88,
            arabicName = "اَلْغَنِيُّ",
            nameTr = "el-Ganiyy",
            nameKu = "El-Xenîyy",
            meaningTr = "Mutlak zenginlik sahibi olup hiçbir varlığa ve şeye muhtaç bulunmayan.",
            meaningKu = "Xwediyê dewlemendiya mutleq ku qet hewcî tu kes û tu tiştî nîne."
        ),
        EsmaUlHusnaItem(
            number = 89,
            arabicName = "اَلْمُغْنِي",
            nameTr = "el-Mugnî",
            nameKu = "El-Muxnî",
            meaningTr = "Dilediği kulunu maddi ve manevi bakımdan zenginleştirip başkasına muhtaç etmeyen.",
            meaningKu = "Yê ku bendeyê bixwaze bi madî û manewî dewlemend dike û ji hewcîtiya xelkê xilas dike."
        ),
        EsmaUlHusnaItem(
            number = 90,
            arabicName = "اَلْمَانِعُ",
            nameTr = "el-Mâni'",
            nameKu = "El-Manî'",
            meaningTr = "Hikmeti gereği bazı şeylerin gerçekleşmesine veya kötülüklere engel olan.",
            meaningKu = "Yê ku li gorî hîkmeta Xwe rê li ber hin tiştan an jî xirabiyan digire."
        ),
        EsmaUlHusnaItem(
            number = 91,
            arabicName = "اَلضَّارُّ",
            nameTr = "ed-Dârr",
            nameKu = "Ed-Darr",
            meaningTr = "İmtihan ve hikmet gereği elem, zarar ve sıkıntı veren halleri yaratan.",
            meaningKu = "Yê ku li gorî îmtihan û hîkmetê rewşên zirar û tengasiyê diafirîne."
        ),
        EsmaUlHusnaItem(
            number = 92,
            arabicName = "اَلنَّافِعُ",
            nameTr = "en-Nâfi'",
            nameKu = "En-Nafî'",
            meaningTr = "Fayda, hayır ve menfaat veren şeyleri yaratan ve kullarına ulaştıran.",
            meaningKu = "Yê ku tiştên sûdmend, xêr û feydeyê diafirîne û digihîne bendeyan."
        ),
        EsmaUlHusnaItem(
            number = 93,
            arabicName = "اَلنُّورُ",
            nameTr = "en-Nûr",
            nameKu = "En-Nûr",
            meaningTr = "Gökleri, yeri ve gönülleri aydınlatan, varlıklara nur veren.",
            meaningKu = "Yê ku ezmanan, erdê û dilan ronî dike û ronahiyê dide hebûnan."
        ),
        EsmaUlHusnaItem(
            number = 94,
            arabicName = "اَلْهَادِي",
            nameTr = "el-Hâdî",
            nameKu = "El-Hadî",
            meaningTr = "Hidayet veren, kullarına doğru yolu gösterip hakka ulaştıran.",
            meaningKu = "Yê ku hîdayetê dide û rêya rast nîşanî bendeyên Xwe dide."
        ),
        EsmaUlHusnaItem(
            number = 95,
            arabicName = "اَلْبَدِيعُ",
            nameTr = "el-Bedî'",
            nameKu = "El-Bedî'",
            meaningTr = "Eşi ve benzeri olmadan, örneksiz ve harikulade biçimde yaratan.",
            meaningKu = "Yê ku bê mînak, bê hevta û bi awayekî bêhempa diafirîne."
        ),
        EsmaUlHusnaItem(
            number = 96,
            arabicName = "اَلْبَاقِي",
            nameTr = "el-Bâkî",
            nameKu = "El-Baqî",
            meaningTr = "Varlığının sonu olmayan, ölümsüz ve sonsuza kadar kalıcı olan.",
            meaningKu = "Yê ku hebûna Wî bê dawî ye û heta hetayê dimîne."
        ),
        EsmaUlHusnaItem(
            number = 97,
            arabicName = "اَلْوَارِثُ",
            nameTr = "el-Vâris",
            nameKu = "El-Warîs",
            meaningTr = "Bütün mülkün ve servetlerin gerçek sahibi; her şey geçtikten sonra baki kalan.",
            meaningKu = "Xwediyê rastîn ê hemû mulkan ku piştî çûna her tiştî dimîne."
        ),
        EsmaUlHusnaItem(
            number = 98,
            arabicName = "اَلرَّشِيدُ",
            nameTr = "er-Reşîd",
            nameKu = "Er-Reşîd",
            meaningTr = "Bütün işleri hikmet ve isabetli düzen üzere olan, kullarına doğru yolu gösteren.",
            meaningKu = "Yê ku hemû karên Wî rast û bi hîkmet in û rêya rast nîşan dide."
        ),
        EsmaUlHusnaItem(
            number = 99,
            arabicName = "اَلصَّبُورُ",
            nameTr = "es-Sabûr",
            nameKu = "Es-Sebûr",
            meaningTr = "Çok sabırlı olan, günahkârları cezalandırmada acele etmeyip süre tanıyan.",
            meaningKu = "Yê ku pir sebir dike, di cezakirina gunehkaran de lez nake û dem dide wan."
        )
    )
}
