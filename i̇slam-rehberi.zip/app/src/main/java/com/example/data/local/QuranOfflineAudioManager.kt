package com.example.data.local

import android.content.Context
import com.example.data.model.QuranReciter
import com.example.util.NetworkUtils
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.TimeUnit

data class OfflineDownloadState(
    val isDownloading: Boolean = false,
    val reciter: QuranReciter = QuranReciter.ALAFASY,
    val currentSurahNumber: Int = 0,
    val completedCount: Int = 0,
    val totalCount: Int = 0,
    val currentSurahProgress: Float = 0f,
    val errorMessage: String? = null
) {
    val overallProgress: Float
        get() {
            if (totalCount <= 0) return 0f
            return ((completedCount + currentSurahProgress) / totalCount.toFloat()).coerceIn(0f, 1f)
        }
}

object QuranOfflineAudioManager {

    private const val AUDIO_ROOT_DIR = "quran_audio"
    private const val MIN_VALID_MP3_BYTES = 2048L

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val client: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(45, TimeUnit.SECONDS)
            .followRedirects(true)
            .build()
    }

    private var activeBatchJob: Job? = null
    private val backgroundCacheJobs = HashMap<String, Job>()

    private val _downloadedSurahsByReciterFlow = MutableStateFlow<Map<String, Set<Int>>>(emptyMap())
    val downloadedSurahsByReciterFlow: StateFlow<Map<String, Set<Int>>> = _downloadedSurahsByReciterFlow.asStateFlow()

    private val _totalStorageBytesFlow = MutableStateFlow(0L)
    val totalStorageBytesFlow: StateFlow<Long> = _totalStorageBytesFlow.asStateFlow()

    private val _downloadStateFlow = MutableStateFlow(OfflineDownloadState())
    val downloadStateFlow: StateFlow<OfflineDownloadState> = _downloadStateFlow.asStateFlow()

    private fun getReciterDir(context: Context, reciter: QuranReciter): File {
        val dir = File(File(context.filesDir, AUDIO_ROOT_DIR), reciter.id)
        if (!dir.exists()) {
            dir.mkdirs()
        }
        return dir
    }

    fun getSurahTargetFile(context: Context, reciter: QuranReciter, surahNumber: Int): File {
        val safeNum = surahNumber.coerceIn(1, 114)
        val fileName = String.format("%03d.mp3", safeNum)
        return File(getReciterDir(context, reciter), fileName)
    }

    fun getLocalSurahFile(context: Context, reciter: QuranReciter, surahNumber: Int): File? {
        val file = getSurahTargetFile(context, reciter, surahNumber)
        return if (file.exists() && file.length() >= MIN_VALID_MP3_BYTES) file else null
    }

    fun isSurahDownloaded(context: Context, reciter: QuranReciter, surahNumber: Int): Boolean {
        return getLocalSurahFile(context, reciter, surahNumber) != null
    }

    fun refreshInventory(context: Context) {
        scope.launch {
            refreshInventorySync(context.applicationContext)
        }
    }

    private fun refreshInventorySync(context: Context) {
        val root = File(context.filesDir, AUDIO_ROOT_DIR)
        if (!root.exists()) {
            _downloadedSurahsByReciterFlow.value = emptyMap()
            _totalStorageBytesFlow.value = 0L
            return
        }

        val map = HashMap<String, Set<Int>>()
        var totalBytes = 0L

        QuranReciter.entries.forEach { reciter ->
            val reciterDir = File(root, reciter.id)
            if (reciterDir.exists() && reciterDir.isDirectory) {
                val surahs = HashSet<Int>()
                reciterDir.listFiles()?.forEach { file ->
                    val name = file.name
                    if (name.endsWith(".mp3") && file.length() >= MIN_VALID_MP3_BYTES) {
                        val num = name.removeSuffix(".mp3").toIntOrNull()
                        if (num != null && num in 1..114) {
                            surahs.add(num)
                            totalBytes += file.length()
                        }
                    } else if (name.endsWith(".tmp")) {
                        // Clean up abandoned temp files if not currently downloading
                        if (!_downloadStateFlow.value.isDownloading) {
                            file.delete()
                        }
                    }
                }
                map[reciter.id] = surahs
            } else {
                map[reciter.id] = emptySet()
            }
        }

        _downloadedSurahsByReciterFlow.value = map
        _totalStorageBytesFlow.value = totalBytes
    }

    /**
     * Silently caches a streamed Surah in the background so subsequent plays require zero internet.
     */
    fun cacheSurahInBackground(context: Context, reciter: QuranReciter, surahNumber: Int) {
        val appCtx = context.applicationContext
        val key = "${reciter.id}_$surahNumber"
        if (getLocalSurahFile(appCtx, reciter, surahNumber) != null) return
        if (!NetworkUtils.isNetworkAvailable(appCtx)) return
        if (backgroundCacheJobs[key]?.isActive == true) return

        backgroundCacheJobs[key] = scope.launch {
            downloadSingleSurahInternal(appCtx, reciter, surahNumber)
            refreshInventorySync(appCtx)
        }
    }

    fun downloadSurah(context: Context, reciter: QuranReciter, surahNumber: Int) {
        val appCtx = context.applicationContext
        if (!NetworkUtils.isNetworkAvailable(appCtx)) {
            _downloadStateFlow.value = OfflineDownloadState(
                isDownloading = false,
                reciter = reciter,
                errorMessage = "İndirme başlatmak için internet bağlantısı gerekiyor."
            )
            return
        }

        activeBatchJob?.cancel()
        activeBatchJob = scope.launch {
            downloadListInternal(appCtx, reciter, listOf(surahNumber.coerceIn(1, 114)))
        }
    }

    fun downloadJuz(context: Context, reciter: QuranReciter, juzNumber: Int) {
        val juz = QuranNavigationData.JUZ_LIST.find { it.number == juzNumber } ?: return
        val start = juz.startSurahNumber.coerceIn(1, 114)
        val end = juz.endSurahNumber.coerceIn(start, 114)
        val surahs = (start..end).toList()

        val appCtx = context.applicationContext
        if (!NetworkUtils.isNetworkAvailable(appCtx)) {
            _downloadStateFlow.value = OfflineDownloadState(
                isDownloading = false,
                reciter = reciter,
                errorMessage = "Cüz indirmek için internet bağlantısı gerekiyor."
            )
            return
        }

        activeBatchJob?.cancel()
        activeBatchJob = scope.launch {
            downloadListInternal(appCtx, reciter, surahs)
        }
    }

    fun downloadAllSurahs(context: Context, reciter: QuranReciter) {
        val appCtx = context.applicationContext
        if (!NetworkUtils.isNetworkAvailable(appCtx)) {
            _downloadStateFlow.value = OfflineDownloadState(
                isDownloading = false,
                reciter = reciter,
                errorMessage = "Tam Kur'an paketini indirmek için internet bağlantısı gerekiyor."
            )
            return
        }

        activeBatchJob?.cancel()
        activeBatchJob = scope.launch {
            downloadListInternal(appCtx, reciter, (1..114).toList())
        }
    }

    fun cancelDownload() {
        activeBatchJob?.cancel()
        activeBatchJob = null
        _downloadStateFlow.value = OfflineDownloadState(isDownloading = false)
    }

    fun deleteSurah(context: Context, reciter: QuranReciter, surahNumber: Int) {
        val appCtx = context.applicationContext
        scope.launch {
            val file = getSurahTargetFile(appCtx, reciter, surahNumber)
            if (file.exists()) file.delete()
            refreshInventorySync(appCtx)
        }
    }

    fun deleteReciterDownloads(context: Context, reciter: QuranReciter) {
        val appCtx = context.applicationContext
        cancelDownload()
        scope.launch {
            val dir = getReciterDir(appCtx, reciter)
            if (dir.exists()) {
                dir.listFiles()?.forEach { it.delete() }
            }
            refreshInventorySync(appCtx)
        }
    }

    private suspend fun downloadListInternal(
        context: Context,
        reciter: QuranReciter,
        surahNumbers: List<Int>
    ) {
        refreshInventorySync(context)
        val pending = surahNumbers.filter { getLocalSurahFile(context, reciter, it) == null }
        val totalCount = surahNumbers.size
        var completed = totalCount - pending.size

        if (pending.isEmpty()) {
            _downloadStateFlow.value = OfflineDownloadState(
                isDownloading = false,
                reciter = reciter,
                completedCount = totalCount,
                totalCount = totalCount,
                currentSurahProgress = 0f
            )
            return
        }

        _downloadStateFlow.value = OfflineDownloadState(
            isDownloading = true,
            reciter = reciter,
            currentSurahNumber = pending.first(),
            completedCount = completed,
            totalCount = totalCount,
            currentSurahProgress = 0f
        )

        var errorMsg: String? = null
        try {
            for (surahNum in pending) {
                if (!scope.isActive) break
                if (!NetworkUtils.isNetworkAvailable(context)) {
                    errorMsg = "İnternet bağlantısı kesildi. İndirilen sureler kaydedildi."
                    break
                }

                _downloadStateFlow.value = _downloadStateFlow.value.copy(
                    isDownloading = true,
                    currentSurahNumber = surahNum,
                    completedCount = completed,
                    currentSurahProgress = 0f,
                    errorMessage = null
                )

                val ok = downloadSingleSurahInternal(context, reciter, surahNum) { progress ->
                    _downloadStateFlow.value = _downloadStateFlow.value.copy(
                        currentSurahProgress = progress
                    )
                }

                if (ok) {
                    completed++
                    refreshInventorySync(context)
                } else {
                    errorMsg = "Bazı sureler indirilemedi ($surahNum. Sure)."
                }
            }
        } catch (ce: CancellationException) {
            throw ce
        } catch (e: Exception) {
            errorMsg = "İndirme sırasında bağlantı hatası oluştu."
        } finally {
            refreshInventorySync(context)
            _downloadStateFlow.value = OfflineDownloadState(
                isDownloading = false,
                reciter = reciter,
                completedCount = completed,
                totalCount = totalCount,
                currentSurahProgress = 0f,
                errorMessage = errorMsg
            )
        }
    }

    private suspend fun downloadSingleSurahInternal(
        context: Context,
        reciter: QuranReciter,
        surahNumber: Int,
        onProgress: ((Float) -> Unit)? = null
    ): Boolean = withContext(Dispatchers.IO) {
        val targetFile = getSurahTargetFile(context, reciter, surahNumber)
        if (targetFile.exists() && targetFile.length() >= MIN_VALID_MP3_BYTES) {
            return@withContext true
        }

        val tempFile = File(targetFile.parentFile, "${targetFile.name}.tmp")
        val candidateUrls = reciter.getSurahAudioUrls(surahNumber)

        for (url in candidateUrls) {
            try {
                if (tempFile.exists()) tempFile.delete()
                val req = Request.Builder().url(url).build()
                client.newCall(req).execute().use { response ->
                    if (!response.isSuccessful) return@use
                    val body = response.body ?: return@use
                    val totalBytes = body.contentLength()
                    var downloadedBytes = 0L

                    body.byteStream().use { input ->
                        FileOutputStream(tempFile).use { output ->
                            val buffer = ByteArray(16 * 1024)
                            var read: Int
                            while (input.read(buffer).also { read = it } != -1) {
                                if (!isActive) {
                                    throw CancellationException("Download cancelled")
                                }
                                output.write(buffer, 0, read)
                                downloadedBytes += read
                                if (totalBytes > 0L) {
                                    onProgress?.invoke((downloadedBytes.toFloat() / totalBytes.toFloat()).coerceIn(0f, 1f))
                                }
                            }
                            output.flush()
                        }
                    }

                    if (tempFile.exists() && tempFile.length() >= MIN_VALID_MP3_BYTES) {
                        if (targetFile.exists()) targetFile.delete()
                        if (tempFile.renameTo(targetFile)) {
                            return@withContext true
                        }
                    }
                }
            } catch (ce: CancellationException) {
                if (tempFile.exists()) tempFile.delete()
                throw ce
            } catch (_: Exception) {
                if (tempFile.exists()) tempFile.delete()
            }
        }
        false
    }

    fun formatStorageSize(bytes: Long): String {
        if (bytes <= 0L) return "0 MB"
        val mb = bytes / (1024.0 * 1024.0)
        return if (mb >= 1024.0) {
            String.format("%.2f GB", mb / 1024.0)
        } else if (mb >= 1.0) {
            String.format("%.1f MB", mb)
        } else {
            String.format("%d KB", (bytes / 1024L).coerceAtLeast(1L))
        }
    }
}
