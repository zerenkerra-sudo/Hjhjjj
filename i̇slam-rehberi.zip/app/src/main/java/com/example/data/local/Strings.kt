package com.example.data.local

import com.example.data.model.AppLanguage
import com.example.data.model.PrayerType

object AppStrings {

    fun appTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "İslam Rehberi"
        AppLanguage.KURMANJI -> "Rêbera Îslamê"
    }

    // Navigation
    fun navPrayer(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Vakitler"
        AppLanguage.KURMANJI -> "Wext"
    }

    fun navQibla(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kıble"
        AppLanguage.KURMANJI -> "Qible"
    }

    fun navQuran(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kur'an-ı Kerim"
        AppLanguage.KURMANJI -> "Qur'ana Pîroz"
    }

    fun navSettings(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Ezan & Ayarlar"
        AppLanguage.KURMANJI -> "Bang & Mîheng"
    }

    // Prayer screen
    fun nextPrayer(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sıradaki Vakit"
        AppLanguage.KURMANJI -> "Wextê Pêş"
    }

    fun remainingTime(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kalan Süre"
        AppLanguage.KURMANJI -> "Dema Mayî"
    }

    fun timeNow(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Vakit Girdi"
        AppLanguage.KURMANJI -> "Wext Hat"
    }

    fun calculationSource(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Hesaplama: Standart Astronomik Güneş Açısı (Fecr 18°, Yatsı 17°)"
        AppLanguage.KURMANJI -> "Rêbaza Hesabê: Hesabê Astronomîk ê Rojê (Fecr 18°, Xeftan 17°)"
    }

    fun offlineBadge(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Çevrimdışı (Önbellek)"
        AppLanguage.KURMANJI -> "Bê Înternet (Bîrgeh)"
    }

    fun selectCity(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Şehir Değiştir"
        AppLanguage.KURMANJI -> "Bajar Biguherîne"
    }

    fun useGps(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "GPS ile Otomatik Bul"
        AppLanguage.KURMANJI -> "Bi GPS Otomatîk Bibîne"
    }

    // Qibla Screen
    fun qiblaDirection(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kıble Yönü"
        AppLanguage.KURMANJI -> "Hêla Qibleyê"
    }

    fun qiblaAngle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kıble Açısı"
        AppLanguage.KURMANJI -> "Pîleya Qibleyê"
    }

    fun deviceHeading(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Pusula Açısı"
        AppLanguage.KURMANJI -> "Hêla Pûsûlayê"
    }

    fun distanceToKaaba(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kâbe'ye Mesafe"
        AppLanguage.KURMANJI -> "Dûriya ber bi Kabe"
    }

    fun alignedWithQibla(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kıbleye Yöneldiniz!"
        AppLanguage.KURMANJI -> "Hûn Ber bi Qibleyê ve ne!"
    }

    fun calibrateCompass(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Daha hassas sonuç için telefonu yatay tutun ve havada '8' çizin."
        AppLanguage.KURMANJI -> "Ji bo encamek baştir telefonê rast bigirin û di hewayê de '8' çêbikin."
    }

    // Quran Screen
    fun surahs(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sureler"
        AppLanguage.KURMANJI -> "Sûre"
    }

    fun searchSurah(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sure veya ayet ara..."
        AppLanguage.KURMANJI -> "Li sûre an ayetan bigere..."
    }

    fun turkishTranslation(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Türkçe Meal"
        AppLanguage.KURMANJI -> "Wateya Tirkî"
    }

    fun kurmanjiTranslation(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kurmancî Meal (Latînî)"
        AppLanguage.KURMANJI -> "Meala Kurmancî (Latînî)"
    }

    fun bothTranslations(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "İki Meali Birlikte Göster"
        AppLanguage.KURMANJI -> "Her du Mealan Nîşan Bide"
    }

    fun listenAudio(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Tilaveti Dinle (Mişari Raşid el-Afasi)"
        AppLanguage.KURMANJI -> "Guh Bide Qir'anê (Mîşarî Reşîd)"
    }

    fun tabSurahs(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sureler (114)"
        AppLanguage.KURMANJI -> "Sûre (114)"
    }

    fun tabJuzs(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Cüzler (30)"
        AppLanguage.KURMANJI -> "Ciz (30)"
    }

    fun tabPages(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Mushaf (604 Sayfa)"
        AppLanguage.KURMANJI -> "Mûshef (604 Rûpel)"
    }

    fun quranHeaderStats(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "30 Cüz • 114 Sure • 6.236 Ayet • 604 Sayfa"
        AppLanguage.KURMANJI -> "30 Ciz • 114 Sûre • 6.236 Ayet • 604 Rûpel"
    }

    fun rtlMushafMode(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sağdan Sola (RTL) Mushaf Düzeni"
        AppLanguage.KURMANJI -> "Rêzkirina Mushafê ya Rast bo Çep"
    }

    fun rtlSwipeHint(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sayfa çevirmek için sağdan sola kaydırın"
        AppLanguage.KURMANJI -> "Ji bo guhertina rûpelê ji rastê ber bi çepê ve kaş bikin"
    }

    // Settings & Adhan
    fun adhanSettingsTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Otomatik Ezan & Bildirim Ayarları"
        AppLanguage.KURMANJI -> "Mîhengên Banga Otomatîk & Agahdariyan"
    }

    fun autoAdhanDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Namaz vakti girdiğinde telefon kapalı olsa bile otomatik ezan sesi çalar."
        AppLanguage.KURMANJI -> "Gava wextê nimêjê hat, heke telefon girtî be jî banga otomatîk dixwîne."
    }

    fun testAdhan(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Ezan Sesini Test Et"
        AppLanguage.KURMANJI -> "Dengê Bangê Ceribîne"
    }

    fun stopAdhan(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Ezanı Durdur"
        AppLanguage.KURMANJI -> "Bangê Bisekine"
    }

    fun batteryOptimizationTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Pil Tasarrufu & Arka Plan Koruması"
        AppLanguage.KURMANJI -> "Kêmkirina Pîlê & Xebata Paşperdeyê"
    }

    fun batteryOptimizationDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Xiaomi, Huawei, Samsung gibi telefonlar arka plandaki alarmları durdurabilir. Ezanın vaktinde okunması için pil kısıtlamasını kaldırın."
        AppLanguage.KURMANJI -> "Telefonên wekî Xiaomi, Huawei, Samsung dikarin bangê bidin sekinandin. Ji bo ku bang di wextê xwe de bixwîne, astengiya pîlê rakin."
    }

    fun openBatterySettings(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Pil Ayarlarını Aç"
        AppLanguage.KURMANJI -> "Mîhengên Pîlê Veke"
    }

    fun languageSelection(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Uygulama Dili"
        AppLanguage.KURMANJI -> "Zimanê Sepanê"
    }

    fun permissionExactAlarmTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Tam Zamanlı Alarm İzni"
        AppLanguage.KURMANJI -> "Destûra Alarma Tam Wext"
    }

    fun permissionExactAlarmDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Ezanın tam vaktinde okunabilmesi için Android sistem alarm izni gereklidir."
        AppLanguage.KURMANJI -> "Ji bo ku bang tam di wextê xwe de bixwîne, destûra pergala Androidê hewce ye."
    }

    fun grantPermission(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "İzin Ver"
        AppLanguage.KURMANJI -> "Destûr Bide"
    }

    // Daily Quran Dua
    fun dailyDuaTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Günün Duası (Kur'an Ayeti)"
        AppLanguage.KURMANJI -> "Duaya Îro (Ayeta Qur'anê)"
    }

    fun dailyDuaSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Her gün Kur'an-ı Kerim'den seçilmiş mübarek bir dua"
        AppLanguage.KURMANJI -> "Her roj duayek pîroz ji Qur'ana Pîroz"
    }

    fun viewAllDuas(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Tüm Dualar"
        AppLanguage.KURMANJI -> "Hemû Dua"
    }

    fun allDuasTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kur'an-ı Kerim Duaları"
        AppLanguage.KURMANJI -> "Duayên Qur'ana Pîroz"
    }

    fun searchDua(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Dua veya sure ara..."
        AppLanguage.KURMANJI -> "Li dua an sûreyan bigere..."
    }

    // Weekly Hutbe
    fun weeklyHutbeTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Haftanın Cuma Hutbesi"
        AppLanguage.KURMANJI -> "Xutbeya Hefteyê ya Înê"
    }

    fun readHutbe(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Hutbeyi Oku"
        AppLanguage.KURMANJI -> "Xutbeyê Bixwîne"
    }

    fun close(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kapat"
        AppLanguage.KURMANJI -> "Bigire"
    }

    fun copy(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kopyala"
        AppLanguage.KURMANJI -> "Kopî bike"
    }

    fun copiedToClipboard(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Metin kopyalandı"
        AppLanguage.KURMANJI -> "Nivîs hate kopîkirin"
    }

    // Religious Days & Kandil
    fun upcomingReligiousDayTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Yaklaşan Dini Gün"
        AppLanguage.KURMANJI -> "Roja Pîroz a Pêş"
    }

    fun allReligiousDaysTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Dini Günler ve Kandiller"
        AppLanguage.KURMANJI -> "Rojên Pîroz û Qendîl"
    }

    fun daysLeftFormat(days: Long, lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> if (days == 0L) "Bugün!" else "$days gün kaldı"
        AppLanguage.KURMANJI -> if (days == 0L) "Îro ye!" else "$days roj ma"
    }

    fun viewReligiousCalendar(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Takvimi Gör"
        AppLanguage.KURMANJI -> "Salnamê Bibîne"
    }

    // Friday and Event Notifications in Settings
    fun settingFridayReminderTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Cuma Hatırlatma Bildirimi"
        AppLanguage.KURMANJI -> "Agahdariya Roja Înê"
    }

    fun settingFridayReminderDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Her Cuma sabahı saat 10:30'da Cuma namazı ve haftanın hutbesi hatırlatması."
        AppLanguage.KURMANJI -> "Her serê sibê ya înê di saet 10:30 de bîrxistina nimêja înê û xutbeyê."
    }

    fun settingReligiousDaysReminderTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kandil ve Bayram Hatırlatması"
        AppLanguage.KURMANJI -> "Agahdariya Qendîl û Cejnan"
    }

    fun settingReligiousDaysReminderDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Mübarek kandil geceleri ve bayram günlerinde tebrik bildirimi."
        AppLanguage.KURMANJI -> "Di şevên qendîlan û rojên cejnan de peyama pîrozbahiyê."
    }

    // Quick Services Dashboard
    fun quickServicesTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "İslam Rehberi Hizmetleri"
        AppLanguage.KURMANJI -> "Xizmetên Rêbera Îslamê"
    }

    fun quickQuranTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Mushaf (604 Sayfa)"
        AppLanguage.KURMANJI -> "Mûshef (604 Rûpel)"
    }

    fun quickQuranDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "30 Cüz • 114 Sure • Sayfa Sayfa"
        AppLanguage.KURMANJI -> "30 Ciz • 114 Sûre • Rûpel bi Rûpel"
    }

    fun quickHutbeTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Cuma Hutbesi"
        AppLanguage.KURMANJI -> "Xutbeya Înê"
    }

    fun quickHutbeDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Güncel Cuma Hutbesi"
        AppLanguage.KURMANJI -> "Xutbeya Hefteyê ya Înê"
    }

    fun quickReligiousDaysTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Dini Günler & Kandiller"
        AppLanguage.KURMANJI -> "Rojên Pîroz & Qendîl"
    }

    fun quickReligiousDaysDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "17 Mübarek Gün & Kutlama"
        AppLanguage.KURMANJI -> "17 Rojên Pîroz & Pîrozbahî"
    }

    fun quickDuasTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kur'an Duaları"
        AppLanguage.KURMANJI -> "Dûayên Qur'anê"
    }

    fun quickDuasDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Günün Duası & 10 Kısa Dua"
        AppLanguage.KURMANJI -> "Dûaya Îro & 10 Dûa"
    }

    fun quickQiblaTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kıble Pusulası"
        AppLanguage.KURMANJI -> "Pûsûlaya Qibleyê"
    }

    fun quickQiblaDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Canlı Sensörlü Yön Bulucu"
        AppLanguage.KURMANJI -> "Hêla Qibleyê bi Sensora Rastîn"
    }

    // Elifba (Quran Alphabet & Reading Lessons)
    fun navElifba(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Elifba"
        AppLanguage.KURMANJI -> "Elîfba"
    }

    fun elifbaTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kur'an Elifbası (60 Yaprak)"
        AppLanguage.KURMANJI -> "Elîfbaya Qur'anê (60 Rûpel)"
    }

    fun elifbaSubtitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sesli ve Türkçe/Kürtçe Okunuşlu Harfler ve Harekeler"
        AppLanguage.KURMANJI -> "Tîp û Tevgerên bi Deng û Bilêvkirinên Kurdî/Tirkî"
    }

    fun listenPronunciation(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Dinle"
        AppLanguage.KURMANJI -> "Guh Bide"
    }

    fun pronunciationLabel(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Okunuşu"
        AppLanguage.KURMANJI -> "Bilêvkirin"
    }

    fun quickElifbaTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Kur'an Elifbası"
        AppLanguage.KURMANJI -> "Elîfbaya Qur'anê"
    }

    fun quickElifbaDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Sesli Harfler, Harekeler & Alıştırmalar"
        AppLanguage.KURMANJI -> "Tîpên bi Deng, Tevger & Xwendin"
    }

    // 60 Yaprak Elifba & Notification Bar
    fun elifba60LeafTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "60 Yaprak Tam Kur'an Elifbası"
        AppLanguage.KURMANJI -> "60 Rûpel Elîfbaya Temam a Qur'anê"
    }

    fun elifbaLeafLabel(page: Int, total: Int, lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Yaprak $page / $total"
        AppLanguage.KURMANJI -> "Rûpel $page / $total"
    }

    fun elifbaJumpDialogTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Yaprağa Git (1 - 60)"
        AppLanguage.KURMANJI -> "Biçe Rûpelê (1 - 60)"
    }

    fun persistentNotificationTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Bildirim Çubuğunda Namaz Vakitleri"
        AppLanguage.KURMANJI -> "Di Cihê Agahdariyê de Demên Nimêjê"
    }

    fun persistentNotificationDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Telefonun üst bildirim ekranında güncel namaz vakitlerini ve sıradaki vakti sürekli gösterir."
        AppLanguage.KURMANJI -> "Li jora ekrana telefonê di beşa agahdariyê de demên nimêjê her tim nîşan dide."
    }

    fun grantNotificationPermission(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Bildirim İzni Ver"
        AppLanguage.KURMANJI -> "Destûra Agahdariyê Bide"
    }

    // Pre-Adhan 30 Minutes Approaching Reminder (High-Volume Alert)
    fun preAdhanReminderTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Ezana 30 Dakika Kala Bildirimi (Yüksek Sesli)"
        AppLanguage.KURMANJI -> "Agahdariya 30 Xulekan Berî Bangê (Dengê Bilind)"
    }

    fun preAdhanReminderDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Her ezana 30 dakika kaldığında 'Ezana az kaldı' uyarısını en yüksek bildirim önceliği ve 3 saniyelik yüksek sesli alarmıyla gönderir."
        AppLanguage.KURMANJI -> "Gava 30 xulek ji her bangê re bimîne, hişyariya 'Kêm ma ji bangê re' bi pêşîniya herî bilind û dengê bilind ê 3 çirkeyan dişîne."
    }

    fun preAdhanNotificationTitle(prayerName: String, lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "$prayerName Vakti Yaklaşıyor • Ezana Az Kaldı!"
        AppLanguage.KURMANJI -> "Wextê $prayerName Nêzîk Dibe • Kêm Ma Ji Bangê Re!"
    }

    fun preAdhanNotificationContent(prayerName: String, time: String, lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "$prayerName ezanına 30 dakika kaldı (Vakit: $time). Abdestinizi alıp namaza hazırlanabilirsiniz."
        AppLanguage.KURMANJI -> "30 xulek ji banga $prayerName re ma (Wext: $time). Hûn dikarin destmêja xwe bigirin û amadehiya nimêjê bikin."
    }

    fun testPreAdhanButton(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Yüksek Sesli 'Ezana Az Kaldı' Bildirimini Test Et"
        AppLanguage.KURMANJI -> "Agahdariya Dengê Bilind (30 Xulek) Ceribandin"
    }

    // Tesbihat & Zikirmatik
    fun quickTesbihatTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Namaz Tesbihatı & Zikirmatik"
        AppLanguage.KURMANJI -> "Tesbîhata Nimêjê & Zikirmatîk"
    }

    fun quickTesbihatDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "33×3 Sünnet Tesbihat, Âyetel Kürsî & Zikir Sayacı"
        AppLanguage.KURMANJI -> "Tesbîhata 33×3, Ayeta Kursî & Jimartina Zikran"
    }

    fun tesbihatScreenTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Tesbihat & Zikirmatik"
        AppLanguage.KURMANJI -> "Tesbîhat û Zikirmatîk"
    }

    fun tesbihatGuidedTab(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Namaz Tesbihatı"
        AppLanguage.KURMANJI -> "Tesbîhata Nimêjê"
    }

    fun tesbihatZikirTab(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Zikirmatik"
        AppLanguage.KURMANJI -> "Zikirmatîk"
    }

    // Esma-ul Husna
    fun quickEsmaTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Esmâ-ül Hüsnâ"
        AppLanguage.KURMANJI -> "Esma-ul Husna"
    }

    fun quickEsmaDesc(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Allah'ın 99 İsmi ve Anlamları"
        AppLanguage.KURMANJI -> "99 Navên Xwedê û Wateyên Wan"
    }

    fun esmaScreenTitle(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "Esmâ-ül Hüsnâ (99 İsim)"
        AppLanguage.KURMANJI -> "Esma-ul Husna (99 Nav)"
    }

    fun esmaSearchHint(lang: AppLanguage): String = when (lang) {
        AppLanguage.TURKISH -> "İsim, numara veya anlam ara..."
        AppLanguage.KURMANJI -> "Li nav, hejmar an wateyê bigere..."
    }
}


