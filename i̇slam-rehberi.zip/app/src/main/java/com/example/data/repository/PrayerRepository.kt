package com.example.data.repository

import com.example.data.local.AppPreferences
import com.example.data.model.NextPrayerInfo
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import com.example.data.remote.ApiClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

class PrayerRepository(
    private val preferences: AppPreferences,
    private val context: android.content.Context? = null
) {
    private val api = ApiClient.aladhanApi

    suspend fun getPrayerTimes(
        latitude: Double,
        longitude: Double,
        cityName: String,
        forceRefresh: Boolean = false,
        country: String = "",
        preferredTz: String = ""
    ): Result<PrayerTimes> = withContext(Dispatchers.IO) {
        val now = Date()
        val resolvedTzId = DiyanetCalculator.resolveTimeZoneId(
            latitude = latitude,
            longitude = longitude,
            cityName = cityName,
            country = country,
            preferredTz = preferredTz
        )
        val targetTz = DiyanetCalculator.getTimeZoneForId(resolvedTzId)
        val todayStr = SimpleDateFormat("dd-MM-yyyy", Locale.US).apply { timeZone = targetTz }.format(now)
        val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = targetTz }.format(now)
        val todayReadable = SimpleDateFormat("dd MMMM yyyy", Locale("tr")).apply { timeZone = targetTz }.format(now)

        val canUseNetwork = context == null || com.example.util.NetworkUtils.isNetworkAvailable(context)

        // Baseline high-precision ephemeris + Diyanet temkin (0, -7, +5, +4, +7, 0)
        val calculated = DiyanetCalculator.calculateTimes(
            latitude = latitude,
            longitude = longitude,
            date = now,
            cityName = cityName,
            country = country,
            preferredTz = resolvedTzId,
            isOfflineMode = !canUseNetwork
        )
        val rawNoTemkin = DiyanetCalculator.calculateRawAstronomicalMinutes(
            latitude = latitude,
            longitude = longitude,
            date = now,
            tz = targetTz
        )

        val cached = preferences.getCachedPrayerTimes()
        if (!forceRefresh && !canUseNetwork && isMatchingFreshCache(cached, cityName, latitude, longitude, todayIso)) {
            return@withContext Result.success(
                cached!!.copy(
                    isOffline = true,
                    cityName = cityName,
                    timezone = resolvedTzId,
                    dateIso = todayIso,
                    calculationMethod = "Çevrimdışı Önbellek"
                )
            )
        }

        if (canUseNetwork) {
            try {
                // Attempt live fetch from Aladhan with Diyanet method (id: 13) and exact target timezone
                val response = api.getTimings(
                    date = todayStr,
                    latitude = latitude,
                    longitude = longitude,
                    method = 13,
                    timezone = resolvedTzId
                )

                if (response.code == 200 && response.data?.timings != null) {
                    val t = response.data.timings
                    val d = response.data.date
                    val hijri = d?.hijri
                    val hijriStr = if (hijri != null) {
                        "${hijri.day ?: ""} ${hijri.month?.en ?: ""} ${hijri.year ?: ""}".trim()
                    } else {
                        ""
                    }.ifBlank { calculated.hijriDate }

                    val apiFajr = cleanTime(t.fajr)
                    val apiSunrise = cleanTime(t.sunrise)
                    val apiDhuhr = cleanTime(t.dhuhr)
                    val apiAsr = cleanTime(t.asr)
                    val apiMaghrib = cleanTime(t.maghrib)
                    val apiIsha = cleanTime(t.isha)

                    val apiCandidate = PrayerTimes(
                        fajr = apiFajr,
                        sunrise = apiSunrise,
                        dhuhr = apiDhuhr,
                        asr = apiAsr,
                        maghrib = apiMaghrib,
                        isha = apiIsha,
                        dateReadable = todayReadable,
                        hijriDate = hijriStr,
                        calculationMethod = "Standart Astronomik Güneş Açısı (Fecr 18°, Yatsı 17°)",
                        isOffline = false,
                        cityName = cityName,
                        latitude = latitude,
                        longitude = longitude,
                        timezone = resolvedTzId,
                        dateIso = todayIso
                    )

                    val finalTimes = reconcileOnlineWithDiyanet(
                        online = apiCandidate,
                        calculated = calculated,
                        rawNoTemkin = rawNoTemkin
                    )

                    // Cache for offline access
                    preferences.saveCachedPrayerTimes(finalTimes)
                    preferences.setLastCoordinates(latitude, longitude)

                    return@withContext Result.success(finalTimes)
                }
            } catch (_: Exception) {
                // Network failure: fall back to fresh matching cache or offline Diyanet ephemeris
            }
        }

        // Only reuse cached timings if date AND location match today's target coordinates
        if (isMatchingFreshCache(cached, cityName, latitude, longitude, todayIso)) {
            return@withContext Result.success(
                cached!!.copy(
                    isOffline = true,
                    cityName = cityName,
                    timezone = resolvedTzId,
                    dateIso = todayIso,
                    calculationMethod = "Çevrimdışı Önbellek"
                )
            )
        }

        // Save fresh offline calculation so alarms/boot receiver always use up-to-date timings
        val offlineResult = calculated.copy(isOffline = true)
        preferences.saveCachedPrayerTimes(offlineResult)
        preferences.setLastCoordinates(latitude, longitude)
        return@withContext Result.success(offlineResult)
    }

    /**
     * Determines which prayer is next, how many milliseconds remain,
     * and whether a prayer is currently underway.
     */
    fun calculateNextPrayer(times: PrayerTimes): NextPrayerInfo {
        val now = System.currentTimeMillis()

        // List of all 6 points of the day in chronological order
        val prayers = listOf(
            PrayerType.FAJR,
            PrayerType.SUNRISE,
            PrayerType.DHUHR,
            PrayerType.ASR,
            PrayerType.MAGHRIB,
            PrayerType.ISHA
        )

        // Find the next upcoming time today
        for (prayer in prayers) {
            val millis = times.getPrayerMillis(prayer, forTomorrowIfPassed = false)
            if (millis > now) {
                return NextPrayerInfo(
                    type = prayer,
                    time = times.getTimeFor(prayer),
                    millisRemaining = millis - now,
                    isCurrent = false
                )
            }
        }

        // If all prayers today have passed, the next prayer is tomorrow's Fajr
        val tomorrowFajrMillis = times.getPrayerMillis(PrayerType.FAJR, forTomorrowIfPassed = true)
        return NextPrayerInfo(
            type = PrayerType.FAJR,
            time = times.fajr,
            millisRemaining = (tomorrowFajrMillis - now).coerceAtLeast(0L),
            isCurrent = false
        )
    }

    /**
     * Identifies the current active prayer period (e.g. between Dhuhr and Asr, Dhuhr is active).
     */
    fun getCurrentActivePrayer(times: PrayerTimes): PrayerType {
        val now = System.currentTimeMillis()
        val prayers = listOf(
            PrayerType.FAJR,
            PrayerType.SUNRISE,
            PrayerType.DHUHR,
            PrayerType.ASR,
            PrayerType.MAGHRIB,
            PrayerType.ISHA
        )

        var active = PrayerType.ISHA
        for (prayer in prayers) {
            val millis = times.getPrayerMillis(prayer, forTomorrowIfPassed = false)
            if (now >= millis) {
                active = prayer
            } else {
                break
            }
        }
        return active
    }

    companion object {
        private val HH_MM_REGEX = Regex("^([01]\\d|2[0-3]):[0-5]\\d$")

        fun cleanTime(timeWithTz: String?): String {
            if (timeWithTz.isNullOrBlank()) return "--:--"
            val candidate = timeWithTz.trim().substringBefore(" ").take(5)
            return if (HH_MM_REGEX.matches(candidate)) candidate else "--:--"
        }

        fun parseMinutesOfDay(hhmm: String): Int? {
            if (!HH_MM_REGEX.matches(hhmm)) return null
            val h = hhmm.substring(0, 2).toIntOrNull() ?: return null
            val m = hhmm.substring(3, 5).toIntOrNull() ?: return null
            return h * 60 + m
        }

        fun areTimesValidChronological(times: PrayerTimes): Boolean {
            val m0 = parseMinutesOfDay(times.fajr) ?: return false
            val m1 = parseMinutesOfDay(times.sunrise) ?: return false
            val m2 = parseMinutesOfDay(times.dhuhr) ?: return false
            val m3 = parseMinutesOfDay(times.asr) ?: return false
            val m4 = parseMinutesOfDay(times.maghrib) ?: return false
            val m5 = parseMinutesOfDay(times.isha) ?: return false
            return m0 < m1 && m1 < m2 && m2 < m3 && m3 < m4 && m4 < m5
        }

        fun isMatchingFreshCache(
            cached: PrayerTimes?,
            cityName: String,
            latitude: Double,
            longitude: Double,
            expectedDateIso: String
        ): Boolean {
            if (cached == null) return false
            if (cached.dateIso.isBlank() || cached.dateIso != expectedDateIso) return false
            if (cached.cityName != cityName) return false
            if (abs(cached.latitude - latitude) > 0.015 || abs(cached.longitude - longitude) > 0.015) return false
            return areTimesValidChronological(cached)
        }

        /**
         * Ensures online API responses accurately honor Diyanet temkin offsets (-7 Sunrise,
         * +5 Dhuhr, +4 Asr, +7 Maghrib) and target timezone/DST. If Aladhan returns raw untuned
         * astronomical timings or skewed timezone values, uses the exact Diyanet ephemeris timings
         * while keeping live Hijri metadata.
         */
        fun reconcileOnlineWithDiyanet(
            online: PrayerTimes,
            calculated: PrayerTimes,
            rawNoTemkin: DiyanetCalculator.RawSolarMinutes
        ): PrayerTimes {
            if (!areTimesValidChronological(online)) {
                return calculated.copy(
                    hijriDate = online.hijriDate.ifBlank { calculated.hijriDate },
                    isOffline = false
                )
            }

            val apiSunrise = parseMinutesOfDay(online.sunrise)!!
            val apiDhuhr = parseMinutesOfDay(online.dhuhr)!!
            val apiAsr = parseMinutesOfDay(online.asr)!!
            val apiMaghrib = parseMinutesOfDay(online.maghrib)!!

            val calcDhuhr = parseMinutesOfDay(calculated.dhuhr)!!
            val calcSunrise = parseMinutesOfDay(calculated.sunrise)!!
            val calcAsr = parseMinutesOfDay(calculated.asr)!!
            val calcMaghrib = parseMinutesOfDay(calculated.maghrib)!!

            // 1. Check timezone discrepancy (> 15 mins shift on solar noon)
            val tzMismatch = abs(apiDhuhr - calcDhuhr) > 15

            // 2. Check whether online response omitted Diyanet temkin offsets
            //    (untuned Aladhan method=13 has sunrise ≈ rawSunrise, dhuhr ≈ rawDhuhr, maghrib ≈ rawMaghrib)
            val missingSunriseTemkin = abs(apiSunrise - rawNoTemkin.sunriseMin) <= 2 && abs(apiSunrise - calcSunrise) >= 4
            val missingDhuhrTemkin = abs(apiDhuhr - rawNoTemkin.dhuhrMin) <= 2 && abs(apiDhuhr - calcDhuhr) >= 3
            val missingAsrTemkin = abs(apiAsr - rawNoTemkin.asrMin) <= 2 && abs(apiAsr - calcAsr) >= 3
            val missingMaghribTemkin = abs(apiMaghrib - rawNoTemkin.maghribMin) <= 2 && abs(apiMaghrib - calcMaghrib) >= 4

            val missingTemkin = missingSunriseTemkin || missingDhuhrTemkin || missingAsrTemkin || missingMaghribTemkin

            // 3. Check general drift > 4 minutes on core diurnal markers
            val largeDrift = abs(apiSunrise - calcSunrise) > 4 ||
                abs(apiDhuhr - calcDhuhr) > 4 ||
                abs(apiAsr - calcAsr) > 4 ||
                abs(apiMaghrib - calcMaghrib) > 4

            return if (tzMismatch || missingTemkin || largeDrift) {
                calculated.copy(
                    hijriDate = online.hijriDate.ifBlank { calculated.hijriDate },
                    dateReadable = online.dateReadable.ifBlank { calculated.dateReadable },
                    isOffline = false
                )
            } else {
                online
            }
        }

        /**
         * Returns valid PrayerTimes for TODAY for alarm scheduling (BootReceiver / AdhanAlarmReceiver / Settings).
         * Never reuses stale dates from previous days or wrong cities.
         */
        fun resolveCurrentPrayerTimesForAlarms(preferences: AppPreferences, now: Date = Date()): PrayerTimes {
            val city = preferences.getSelectedCity()
            val lat = if (city.isGps) preferences.getLastLatitude() else city.latitude
            val lng = if (city.isGps) preferences.getLastLongitude() else city.longitude
            val tzId = DiyanetCalculator.resolveTimeZoneId(lat, lng, city.nameTr, city.country)
            val tz = DiyanetCalculator.getTimeZoneForId(tzId)
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }.format(now)

            val cached = preferences.getCachedPrayerTimes()
            if (isMatchingFreshCache(cached, city.nameTr, lat, lng, todayIso)) {
                return cached!!
            }

            val fresh = DiyanetCalculator.calculateTimes(
                latitude = lat,
                longitude = lng,
                date = now,
                cityName = city.nameTr,
                country = city.country,
                preferredTz = tzId,
                isOfflineMode = true
            )
            preferences.saveCachedPrayerTimes(fresh)
            return fresh
        }
    }
}
