package com.example.data.local

import com.example.data.model.AppLanguage
import com.example.data.model.ReligiousDay
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

object ReligiousDaysData {

    val RELIGIOUS_DAYS: List<ReligiousDay> = listOf(
        ReligiousDay(
            id = "regaip_2025",
            nameTr = "Regaip Kandili",
            nameKu = "Qendîla Rexeîbê",
            hijriDate = "1 Receb 1446",
            gregorianDateStr = "2025-01-02",
            displayDateTr = "2 Ocak 2025 Perşembe",
            displayDateKu = "2 Rêbendan 2025 Pêncşem",
            descriptionTr = "Üç ayların müjdecisi ve Recep ayının ilk Cuma gecesi.",
            descriptionKu = "Mizgîniya hersê mehan û şeva yekemîn a înê ya meha Recebê.",
            significanceTr = "Regaip; rağbet edilen, arzulanan, bağış ve ihsanı bol olan demektir. Rahmet kapılarının ardına kadar açıldığı bu mübarek gece, kulun Rabbine yönelmesi, samimi tevbe ve niyazda bulunması için büyük bir fırsattır.",
            significanceKu = "Rexeîb; tişta ku jê re hezkirin heye, bexş û xêra zêde tê wateya. Di vê şeva pîroz de deriyên rehmetê vedibin û bende bi tobe û lavakirinê ber bi Rebbê xwe ve diçe.",
            recommendedDeedsTr = "• Bu geceyi kaza veya nafile namazlarla ihya etmek.\n• Bol bol istiğfar getirmek ve Kur'an-ı Kerim tilavet etmek.\n• Gündüzünde oruç tutmak ve fakirleri sevindirmek.",
            recommendedDeedsKu = "• Şevê bi nimêjên qeza an nafile zindî kirin.\n• Gelek caran tobe kirin û Qur'ana Pîroz xwendin.\n• Roja wê bi rojî derbas kirin û alîkariya hejaran kirin.",
            celebrationMessageTr = "Regaip Kandiliniz mübarek olsun. Bu kutlu gecenin ailenize, milletimize ve tüm İslam alemine huzur, sağlık ve bereket getirmesini Cenab-ı Hak'tan niyaz ederiz.",
            celebrationMessageKu = "Qendîla we ya Rexeîbê pîroz be. Xwedayê mezin vê şeva bimbarek ji bo we, malbata we û hemû cîhana îslamê bike wesîleya aramî, tenduristî û aşitiyê."
        ),
        ReligiousDay(
            id = "mirac_2025",
            nameTr = "Miraç Kandili",
            nameKu = "Qendîla Mîracê",
            hijriDate = "27 Receb 1446",
            gregorianDateStr = "2025-01-26",
            displayDateTr = "26 Ocak 2025 Pazar",
            displayDateKu = "26 Rêbendan 2025 Yekşem",
            descriptionTr = "Peygamber Efendimiz'in (s.a.v.) ilahi huzura yükseldiği ve beş vakit namazın farz kılındığı gece.",
            descriptionKu = "Şeva ku Pêxemberê me (s.a.v.) derket hizûra Xwedê û pênc wext nimêj ferz bû.",
            significanceTr = "Miraç; bir yükseliş ve manevi arınış yolculuğudur. Sevgili Peygamberimiz Mescid-i Haram'dan Mescid-i Aksa'ya, oradan da Sidretü'l-Münteha'ya yükseltilmiştir. Beş vakit namaz, Bakara Suresi'nin son ayetleri (Amenerrasulü) ve Allah'a şirk koşmayanların affedileceği müjdesi bu gecede hediye edilmiştir.",
            significanceKu = "Mîrac; rêwîtiya hilkişîn û paqijiya ruhanî ye. Pêxemberê me ji Mescîda Heram ber bi Mescîda Eqsa ve, ji wir jî ber bi ezmanan ve bilind bû. Pênc wext nimêj, ayetên dawî yên sûreya Beqere di vê şevê de hatin dayîn.",
            recommendedDeedsTr = "• Namaz ibadetine gereken itinayı göstermek.\n• Efendimiz'e (s.a.v.) salat ve selam getirmek.\n• Anne, baba ve akrabaları arayıp hayır dualarını almak.",
            recommendedDeedsKu = "• Girîngî dayîna nimêjê.\n• Şandina salawat li ser Pêxember (s.a.v.).\n• Xwestina duayên xêrê ji dayik û bavan.",
            celebrationMessageTr = "Miraç Kandiliniz mübarek olsun. Dualarınızın kabul, ibadetlerinizin makbul olmasını dileriz.",
            celebrationMessageKu = "Qendîla we ya Mîracê bimbarek be. Bila duayên we qebûl û gunehên we baxşandî bin."
        ),
        ReligiousDay(
            id = "berat_2025",
            nameTr = "Berat Kandili",
            nameKu = "Qendîla Beratê",
            hijriDate = "15 Şaban 1446",
            gregorianDateStr = "2025-02-13",
            displayDateTr = "13 Şubat 2025 Perşembe",
            displayDateKu = "13 Reşemî 2025 Pêncşem",
            descriptionTr = "Günahlardan arınma, af ve mağfiret gecesi; Ramazan-ı Şerif'in habercisi.",
            descriptionKu = "Şeva lêborîn û paqijbûna ji gunehan; mizgîniya meha pîroz a Remezanê.",
            significanceTr = "Berat; borçtan, hastalıktan, suç ve cezadan kurtulmak demektir. Şaban ayının 15. gecesi olan Berat gecesinde Yüce Allah'ın rahmet tecellileri tüm alemi kuşatır, kulların rızık, ecel ve amel takdirleri melekler tarafından düzenlenir.",
            significanceKu = "Berat; tê wateya rizgariya ji deyndarî, guneh û ezabê. Di vê şevê de deriyên efûyê tên vekirin û Rebbê me her kesê tobe bike dibaxşîne.",
            recommendedDeedsTr = "• Gecenin ihyası: Yatsı ve sabah namazlarını cemaatle kılmak.\n• Küsleri barıştırmak ve gönül kırmaktan sakınmak.\n• Gece boyunca \"Allahümme inneke afüvvün tuhibbü'l-afve fa'fü annî\" duasını çokça okumak.",
            recommendedDeedsKu = "• Zindîkirina şevê bi duayan.\n• Lihevanîna kesên ku ji hev xeyidîne.\n• Xwendina duaya lêborînê.",
            celebrationMessageTr = "Berat Kandilinizi en kalbi duygularımızla tebrik eder, beratını eline alan bahtiyar kullardan olmanızı Yüce Rabbimizden niyaz ederiz.",
            celebrationMessageKu = "Em bi dil û can Qendîla we ya Beratê pîroz dikin. Bila ev şev bibe sedema rizgarbûna me ji agirê dojehê."
        ),
        ReligiousDay(
            id = "ramazan_baslangici_2025",
            nameTr = "Ramazan-ı Şerif Başlangıcı",
            nameKu = "Destpêka Meha Remezana Pîroz",
            hijriDate = "1 Ramazan 1446",
            gregorianDateStr = "2025-03-01",
            displayDateTr = "1 Mart 2025 Cumartesi",
            displayDateKu = "1 Adar 2025 Şemî",
            descriptionTr = "On bir ayın sultanı, oruç, Kur'an ve rahmet ayının ilk günü.",
            descriptionKu = "Roja yekem a meha rehmet, Qur'an û rojiya Remezanê.",
            significanceTr = "Ramazan ayı; Kur'an-ı Kerim'in indirildiği, cennet kapılarının açılıp cehennem kapılarının kapandığı, şeytanların zincire vurulduğu bereketli bir aydır. Oruç ile nefisler terbiye edilir, sabır ve şükür idraki gelişir.",
            significanceKu = "Meha Remezanê; meha ku Qur'an tê de daketiye, deriyên bihûştê vebûne û deriyên dojehê hatine girtin. Rojiya vê mehê can û rihê mirov paqij dike.",
            recommendedDeedsTr = "• Orucu sıhhat ve ihlasla tutmak.\n• Mukabele takip etmek ve teravih namazlarını eda etmek.\n• İftar sofralarında yoksulları ve kimsesizleri ağırlamak.",
            recommendedDeedsKu = "• Girtina rojiya bi îxlas.\n• Xwendina Qur'anê û nimêjên terawîhê.\n• Parvekirina xwarina fitarê bi hejaran re.",
            celebrationMessageTr = "Mübarek Ramazan ayınız hayırlı, bereketli ve huzurlu olsun. Oruçlarımız, dualarımız ve ibadetlerimiz dergah-ı izzette makbul olsun.",
            celebrationMessageKu = "Meha Remezana we pîroz û bimbarek be. Xwedê rojiya we û îbadetên we qebûl bike."
        ),
        ReligiousDay(
            id = "kadir_gecesi_2025",
            nameTr = "Kadir Gecesi",
            nameKu = "Şeva Qedrê ya Pîroz",
            hijriDate = "27 Ramazan 1446",
            gregorianDateStr = "2025-03-26",
            displayDateTr = "26 Mart 2025 Çarşamba",
            displayDateKu = "26 Adar 2025 Çarşem",
            descriptionTr = "Bin aydan daha hayırlı olan, Kur'an-ı Kerim'in indirilmeye başlandığı mübarek gece.",
            descriptionKu = "Şeva ku ji hezar mehî çêtir e û Qur'ana pîroz tê de dest pê kir dakeve erdê.",
            significanceTr = "Kadir Gecesi; Kur'an-ı Kerim'de müstakil bir sureyle (Kadir Suresi) şerefi beyan edilmiş, bin aydan (yaklaşık 83 yıl 4 aydan) daha hayırlı olduğu müjdelenmiş en faziletli gecedir. Melekler ve Cebrail (a.s.) yeryüzüne fevc fevc iner.",
            significanceKu = "Şeva Qedrê; şeva ku di Sûreya Qedrê de hatiye pesnandin û ji hezar mehî bi xêrtir e. Milyaket û Cebraîl (a.s.) heta berbangê li ser rûyê erdê ji bo bawermendan aramî û selametiyê dixwazin.",
            recommendedDeedsTr = "• Geceyi uyanık geçirip tevbe ve niyaz ile değerlendirmek.\n• Kur'an-ı Kerim tilavet etmek ve tefekkürde bulunmak.\n• Hz. Aişe validemizin rivayet ettiği af duasını okumak.",
            recommendedDeedsKu = "• Zindîkirina şevê bi tobe û lavakirinê.\n• Xwendin û fehmkirina Qur'anê.\n• Xwestina lêborînê.",
            celebrationMessageTr = "Bin aydan daha hayırlı olan Kadir Geceniz mübarek olsun. Dualarınızın kabul olması dileğiyle hayırlı kandiller.",
            celebrationMessageKu = "Şeva we ya Qedrê ku ji hezar mehî bi xêrtir e bimbarek be. Bila hemû duayên we werin qebûlkirin."
        ),
        ReligiousDay(
            id = "ramazan_bayrami_2025",
            nameTr = "Ramazan Bayramı (1. Gün)",
            nameKu = "Cejna Remezanê (Roja Yekem)",
            hijriDate = "1 Şevval 1446",
            gregorianDateStr = "2025-03-30",
            displayDateTr = "30 Mart 2025 Pazar",
            displayDateKu = "30 Adar 2025 Yekşem",
            descriptionTr = "Ramazan orucunun tamamlanmasıyla Müslümanların birlik, sevinç ve kardeşlik bayramı.",
            descriptionKu = "Roja şahî, biratî û spasdarî ya temamkirina meha Remezanê.",
            significanceTr = "Ramazan Bayramı; bir ay boyunca tutulan oruçların, verilen fıtır sadakalarının ve yapılan ibadetlerin sevinçle taçlandırıldığı kutlu gündür. Kardeşlik bağları kuvvetlenir, küsler barışır, yetimler ve çocuklar sevindirilir.",
            significanceKu = "Cejna Remezanê; roja spasdariya ji bo qedandina meha rojiya pîroz e. Di vê rojê de dildarî, serdana xizm û hevalan û kêfxweşkirina zarok û hejaran esas e.",
            recommendedDeedsTr = "• Sabahleyin bayram namazını cemaatle kılmak.\n• Sıla-i rahim yaparak büyükleri ziyaret etmek ve hayır dualarını almak.\n• Çocukları sevindirmek ve küskünlüklere son vermek.",
            recommendedDeedsKu = "• Kirina nimêja cejnê bi komî.\n• Serdana dê, bav û xizmên xwe.\n• Kêfxweşkirina zarokan û hejaran.",
            celebrationMessageTr = "Ramazan Bayramınız mübarek olsun! Sevdiklerinizle birlikte sağlıklı, huzurlu ve neşe dolu nice bayramlar dileriz.",
            celebrationMessageKu = "Cejna we ya Remezanê pîroz be! Em ji bo we û malbata we rojeke tijî şahî, tenduristî û aşitî dixwazin."
        ),
        ReligiousDay(
            id = "kurban_bayrami_2025",
            nameTr = "Kurban Bayramı (1. Gün)",
            nameKu = "Cejna Qurbanê (Roja Yekem)",
            hijriDate = "10 Zilhicce 1446",
            gregorianDateStr = "2025-06-06",
            displayDateTr = "6 Haziran 2025 Cuma",
            displayDateKu = "6 Pûşper 2025 În",
            descriptionTr = "Hz. İbrahim ve İsmail'in teslimiyetini anma ve Allah'a yakınlaşma bayramı.",
            descriptionKu = "Cejna hezkirin, xweberxwedan û nêzîkbûna ji Xwedê re.",
            significanceTr = "Kurban; kelime anlamıyla Allah'a yaklaşmak demektir. Hz. İbrahim'in sadakati, Hz. İsmail'in teslimiyetiyle sembolleşen bu bayram; paylaşmayı, yoksulun elinden tutmayı ve nefsi kurban edebilmeyi öğretir. Arefe günü sabahından bayramın 4. günü ikindi vaktine kadar teşrik tekbirleri getirilir.",
            significanceKu = "Qurban; nêzîkbûna ji Xwedê re ye. Ev cejn bîranîna teslîmiyeta Hz. Îbrahîm û kurê wî Hz. Îsmaîl e. Hezkirin, qurbankirin û parvekirina goştê qurbanê bi feqîran re tê kirin.",
            recommendedDeedsTr = "• Bayram namazını eda etmek ve kurban ibadetini ifa etmek.\n• Teşrik tekbirlerini (Allahu Ekber, Allahu Ekber...) unutmamak.\n• Kurban etini ihtiyaç sahiplerine dağıtmak.",
            recommendedDeedsKu = "• Kirina nimêja cejna qurbanê û serjêkirina qurbanê.\n• Gotina tekbîrên teşrîqê li pey her nimêjê.\n• Belavkirina goştê qurbanê li ser mihtacan.",
            celebrationMessageTr = "Mübarek Kurban Bayramınızı tebrik eder; kesilen kurbanların ve yapılan duaların makbul olmasını Yüce Mevla'dan niyaz ederiz.",
            celebrationMessageKu = "Cejna we ya Qurbanê bimbarek be! Qurban û duayên we li ba Xwedê werin qebûlkirin."
        ),
        ReligiousDay(
            id = "hicri_yilbasi_2025",
            nameTr = "Hicri Yılbaşı",
            nameKu = "Serê Sala Koçî (Hicrî)",
            hijriDate = "1 Muharrem 1447",
            gregorianDateStr = "2025-06-26",
            displayDateTr = "26 Haziran 2025 Perşembe",
            displayDateKu = "26 Pûşper 2025 Pêncşem",
            descriptionTr = "Hz. Peygamber'in Medine'ye hicretini esas alan Hicri 1447 yılının başlangıcı.",
            descriptionKu = "Destpêka sala nû ya hicrî 1447 û bîranîna koça ber bi Medîneyê.",
            significanceTr = "Hicret; zulümden adalete, batıldan hakka doğru ilahi bir yürüyüşün adıdır. Hz. Ömer'in halifeliği döneminde Peygamber Efendimiz'in Mekke'den Medine'ye hicreti İslam takviminin başlangıcı kabul edilmiştir.",
            significanceKu = "Hicret; koça pîroz a ji zilmê ber bi edaletê ye. Destpêka sala hicrî bi bîranîna koça Hz. Muhemmed (s.a.v.) tê pîrozkirin.",
            recommendedDeedsTr = "• Geçmiş bir yılın muhasebesini yapmak.\n• Yeni yıl için hayırlı niyetlerde bulunmak.\n• Muharrem ayının faziletli günlerinde nafile oruç tutmak.",
            recommendedDeedsKu = "• Hesabê sala borî kirin.\n• Niyeta qenciyan ji bo sala nû kirin.\n• Girtina rojiya meha Miherremê.",
            celebrationMessageTr = "Hicri Yeni Yılınızı tebrik eder, tüm İslam alemine ve insanlığa barış, kardeşlik ve adalet getirmesini dileriz.",
            celebrationMessageKu = "Sala we ya nû ya hicrî pîroz be. Bila bibe wesîleya xêr, selametî û serkeftinê."
        ),
        ReligiousDay(
            id = "asure_gunu_2025",
            nameTr = "Aşure Günü",
            nameKu = "Roja Aşûrayê",
            hijriDate = "10 Muharrem 1447",
            gregorianDateStr = "2025-07-05",
            displayDateTr = "5 Temmuz 2025 Cumartesi",
            displayDateKu = "5 Tîrmeh 2025 Şemî",
            descriptionTr = "Peygamberlerin kurtuluşa erdiği, bereket ve Kerbela şehitlerini hüzünle anma günü.",
            descriptionKu = "Roja bereket, rizgarbûna pêxemberan û bîranîna şehîdên Kerbelayê.",
            significanceTr = "Muharrem ayının 10. günü olan Aşure günü; Hz. Nuh'un gemisinin tufandan kurtulduğu, Hz. Musa'nın Firavun'un zulmünden kurtulduğu gündür. Aynı zamanda Sevgili Peygamberimiz'in ciğerparesi Hz. Hüseyin ve Ehl-i Beyt'in Kerbela'da şehit edildiği derin bir hüzün günüdür.",
            significanceKu = "Roja Aşûrayê; roja xelasiya Hz. Nûh û Hz. Mûsa ye. Di heman demê de roja şehîdbûna neviyê Pêxember Hz. Huseyîn û hevalên wî li Kerbelayê ye.",
            recommendedDeedsTr = "• 9-10 veya 10-11 Muharrem günlerinde oruç tutmak.\n• Aşure tatlısı pişirip komşulara ve yoksullara dağıtmak.\n• Kerbela şehitlerine Fatihalar ve dualar göndermek.",
            recommendedDeedsKu = "• Girtina rojiya 9-10 an 10-11'ê Miherremê.\n• Belavkirina xwarin û şîraniyê li ser cîranan.\n• Şandina Fatiha û duayan ji bo şehîdên Kerbelayê.",
            celebrationMessageTr = "Aşure Gününüz mübarek olsun. Bu anlamlı günün birliğimize, beraberliğimize ve kardeşliğimize vesile olmasını dileriz.",
            celebrationMessageKu = "Roja we ya Aşûrayê pîroz be. Bila ev roj bibe wesîleya yekîtî û biratiya me."
        ),
        ReligiousDay(
            id = "mevlid_2025",
            nameTr = "Mevlid Kandili",
            nameKu = "Qendîla Mewlûdê ya Pîroz",
            hijriDate = "12 Rebiülevvel 1447",
            gregorianDateStr = "2025-09-03",
            displayDateTr = "3 Eylül 2025 Çarşamba",
            displayDateKu = "3 Rezber 2025 Çarşem",
            descriptionTr = "Alemlere rahmet olarak gönderilen Sevgili Peygamberimiz'in (s.a.v.) dünyayı teşrif ettiği kutlu gece.",
            descriptionKu = "Şeva zayîna pîroz a Pêxemberê me yê delal (silavên Xwedê lê bin).",
            significanceTr = "Mevlid; doğum zamanı demektir. İnsanlığın cehalet ve zulüm karanlığında bocaladığı bir dönemde, alemlere rahmet olarak gönderilen Hz. Muhammed Mustafa (s.a.v.) bu gecede dünyayı şereflendirmiştir. O'nun ahlakı, sünneti ve rehberliği insanlığın kurtuluş reçetesidir.",
            significanceKu = "Mewlûd; roja jidayikbûnê ye. Pêxemberê me yê delal Hz. Muhemmed (s.a.v.) di vê şevê de hatiye dinyayê û riya rast nîşanî mirovahiyê daye.",
            recommendedDeedsTr = "• Peygamber Efendimiz'in hayatını ve sünnet-i seniyyesini okumak.\n• Mevlid-i Şerif okumak ve salavat-ı şerife getirmek.\n• İhtiyaç sahiplerini sevindirip ikramda bulunmak.",
            recommendedDeedsKu = "• Xwendina jiyana Pêxember.\n• Xwendina Mewlûda Şerîf û gotina salawatan.\n• Alîkarî û xêrxwaziya ji bo hejaran.",
            celebrationMessageTr = "Alemlere rahmet olarak gönderilen Peygamber Efendimiz'in dünyayı şereflendirdiği Mevlid Kandiliniz mübarek olsun.",
            celebrationMessageKu = "Qendîla we ya Mewlûdê ya zayîna Pêxemberê me pîroz be. Bila rêya wî her tim bibe rêbera me."
        )
    )

    private val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    /**
     * Calculates days difference from today to the given date string.
     */
    fun getDaysDifference(gregorianDateStr: String): Long {
        return try {
            val target = dateFormat.parse(gregorianDateStr) ?: return -9999
            val todayCal = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val targetCal = Calendar.getInstance().apply {
                time = target
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
            val diffMs = targetCal.timeInMillis - todayCal.timeInMillis
            TimeUnit.MILLISECONDS.toDays(diffMs)
        } catch (e: Exception) {
            -9999
        }
    }

    /**
     * Returns the closest upcoming or ongoing religious day along with days remaining.
     */
    fun getNextUpcomingReligiousDay(): Pair<ReligiousDay, Long>? {
        var closest: ReligiousDay? = null
        var minDays: Long = Long.MAX_VALUE

        for (day in RELIGIOUS_DAYS) {
            val diff = getDaysDifference(day.gregorianDateStr)
            if (diff >= 0 && diff < minDays) {
                minDays = diff
                closest = day
            }
        }

        return if (closest != null) Pair(closest, minDays) else null
    }
}
