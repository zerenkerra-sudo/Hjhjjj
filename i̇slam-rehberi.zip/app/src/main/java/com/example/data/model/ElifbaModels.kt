package com.example.data.model

data class ElifbaItem(
    val id: String,
    val arabicText: String,
    val letterNameTr: String,
    val letterNameKu: String,
    val pronunciationTr: String,
    val pronunciationKu: String,
    val noteTr: String = "",
    val noteKu: String = ""
) {
    fun getLetterName(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) letterNameKu else letterNameTr
    }

    fun getPronunciation(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) pronunciationKu else pronunciationTr
    }

    fun getNote(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) noteKu else noteTr
    }
}

data class ElifbaLesson(
    val id: String,
    val lessonNumber: Int,
    val titleTr: String,
    val titleKu: String,
    val subtitleTr: String,
    val subtitleKu: String,
    val descriptionTr: String,
    val descriptionKu: String,
    val items: List<ElifbaItem>
) {
    fun getTitle(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) titleKu else titleTr
    }

    fun getSubtitle(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) subtitleKu else subtitleTr
    }

    fun getDescription(language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) descriptionKu else descriptionTr
    }
}
