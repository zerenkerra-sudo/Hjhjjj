package com.example.data.remote

import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query

interface AladhanApi {

    /**
     * Fetches prayer times from Aladhan API using method=13 (Diyanet İşleri Başkanlığı, Turkey)
     */
    @GET("v1/timings/{date}")
    suspend fun getTimings(
        @Path("date") date: String, // DD-MM-YYYY format
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("method") method: Int = 13, // 13 is Diyanet İşleri Başkanlığı
        @Query("timezonestring") timezone: String? = null
    ): AladhanApiResponse

    @GET("v1/timingsByCity/{date}")
    suspend fun getTimingsByCity(
        @Path("date") date: String,
        @Query("city") city: String,
        @Query("country") country: String = "Turkey",
        @Query("method") method: Int = 13
    ): AladhanApiResponse
}
