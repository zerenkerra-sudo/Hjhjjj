package com.example.data.model

data class SurahInfo(
    val number: Int,
    val nameArabic: String,
    val nameTr: String,
    val nameKu: String,
    val meaningTr: String,
    val meaningKu: String,
    val versesCount: Int,
    val revelationTypeTr: String, // Mekke / Medine
    val revelationTypeKu: String, // Mekkî / Medenî
    val startPage: Int = 1,
    val startJuz: Int = 1
) {
    fun getDisplayName(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> nameTr
            AppLanguage.KURMANJI -> nameKu
        }
    }

    fun getMeaning(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> meaningTr
            AppLanguage.KURMANJI -> meaningKu
        }
    }

    fun getRevelation(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> revelationTypeTr
            AppLanguage.KURMANJI -> revelationTypeKu
        }
    }
}

data class JuzInfo(
    val number: Int,
    val startSurahNumber: Int,
    val startSurahNameTr: String,
    val startSurahNameKu: String,
    val startAyah: Int,
    val endSurahNumber: Int,
    val endSurahNameTr: String,
    val endSurahNameKu: String,
    val endAyah: Int,
    val startPage: Int,
    val endPage: Int
) {
    fun getDisplayName(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> "$number. Cüz"
            AppLanguage.KURMANJI -> "Cizê $number"
        }
    }

    fun getRangeDescription(language: AppLanguage): String {
        val startName = if (language == AppLanguage.TURKISH) startSurahNameTr else startSurahNameKu
        val endName = if (language == AppLanguage.TURKISH) endSurahNameTr else endSurahNameKu
        return "$startName $startAyah - $endName $endAyah (Sayfa $startPage - $endPage)"
    }
}

data class PageInfo(
    val pageNumber: Int,
    val juzNumber: Int,
    val mainSurahNumber: Int,
    val mainSurahNameTr: String,
    val mainSurahNameKu: String
)

data class AyahItem(
    val numberInSurah: Int,
    val textArabic: String,
    val translationTr: String,
    val translationKuLatin: String,
    val audioUrl: String = ""
)

data class SurahDetail(
    val info: SurahInfo,
    val ayahs: List<AyahItem>
)

data class PageAyah(
    val surahNumber: Int,
    val surahNameArabic: String,
    val surahNameTr: String,
    val surahNameKu: String,
    val numberInSurah: Int,
    val textArabic: String,
    val translationTr: String,
    val translationKuLatin: String
)

data class QuranPageDetail(
    val pageNumber: Int,
    val juzNumber: Int,
    val mainSurahNumber: Int,
    val mainSurahNameArabic: String,
    val mainSurahNameTr: String,
    val mainSurahNameKu: String,
    val ayahs: List<PageAyah>
)

