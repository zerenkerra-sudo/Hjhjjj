package com.example.data.model

enum class PrayerType(
    val key: String,
    val turkishName: String,
    val kurmanjiName: String,
    val hasAdhan: Boolean,
    val defaultAdhanEnabled: Boolean,
    val soundAsset: String
) {
    FAJR("fajr", "Sabah (İmsak)", "Berbanga Sibê", true, true, "adhan_fajr.mp3"),
    SUNRISE("sunrise", "Güneş", "Rojhilat", false, false, ""),
    DHUHR("dhuhr", "Öğle", "Nîvro", true, true, "adhan.mp3"),
    ASR("asr", "İkindi", "Esir (Êvarî)", true, true, "adhan.mp3"),
    MAGHRIB("maghrib", "Akşam", "Şam (Meẍrîb)", true, true, "adhan.mp3"),
    ISHA("isha", "Yatsı", "Êşa (Derengî)", true, true, "adhan.mp3");

    fun getName(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> turkishName
            AppLanguage.KURMANJI -> kurmanjiName
        }
    }
}
