package com.example.data.model

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

enum class WeatherConditionType {
    CLEAR_DAY,
    CLEAR_NIGHT,
    PARTLY_CLOUDY,
    OVERCAST,
    FOG,
    DRIZZLE,
    RAIN,
    SNOW,
    THUNDERSTORM
}

data class HourlyForecastPoint(
    val hourLabel: String,
    val temperatureC: Double,
    val weatherCode: Int,
    val isDay: Boolean
)

data class DailyForecastDay(
    val dateIso: String,
    val weatherCode: Int,
    val minTempC: Double,
    val maxTempC: Double,
    val precipitationChancePercent: Int = 0
) {
    val conditionType: WeatherConditionType
        get() = WeatherInfo.classifyWmoCode(weatherCode, isDay = true)

    fun getConditionLabel(language: AppLanguage): String =
        WeatherInfo.describeWmoCode(weatherCode, isDay = true, language = language)
}

data class WeatherInfo(
    val locationName: String,
    val temperatureC: Double,
    val apparentTemperatureC: Double,
    val humidityPercent: Int,
    val windSpeedKmh: Double,
    val weatherCode: Int,
    val isDay: Boolean,
    val minTempC: Double,
    val maxTempC: Double,
    val hourlyForecast: List<HourlyForecastPoint> = emptyList(),
    val dailyForecast: List<DailyForecastDay> = emptyList(),
    val latitude: Double,
    val longitude: Double,
    val updatedAtMillis: Long = System.currentTimeMillis(),
    val isOfflineCache: Boolean = false,
    val timezoneId: String = "",
    val observationTimeLabel: String = ""
) {
    val conditionType: WeatherConditionType
        get() = classifyWmoCode(weatherCode, isDay)

    fun getConditionLabel(language: AppLanguage): String =
        describeWmoCode(weatherCode, isDay, language)

    fun getUpdatedClockLabel(): String {
        if (observationTimeLabel.isNotBlank()) return observationTimeLabel
        val tz = if (timezoneId.isNotBlank()) {
            java.util.TimeZone.getTimeZone(timezoneId)
        } else {
            java.util.TimeZone.getDefault()
        }
        return SimpleDateFormat("HH:mm", Locale.US).apply {
            timeZone = tz
        }.format(java.util.Date(updatedAtMillis))
    }

    companion object {
        fun classifyWmoCode(code: Int, isDay: Boolean): WeatherConditionType {
            return when (code) {
                0 -> if (isDay) WeatherConditionType.CLEAR_DAY else WeatherConditionType.CLEAR_NIGHT
                1, 2 -> WeatherConditionType.PARTLY_CLOUDY
                3 -> WeatherConditionType.OVERCAST
                45, 48 -> WeatherConditionType.FOG
                51, 53, 55, 56, 57 -> WeatherConditionType.DRIZZLE
                61, 63, 65, 66, 67, 80, 81, 82 -> WeatherConditionType.RAIN
                71, 73, 75, 77, 85, 86 -> WeatherConditionType.SNOW
                95, 96, 99 -> WeatherConditionType.THUNDERSTORM
                else -> if (isDay) WeatherConditionType.PARTLY_CLOUDY else WeatherConditionType.CLEAR_NIGHT
            }
        }

        fun describeWmoCode(code: Int, isDay: Boolean, language: AppLanguage): String {
            val isKu = language == AppLanguage.KURMANJI
            return when (code) {
                0 -> if (isDay) {
                    if (isKu) "Sayan û Tavî" else "Açık ve Güneşli"
                } else {
                    if (isKu) "Şevê Sayan" else "Açık Gece"
                }
                1 -> if (isKu) "Kêm Ewr" else "Az Bulutlu"
                2 -> if (isKu) "Nîv Ewr" else "Parçalı Bulutlu"
                3 -> if (isKu) "Pir Ewr" else "Çok Bulutlu"
                45, 48 -> if (isKu) "Mij û Dûman" else "Sisli"
                51, 53, 55, 56, 57 -> if (isKu) "Barana Sivik" else "Çisenti"
                61, 63, 80, 81 -> if (isKu) "Baran" else "Yağmurlu"
                65, 66, 67, 82 -> if (isKu) "Barana Gur" else "Kuvvetli Yağmur"
                71, 73, 75, 77, 85, 86 -> if (isKu) "Berf" else "Kar Yağışlı"
                95, 96, 99 -> if (isKu) "Birusk û Baran" else "Gök Gürültülü Sağanak"
                else -> if (isKu) "Nîv Ewr" else "Parçalı Bulutlu"
            }
        }

        fun formatDayLabel(
            dateIso: String,
            dayIndex: Int,
            language: AppLanguage,
            todayIso: String? = null
        ): String {
            val isKu = language == AppLanguage.KURMANJI
            val normalizedDate = dateIso.take(10)
            if (todayIso != null && todayIso.length >= 10) {
                val baseToday = todayIso.take(10)
                if (normalizedDate == baseToday) {
                    return if (isKu) "Îro" else "Bugün"
                }
                val tomorrowIso = addDaysIso(baseToday, 1)
                if (tomorrowIso != null && normalizedDate == tomorrowIso) {
                    return if (isKu) "Sibê" else "Yarın"
                }
            } else {
                if (dayIndex == 0) return if (isKu) "Îro" else "Bugün"
                if (dayIndex == 1) return if (isKu) "Sibê" else "Yarın"
            }

            val cal = parseIsoDate(dateIso) ?: return dateIso
            return when (cal.get(Calendar.DAY_OF_WEEK)) {
                Calendar.SUNDAY -> if (isKu) "Yek" else "Paz"
                Calendar.MONDAY -> if (isKu) "Duş" else "Pzt"
                Calendar.TUESDAY -> if (isKu) "Sêş" else "Sal"
                Calendar.WEDNESDAY -> if (isKu) "Çar" else "Çar"
                Calendar.THURSDAY -> if (isKu) "Pên" else "Per"
                Calendar.FRIDAY -> if (isKu) "În" else "Cum"
                Calendar.SATURDAY -> if (isKu) "Şem" else "Cmt"
                else -> dateIso
            }
        }

        private fun addDaysIso(dateIso: String, days: Int): String? {
            val cal = parseIsoDate(dateIso) ?: return null
            cal.add(Calendar.DAY_OF_YEAR, days)
            return SimpleDateFormat("yyyy-MM-dd", Locale.US).format(cal.time)
        }

        fun formatShortDate(dateIso: String, language: AppLanguage): String {
            val cal = parseIsoDate(dateIso) ?: return ""
            val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
            val monthIndex = cal.get(Calendar.MONTH)
            val isKu = language == AppLanguage.KURMANJI
            val monthNames = if (isKu) {
                arrayOf("Rêb", "Sib", "Ada", "Nîs", "Gul", "Hez", "Tîr", "Teb", "Îlo", "Cot", "Mij", "Ber")
            } else {
                arrayOf("Oca", "Şub", "Mar", "Nis", "May", "Haz", "Tem", "Ağu", "Eyl", "Eki", "Kas", "Ara")
            }
            val monthStr = monthNames.getOrNull(monthIndex) ?: ""
            return "$dayOfMonth $monthStr"
        }

        private fun parseIsoDate(dateIso: String): Calendar? {
            if (dateIso.length < 10) return null
            return try {
                val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
                val date = sdf.parse(dateIso.substring(0, 10)) ?: return null
                Calendar.getInstance().apply { time = date }
            } catch (_: Exception) {
                null
            }
        }
    }
}
