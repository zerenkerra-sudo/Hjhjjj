package com.example.data.remote

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.Query

@JsonClass(generateAdapter = true)
data class OpenMeteoForecastResponse(
    @param:Json(name = "latitude") val latitude: Double? = null,
    @param:Json(name = "longitude") val longitude: Double? = null,
    @param:Json(name = "utc_offset_seconds") val utcOffsetSeconds: Int? = null,
    @param:Json(name = "timezone") val timezone: String? = null,
    @param:Json(name = "current") val current: OpenMeteoCurrent? = null,
    @param:Json(name = "daily") val daily: OpenMeteoDaily? = null,
    @param:Json(name = "hourly") val hourly: OpenMeteoHourly? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoCurrent(
    @param:Json(name = "time") val time: String? = null,
    @param:Json(name = "temperature_2m") val temperature2m: Double? = null,
    @param:Json(name = "relative_humidity_2m") val relativeHumidity2m: Int? = null,
    @param:Json(name = "apparent_temperature") val apparentTemperature: Double? = null,
    @param:Json(name = "is_day") val isDay: Int? = null,
    @param:Json(name = "weather_code") val weatherCode: Int? = null,
    @param:Json(name = "wind_speed_10m") val windSpeed10m: Double? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoDaily(
    @param:Json(name = "time") val time: List<String?>? = null,
    @param:Json(name = "weather_code") val weatherCode: List<Int?>? = null,
    @param:Json(name = "temperature_2m_max") val temperature2mMax: List<Double?>? = null,
    @param:Json(name = "temperature_2m_min") val temperature2mMin: List<Double?>? = null,
    @param:Json(name = "precipitation_probability_max") val precipitationProbabilityMax: List<Int?>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoHourly(
    @param:Json(name = "time") val time: List<String?>? = null,
    @param:Json(name = "temperature_2m") val temperature2m: List<Double?>? = null,
    @param:Json(name = "weather_code") val weatherCode: List<Int?>? = null,
    @param:Json(name = "is_day") val isDay: List<Int?>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoGeocodingResponse(
    @param:Json(name = "results") val results: List<OpenMeteoGeoResult>? = null
)

@JsonClass(generateAdapter = true)
data class OpenMeteoGeoResult(
    @param:Json(name = "id") val id: Long? = null,
    @param:Json(name = "name") val name: String? = null,
    @param:Json(name = "latitude") val latitude: Double? = null,
    @param:Json(name = "longitude") val longitude: Double? = null,
    @param:Json(name = "country") val country: String? = null,
    @param:Json(name = "country_code") val countryCode: String? = null,
    @param:Json(name = "admin1") val admin1: String? = null,
    @param:Json(name = "admin2") val admin2: String? = null,
    @param:Json(name = "admin3") val admin3: String? = null
)

interface OpenMeteoWeatherApi {
    @GET("v1/forecast")
    suspend fun getForecast(
        @Query("latitude") latitude: Double,
        @Query("longitude") longitude: Double,
        @Query("current") current: String = "temperature_2m,relative_humidity_2m,apparent_temperature,is_day,weather_code,wind_speed_10m",
        @Query("daily") daily: String = "weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max",
        @Query("hourly") hourly: String = "temperature_2m,weather_code,is_day",
        @Query("forecast_days") forecastDays: Int = 7,
        @Query("timezone") timezone: String = "auto",
        @Query("temperature_unit") temperatureUnit: String = "celsius",
        @Query("wind_speed_unit") windSpeedUnit: String = "kmh",
        @Query("cell_selection") cellSelection: String = "land",
        @Header("Cache-Control") cacheControl: String = "no-cache"
    ): OpenMeteoForecastResponse
}

@JsonClass(generateAdapter = true)
data class MetNorwayForecastResponse(
    @param:Json(name = "properties") val properties: MetNorwayProperties? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayProperties(
    @param:Json(name = "timeseries") val timeseries: List<MetNorwayTimeseriesEntry?>? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayTimeseriesEntry(
    @param:Json(name = "time") val time: String? = null,
    @param:Json(name = "data") val data: MetNorwayData? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayData(
    @param:Json(name = "instant") val instant: MetNorwayInstant? = null,
    @param:Json(name = "next_1_hours") val next1Hours: MetNorwayPeriod? = null,
    @param:Json(name = "next_6_hours") val next6Hours: MetNorwayPeriod? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayInstant(
    @param:Json(name = "details") val details: MetNorwayInstantDetails? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayInstantDetails(
    @param:Json(name = "air_temperature") val airTemperature: Double? = null,
    @param:Json(name = "relative_humidity") val relativeHumidity: Double? = null,
    @param:Json(name = "wind_speed") val windSpeed: Double? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayPeriod(
    @param:Json(name = "summary") val summary: MetNorwaySummary? = null,
    @param:Json(name = "details") val details: MetNorwayPeriodDetails? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwaySummary(
    @param:Json(name = "symbol_code") val symbolCode: String? = null
)

@JsonClass(generateAdapter = true)
data class MetNorwayPeriodDetails(
    @param:Json(name = "precipitation_amount") val precipitationAmount: Double? = null
)

interface MetNorwayWeatherApi {
    @GET("weatherapi/locationforecast/2.0/compact")
    suspend fun getLocationForecast(
        @Query("lat") latitude: String,
        @Query("lon") longitude: String,
        @Header("User-Agent") userAgent: String = "IslamRehberiAndroid/1.0 (https://islamrehberi.app)",
        @Header("Cache-Control") cacheControl: String = "no-cache"
    ): MetNorwayForecastResponse
}

interface OpenMeteoGeocodingApi {
    @GET("v1/search")
    suspend fun searchLocations(
        @Query("name") name: String,
        @Query("count") count: Int = 20,
        @Query("language") language: String = "tr",
        @Query("format") format: String = "json"
    ): OpenMeteoGeocodingResponse
}
