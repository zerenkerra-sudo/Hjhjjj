package com.example.data.local

import com.example.data.model.JuzInfo
import com.example.data.model.PageInfo

object QuranNavigationData {

    // 30 Juz (Cüz) of the Holy Quran
    val JUZ_LIST: List<JuzInfo> = listOf(
        JuzInfo(1, 1, "Fâtiha", "Fatihe", 1, 2, "Bakara", "Beqere", 141, 1, 21),
        JuzInfo(2, 2, "Bakara", "Beqere", 142, 2, "Bakara", "Beqere", 252, 22, 41),
        JuzInfo(3, 2, "Bakara", "Beqere", 253, 3, "Âl-i İmrân", "Mala Îmran", 92, 42, 61),
        JuzInfo(4, 3, "Âl-i İmrân", "Mala Îmran", 93, 4, "Nisâ", "Nîsa", 23, 62, 81),
        JuzInfo(5, 4, "Nisâ", "Nîsa", 24, 4, "Nisâ", "Nîsa", 147, 82, 101),
        JuzInfo(6, 4, "Nisâ", "Nîsa", 148, 5, "Mâide", "Maîde", 81, 102, 120),
        JuzInfo(7, 5, "Mâide", "Maîde", 82, 6, "En'âm", "En'am", 110, 121, 141),
        JuzInfo(8, 6, "En'âm", "En'am", 111, 7, "A'râf", "E'raf", 87, 142, 161),
        JuzInfo(9, 7, "A'râf", "E'raf", 88, 8, "Enfâl", "Enfal", 40, 162, 181),
        JuzInfo(10, 8, "Enfâl", "Enfal", 41, 9, "Tevbe", "Tewbe", 92, 182, 200),
        JuzInfo(11, 9, "Tevbe", "Tewbe", 93, 11, "Hûd", "Hûd", 5, 201, 221),
        JuzInfo(12, 11, "Hûd", "Hûd", 6, 12, "Yûsuf", "Yûsif", 52, 222, 241),
        JuzInfo(13, 12, "Yûsuf", "Yûsif", 53, 14, "İbrâhîm", "Îbrahîm", 52, 242, 261),
        JuzInfo(14, 15, "Hicr", "Hicr", 1, 16, "Nahl", "Nehl", 128, 262, 281),
        JuzInfo(15, 17, "İsrâ", "Îsra", 1, 18, "Kehf", "Kehf", 74, 282, 301),
        JuzInfo(16, 18, "Kehf", "Kehf", 75, 20, "Tâhâ", "Taha", 135, 302, 321),
        JuzInfo(17, 21, "Enbiyâ", "Enbiya", 1, 22, "Hac", "Hec", 78, 322, 341),
        JuzInfo(18, 23, "Mü'minûn", "Mu'minûn", 1, 25, "Furkân", "Furkan", 20, 342, 361),
        JuzInfo(19, 25, "Furkân", "Furkan", 21, 27, "Neml", "Neml", 55, 362, 381),
        JuzInfo(20, 27, "Neml", "Neml", 56, 29, "Ankebût", "Enkebût", 45, 382, 401),
        JuzInfo(21, 29, "Ankebût", "Enkebût", 46, 33, "Ahzâb", "Ahzab", 30, 402, 421),
        JuzInfo(22, 33, "Ahzâb", "Ahzab", 31, 36, "Yâsîn", "Yasin", 27, 422, 441),
        JuzInfo(23, 36, "Yâsîn", "Yasin", 28, 39, "Zümer", "Zumer", 31, 442, 461),
        JuzInfo(24, 39, "Zümer", "Zumer", 32, 41, "Fussilet", "Fusilet", 46, 462, 481),
        JuzInfo(25, 41, "Fussilet", "Fusilet", 47, 45, "Câsiye", "Casiye", 37, 482, 501),
        JuzInfo(26, 46, "Ahkâf", "Ahqaf", 1, 51, "Zâriyât", "Zariyat", 30, 502, 521),
        JuzInfo(27, 51, "Zâriyât", "Zariyat", 31, 57, "Hadîd", "Hedîd", 29, 522, 541),
        JuzInfo(28, 58, "Mücâdele", "Mucadele", 1, 66, "Tahrîm", "Tehrîm", 12, 542, 561),
        JuzInfo(29, 67, "Mülk", "Mulk", 1, 77, "Mürselât", "Murselat", 50, 562, 581),
        JuzInfo(30, 78, "Nebe", "Nebe", 1, 114, "Nâs", "Nas", 6, 582, 604)
    )

    fun getJuzForPage(page: Int): Int {
        val clamped = page.coerceIn(1, 604)
        return QuranPageMetadata.getJuzForPage(clamped)
    }

    fun getSurahNumberForPage(page: Int): Int {
        val clamped = page.coerceIn(1, 604)
        return QuranPageMetadata.getPage(clamped).startSurah
    }
}
