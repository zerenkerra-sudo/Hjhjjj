package com.example.data.model

data class QuranDua(
    val id: String,
    val titleTr: String,
    val titleKu: String,
    val surahNameTr: String,
    val surahNameKu: String,
    val ayahReference: String,
    val arabicText: String,
    val translationTr: String,
    val translationKuLatin: String,
    val themeTr: String,
    val themeKu: String
) {
    fun getTitle(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) titleKu else titleTr
    fun getSurah(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) surahNameKu else surahNameTr
    fun getTranslation(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) translationKuLatin else translationTr
    fun getTheme(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) themeKu else themeTr
}

data class Hutbe(
    val id: String,
    val date: String,
    val titleTr: String,
    val titleKu: String,
    val source: String = "T.C. Diyanet İşleri Başkanlığı (dinhizmetleri.diyanet.gov.tr)",
    val arabicVerseOrHadith: String,
    val summaryTr: String,
    val summaryKu: String,
    val fullTextTr: String,
    val fullTextKu: String,
    val dateIso: String = "",
    val officialUrl: String = "",
    val audioUrl: String = "",
    val arabicFullText: String = "",
    val footnotes: String = "",
    val isSyncedFromDiyanet: Boolean = false,
    val fetchedAtMillis: Long = 0L,
    val arabicHeaderImageBase64: String = ""
) {
    fun getTitle(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI && titleKu.isNotBlank()) titleKu else titleTr

    fun getSummary(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI && summaryKu.isNotBlank()) summaryKu else summaryTr

    fun getFullText(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI && fullTextKu.isNotBlank()) fullTextKu else fullTextTr
}

data class ReligiousDay(
    val id: String,
    val nameTr: String,
    val nameKu: String,
    val hijriDate: String,
    val gregorianDateStr: String, // YYYY-MM-DD
    val displayDateTr: String,
    val displayDateKu: String,
    val descriptionTr: String,
    val descriptionKu: String,
    val isKandilOrBayram: Boolean = true,
    val significanceTr: String = "",
    val significanceKu: String = "",
    val recommendedDeedsTr: String = "",
    val recommendedDeedsKu: String = "",
    val celebrationMessageTr: String = "",
    val celebrationMessageKu: String = ""
) {
    fun getName(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) nameKu else nameTr
    fun getDisplayDate(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) displayDateKu else displayDateTr
    fun getDescription(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) descriptionKu else descriptionTr
    fun getSignificance(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) significanceKu else significanceTr
    fun getRecommendedDeeds(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) recommendedDeedsKu else recommendedDeedsTr
    fun getCelebrationMessage(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) celebrationMessageKu else celebrationMessageTr
}
