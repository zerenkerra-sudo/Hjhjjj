package com.example.data.local

import com.example.data.model.AyahItem
import com.example.data.model.SurahDetail
import com.example.data.model.SurahInfo

object BuiltinQuranData {

    val SURAH_LIST: List<SurahInfo> = listOf(
        SurahInfo(1, "الفَاتِحة", "Fâtiha", "Fatihe", "Açılış", "Destpêk", 7, "Mekke", "Mekkî", 1, 1),
        SurahInfo(2, "البَقَرَة", "Bakara", "Beqere", "Sığır", "Çêlek", 286, "Medine", "Medenî", 2, 1),
        SurahInfo(3, "آل عِمرَان", "Âl-i İmrân", "Mala Îmran", "İmran Ailesi", "Xêzana Îmran", 200, "Medine", "Medenî", 50, 3),
        SurahInfo(4, "النِّسَاء", "Nisâ", "Nîsa", "Kadınlar", "Jin", 176, "Medine", "Medenî", 77, 4),
        SurahInfo(5, "المَائدة", "Mâide", "Maîde", "Sofra", "Sifre", 120, "Medine", "Medenî", 106, 6),
        SurahInfo(6, "الأنعَام", "En'âm", "En'am", "Davarlar", "Pez û Dewar", 165, "Mekke", "Mekkî", 128, 7),
        SurahInfo(7, "الأعرَاف", "A'râf", "E'raf", "A'râf", "E'raf", 206, "Mekke", "Mekkî", 151, 8),
        SurahInfo(8, "الأنفَال", "Enfâl", "Enfal", "Ganimetler", "Xenîmet", 75, "Medine", "Medenî", 177, 9),
        SurahInfo(9, "التَّوبَة", "Tevbe", "Tewbe", "Tövbe", "Tobe", 129, "Medine", "Medenî", 187, 10),
        SurahInfo(10, "يُونُس", "Yûnus", "Yûnis", "Yunus Peygamber", "Pêxember Yûnis", 109, "Mekke", "Mekkî", 208, 11),
        SurahInfo(11, "هُود", "Hûd", "Hûd", "Hûd Peygamber", "Pêxember Hûd", 123, "Mekke", "Mekkî", 221, 11),
        SurahInfo(12, "يُوسُف", "Yûsuf", "Yûsif", "Yusuf Peygamber", "Pêxember Yûsif", 111, "Mekke", "Mekkî", 235, 12),
        SurahInfo(13, "الرَّعد", "Ra'd", "Re'd", "Gök Gürültüsü", "Birûsk", 43, "Medine", "Medenî", 249, 13),
        SurahInfo(14, "إبرَاهِيم", "İbrâhîm", "Îbrahîm", "İbrahim Peygamber", "Pêxember Îbrahîm", 52, "Mekke", "Mekkî", 255, 13),
        SurahInfo(15, "الحِجْر", "Hicr", "Hicr", "Hicr Bölgesi", "Herêma Hicrê", 99, "Mekke", "Mekkî", 262, 14),
        SurahInfo(16, "النَّحْل", "Nahl", "Nehl", "Bal Arısı", "Mêşa Hingiv", 128, "Mekke", "Mekkî", 267, 14),
        SurahInfo(17, "الإسرَاء", "İsrâ", "Îsra", "Gece Yürüyüşü", "Şebrêveçûn", 111, "Mekke", "Mekkî", 282, 15),
        SurahInfo(18, "الكَهْف", "Kehf", "Kehf", "Mağara", "Şikeft", 110, "Mekke", "Mekkî", 293, 15),
        SurahInfo(19, "مَريَم", "Meryem", "Meryem", "Meryem", "Hz. Meryem", 98, "Mekke", "Mekkî", 305, 16),
        SurahInfo(20, "طه", "Tâhâ", "Taha", "Tâ-Hâ", "Ta-Ha", 135, "Mekke", "Mekkî", 312, 16),
        SurahInfo(21, "الأَنبِيَاء", "Enbiyâ", "Enbiya", "Peygamberler", "Pêxember", 112, "Mekke", "Mekkî", 322, 17),
        SurahInfo(22, "الحَجّ", "Hac", "Hec", "Hac", "Hec", 78, "Medine", "Medenî", 332, 17),
        SurahInfo(23, "المُؤمِنُون", "Mü'minûn", "Mu'minûn", "Müminler", "Bawermend", 118, "Mekke", "Mekkî", 342, 18),
        SurahInfo(24, "النُّور", "Nûr", "Nûr", "Işık", "Ronahî", 64, "Medine", "Medenî", 350, 18),
        SurahInfo(25, "الفُرقَان", "Furkân", "Furkan", "Furkan", "Furkan", 77, "Mekke", "Mekkî", 359, 18),
        SurahInfo(26, "الشُّعَرَاء", "Şuarâ", "Şu'era", "Şairler", "Helbestvan", 227, "Mekke", "Mekkî", 367, 19),
        SurahInfo(27, "النَّمْل", "Neml", "Neml", "Karınca", "Gêrînek", 93, "Mekke", "Mekkî", 377, 19),
        SurahInfo(28, "القَصَص", "Kasas", "Qesas", "Kıssalar", "Çîrok û Serpêhatî", 88, "Mekke", "Mekkî", 385, 20),
        SurahInfo(29, "العَنكَبُوت", "Ankebût", "Enkebût", "Örümcek", "Tevnkirk", 69, "Mekke", "Mekkî", 396, 20),
        SurahInfo(30, "الرُّوم", "Rûm", "Rûm", "Romalılar", "Romayî", 60, "Mekke", "Mekkî", 404, 21),
        SurahInfo(31, "لُقمَان", "Lokmân", "Loqman", "Lokman Hekim", "Loqmanê Hekîm", 34, "Mekke", "Mekkî", 411, 21),
        SurahInfo(32, "السَّجدَة", "Secde", "Secde", "Secde", "Secde", 30, "Mekke", "Mekkî", 415, 21),
        SurahInfo(33, "الأَحزَاب", "Ahzâb", "Ahzab", "Gruplar", "Komik", 73, "Medine", "Medenî", 418, 21),
        SurahInfo(34, "سَبَأ", "Sebe", "Sebe", "Sebe Kavmi", "Qewmê Sebeê", 54, "Mekke", "Mekkî", 428, 22),
        SurahInfo(35, "فَاطِر", "Fâtır", "Fatir", "Yaratan", "Afirîner", 45, "Mekke", "Mekkî", 434, 22),
        SurahInfo(36, "يس", "Yâsîn", "Yasin", "Yâ-Sîn", "Ya-Sîn", 83, "Mekke", "Mekkî", 440, 22),
        SurahInfo(37, "الصَّافَّات", "Sâffât", "Saffat", "Sıra Sıra Duranlar", "Rêzbûyî", 182, "Mekke", "Mekkî", 446, 23),
        SurahInfo(38, "ص", "Sâd", "Sad", "Sâd Harfi", "Tîpa Sadê", 88, "Mekke", "Mekkî", 453, 23),
        SurahInfo(39, "الزُّمَر", "Zümer", "Zumer", "Kümeler", "Komên Mirovan", 75, "Mekke", "Mekkî", 458, 23),
        SurahInfo(40, "غَافِر", "Mü'min (Gâfir)", "Xafir (Mu'min)", "Bağışlayan", "Baxşîner", 85, "Mekke", "Mekkî", 467, 24),
        SurahInfo(41, "فُصِّلَت", "Fussilet", "Fusilet", "Açıklanmış", "Berfirehkirî", 54, "Mekke", "Mekkî", 477, 24),
        SurahInfo(42, "الشُّورَىٰ", "Şûrâ", "Şûra", "Danışma", "Şêwirmendî", 53, "Mekke", "Mekkî", 483, 25),
        SurahInfo(43, "الزُّخْرُف", "Zuhruf", "Zuxruf", "Yaldız / Altın", "Zêr û Xeml", 89, "Mekke", "Mekkî", 489, 25),
        SurahInfo(44, "الدُّخَان", "Duhân", "Duxan", "Duman", "Dû", 59, "Mekke", "Mekkî", 496, 25),
        SurahInfo(45, "الجَاثِيَة", "Câsiye", "Casiye", "Diz Üstü Çökenler", "Çongşikestî", 37, "Mekke", "Mekkî", 499, 25),
        SurahInfo(46, "الأَحقَاف", "Ahkâf", "Ahqaf", "Kum Tepeleri", "Girên Xîzê", 35, "Mekke", "Mekkî", 502, 26),
        SurahInfo(47, "مُحَمَّد", "Muhammed", "Muhemmed", "Hz. Muhammed", "Hz. Muhemmed", 38, "Medine", "Medenî", 507, 26),
        SurahInfo(48, "الفَتْح", "Fetih", "Feth", "Zafer", "Serkeftin", 29, "Medine", "Medenî", 511, 26),
        SurahInfo(49, "الحُجُرَات", "Hucurât", "Hucurat", "Odalar", "Ode", 18, "Medine", "Medenî", 515, 26),
        SurahInfo(50, "ق", "Kâf", "Qaf", "Kâf Harfi", "Tîpa Qafê", 45, "Mekke", "Mekkî", 518, 26),
        SurahInfo(51, "الذَّارِيَات", "Zâriyât", "Zariyat", "Rüzgârlar", "Ba yên Bagurdan", 60, "Mekke", "Mekkî", 520, 26),
        SurahInfo(52, "الطُّور", "Tûr", "Tûr", "Tûr Dağı", "Çiyayê Tûrê", 49, "Mekke", "Mekkî", 523, 27),
        SurahInfo(53, "النَّجْم", "Necm", "Necm", "Yıldız", "Stêrk", 62, "Mekke", "Mekkî", 526, 27),
        SurahInfo(54, "القَمَر", "Kamer", "Qemer", "Ay", "Heyv", 55, "Mekke", "Mekkî", 528, 27),
        SurahInfo(55, "الرَّحْمَٰن", "Rahmân", "Rehman", "Rahmân", "Xwedayê Dilovan", 78, "Medine", "Medenî", 531, 27),
        SurahInfo(56, "الوَاقِعَة", "Vâkıa", "Waqî'e", "Kıyamet", "Roja Qiyametê", 96, "Mekke", "Mekkî", 534, 27),
        SurahInfo(57, "الحَدِيد", "Hadîd", "Hedîd", "Demir", "Hesin", 29, "Medine", "Medenî", 537, 27),
        SurahInfo(58, "المُجَادَلَة", "Mücâdele", "Mucadele", "Tartışma", "Genûşe", 22, "Medine", "Medenî", 542, 28),
        SurahInfo(59, "الحَشْر", "Haşr", "Heşr", "Toplanma", "Komkirin", 24, "Medine", "Medenî", 545, 28),
        SurahInfo(60, "المُمتَحَنَة", "Mümtehine", "Mumtehîne", "İmtihan Edilen", "Ezmûnkêş", 13, "Medine", "Medenî", 549, 28),
        SurahInfo(61, "الصَّفّ", "Saff", "Seff", "Sıra / Saf", "Rêz", 14, "Medine", "Medenî", 551, 28),
        SurahInfo(62, "الجُمُعَة", "Cuma", "În (Cuma)", "Cuma Günü", "Roja Înê", 11, "Medine", "Medenî", 553, 28),
        SurahInfo(63, "المُنَافِقُون", "Münâfikûn", "Munafiqûn", "İki Yüzlüler", "Durûyî", 11, "Medine", "Medenî", 554, 28),
        SurahInfo(64, "التَّغَابُن", "Teğâbün", "Texabûn", "Aldanma", "Xapandin", 18, "Medine", "Medenî", 556, 28),
        SurahInfo(65, "الطَّلَاق", "Talâk", "Telaq", "Boşanma", "Berdana Jinê", 12, "Medine", "Medenî", 558, 28),
        SurahInfo(66, "التَّحرِيم", "Tahrîm", "Tehrîm", "Haram Kılma", "Heramkirin", 12, "Medine", "Medenî", 560, 28),
        SurahInfo(67, "المُلْك", "Mülk", "Mulk", "Hükümranlık", "Desthilatdarî", 30, "Mekke", "Mekkî", 562, 29),
        SurahInfo(68, "القَلَم", "Kalem", "Qelem", "Kalem", "Pênûs", 52, "Mekke", "Mekkî", 564, 29),
        SurahInfo(69, "الحَاقَّة", "Hâkka", "Haqqe", "Gerçekleşecek Olan", "Ya ku dê Bibe", 52, "Mekke", "Mekkî", 566, 29),
        SurahInfo(70, "المَعَارِج", "Meâric", "Me'aric", "Yükselme Yolları", "Pîle û Hilkişîn", 44, "Mekke", "Mekkî", 568, 29),
        SurahInfo(71, "نُوح", "Nûh", "Nûh", "Nûh Peygamber", "Pêxember Nûh", 28, "Mekke", "Mekkî", 570, 29),
        SurahInfo(72, "الجِنّ", "Cin", "Cin", "Cinler", "Cin", 28, "Mekke", "Mekkî", 572, 29),
        SurahInfo(73, "المُزَّمِّل", "Müzzemmil", "Muzzemmil", "Örtünüp Bürünen", "Xwepêça", 20, "Mekke", "Mekkî", 574, 29),
        SurahInfo(74, "المُدَّثِّر", "Müddessir", "Muddessir", "Bürünen", "Xwepêçanî", 56, "Mekke", "Mekkî", 575, 29),
        SurahInfo(75, "القِيَامَة", "Kıyâme", "Qiyame", "Kıyamet", "Qiyamet", 40, "Mekke", "Mekkî", 577, 29),
        SurahInfo(76, "الإِنسَان", "İnsân", "Însan", "İnsan", "Mirov", 31, "Medine", "Medenî", 578, 29),
        SurahInfo(77, "المُرسَلَات", "Mürselât", "Murselat", "Gönderilenler", "Şandî", 50, "Mekke", "Mekkî", 580, 29),
        SurahInfo(78, "النَّبَأ", "Nebe", "Nebe", "Büyük Haber", "Xebera Mezin", 40, "Mekke", "Mekkî", 582, 30),
        SurahInfo(79, "النَّازِعَات", "Nâziât", "Nazi'at", "Çekip Çıkaranlar", "Ya Rêkêşer", 46, "Mekke", "Mekkî", 583, 30),
        SurahInfo(80, "عَبَسَ", "Abese", "Ebese", "Yüzünü Ekşitti", "Rûyê Xwe Tirş Kir", 42, "Mekke", "Mekkî", 585, 30),
        SurahInfo(81, "التَّكوِير", "Tekvîr", "Tekwîr", "Dürülme", "Lêpêçan", 29, "Mekke", "Mekkî", 586, 30),
        SurahInfo(82, "الانفِطَار", "İnfitâr", "Înfitar", "Yarılma", "Şeqbûn", 19, "Mekke", "Mekkî", 587, 30),
        SurahInfo(83, "المُطَفِّفِين", "Mutaffifîn", "Muteffifîn", "Ölçüde Hile Yapanlar", "Kêmfiroş", 36, "Mekke", "Mekkî", 587, 30),
        SurahInfo(84, "الانشِقَاق", "İnşikâk", "Înşiqaq", "Parçalanma", "Parçebûn", 25, "Mekke", "Mekkî", 589, 30),
        SurahInfo(85, "البُرُوج", "Bürûc", "Burûc", "Burçlar", "Birc", 22, "Mekke", "Mekkî", 590, 30),
        SurahInfo(86, "الطَّارِق", "Târık", "Tariq", "Sabah Yıldızı", "Stêrka Spêdeyê", 17, "Mekke", "Mekkî", 591, 30),
        SurahInfo(87, "الأَعْلَىٰ", "A'lâ", "E'la", "En Yüce", "Herî Bilind", 19, "Mekke", "Mekkî", 591, 30),
        SurahInfo(88, "الغَاشِيَة", "Gâşiye", "Xaşiye", "Kuşatan / Dehşetli Gün", "Pêçayî", 26, "Mekke", "Mekkî", 592, 30),
        SurahInfo(89, "الفَجْر", "Fecr", "Fecr", "Tan Vakti", "Spêde", 30, "Mekke", "Mekkî", 593, 30),
        SurahInfo(90, "البَلَد", "Beled", "Beled", "Şehir", "Bajar", 20, "Mekke", "Mekkî", 594, 30),
        SurahInfo(91, "الشَّمْس", "Şems", "Şems", "Güneş", "Roj", 15, "Mekke", "Mekkî", 595, 30),
        SurahInfo(92, "اللَّيْل", "Leyl", "Leyl", "Gece", "Şev", 21, "Mekke", "Mekkî", 595, 30),
        SurahInfo(93, "الضُّحَىٰ", "Duhâ", "Duha", "Kuşluk Vakti", "Danê Çêştê", 11, "Mekke", "Mekkî", 596, 30),
        SurahInfo(94, "الشَّرْح", "İnşirâh", "Şerh", "Ferahlık", "Hêsanî", 8, "Mekke", "Mekkî", 596, 30),
        SurahInfo(95, "التِّين", "Tîn", "Tîn", "İncir", "Hêjîr", 8, "Mekke", "Mekkî", 597, 30),
        SurahInfo(96, "العَلَق", "Alak", "Eleq", "Aşılanmış Yumurta", "Pirtika Xwînê", 19, "Mekke", "Mekkî", 597, 30),
        SurahInfo(97, "القَدْر", "Kadir", "Qedr", "Kadir Gecesi", "Şeva Qedrê", 5, "Mekke", "Mekkî", 598, 30),
        SurahInfo(98, "البَيِّنَة", "Beyyine", "Beyyîne", "Açık Delil", "Belgeya Eşkere", 8, "Medine", "Medenî", 598, 30),
        SurahInfo(99, "الزَّلْزَلَة", "Zilzâl", "Zilzal", "Deprem", "Erdhej", 8, "Medine", "Medenî", 599, 30),
        SurahInfo(100, "العَادِيَات", "Âdiyât", "Adiyat", "Koşan Atlar", "Hespên Bezok", 11, "Mekke", "Mekkî", 599, 30),
        SurahInfo(101, "القَارِعَة", "Kâria", "Qari'a", "Büyük Felaket", "Karesata Mezin", 11, "Mekke", "Mekkî", 600, 30),
        SurahInfo(102, "التَّكَاثُر", "Tekâsür", "Tekasur", "Çokluk Yarışı", "Zêdehevî", 8, "Mekke", "Mekkî", 600, 30),
        SurahInfo(103, "العَصْر", "Asr", "Esir", "Zaman", "Wext", 3, "Mekke", "Mekkî", 601, 30),
        SurahInfo(104, "الهُمَزَة", "Hümeze", "Humeze", "Dedikoducu", "Çêbêj", 9, "Mekke", "Mekkî", 601, 30),
        SurahInfo(105, "الفِيل", "Fîl", "Fîl", "Fil", "Fîl", 5, "Mekke", "Mekkî", 601, 30),
        SurahInfo(106, "قُرَيْش", "Kureyş", "Qureyş", "Kureyş Kabilesi", "Qebîleya Qureyşê", 4, "Mekke", "Mekkî", 602, 30),
        SurahInfo(107, "المَاعُون", "Mâûn", "Ma'ûn", "Yardımlaşma", "Alîkarî", 7, "Mekke", "Mekkî", 602, 30),
        SurahInfo(108, "الكَوْثَر", "Kevser", "Kewser", "Bol Nimet", "Kewser", 3, "Mekke", "Mekkî", 602, 30),
        SurahInfo(109, "الكَافِرُون", "Kâfirûn", "Kafirûn", "İnkârcılar", "Kafir", 6, "Mekke", "Mekkî", 603, 30),
        SurahInfo(110, "النَّصْر", "Nasr", "Nesir", "Yardım", "Serkeftin", 3, "Medine", "Medenî", 603, 30),
        SurahInfo(111, "المَسَد", "Tebbet (Mesed)", "Mesed", "Hurma Lifi", "Pûşê Xurmeyan", 5, "Mekke", "Mekkî", 603, 30),
        SurahInfo(112, "الإِخْلَاص", "İhlâs", "Îxlas", "Samimiyet", "Yekbûna Xwedê", 4, "Mekke", "Mekkî", 604, 30),
        SurahInfo(113, "الفَلَق", "Felak", "Feleq", "Sabah Aydınlığı", "Spêde", 5, "Mekke", "Mekkî", 604, 30),
        SurahInfo(114, "النَّاس", "Nâs", "Nas", "İnsanlar", "Mirov", 6, "Mekke", "Mekkî", 604, 30),
    )

    // Detailed Ayahs with authentic Arabic, Turkish (Diyanet) and Kurmanji Latin
    // Verbatim official Diyanet Arabic, Turkish, and Kurdish (Latin) ayahs
    val DETAILS_MAP: Map<Int, List<AyahItem>> = mapOf(
        // 1. Al-Fatiha
        1 to listOf(
            AyahItem(1, "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحٖیمِ", "Rahmân ve rahîm olan Allah’ın adıyla", "Bi Navê Xwedayê Reḥman ê Reḥîm."),
            AyahItem(2, "اَلْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمٖینَۙ", "Hamd, âlemlerin Rabbi olan Allah’a mahsustur.", "Hemd (pesn û spasî) ji Xwedê re be ku ew perwerdegarê ‘alemê ye."),
            AyahItem(3, "اَلرَّحْمٰنِ الرَّحٖیمِۙ", "Rahmân ve rahîm", "Ew ê ku Rehman e, Rehîm e."),
            AyahItem(4, "مَالِكِ یَوْمِ الدّٖینِؕ", "Ödül ve ceza gününün tek hâkimi.", "Ew ê ku xwediyê roja hesabdîtin û cizadanê ye."),
            AyahItem(5, "اِیَّاكَ نَعْبُدُ وَاِیَّاكَ نَسْتَعٖینُؕ", "(Rabbimiz!) Ancak sana kulluk eder ve yalnız senden yardım dileriz.", "Em bes ji bo te îbadet dikin û her ji te arîkariyê dixwazin."),
            AyahItem(6, "اِهْدِنَا الصِّرَاطَ الْمُسْتَقٖیمَۙ", "Bizi dosdoğru yola ilet;", "Riya rast û durist nîşanî me bide û me li serê rasterê bike."),
            AyahItem(7, "صِرَاطَ الَّذٖینَ اَنْعَمْتَ عَلَیْهِمْۙ غَیْرِ الْمَغْضُوبِ عَلَیْهِمْ وَلَا الضَّٓالّٖینَ", "Nimetine erdirdiklerinin yoluna; gazaba uğramışların yoluna da, dalâlete sapmışların yoluna da değil! Âmin!", "Riya wan kesên ku te qencî û dilşadî daye wan; ne ew ên ku xezeb li wan bûye û ne ew ên riya heq şaş kirine.")
        ),
        // 94. Al-Inshirah
        94 to listOf(
            AyahItem(1, "اَلَمْ نَشْرَحْ لَكَ صَدْرَكَۙ", "Senin kalbini açıp genişletmedik mi?", "Erê ma Me sînga te (ji bo ahkamên dîn) venekir?"),
            AyahItem(2, "وَوَضَعْنَا عَنْكَ وِزْرَكَۙ", "Belini büken yükünü üzerinden kaldırmadık mı?", "Ma Me barê te li ser te sivik nekir?"),
            AyahItem(3, "اَلَّذٖٓی اَنْقَضَ ظَهْرَكَۙ", "Belini büken yükünü üzerinden kaldırmadık mı?", "Ew barê ku pişta te xistibû ber te."),
            AyahItem(4, "وَرَفَعْنَا لَكَ ذِكْرَكَؕ", "Ve senin şanını yüceltmedik mi?", "Ma Me nav û dengê te bilind nekir?"),
            AyahItem(5, "فَاِنَّ مَعَ الْعُسْرِ یُسْرًاۙ", "Demek ki zorlukla beraber bir kolaylık vardır.", "Vêca birastî digel her tengasiyê firehî heye."),
            AyahItem(6, "اِنَّ مَعَ الْعُسْرِ یُسْرًاؕ", "Evet, doğrusu her güçlüğün yanında bir kolaylık var.", "Birastî digel her tengasiyê firehî heye."),
            AyahItem(7, "فَاِذَا فَرَغْتَ فَانْصَبْۙ", "O halde önemli bir işi bitirince hemen diğerine koyul.", "Nexwe dema ku tu (ji karekî) vala bûyî, dest bi karekî din bike."),
            AyahItem(8, "وَاِلٰى رَبِّكَ فَارْغَبْ", "Ve yalnız rabbine yönel.", "Bila perwerdegarê te jî daxwaza te bê.")
        ),
        // 95. At-Tin
        95 to listOf(
            AyahItem(1, "وَالتّٖینِ وَالزَّیْتُونِۙ", "Yemin olsun incire ve zeytine;", "Sond bi hejîr û zeytûnê…"),
            AyahItem(2, "وَطُورِ سٖینٖینَۙ", "Sînâ dağına;", "Bi Çiyayê Tûrî Sîna."),
            AyahItem(3, "وَهٰذَا الْبَلَدِ الْاَمٖینِۙ", "Ve şu güvenli beldeye!", "Bi vî bajarê ewle…"),
            AyahItem(4, "لَقَدْ خَلَقْنَا الْاِنْسَانَ فٖٓی اَحْسَنِ تَقْوٖیمٍؗ", "Şüphesiz biz insanı en güzel biçimde yaratmışızdır.", "Bi rastî jî Me însan di şeklê herî rind û tekûz de afirandiye."),
            AyahItem(5, "ثُمَّ رَدَدْنَاهُ اَسْفَلَ سَافِلٖینَۙ", "Sonra onu aşağıların aşağısına indirdik.", "Paşê me ew gerandiye nizmtirînê nizman."),
            AyahItem(6, "اِلَّا الَّذٖینَ اٰمَنُوا وَعَمِلُوا الصَّالِحَاتِ فَلَهُمْ اَجْرٌ غَیْرُ مَمْنُونٍؕ", "Ancak iman edip dünya ve âhiret için yararlı işler yapanlar başka; onlar için kesintisiz bir ödül vardır.", "Ji bilî yên bawerî anîn û emelê salih kirin, vêca ji wan re perûyeke bêqutbûn heye."),
            AyahItem(7, "فَمَا یُكَذِّبُكَ بَعْدُ بِالدّٖینِؕ", "Artık bu kanıtlardan sonra (ey insan!) sana dini inkâr ettiren şey nedir?", "Êdî (hey însan!) ew çi ye ku piştî vê yekê te ji roja cezadanê bêbawer dike?"),
            AyahItem(8, "اَلَیْسَ اللّٰهُ بِاَحْكَمِ الْحَاكِمٖینَ", "Allah hüküm verenlerin en âdili değil midir?", "Erê, ma Xweda ne mikûmtirîn fermanrewa ye.")
        ),
        // 97. Al-Qadr
        97 to listOf(
            AyahItem(1, "اِنَّٓا اَنْزَلْنَاهُ فٖی لَیْلَةِ الْقَدْرِۚ", "Biz onu (Kur’an’ı) Kadir gecesinde indirdik.", "Bêguman Me ew (Quran) di Leyletu’l-Qedrê de hinartiye."),
            AyahItem(2, "وَمَٓا اَدْرٰیكَ مَا لَیْلَةُ الْقَدْرِؕ", "Bilir misin nedir Kadir gecesi?", "Ma kê te fêrkiriye heta ti zanibe ka Leyletu’l-Qedir çi ye?"),
            AyahItem(3, "لَیْلَةُ الْقَدْرِ خَیْرٌ مِنْ اَلْفِ شَهْرٍؕ", "Kadir gecesi bin aydan hayırlıdır.", "Şeva Qedrê ji hezar heyvî bixêrtir e."),
            AyahItem(4, "تَنَزَّلُ الْمَلٰٓئِكَةُ وَالرُّوحُ فٖیهَا بِاِذْنِ رَبِّهِمْۚ مِنْ كُلِّ اَمْرٍۙۛ", "O gece melekler ve ruh, rablerinin izniyle her bir iş için iner dururlar.", "Di wê şevê de, melayîket û Ruh (Cibrîl) bi destûra Xwedayê xwe, der barê her kar û barî de têne ser erdê."),
            AyahItem(5, "سَلَامٌࣞۛ هِیَ حَتّٰى مَطْلَعِ الْفَجْرِ", "O gece tan yeri ağarıncaya kadar esenlik doludur.", "Ew şev selametî û aramî ye. Heyanî spêdeyê berdewam e")
        ),
        // 103. Al-Asr
        103 to listOf(
            AyahItem(1, "وَالْعَصْرِۙ", "Asra yemin ederim ki,", "Bi demê (an jî, bi dema ‘Esrê) sond be!"),
            AyahItem(2, "اِنَّ الْاِنْسَانَ لَفٖی خُسْرٍۙ", "İnsan gerçekten ziyandadır.", "Bi rastî mirov hemû di ziyanê de ne."),
            AyahItem(3, "اِلَّا الَّذٖینَ اٰمَنُوا وَعَمِلُوا الصَّالِحَاتِ وَتَوَاصَوْا بِالْحَقِّ وَتَوَاصَوْا بِالصَّبْرِ", "Ancak iman edip dünya ve âhiret için yararlı işler yapanlar, birbirlerine hakkı tavsiye edenler ve sabrı tavsiye edenler başkadır.", "Ji bilî yên ku bawerî anîn û karên qenc kirin û li ser heqî û sebrê hev şîret kirin.")
        ),
        // 105. Al-Fil
        105 to listOf(
            AyahItem(1, "اَلَمْ تَرَ كَیْفَ فَعَلَ رَبُّكَ بِاَصْحَابِ الْفٖیلِؕ", "Rabbin fil ordusuna ne yaptı, görmedin mi?", "Ka ji min re bêje: Ma tu dizanî Xwedayê te çi bi serê Eshabu’l-Fîl anî?"),
            AyahItem(2, "اَلَمْ یَجْعَلْ كَیْدَهُمْ فٖی تَضْلٖیلٍۙ", "Onların planlarını boşa çıkarmadı mı?", "Ma Wî fen û fûtê wan berhewa û pûç nekir?"),
            AyahItem(3, "وَاَرْسَلَ عَلَیْهِمْ طَیْرًا اَبَابٖیلَۙ", "Onların üzerine pişkin tuğladan yapılmış taşlar yağdıran sürü sürü kuşlar salmadı mı?", "Ma teyrên ebabîl bi ser wan de ref bi ref neşand?"),
            AyahItem(4, "تَرْمٖیهِمْ بِحِجَارَةٍ مِنْ سِجّٖیلٍࣕۙ", "Onların üzerine pişkin tuğladan yapılmış taşlar yağdıran sürü sürü kuşlar salmadı mı?", "Wan, kevirên ji heriya pehtî di wan werkirin."),
            AyahItem(5, "فَجَعَلَهُمْ كَعَصْفٍ مَاْكُولٍ", "Sonuçta Allah onları yenilip ezilmiş ekine çevirdi.", "Vêca wekî gihayê cûtî ku ketiye bin piya li wan kirin.")
        ),
        // 106. Quraysh
        106 to listOf(
            AyahItem(1, "لِاٖیلَافِ قُرَیْشٍۙ", "Kureyş’in güvenliğini, onların kış ve yaz yolculuklarında güvenliğini sağlamak için (Allah lutuflarda bulundu).", "Bi sedema hogirî û sehilkirina bazirganiyê bi qureyşiyan;"),
            AyahItem(2, "اٖیلَافِهِمْ رِحْلَةَ الشِّتَٓاءِ وَالصَّیْفِۚ", "Kureyş’in güvenliğini, onların kış ve yaz yolculuklarında güvenliğini sağlamak için (Allah lutuflarda bulundu).", "Hogirî û sehlkirina bazirganiya zivistan û havînê."),
            AyahItem(3, "فَلْیَعْبُدُوا رَبَّ هٰذَا الْبَیْتِۙ", "Onlar da kendilerini besleyip açlıklarını gideren ve her çeşit korkudan emin kılan şu evin rabbine kulluk etsinler.", "Vêca bila qureyşî, xwedayê vê malê (ku Ke’be ye) bihebînin."),
            AyahItem(4, "اَلَّذٖٓی اَطْعَمَهُمْ مِنْ جُوعٍ وَاٰمَنَهُمْ مِنْ خَوْفٍ", "Onlar da kendilerini besleyip açlıklarını gideren ve her çeşit korkudan emin kılan şu evin rabbine kulluk etsinler.", "Ew Xwedayê ku ew ji birçîbûnê têr kirine û ji tirsê ewle kirine.")
        ),
        // 107. Al-Ma'un
        107 to listOf(
            AyahItem(1, "اَرَاَیْتَ الَّذٖی یُكَذِّبُ بِالدّٖینِؕ", "Gördün mü dini yalan sayanı?", "Ji min re bêje: te dît ew ê ku bi roja cezadanê bawerî nayînî?"),
            AyahItem(2, "فَذٰلِكَ الَّذٖی یَدُعُّ الْیَتٖیمَۙ", "İşte odur yetimi itip kakan;", "Ha ew e ku yê sêwî bi dilhişkî dide paş (merhemetê lê nake)."),
            AyahItem(3, "وَلَا یَحُضُّ عَلٰى طَعَامِ الْمِسْكٖینِؕ", "Ve yoksula yedirmeyi özendirmeyen!", "Li ser nandayîn û têrkirina belengazan kesî diber ranake."),
            AyahItem(4, "فَوَیْلٌ لِلْمُصَلّٖینَۙ", "Vay haline o namaz kılanların ki,", "Wax li halê nimêjkeran be…"),
            AyahItem(5, "اَلَّذٖینَ هُمْ عَنْ صَلَاتِهِمْ سَاهُونَۙ", "Onlar namazlarının özünden uzaktırlar.", "Ew nimêjkerên ku haya wan ji nimêja wan nîn e."),
            AyahItem(6, "اَلَّذٖینَ هُمْ یُرَٓاؤُ𐻿نَۙ", "Onlar halka gösteriş yaparlar.", "Ew ên ku zerqekariyê (riyakariyê) dikin."),
            AyahItem(7, "وَیَمْنَعُونَ الْمَاعُونَ", "Hayra da engel olurlar.", "Riya qedandinê jî li ber hewcedaran digirin.")
        ),
        // 108. Al-Kawthar
        108 to listOf(
            AyahItem(1, "اِنَّٓا اَعْطَیْنَاكَ الْكَوْثَرَؕ", "Şüphesiz biz sana bitip tükenmez nimetler verdik.", "(Resûlê min) Bi rastî me kewser (xêra pir) daye te."),
            AyahItem(2, "فَصَلِّ لِرَبِّكَ وَانْحَرْؕ", "Şimdi sen rabbin için namaz kıl ve kurban kes!", "Vêca ji Rebbê xwe re nimêj bike û ji bo Wî şerjê bike."),
            AyahItem(3, "اِنَّ شَانِئَكَ هُوَ الْاَبْتَرُ", "Asıl soyu gelmeyecek olan, sana karşı nefret duyandır.", "Bi rastî yê ku ji te dikeribe û hez ji te nake, ew e yê warkor û bêdunde.")
        ),
        // 109. Al-Kafirun
        109 to listOf(
            AyahItem(1, "قُلْ یَٓا اَیُّهَا الْكَافِرُونَۙ", "De ki: “Ey inkârcılar!", "Bibêje: Hey gelî kafiran!"),
            AyahItem(2, "لَٓا اَعْبُدُ مَا تَعْبُدُونَۙ", "Ben sizin tapmakta olduğunuz şeylere tapmam.", "Ew ên ku hûn îbadetê wan dikin ez îbadetê wan nakim."),
            AyahItem(3, "وَلَٓا اَنْتُمْ عَابِدُونَ مَٓا اَعْبُدُۚ", "Siz de benim taptığıma tapıyor değilsiniz.", "Ew ê ku ez îbadetê Wî dikim hûn jî îbadetê Wî nakin."),
            AyahItem(4, "وَلَٓا اَنَا𐻾 عَابِدٌ مَا عَبَدْتُمْۙ", "Ben sizin taptıklarınıza tapacak değilim.", "Ez bi xwe dê nebim îbadetkerê yê ku hûn îbadetê wî dikin."),
            AyahItem(5, "وَلَٓا اَنْتُمْ عَابِدُونَ مَٓا اَعْبُدُؕ", "Siz de benim taptığıma tapıyor değilsiniz.", "Hûn bi xwe jî dê nebin îbadetkerê wî yê ku ez îbadetê Wî dikim."),
            AyahItem(6, "لَكُمْ دٖینُكُمْ وَلِیَ دٖینِ", "Sizin dininiz size, benim dinim banadır.”", "Dînê we ji we re û dînê min jî ji min re ye.")
        ),
        // 110. An-Nasr
        110 to listOf(
            AyahItem(1, "اِذَا جَٓاءَ نَصْرُ اللّٰهِ وَالْفَتْحُۙ", "Allah’ın yardımı gelip fetih gerçekleştiğinde;", "Dema arîkarîya Xwedê û serkevtin ji bo te hat."),
            AyahItem(2, "وَرَاَیْتَ النَّاسَ یَدْخُلُونَ فٖی دٖینِ اللّٰهِ اَفْوَاجًاۙ", "Ve insanların akın akın Allah’ın dinine girdiğini gördüğünde;", "Te jî dît ku mirov kom bi kom dikevine dînê Xwedê de."),
            AyahItem(3, "فَسَبِّحْ بِحَمْدِ رَبِّكَ وَاسْتَغْفِرْهُؕ اِنَّهُ كَانَ تَوَّابًا", "Rabbine hamdederek şanının yüceliğini dile getir ve O’ndan af dile; şüphesiz O, tövbeleri çok kabul edendir.", "Vêca hingê ḥemdê Xwedayê xwe bike, ji her kêmasiyê pak bidêre û daxwaza lêborîna xwe jê bike. Birastî jî ew, pir tobepejrên e.")
        ),
        // 111. Al-Masad
        111 to listOf(
            AyahItem(1, "تَبَّتْ یَدَٓا اَبٖی لَهَبٍ وَتَبَّؕ", "Ebû Leheb’in elleri kurusun! Kurudu zaten.", "Dest û lepê Ebû Leheb şeht bibin ku xêrê ji xwe nebîne û xêr ji xwe ne dît jî."),
            AyahItem(2, "مَٓا اَغْنٰى عَنْهُ مَالُهُ وَمَا كَسَبَؕ", "Ona ne malı fayda verdi ne de kazandığı başka şeyler.", "Serwet û qazanca ku kirî tu feyde nedayê."),
            AyahItem(3, "سَیَصْلٰى نَارًا ذَاتَ لَهَبٍۚ", "O, alev alev yanan ateşe atılacak!", "Ew ê bikeve agirekî bipêt."),
            AyahItem(4, "وَامْرَاَتُهُؕ حَمَّالَةَ الْحَطَبِۚ", "Dedikodu yapıp söz taşıyan karısı da.", "Jina wî jî barhilgira daran e (daran davêje ser agirê mêrê xwe)."),
            AyahItem(5, "فٖی جٖیدِهَا حَبْلٌ مِنْ مَسَدٍ", "Boynunda da ipten bükülmüş bir halat bulunacak.", "Werîsekî lihevhûnayî di stûyê wê de ye.")
        ),
        // 112. Al-Ikhlas
        112 to listOf(
            AyahItem(1, "قُلْ هُوَ اللّٰهُ اَحَدٌۚ", "De ki: “O, Allah’tır, tektir.", "Bibêje: Xwedê her yek e, tek e."),
            AyahItem(2, "اَللّٰهُ الصَّمَدُۚ", "Allah sameddir.", "Her Xwedê ye bergeha hewcedaran."),
            AyahItem(3, "لَمْ یَلِدْ وَلَمْ یُولَدْۙ", "Doğurmamış ve doğmamıştır.", "Kes jê çênebûye û ew jî ji kesî çênebûye."),
            AyahItem(4, "وَلَمْ یَكُنْ لَهُ كُفُوًا اَحَدٌ", "O’nun hiçbir dengi yoktur.”", "Tu hemkûf û hevta jî jê re tun in.")
        ),
        // 113. Al-Falaq
        113 to listOf(
            AyahItem(1, "قُلْ اَعُوذُ بِرَبِّ الْفَلَقِۙ", "De ki: “Sabahın rabbine sığınırım;", "Bibêje: Ez bi Xwedayê spêdeyê (şeveqê) xwe diparêzim."),
            AyahItem(2, "مِنْ شَرِّ مَا خَلَقَۙ", "Yarattığı şeylerden gelebilecek kötülüklerden;", "Ji xerabî û neqenciya her afirandiyekî…"),
            AyahItem(3, "وَمِنْ شَرِّ غَاسِقٍ اِذَا وَقَبَۙ", "Karanlığı çöktüğü zaman gecenin şerrinden;", "Ji zerar û neqenciya şevê gava bi tekûzî tarî dibe…"),
            AyahItem(4, "وَمِنْ شَرِّ النَّفَّاثَاتِ فِی الْعُقَدِۙ", "Düğümlere üfürenlerin şerrinden;", "Ji neqenciya sêrebendan dema di girêkan de pif dikin…"),
            AyahItem(5, "وَمِنْ شَرِّ حَاسِدٍ اِذَا حَسَدَ", "Bir de kıskandığı vakit kıskanç kişinin şerrinden!”", "Ji neqenciya kesê çavnebar gava çavnebariyê dike.")
        ),
        // 114. An-Nas
        114 to listOf(
            AyahItem(1, "قُلْ اَعُوذُ بِرَبِّ النَّاسِۙ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Bibêje: Ez bi Perwerdegarê mirovan xwe diparêzim…"),
            AyahItem(2, "مَلِكِ النَّاسِۙ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Padîşah û serwerê mirovan…"),
            AyahItem(3, "اِلٰهِ النَّاسِۙ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Xwedayê mirovan…"),
            AyahItem(4, "مِنْ شَرِّ الْوَسْوَاسِ الْخَنَّاسِۙ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Ji neqenciya (şeytan)ê tasawasker ê xwe nependî dike…"),
            AyahItem(5, "اَلَّذٖی یُوَسْوِسُ فٖی صُدُورِ النَّاسِۙ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Ew ê ku şubhe û tasewasê dixe dilên mirovan…"),
            AyahItem(6, "مِنَ الْجِنَّةِ وَالنَّاسِ", "De ki: “Cinlerden olsun insanlardan olsun, insanların kalplerine vesvese sokan sinsi şeytanın şerrinden insanların rabbine, insanların mâlik ve hâkimine, insanların mâbuduna sığınırım!”", "Ji şeytanên cinî û şeytanên insî.")
        ),
        // 36. Ya-Sin
        36 to listOf(
            AyahItem(1, "یٰسٓؕ", "Yâ-sîn.", "Yasîn."),
            AyahItem(2, "وَالْقُرْاٰنِ الْحَكٖیمِۙ", "Hikmet dolu Kur’an’a andolsun ki, sen kesinlikle dosdoğru bir yolda yürümek üzere gönderilmiş peygamberlerden birisin.", "Qesem bi Qurana Ḥekîm be."),
            AyahItem(3, "اِنَّكَ لَمِنَ الْمُرْسَلٖینَۙ", "Hikmet dolu Kur’an’a andolsun ki, sen kesinlikle dosdoğru bir yolda yürümek üzere gönderilmiş peygamberlerden birisin.", "Bêguman tu (ey Muhemmed) ji pêxemberan î."),
            AyahItem(4, "عَلٰى صِرَاطٍ مُسْتَقٖیمٍؕ", "Hikmet dolu Kur’an’a andolsun ki, sen kesinlikle dosdoğru bir yolda yürümek üzere gönderilmiş peygamberlerden birisin.", "Li ser riyeke rast û durist î."),
            AyahItem(5, "تَنْزٖیلَ الْعَزٖیزِ الرَّحٖیمِۙ", "(Bu kitap) aziz ve rahmeti bol olan Allah tarafından, ataları uyarılmamış, bu yüzden kendileri de gaflet içinde bulunan bir toplumu uyarasın diye indirilmiştir.", "(Ev Quran), ji cem Xwedayê ‘Ezîz ê Reḥîm ve hatiye hinartin…")
        ),
        // 67. Al-Mulk
        67 to listOf(
            AyahItem(1, "تَبَارَكَ الَّذٖی بِیَدِهِ الْمُلْكُؗ وَهُوَ عَلٰى كُلِّ شَیْءٍ قَدٖیرٌۙ", "Mutlak hükümranlık elinde olan Allah aşkındır, cömerttir ve O’nun her şeye gücü yeter.", "Ew Xwedayê ku xwedanî û fermandarî bi destê Wî ye pak û pîroz e û ew li ser her tiştî qadir e."),
            AyahItem(2, "اَلَّذٖی خَلَقَ الْمَوْتَ وَالْحَیٰوةَ لِیَبْلُوَكُمْ اَیُّكُمْ اَحْسَنُ عَمَلًاؕ وَهُوَ الْعَزٖیزُ الْغَفُورُۙ", "Hanginizin davranışça daha iyi olduğunu denemek için ölümü ve hayatı yaratan O’dur. O, güçlüdür, çok bağışlayıcıdır.", "Xwedê mirin û jiyan afirandin da ku we biceribîne; ka kar û kiryarên kê ji we çêtir e. Her ew e yê ‘Ezîz yê Xefûr.")
        )
    )

    fun getAudioUrlForSurah(surahNumber: Int): String {
        // High-availability CDN audio recitation by Sheikh Mishary Rashid Alafasy
        val padded = String.format("%03d", surahNumber)
        return "https://server8.mp3quran.net/afs/$padded.mp3"
    }
}
