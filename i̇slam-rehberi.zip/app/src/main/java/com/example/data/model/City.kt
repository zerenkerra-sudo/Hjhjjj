package com.example.data.model

import android.content.Context
import android.location.Geocoder
import java.util.Locale

data class City(
    val id: String,
    val nameTr: String,
    val nameKu: String,
    val country: String,
    val latitude: Double,
    val longitude: Double,
    val isGps: Boolean = false,
    val provinceTr: String = "",
    val provinceKu: String = "",
    val isDistrict: Boolean = false
) {
    fun getDisplayName(language: AppLanguage): String {
        return if (isGps) {
            if (nameTr.isNotBlank() && nameTr != GPS.nameTr && nameTr != "GPS Konumu") {
                nameTr
            } else {
                when (language) {
                    AppLanguage.TURKISH -> "GPS (Otomatik Konum)"
                    AppLanguage.KURMANJI -> "GPS (Cihê Otomatîk)"
                }
            }
        } else {
            when (language) {
                AppLanguage.TURKISH -> nameTr
                AppLanguage.KURMANJI -> nameKu
            }
        }
    }

    companion object {
        val GPS = City(
            id = "gps",
            nameTr = "GPS (Otomatik)",
            nameKu = "GPS (Otomatîk)",
            country = "Türkiye",
            latitude = 41.0082,
            longitude = 28.9784,
            isGps = true
        )

        // Comprehensive list of Turkey 81 provinces, Kurdish cities, European diaspora hubs, and major world cities
        val DEFAULT_CITIES = listOf(
            GPS,
            // Kutsal Şehirler
            City("makkah", "Mekke-i Mükerreme", "Mekke", "Suudi Arabistan", 21.4225, 39.8262),
            City("madinah", "Medine-i Münevvere", "Medîne", "Suudi Arabistan", 24.4672, 39.6111),
            City("quds", "Kudüs (Mescid-i Aksa)", "Quds (Qudsî Şerîf)", "Filistin", 31.7767, 35.2345),

            // Türkiye İlleri (Başta Bölge İlleri & Metropoller)
            City("diyarbakir", "Diyarbakır", "Amed (Diyarbekir)", "Türkiye", 37.9144, 40.2306),
            City("istanbul", "İstanbul", "Stembol", "Türkiye", 41.0082, 28.9784),
            City("ankara", "Ankara", "Enqere", "Türkiye", 39.9334, 32.8597),
            City("izmir", "İzmir", "Îzmîr", "Türkiye", 38.4192, 27.1287),
            City("van", "Van", "Wan", "Türkiye", 38.4891, 43.4089),
            City("mardin", "Mardin", "Mêrdîn", "Türkiye", 37.3212, 40.7245),
            City("sanliurfa", "Şanlıurfa", "Riha", "Türkiye", 37.1674, 38.7955),
            City("batman", "Batman", "Êlih", "Türkiye", 37.8812, 41.1293),
            City("sirnak", "Şırnak", "Şirnex", "Türkiye", 37.5164, 42.4592),
            City("hakkari", "Hakkâri", "Colemêrg", "Türkiye", 37.5833, 43.7333),
            City("siirt", "Siirt", "Sêrt", "Türkiye", 37.9333, 41.9500),
            City("bitlis", "Bitlis", "Bedlîs", "Türkiye", 38.4000, 42.1167),
            City("mus", "Muş", "Mûş", "Türkiye", 38.7432, 41.5064),
            City("agri", "Ağrı", "Agirî", "Türkiye", 39.7191, 43.0503),
            City("igdir", "Iğdır", "Îdir", "Türkiye", 39.9167, 44.0333),
            City("kars", "Kars", "Qers", "Türkiye", 40.6013, 43.0975),
            City("bingol", "Bingöl", "Çewlîg", "Türkiye", 38.8847, 40.4939),
            City("tunceli", "Tunceli", "Dêrsim", "Türkiye", 39.1079, 39.5401),
            City("elazig", "Elazığ", "Xarpêt", "Türkiye", 38.6810, 39.2264),
            City("malatya", "Malatya", "Meletî", "Türkiye", 38.3552, 38.3095),
            City("adana", "Adana", "Edene", "Türkiye", 37.0000, 35.3213),
            City("adiyaman", "Adıyaman", "Semsûr", "Türkiye", 37.7648, 38.2786),
            City("antep", "Gaziantep", "Entab", "Türkiye", 37.0662, 37.3833),
            City("kilis", "Kilis", "Kîlîs", "Türkiye", 36.7184, 37.1212),
            City("antalya", "Antalya", "Antalya", "Türkiye", 36.8969, 30.7133),
            City("bursa", "Bursa", "Bursa", "Türkiye", 40.1885, 29.0610),
            City("konya", "Konya", "Qonye", "Türkiye", 37.8667, 32.4833),
            City("kayseri", "Kayseri", "Qeyserî", "Türkiye", 38.7312, 35.4787),
            City("sivas", "Sivas", "Sêwas", "Türkiye", 39.7477, 37.0179),
            City("erzurum", "Erzurum", "Erzîrom", "Türkiye", 39.9043, 41.2679),
            City("erzincan", "Erzincan", "Erzîngan", "Türkiye", 39.7500, 39.5000),
            City("trabzon", "Trabzon", "Trabzon", "Türkiye", 41.0027, 39.7168),
            City("samsun", "Samsun", "Samsûn", "Türkiye", 41.2867, 36.3300),
            City("kahramanmaras", "Kahramanmaraş", "Mereş", "Türkiye", 37.5858, 36.9371),
            City("mersin", "Mersin", "Mersîn", "Türkiye", 36.8000, 34.6333),
            City("hatay", "Hatay", "Xetay", "Türkiye", 36.2023, 36.1606),
            City("osmaniye", "Osmaniye", "Osmaniye", "Türkiye", 37.0742, 36.2472),
            City("ardahan", "Ardahan", "Erdêxan", "Türkiye", 41.1105, 42.7022),
            City("bayburt", "Bayburt", "Baybûrd", "Türkiye", 40.2552, 40.2249),
            City("gumushane", "Gümüşhane", "Gimishane", "Türkiye", 40.4600, 39.4814),
            City("rize", "Rize", "Rize", "Türkiye", 41.0201, 40.5234),
            City("artvin", "Artvin", "Artvîn", "Türkiye", 41.1828, 41.8183),
            City("giresun", "Giresun", "Giresun", "Türkiye", 40.9128, 38.3895),
            City("ordu", "Ordu", "Ordu", "Türkiye", 40.9839, 37.8764),
            City("tokat", "Tokat", "Toqat", "Türkiye", 40.3167, 36.5500),
            City("amasya", "Amasya", "Amasya", "Türkiye", 40.6500, 35.8333),
            City("corum", "Çorum", "Çorum", "Türkiye", 40.5506, 34.9556),
            City("yozgat", "Yozgat", "Yozgat", "Türkiye", 39.8181, 34.8147),
            City("kirsehir", "Kırşehir", "Qirşehir", "Türkiye", 39.1425, 34.1709),
            City("nevsehir", "Nevşehir", "Nevşehir", "Türkiye", 38.6244, 34.7144),
            City("nigde", "Niğde", "Nîxde", "Türkiye", 37.9667, 34.6833),
            City("aksaray", "Aksaray", "Aqseray", "Türkiye", 38.3687, 34.0370),
            City("karaman", "Karaman", "Qaraman", "Türkiye", 37.1759, 33.2287),
            City("isparta", "Isparta", "Isparta", "Türkiye", 37.7648, 30.5566),
            City("burdur", "Burdur", "Burdur", "Türkiye", 37.7206, 30.2908),
            City("mugla", "Muğla", "Mugla", "Türkiye", 37.2153, 28.3636),
            City("aydin", "Aydın", "Aydin", "Türkiye", 37.8560, 27.8416),
            City("denizli", "Denizli", "Denîzlî", "Türkiye", 37.7765, 29.0864),
            City("manisa", "Manisa", "Manîsa", "Türkiye", 38.6191, 27.4289),
            City("usak", "Uşak", "Uşaq", "Türkiye", 38.6823, 29.4082),
            City("kutahya", "Kütahya", "Kutahya", "Türkiye", 39.4167, 29.9833),
            City("afyon", "Afyonkarahisar", "Afyon", "Türkiye", 38.7507, 30.5567),
            City("eskisehir", "Eskişehir", "Eskîşehr", "Türkiye", 39.7767, 30.5206),
            City("bilecik", "Bilecik", "Bilecik", "Türkiye", 40.1451, 29.9799),
            City("sakarya", "Sakarya (Adapazarı)", "Sakarya", "Türkiye", 40.7569, 30.3783),
            City("kocaeli", "Kocaeli (İzmit)", "Qocaêlî", "Türkiye", 40.8533, 29.8815),
            City("yalova", "Yalova", "Yalova", "Türkiye", 40.6500, 29.2667),
            City("tekirdag", "Tekirdağ", "Tekîrdag", "Türkiye", 40.9833, 27.5167),
            City("edirne", "Edirne", "Edirne", "Türkiye", 41.6772, 26.5557),
            City("kirklareli", "Kırklareli", "Qirqlarelî", "Türkiye", 41.7333, 27.2167),
            City("balikesir", "Balıkesir", "Balikesîr", "Türkiye", 39.6484, 27.8826),
            City("canakkale", "Çanakkale", "Çeneqqele", "Türkiye", 40.1553, 26.4142),
            City("bolu", "Bolu", "Bolu", "Türkiye", 40.7350, 31.6061),
            City("duzce", "Düzce", "Duzce", "Türkiye", 40.8438, 31.1565),
            City("zonguldak", "Zonguldak", "Zonguldak", "Türkiye", 41.4564, 31.7987),
            City("bartin", "Bartın", "Bartin", "Türkiye", 41.6344, 32.3375),
            City("karabuk", "Karabük", "Qarabuk", "Türkiye", 41.2061, 32.6277),
            City("kastamonu", "Kastamonu", "Qestamonu", "Türkiye", 41.3887, 33.7827),
            City("sinop", "Sinop", "Sînop", "Türkiye", 42.0231, 35.1531),
            City("cankiri", "Çankırı", "Çanqirî", "Türkiye", 40.6013, 33.6134),
            City("kirikkale", "Kırıkkale", "Qiriqqele", "Türkiye", 39.8468, 33.5153),

            // Irak & Kürdistan Bölgesi
            City("erbil", "Erbil", "Hewlêr", "Irak", 36.1911, 44.0092),
            City("sulaymaniyah", "Süleymaniye", "Silêmanî", "Irak", 35.5612, 45.4375),
            City("duhok", "Duhok", "Duhok", "Irak", 36.8679, 42.9904),
            City("kirkuk", "Kerkük", "Kerkûk", "Irak", 35.4681, 44.3922),
            City("zakho", "Zaho", "Zaxo", "Irak", 37.1439, 42.6869),
            City("halabja", "Halepçe", "Helebce", "Irak", 35.1778, 45.9861),
            City("baghdad", "Bağdat", "Bexda", "Irak", 33.3152, 44.3661),
            City("mosul", "Musul", "Mûsil", "Irak", 36.3400, 43.1300),
            City("basra", "Basra", "Besra", "Irak", 30.5081, 47.7835),

            // Suriye & Rojava
            City("damascus", "Şam", "Şam (Dîmeşq)", "Suriye", 33.5138, 36.2765),
            City("aleppo", "Halep", "Heleb", "Suriye", 36.2021, 37.1343),
            City("qamishli", "Kamışlı", "Qamişlo", "Suriye", 37.0503, 41.2294),
            City("kobani", "Kobani", "Kobanê", "Suriye", 36.8911, 38.3536),
            City("afrin", "Afrin", "Efrîn", "Suriye", 36.5119, 36.8692),
            City("hasakah", "Haseke", "Hesekê", "Suriye", 36.5022, 40.7483),

            // İran & Rojhilat
            City("urmia", "Urmiye", "Urmiyê", "İran", 37.5527, 45.0761),
            City("tabriz", "Tebriz", "Tebrîz", "İran", 38.0800, 46.2919),
            City("sanandaj", "Senendec (Sine)", "Sine", "İran", 35.3219, 46.9862),
            City("mahabad", "Mahabad", "Mehabad", "İran", 36.7631, 45.7222),
            City("kermanshah", "Kirmanşah", "Kirmaşan", "İran", 34.3142, 47.0650),
            City("tehran", "Tahran", "Taran", "İran", 35.6892, 51.3890),

            // Almanya (Geniş İslami & Türk/Kürt Topluluk)
            City("berlin", "Berlin", "Berlîn", "Almanya", 52.5200, 13.4050),
            City("cologne", "Köln", "Koln", "Almanya", 50.9375, 6.9603),
            City("frankfurt", "Frankfurt am Main", "Frankfûrt", "Almanya", 50.1109, 8.6821),
            City("munich", "Münih (München)", "Munîx", "Almanya", 48.1351, 11.5820),
            City("hamburg", "Hamburg", "Hambûrg", "Almanya", 53.5511, 9.9937),
            City("stuttgart", "Stuttgart", "Stuttgart", "Almanya", 48.7758, 9.1829),
            City("dusseldorf", "Düsseldorf", "Dusseldorf", "Almanya", 51.2277, 6.7735),
            City("dortmund", "Dortmund", "Dortmûnd", "Almanya", 51.5136, 7.4653),
            City("essen", "Essen", "Essen", "Almanya", 51.4556, 7.0116),
            City("bremen", "Bremen", "Bremen", "Almanya", 53.0793, 8.8017),
            City("hannover", "Hannover", "Hannover", "Almanya", 52.3759, 9.7320),
            City("duisburg", "Duisburg", "Dûîsbûrg", "Almanya", 51.4344, 6.7623),
            City("nuremberg", "Nürnberg", "Nurnberg", "Almanya", 49.4521, 11.0767),
            City("mannheim", "Mannheim", "Mannheîm", "Almanya", 49.4875, 8.4660),
            City("bochum", "Bochum", "Boxûm", "Almanya", 51.4818, 7.2162),
            City("wuppertal", "Wuppertal", "Wuppertal", "Almanya", 51.2562, 7.1508),
            City("bonn", "Bonn", "Bonn", "Almanya", 50.7374, 7.0982),

            // Fransa
            City("paris", "Paris", "Parîs", "Fransa", 48.8566, 2.3522),
            City("marseille", "Marsilya", "Marsîlya", "Fransa", 43.2965, 5.3698),
            City("lyon", "Lyon", "Lîyon", "Fransa", 45.7640, 4.8357),
            City("strasbourg", "Strazburg", "Strasbourg", "Fransa", 48.5734, 7.7521),
            City("nice", "Nice", "Nice", "Fransa", 43.7102, 7.2620),

            // İngiltere (Birleşik Krallık)
            City("london", "Londra", "London", "İngiltere", 51.5074, -0.1278),
            City("birmingham", "Birmingham", "Birmingham", "İngiltere", 52.4862, -1.8904),
            City("manchester", "Manchester", "Mançester", "İngiltere", 53.4808, -2.2426),

            // Hollanda
            City("amsterdam", "Amsterdam", "Amsterdam", "Hollanda", 52.3676, 4.9041),
            City("rotterdam", "Rotterdam", "Rotterdam", "Hollanda", 51.9244, 4.4777),
            City("hague", "Lahey (Den Haag)", "Den Haag", "Hollanda", 52.0705, 4.3007),
            City("utrecht", "Utrecht", "Utrecht", "Hollanda", 52.0907, 5.1214),

            // Belçika
            City("brussels", "Brüksel", "Bruksel", "Belçika", 50.8503, 4.3517),
            City("antwerp", "Anvers (Antwerpen)", "Antwerpen", "Belçika", 51.2194, 4.4025),
            City("genk", "Genk", "Genk", "Belçika", 50.9655, 5.5008),

            // Avusturya & İsviçre
            City("vienna", "Viyana", "Vîyana", "Avusturya", 48.2082, 16.3738),
            City("graz", "Graz", "Graz", "Avusturya", 47.0707, 15.4395),
            City("linz", "Linz", "Linz", "Avusturya", 48.3069, 14.2858),
            City("zurich", "Zürih", "Zurîx", "İsviçre", 47.3769, 8.5417),
            City("geneva", "Cenevre", "Cenevre", "İsviçre", 46.2044, 6.1432),
            City("basel", "Basel", "Basel", "İsviçre", 47.5596, 7.5886),
            City("bern", "Bern", "Bern", "İsviçre", 46.9480, 7.4474),

            // İskandinavya
            City("stockholm", "Stockholm", "Stokholm", "İsveç", 59.3293, 18.0686),
            City("gothenburg", "Göteborg", "Goteborg", "İsveç", 57.7089, 11.9746),
            City("malmo", "Malmö", "Malmo", "İsveç", 55.6050, 13.0038),
            City("oslo", "Oslo", "Oslo", "Norveç", 59.9139, 10.7522),
            City("copenhagen", "Kopenhag", "Kopenhag", "Danimarka", 55.6761, 12.5683),

            // Balkanlar
            City("sarajevo", "Saraybosna", "Sarayevo", "Bosna-Hersek", 43.8563, 18.4131),
            City("mostar", "Mostar", "Mostar", "Bosna-Hersek", 43.3438, 17.8078),
            City("skopje", "Üsküp", "Uskup", "Kuzey Makedonya", 41.9981, 21.4254),
            City("pristina", "Priştine", "Prîştîne", "Kosova", 42.6629, 21.1655),
            City("prizren", "Prizren", "Prizren", "Kosova", 42.2139, 20.7397),
            City("tirana", "Tiran", "Tîran", "Arnavutluk", 41.3275, 19.8187),
            City("novipazar", "Novi Pazar", "Novî Pazar", "Sırbistan", 43.1407, 20.5181),

            // Kafkaslar & Orta Asya
            City("baku", "Bakü", "Bakû", "Azerbaycan", 40.4093, 49.8671),
            City("ganja", "Gence", "Gence", "Azerbaycan", 40.6828, 46.3606),
            City("tashkent", "Taşkent", "Taşkent", "Özbekistan", 41.2995, 69.2401),
            City("samarkand", "Semerkant", "Semerqend", "Özbekistan", 39.6542, 66.9597),
            City("bukhara", "Buhara", "Buxara", "Özbekistan", 39.7681, 64.4556),
            City("almaty", "Almatı", "Almatî", "Kazakistan", 43.2220, 76.8512),
            City("astana", "Astana", "Astana", "Kazakistan", 51.1694, 71.4491),
            City("bishkek", "Bişkek", "Bîşkek", "Kırgızistan", 42.8746, 74.5698),
            City("dushanbe", "Duşanbe", "Duşenbe", "Tacikistan", 38.5598, 68.7870),
            City("ashgabat", "Aşkabat", "Eşqabat", "Türkmenistan", 37.9601, 58.3261),

            // Orta Doğu & Körfez
            City("riyadh", "Riyad", "Riyad", "Suudi Arabistan", 24.7136, 46.6753),
            City("jeddah", "Cidde", "Cîdde", "Suudi Arabistan", 21.4858, 39.1925),
            City("dubai", "Dubai", "Dubayî", "Birleşik Arap Emirlikleri", 25.2048, 55.2708),
            City("abudhabi", "Abu Dabi", "Ebû Debî", "Birleşik Arap Emirlikleri", 24.4539, 54.3773),
            City("doha", "Doha", "Doha", "Katar", 25.2854, 51.5310),
            City("kuwait", "Kuveyt", "Kuweyt", "Kuveyt", 29.3759, 47.9774),
            City("cairo", "Kahire", "Qahîre", "Mısır", 30.0444, 31.2357),
            City("alexandria", "İskenderiye", "Iskenderiye", "Mısır", 31.2001, 29.9187),
            City("tripoli", "Trablus", "Trablus", "Libya", 32.8872, 13.1913),
            City("tunis", "Tunus", "Tûnis", "Tunus", 36.8065, 10.1815),
            City("algiers", "Cezayir", "Cezayîr", "Cezayir", 36.7538, 3.0588),
            City("casablanca", "Kazablanka", "Darulbeyda", "Fas", 33.5731, -7.5898),
            City("beirut", "Beyrut", "Beyrût", "Lübnan", 33.8938, 35.5018),
            City("amman", "Amman", "Emman", "Ürdün", 31.9454, 35.9284),

            // Amerika & Diğer Dünya Metropolleri
            City("newyork", "New York", "New York", "ABD", 40.7128, -74.0060),
            City("chicago", "Chicago", "Şîkago", "ABD", 41.8781, -87.6298),
            City("losangeles", "Los Angeles", "Los Angeles", "ABD", 34.0522, -118.2437),
            City("houston", "Houston", "Hûston", "ABD", 29.7604, -95.3698),
            City("toronto", "Toronto", "Toronto", "Kanada", 43.6532, -79.3832),
            City("montreal", "Montreal", "Montreal", "Kanada", 45.5017, -73.5673),
            City("sydney", "Sidney", "Sydney", "Avustralya", -33.8688, 151.2093),
            City("melbourne", "Melbourne", "Melbûrn", "Avustralya", -37.8136, 144.9631),
            City("tokyo", "Tokyo", "Tokyo", "Japonya", 35.6762, 139.6503),
            City("seoul", "Seul", "Seûl", "Güney Kore", 37.5665, 126.9780),
            City("jakarta", "Cakarta", "Cakarta", "Endonezya", -6.2088, 106.8456),
            City("kualalumpur", "Kuala Lumpur", "Kuala Lûmpûr", "Malezya", 3.1390, 101.6869),
            City("islamabad", "İslamabad", "Islamabad", "Pakistan", 33.6844, 73.0479),
            City("karachi", "Karaçi", "Keraçî", "Pakistan", 24.8607, 67.0011),
            City("lahore", "Lahor", "Lahor", "Pakistan", 31.5204, 74.3587),
            City("dhaka", "Dakka", "Deqqa", "Bangladeş", 23.8103, 90.4125),
            City("delhi", "Yeni Delhi", "Delhiya Nû", "Hindistan", 28.6139, 77.2090)
        )

        /**
         * Live worldwide lookup (Open-Meteo Geocoding + Android Geocoder fallback)
         * to find ANY city, district (ilçe), town, or village anywhere on Earth.
         */
        suspend fun searchWorldCitiesOnline(
            context: Context,
            query: String,
            language: AppLanguage = AppLanguage.TURKISH
        ): List<City> {
            val trimmed = query.trim()
            if (trimmed.length < 2) return emptyList()

            val results = mutableListOf<City>()
            val langCode = if (language == AppLanguage.KURMANJI) "en" else "tr"

            try {
                val geoResp = com.example.data.remote.ApiClient.openMeteoGeocodingApi
                    .searchLocations(name = trimmed, count = 20, language = langCode)
                geoResp.results?.forEach { dto ->
                    val name = dto.name?.trim().orEmpty()
                    val lat = dto.latitude ?: return@forEach
                    val lng = dto.longitude ?: return@forEach
                    if (name.isEmpty()) return@forEach

                    val admin1 = dto.admin1?.trim().orEmpty()
                    val admin2 = dto.admin2?.trim().orEmpty()
                    val country = dto.country?.trim().orEmpty()

                    val provincePart = when {
                        admin2.isNotEmpty() && !admin2.equals(name, ignoreCase = true) && admin1.isNotEmpty() && !admin1.equals(admin2, ignoreCase = true) ->
                            "$admin2, $admin1"
                        admin1.isNotEmpty() && !admin1.equals(name, ignoreCase = true) ->
                            admin1
                        admin2.isNotEmpty() && !admin2.equals(name, ignoreCase = true) ->
                            admin2
                        else -> ""
                    }

                    val displayName = if (provincePart.isNotEmpty()) "$name, $provincePart" else name
                    val hasDistrict = admin1.isNotEmpty() && !admin1.equals(name, ignoreCase = true)

                    results.add(
                        City(
                            id = "om_${dto.id ?: "${lat}_${lng}"}",
                            nameTr = displayName,
                            nameKu = displayName,
                            country = country.ifEmpty { "Dünya" },
                            latitude = lat,
                            longitude = lng,
                            isGps = false,
                            provinceTr = admin1,
                            provinceKu = admin1,
                            isDistrict = hasDistrict
                        )
                    )
                }
            } catch (_: Exception) {
                // Fall through to Android Geocoder fallback below
            }

            if (results.isEmpty()) {
                results.addAll(searchWorldCities(context, trimmed))
            }

            return results.distinctBy { "${it.nameTr.lowercase()}_${it.country.lowercase()}" }
        }

        /**
         * Android Geocoder lookup fallback to find any city, town or district anywhere on Earth.
         */
        @Suppress("DEPRECATION")
        fun searchWorldCities(context: Context, query: String): List<City> {
            if (query.trim().length < 2) return emptyList()
            return try {
                val geocoder = Geocoder(context, Locale.getDefault())
                val addresses = geocoder.getFromLocationName(query.trim(), 8) ?: emptyList()
                addresses.mapNotNull { addr ->
                    val districtOrCity = addr.subLocality
                        ?: addr.locality
                        ?: addr.subAdminArea
                        ?: addr.adminArea
                        ?: addr.featureName
                        ?: return@mapNotNull null
                    val province = addr.adminArea ?: addr.subAdminArea ?: ""
                    val countryName = addr.countryName ?: ""
                    val fullTitle = when {
                        province.isNotBlank() && !province.equals(districtOrCity, ignoreCase = true) ->
                            "$districtOrCity, $province"
                        countryName.isNotBlank() && !districtOrCity.contains(countryName) ->
                            "$districtOrCity, $countryName"
                        else -> districtOrCity
                    }
                    City(
                        id = "geo_${addr.latitude}_${addr.longitude}",
                        nameTr = fullTitle,
                        nameKu = fullTitle,
                        country = countryName.ifBlank { "Dünya" },
                        latitude = addr.latitude,
                        longitude = addr.longitude,
                        isGps = false,
                        provinceTr = province,
                        provinceKu = province,
                        isDistrict = province.isNotBlank() && !province.equals(districtOrCity, ignoreCase = true)
                    )
                }
            } catch (e: Exception) {
                emptyList()
            }
        }
    }
}
