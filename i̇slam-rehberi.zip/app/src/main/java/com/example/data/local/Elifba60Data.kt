package com.example.data.local

import com.example.data.model.ElifbaItem

data class ElifbaPageInfo(
    val pageNumber: Int, // 1 .. 60
    val sectionNumber: Int, // 1 .. 10
    val titleTr: String,
    val titleKu: String,
    val subtitleTr: String,
    val subtitleKu: String,
    val descriptionTr: String,
    val descriptionKu: String,
    val items: List<ElifbaItem>,
    val ruleNoteTr: String = "",
    val ruleNoteKu: String = ""
)

object Elifba60Data {

    val SECTIONS = listOf(
        "1. Bölüm: Harflerin Yalın Hali (Müfredat)" to "Beşa 1: Tîpên Erebî (Hateyî)",
        "2. Bölüm: Harflerin Bitişme Halleri" to "Beşa 2: Awayê Girêdana Tîpan",
        "3. Bölüm: Üstün (Fetha / Ser)" to "Beşa 3: Tevgera Ser (Fetha)",
        "4. Bölüm: Esre (Kesra / Bin)" to "Beşa 4: Tevgera Bin (Kesra)",
        "5. Bölüm: Ötre (Zamme / Bêş)" to "Beşa 5: Tevgera Bêş (Zamme)",
        "6. Bölüm: Cezim (Sükûn / Sekin)" to "Beşa 6: Cezm û Sekin",
        "7. Bölüm: Şedde (Tecdîd / Şedd)" to "Beşa 7: Şedd û Xûnne",
        "8. Bölüm: Med (Uzatma) Harfleri" to "Beşa 8: Tîpên Dirêjkirinê (Med)",
        "9. Bölüm: Tenvin (İki Üstün, Esre, Ötre)" to "Beşa 9: Tenwîn (Du Ser, Bin, Bêş)",
        "10. Bölüm: Tecvid & Kur'an Okuma Alıştırmaları" to "Beşa 10: Tecwîd & Xwendina Qur'anê"
    )

    val PAGES: List<ElifbaPageInfo> by lazy {
        generate60Pages()
    }

    fun getPage(pageNumber: Int): ElifbaPageInfo {
        val index = (pageNumber - 1).coerceIn(0, 59)
        return PAGES[index]
    }

    private fun generate60Pages(): List<ElifbaPageInfo> {
        val list = ArrayList<ElifbaPageInfo>(60)
        for (p in 1..60) {
            val secIdx = ((p - 1) / 6).coerceIn(0, 9)
            val secTitles = SECTIONS[secIdx]
            val pageInSec = (p - 1) % 6 + 1
            list.add(createPage(p, secIdx + 1, secTitles.first, secTitles.second, pageInSec))
        }
        return list
    }

    private fun createPage(
        pageNum: Int,
        sectionNum: Int,
        secTitleTr: String,
        secTitleKu: String,
        pageInSec: Int
    ): ElifbaPageInfo {
        val items = getItemsForPage(pageNum, sectionNum, pageInSec)
        val ruleTr = getRuleTr(pageNum, sectionNum)
        val ruleKu = getRuleKu(pageNum, sectionNum)

        return ElifbaPageInfo(
            pageNumber = pageNum,
            sectionNumber = sectionNum,
            titleTr = "$secTitleTr • Yaprak $pageNum / 60",
            titleKu = "$secTitleKu • Rûpel $pageNum / 60",
            subtitleTr = "Kur'an Elifbası • $pageNum. Yaprak",
            subtitleKu = "Elîfbaya Qur'anê • Rûpela $pageNum",
            descriptionTr = "Her harfin ve kelimenin altındaki Dinle butonuna basarak Arapça aslıyla birebir sesli okunuşunu dinleyebilirsiniz.",
            descriptionKu = "Hûn dikarin li ser bişkoka Guhdarî Bike ya binê her tîp an peyvê bixin da ku dengê wê yê Erebî yê resen bibihîzin.",
            items = items,
            ruleNoteTr = ruleTr,
            ruleNoteKu = ruleKu
        )
    }

    private fun getItemsForPage(pageNum: Int, sectionNum: Int, pageInSec: Int): List<ElifbaItem> {
        return when (sectionNum) {
            1 -> getSection1Items(pageInSec)
            2 -> getSection2Items(pageInSec)
            3 -> getSection3Items(pageInSec)
            4 -> getSection4Items(pageInSec)
            5 -> getSection5Items(pageInSec)
            6 -> getSection6Items(pageInSec)
            7 -> getSection7Items(pageInSec)
            8 -> getSection8Items(pageInSec)
            9 -> getSection9Items(pageInSec)
            10 -> getSection10Items(pageInSec)
            else -> getSection1Items(pageInSec)
        }
    }

    // 1. Bölüm (Sayfa 1 - 6): Harflerin Yalın Hali
    private fun getSection1Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p1_1", "ا", "Elif", "Elîf", "Elif", "Elîf", "Düz ince ses", "Dengê zirav"),
                ElifbaItem("p1_2", "ب", "Be", "Bê", "Be", "Bê", "Dudak harfi", "Tîpa lêvê"),
                ElifbaItem("p1_3", "ت", "Te", "Tê", "Te", "Tê", "Üst diş eti", "Binê diranan"),
                ElifbaItem("p1_4", "ث", "Se", "Sê", "Se (Peltek)", "Sê (Nerm)", "Peltek ince", "Peltek zirav")
            )
            2 -> listOf(
                ElifbaItem("p2_1", "ج", "Cim", "Cîm", "Cim", "Cîm", "Dil ortası damağa", "Navenda ziman"),
                ElifbaItem("p2_2", "ح", "Ha", "Ha", "Ha (Boğaz)", "Ha (Qirik)", "Boğaz ortası", "Ji qirikê"),
                ElifbaItem("p2_3", "خ", "Hı", "Xî", "Hı (Hırıltılı)", "Xî (Tîpa X)", "Hırıltılı boğaz", "Dengê X ya kurdî"),
                ElifbaItem("p2_4", "د", "Dal", "Dal", "Dal", "Dal", "İnce D sesi", "Dengê D yê zelal")
            )
            3 -> listOf(
                ElifbaItem("p3_1", "ذ", "Zel", "Zel", "Zel (Peltek)", "Zel (Nerm)", "Peltek Z", "Z-ya nerm"),
                ElifbaItem("p3_2", "ر", "Ra", "Ra", "Ra", "Ra", "Dil ucu üst damak", "Tîpa R"),
                ElifbaItem("p3_3", "ز", "Ze", "Zê", "Ze (Keskin)", "Zê (Tûj)", "Keskin diş sesi", "Z-ya tûj"),
                ElifbaItem("p3_4", "س", "Sin", "Sîn", "Sin (İnce)", "Sîn (Zirav)", "İnce S sesi", "S-ya zirav")
            )
            4 -> listOf(
                ElifbaItem("p4_1", "ش", "Şın", "Şîn", "Şın", "Şîn", "Geniş Ş sesi", "Tîpa Ş ya kurdî"),
                ElifbaItem("p4_2", "ص", "Sad", "Sad", "Sad (Kalın)", "Sad (Qalind)", "Kalın ve dolgun", "S-ya qalind"),
                ElifbaItem("p4_3", "ض", "Dad", "Dad", "Dad (Kalın)", "Dad (Qalind)", "Azı dişlerinden", "Ji diranên aş"),
                ElifbaItem("p4_4", "ط", "Tı", "Tı", "Tı (Kalın)", "Tı (Qalind)", "Kalın kuvvetli T", "T-ya qalind")
            )
            5 -> listOf(
                ElifbaItem("p5_1", "ظ", "Zı", "Zı", "Zı (Kalın Peltek)", "Zı (Qalind)", "Kalın peltek Z", "Z-ya qalind"),
                ElifbaItem("p5_2", "ع", "Ayn", "Eyn", "Ayn (Boğaz)", "Eyn (Qirikî)", "Boğaz sıkılarak", "Ji kûrahiya qirikê"),
                ElifbaItem("p5_3", "غ", "Gayn", "Xeyn", "Gayn (Kalın)", "Xeyn", "Boğazın üstü", "Dengê Xeynê"),
                ElifbaItem("p5_4", "ف", "Fe", "Fê", "Fe", "Fê", "Alt dudak ön diş", "Lêva jêr diranê jor"),
                ElifbaItem("p5_5", "ق", "Kaf", "Qaf", "Kaf (Kalın Q)", "Qaf (Tîpa Q)", "Kalın gırtlak Kaf", "Q-ya kurmancî")
            )
            else -> listOf(
                ElifbaItem("p6_1", "ك", "Kef", "Kêf", "Kef (İnce K)", "Kêf (Zirav)", "İnce zarif K", "K-ya zirav"),
                ElifbaItem("p6_2", "ل", "Lam", "Lam", "Lam", "Lam", "Dil ucu üst damak", "Tîpa L"),
                ElifbaItem("p6_3", "م", "Mim", "Mîm", "Mim", "Mîm", "İki dudak kapanır", "Lêv digihîjin hev"),
                ElifbaItem("p6_4", "ن", "Nun", "Nûn", "Nun", "Nûn", "Genizden gelen ses", "Dengê difinî"),
                ElifbaItem("p6_5", "و", "Vav", "Waw", "Vav (W)", "Waw (Tîpa W)", "Dudaklar yuvarlak", "W-ya kurdî"),
                ElifbaItem("p6_6", "ه", "He", "Hê", "He (İnce)", "Hê (Zirav)", "Göğüsten ince H", "H-ya zirav"),
                ElifbaItem("p6_7", "ي", "Ye", "Yê", "Ye", "Yê", "Dil ortası yukarı", "Tîpa Y")
            )
        }
    }

    // 2. Bölüm (Sayfa 7 - 12): Bitişme Halleri
    private fun getSection2Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p7_1", "بـ ـبـ ـب", "Be Bitişme", "Bê Girêdan", "Be (Başta-Ortada-Sonda)", "Bê (Destpêk-Navîn-Dawî)", "Bitişir", "Tê girêdan"),
                ElifbaItem("p7_2", "تـ ـتـ ـت", "Te Bitişme", "Tê Girêdan", "Te (Başta-Ortada-Sonda)", "Tê (Destpêk-Navîn-Dawî)", "İki noktalı", "Bi du xalan"),
                ElifbaItem("p7_3", "ثـ ـثـ ـث", "Se Bitişme", "Sê Girêdan", "Se (Başta-Ortada-Sonda)", "Sê (Destpêk-Navîn-Dawî)", "Üç noktalı", "Bi sê xalan")
            )
            2 -> listOf(
                ElifbaItem("p8_1", "جـ ـجـ ـج", "Cim Bitişme", "Cîm Girêdan", "Cim (Başta-Ortada-Sonda)", "Cîm (Destpêk-Navîn-Dawî)", "Noktası altta", "Xala wê li jêr e"),
                ElifbaItem("p8_2", "حـ ـحـ ـح", "Ha Bitişme", "Ha Girêdan", "Ha (Başta-Ortada-Sonda)", "Ha (Destpêk-Navîn-Dawî)", "Noktasız boğaz", "Bê xal"),
                ElifbaItem("p8_3", "خـ ـخـ ـخ", "Hı Bitişme", "Xî Girêdan", "Hı (Başta-Ortada-Sonda)", "Xî (Destpêk-Navîn-Dawî)", "Noktası üstte", "Xala wê li jor e")
            )
            3 -> listOf(
                ElifbaItem("p9_1", "سـ ـسـ ـس", "Sin Bitişme", "Sîn Girêdan", "Sin (Başta-Ortada-Sonda)", "Sîn (Destpêk-Navîn-Dawî)", "Üç dişli", "Bi sê diranan"),
                ElifbaItem("p9_2", "شـ ـشـ ـش", "Şın Bitişme", "Şîn Girêdan", "Şın (Başta-Ortada-Sonda)", "Şîn (Destpêk-Navîn-Dawî)", "Üç noktalı", "Bi sê xalan"),
                ElifbaItem("p9_3", "صـ ـصـ ـص", "Sad Bitişme", "Sad Girêdan", "Sad (Başta-Ortada-Sonda)", "Sad (Destpêk-Navîn-Dawî)", "Baş kısmı yuvarlak", "Qalind"),
                ElifbaItem("p9_4", "ضـ ـضـ ـض", "Dad Bitişme", "Dad Girêdan", "Dad (Başta-Ortada-Sonda)", "Dad (Destpêk-Navîn-Dawî)", "Üstü tek noktalı kalın", "Bi yek xal li jor")
            )
            4 -> listOf(
                ElifbaItem("p10_1", "طـ ـطـ ـط", "Tı Bitişme", "Tı Girêdan", "Tı (Başta-Ortada-Sonda)", "Tı (Destpêk-Navîn-Dawî)", "Çizgili kalın", "Bi xêz"),
                ElifbaItem("p10_2", "ظـ ـظـ ـظ", "Zı Bitişme", "Zı Girêdan", "Zı (Başta-Ortada-Sonda)", "Zı (Destpêk-Navîn-Dawî)", "Noktalı kalın peltek", "Qalind û bi xal"),
                ElifbaItem("p10_3", "عـ ـعـ ـع", "Ayn Bitişme", "Eyn Girêdan", "Ayn (Başta-Ortada-Sonda)", "Eyn (Destpêk-Navîn-Dawî)", "Ortada içi kapalı", "Di navîn de girtî"),
                ElifbaItem("p10_4", "غـ ـغـ ـغ", "Gayn Bitişme", "Xeyn Girêdan", "Gayn (Başta-Ortada-Sonda)", "Xeyn (Destpêk-Navîn-Dawî)", "Üstü noktalı", "Bi xal")
            )
            5 -> listOf(
                ElifbaItem("p11_1", "فـ ـفـ ـف", "Fe Bitişme", "Fê Girêdan", "Fe (Başta-Ortada-Sonda)", "Fê (Destpêk-Navîn-Dawî)", "Tek noktalı", "Bi yek xal"),
                ElifbaItem("p11_2", "قـ ـقـ ـق", "Kaf Bitişme", "Qaf Girêdan", "Kaf (Başta-Ortada-Sonda)", "Qaf (Destpêk-Navîn-Dawî)", "İki noktalı", "Bi du xalan"),
                ElifbaItem("p11_3", "كـ ـكـ ـك", "Kef Bitişme", "Kêf Girêdan", "Kef (Başta-Ortada-Sonda)", "Kêf (Destpêk-Navîn-Dawî)", "Başta kavisli", "Zirav"),
                ElifbaItem("p11_4", "لـ ـلـ ـل", "Lam Bitişme", "Lam Girêdan", "Lam (Başta-Ortada-Sonda)", "Lam (Destpêk-Navîn-Dawî)", "Uzun kollu", "Tîpa L")
            )
            else -> listOf(
                ElifbaItem("p12_1", "مـ ـمـ ـم", "Mim Bitişme", "Mîm Girêdan", "Mim (Başta-Ortada-Sonda)", "Mîm (Destpêk-Navîn-Dawî)", "Yuvarlak halka", "Tîpa M"),
                ElifbaItem("p12_2", "نـ ـنـ ـن", "Nun Bitişme", "Nûn Girêdan", "Nun (Başta-Ortada-Sonda)", "Nûn (Destpêk-Navîn-Dawî)", "Üstü tek noktalı", "Xala wê li jor e"),
                ElifbaItem("p12_3", "هـ ـهـ ـه", "He Bitişme", "Hê Girêdan", "He (Başta-Ortada-Sonda)", "Hê (Destpêk-Navîn-Dawî)", "Ortada iki gözlü", "Di navîn de du çav"),
                ElifbaItem("p12_4", "يـ ـيـ ـي", "Ye Bitişme", "Yê Girêdan", "Ye (Başta-Ortada-Sonda)", "Yê (Destpêk-Navîn-Dawî)", "Altı iki noktalı", "Di bin de du xal"),
                ElifbaItem("p12_5", "لا ـلا", "Lamelif", "Lamelîf", "Lâm-Elif (Lam + Elif)", "Lam-Elîf (Lam + Elîf)", "Lam ve Elif birleşimi", "Girêdana Lam û Elîfê"),
                ElifbaItem("p12_6", "ا د ذ ر ز و", "Bitişmeyenler", "Tîpên Negirêdayî", "Elif, Dal, Zel, Ra, Ze, Vav", "Elîf, Dal, Zel, Ra, Zê, Waw", "Kendinden sonrakine bitişmez", "Bi tîpa pişt re nayên girêdan")
            )
        }
    }

    // 3. Bölüm (Sayfa 13 - 18): Üstün (Fetha / Ser)
    private fun getSection3Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p13_1", "اَ", "Elif Üstün", "Elîf Ser", "E", "E", "İnce", "Zirav"),
                ElifbaItem("p13_2", "بَ", "Be Üstün", "Bê Ser", "Be", "Be", "İnce", "Zirav"),
                ElifbaItem("p13_3", "تَ", "Te Üstün", "Tê Ser", "Te", "Te", "İnce", "Zirav"),
                ElifbaItem("p13_4", "ثَ", "Se Üstün", "Sê Ser", "Se", "Se", "Peltek", "Nerm")
            )
            2 -> listOf(
                ElifbaItem("p14_1", "جَ", "Cim Üstün", "Cîm Ser", "Ce", "Ce", "İnce", "Zirav"),
                ElifbaItem("p14_2", "حَ", "Ha Üstün", "Ha Ser", "Ha", "Ha", "Boğaz", "Qirikî"),
                ElifbaItem("p14_3", "خَ", "Hı Üstün", "Xî Ser", "Ha", "Xa", "Hırıltılı kalın", "X-ya kurdî"),
                ElifbaItem("p14_4", "دَ", "Dal Üstün", "Dal Ser", "De", "De", "İnce", "Zirav")
            )
            3 -> listOf(
                ElifbaItem("p15_1", "ذَ", "Zel Üstün", "Zel Ser", "Ze", "Ze", "Peltek", "Nerm"),
                ElifbaItem("p15_2", "رَ", "Ra Üstün", "Ra Ser", "Ra", "Ra", "Kalın okunur", "Qalind dibe"),
                ElifbaItem("p15_3", "زَ", "Ze Üstün", "Zê Ser", "Ze", "Ze", "Keskin", "Tûj"),
                ElifbaItem("p15_4", "سَ", "Sin Üstün", "Sîn Ser", "Se", "Se", "İnce", "Zirav")
            )
            4 -> listOf(
                ElifbaItem("p16_1", "شَ", "Şın Üstün", "Şîn Ser", "Şe", "Şe", "İnce", "Zirav"),
                ElifbaItem("p16_2", "صَ", "Sad Üstün", "Sad Ser", "Sa", "Sa", "Kalın", "Qalind"),
                ElifbaItem("p16_3", "ضَ", "Dad Üstün", "Dad Ser", "Da", "Da", "Kalın", "Qalind"),
                ElifbaItem("p16_4", "طَ", "Tı Üstün", "Tı Ser", "Ta", "Ta", "Kalın", "Qalind")
            )
            5 -> listOf(
                ElifbaItem("p17_1", "ظَ", "Zı Üstün", "Zı Ser", "Za", "Za", "Kalın peltek", "Qalind"),
                ElifbaItem("p17_2", "عَ", "Ayn Üstün", "Eyn Ser", "A", "E", "Boğaz sıkılarak", "Ji qirikê"),
                ElifbaItem("p17_3", "غَ", "Gayn Üstün", "Xeyn Ser", "Ga", "Xa", "Kalın", "Qalind"),
                ElifbaItem("p17_4", "فَ", "Fe Üstün", "Fê Ser", "Fe", "Fe", "İnce", "Zirav")
            )
            else -> listOf(
                ElifbaItem("p18_1", "قَ", "Kaf Üstün", "Qaf Ser", "Ka", "Qa", "Kalın Q", "Q-ya resen"),
                ElifbaItem("p18_2", "كَ", "Kef Üstün", "Kêf Ser", "Ke", "Ke", "İnce", "Zirav"),
                ElifbaItem("p18_3", "لَ", "Lam Üstün", "Lam Ser", "Le", "Le", "İnce", "Zirav"),
                ElifbaItem("p18_4", "مَ", "Mim Üstün", "Mîm Ser", "Me", "Me", "İnce", "Zirav"),
                ElifbaItem("p18_5", "نَ", "Nun Üstün", "Nûn Ser", "Ne", "Ne", "İnce", "Zirav"),
                ElifbaItem("p18_6", "وَ", "Vav Üstün", "Waw Ser", "Ve", "We", "İnce", "W-ya kurdî"),
                ElifbaItem("p18_7", "هَ", "He Üstün", "Hê Ser", "He", "He", "İnce", "Zirav"),
                ElifbaItem("p18_8", "يَ", "Ye Üstün", "Yê Ser", "Ye", "Ye", "İnce", "Zirav"),
                ElifbaItem("p18_9", "كَتَبَ", "Ketebe", "Ketebe", "Ke - te - be", "Ke - te - be", "Yazdı", "Nivîsand")
            )
        }
    }

    // 4. Bölüm (Sayfa 19 - 24): Esre (Kesra / Bin)
    private fun getSection4Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p19_1", "اِ", "Elif Esre", "Elîf Bin", "İ", "Î", "İnce", "Zirav"),
                ElifbaItem("p19_2", "بِ", "Be Esre", "Bê Bin", "Bi", "Bî", "İnce", "Zirav"),
                ElifbaItem("p19_3", "تِ", "Te Esre", "Tê Bin", "Ti", "Tî", "İnce", "Zirav"),
                ElifbaItem("p19_4", "ثِ", "Se Esre", "Sê Bin", "Si", "Sî", "Peltek", "Nerm")
            )
            2 -> listOf(
                ElifbaItem("p20_1", "جِ", "Cim Esre", "Cîm Bin", "Ci", "Cî", "İnce", "Zirav"),
                ElifbaItem("p20_2", "حِ", "Ha Esre", "Ha Bin", "Hı / Hi", "Hî", "Boğaz", "Qirikî"),
                ElifbaItem("p20_3", "خِ", "Hı Esre", "Xî Bin", "Hı", "Xî", "Hırıltılı", "X-ya kurdî"),
                ElifbaItem("p20_4", "دِ", "Dal Esre", "Dal Bin", "Di", "Dî", "İnce", "Zirav")
            )
            3 -> listOf(
                ElifbaItem("p21_1", "ذِ", "Zel Esre", "Zel Bin", "Zi", "Zî", "Peltek", "Nerm"),
                ElifbaItem("p21_2", "رِ", "Ra Esre", "Ra Bin", "Ri", "Rî", "Esreli Ra incedir", "R-ya zirav"),
                ElifbaItem("p21_3", "زِ", "Ze Esre", "Zê Bin", "Zi", "Zî", "İnce", "Zirav"),
                ElifbaItem("p21_4", "سِ", "Sin Esre", "Sîn Bin", "Si", "Sî", "İnce", "Zirav")
            )
            4 -> listOf(
                ElifbaItem("p22_1", "شِ", "Şın Esre", "Şîn Bin", "Şi", "Şî", "İnce", "Zirav"),
                ElifbaItem("p22_2", "صِ", "Sad Esre", "Sad Bin", "Sı", "Sî (Qalind)", "Kalın", "Qalind"),
                ElifbaItem("p22_3", "ضِ", "Dad Esre", "Dad Bin", "Dı", "Dî (Qalind)", "Kalın", "Qalind"),
                ElifbaItem("p22_4", "طِ", "Tı Esre", "Tı Bin", "Tı", "Tî (Qalind)", "Kalın", "Qalind")
            )
            5 -> listOf(
                ElifbaItem("p23_1", "ظِ", "Zı Esre", "Zı Bin", "Zı", "Zî (Qalind)", "Kalın peltek", "Qalind"),
                ElifbaItem("p23_2", "عِ", "Ayn Esre", "Eyn Bin", "İ (Boğaz)", "Î (Eyn)", "Boğaz", "Qirikî"),
                ElifbaItem("p23_3", "غِ", "Gayn Esre", "Xeyn Bin", "Gı", "Xî", "Kalın", "Qalind"),
                ElifbaItem("p23_4", "فِ", "Fe Esre", "Fê Bin", "Fi", "Fî", "İnce", "Zirav")
            )
            else -> listOf(
                ElifbaItem("p24_1", "قِ", "Kaf Esre", "Qaf Bin", "Kı", "Qî", "Kalın Q", "Q-ya kurdî"),
                ElifbaItem("p24_2", "كِ", "Kef Esre", "Kêf Bin", "Ki", "Kî", "İnce", "Zirav"),
                ElifbaItem("p24_3", "لِ", "Lam Esre", "Lam Bin", "Li", "Lî", "İnce", "Zirav"),
                ElifbaItem("p24_4", "مِ", "Mim Esre", "Mîm Bin", "Mi", "Mî", "İnce", "Zirav"),
                ElifbaItem("p24_5", "نِ", "Nun Esre", "Nûn Bin", "Ni", "Nî", "İnce", "Zirav"),
                ElifbaItem("p24_6", "وِ", "Vav Esre", "Waw Bin", "Vi", "Wî", "İnce", "W-ya kurdî"),
                ElifbaItem("p24_7", "هِ", "He Esre", "Hê Bin", "Hi", "Hî", "İnce", "Zirav"),
                ElifbaItem("p24_8", "يِ", "Ye Esre", "Yê Bin", "Yi", "Yî", "İnce", "Zirav"),
                ElifbaItem("p24_9", "عَلِمَ", "Alime", "Elime", "A - li - me", "E - li - me", "Bildi", "Zanî"),
                ElifbaItem("p24_10", "سَمِعَ", "Semi'a", "Semi'e", "Se - mi - a", "Se - mi - e", "İşitti", "Bihîst")
            )
        }
    }

    // 5. Bölüm (Sayfa 25 - 30): Ötre (Zamme / Bêş)
    private fun getSection5Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p25_1", "اُ", "Elif Ötre", "Elîf Bêş", "U / Ü", "U / Û", "İnce", "Zirav"),
                ElifbaItem("p25_2", "بُ", "Be Ötre", "Bê Bêş", "Bü", "Bû", "İnce", "Zirav"),
                ElifbaItem("p25_3", "تُ", "Te Ötre", "Tê Bêş", "Tü", "Tû", "İnce", "Zirav"),
                ElifbaItem("p25_4", "ثُ", "Se Ötre", "Sê Bêş", "Sü", "Sû", "Peltek", "Nerm")
            )
            2 -> listOf(
                ElifbaItem("p26_1", "جُ", "Cim Ötre", "Cîm Bêş", "Cü", "Cû", "İnce", "Zirav"),
                ElifbaItem("p26_2", "حُ", "Ha Ötre", "Ha Bêş", "Hu", "Hû", "Boğaz", "Qirikî"),
                ElifbaItem("p26_3", "خُ", "Hı Ötre", "Xî Bêş", "Hu", "Xu", "Hırıltılı", "X-ya kurdî"),
                ElifbaItem("p26_4", "دُ", "Dal Ötre", "Dal Bêş", "Dü", "Dû", "İnce", "Zirav")
            )
            3 -> listOf(
                ElifbaItem("p27_1", "ذُ", "Zel Ötre", "Zel Bêş", "Zü", "Zû", "Peltek", "Nerm"),
                ElifbaItem("p27_2", "رُ", "Ra Ötre", "Ra Bêş", "Ru", "Rû", "Ötreli Ra kalındır", "Qelew dibe"),
                ElifbaItem("p27_3", "زُ", "Ze Ötre", "Zê Bêş", "Zü", "Zû", "İnce", "Zirav"),
                ElifbaItem("p27_4", "سُ", "Sin Ötre", "Sîn Bêş", "Sü", "Sû", "İnce", "Zirav")
            )
            4 -> listOf(
                ElifbaItem("p28_1", "شُ", "Şın Ötre", "Şîn Bêş", "Şü", "Şû", "İnce", "Zirav"),
                ElifbaItem("p28_2", "صُ", "Sad Ötre", "Sad Bêş", "Su", "Sû", "Kalın", "Qalind"),
                ElifbaItem("p28_3", "ضُ", "Dad Ötre", "Dad Bêş", "Du", "Dû", "Kalın", "Qalind"),
                ElifbaItem("p28_4", "طُ", "Tı Ötre", "Tı Bêş", "Tu", "Tû", "Kalın", "Qalind")
            )
            5 -> listOf(
                ElifbaItem("p29_1", "ظُ", "Zı Ötre", "Zı Bêş", "Zu", "Zû", "Kalın peltek", "Qalind"),
                ElifbaItem("p29_2", "عُ", "Ayn Ötre", "Eyn Bêş", "U (Boğaz)", "U (Eyn)", "Boğaz", "Qirikî"),
                ElifbaItem("p29_3", "غُ", "Gayn Ötre", "Xeyn Bêş", "Gu", "Xu", "Kalın", "Qalind"),
                ElifbaItem("p29_4", "فُ", "Fe Ötre", "Fê Bêş", "Fü", "Fû", "İnce", "Zirav")
            )
            else -> listOf(
                ElifbaItem("p30_1", "قُ", "Kaf Ötre", "Qaf Bêş", "Ku", "Qu", "Kalın Q", "Q-ya kurdî"),
                ElifbaItem("p30_2", "كُ", "Kef Ötre", "Kêf Bêş", "Kü", "Kû", "İnce", "Zirav"),
                ElifbaItem("p30_3", "لُ", "Lam Ötre", "Lam Bêş", "Lü", "Lû", "İnce", "Zirav"),
                ElifbaItem("p30_4", "مُ", "Mim Ötre", "Mîm Bêş", "Mü", "Mû", "İnce", "Zirav"),
                ElifbaItem("p30_5", "نُ", "Nun Ötre", "Nûn Bêş", "Nü", "Nû", "İnce", "Zirav"),
                ElifbaItem("p30_6", "وُ", "Vav Ötre", "Waw Bêş", "Vü", "Wû", "İnce", "W-ya kurdî"),
                ElifbaItem("p30_7", "هُ", "He Ötre", "Hê Bêş", "Hü", "Hû", "İnce", "Zirav"),
                ElifbaItem("p30_8", "يُ", "Ye Ötre", "Yê Bêş", "Yü", "Yû", "İnce", "Zirav"),
                ElifbaItem("p30_9", "كُتُبُ", "Kütübü", "Kutubu", "Kü - tü - bü", "Ku - tu - bu", "Kitaplar", "Pirtûk"),
                ElifbaItem("p30_10", "رُسُلُ", "Rüsülü", "Rusulu", "Rü - sü - lü", "Ru - su - lu", "Elçiler", "Pêxember")
            )
        }
    }

    // 6. Bölüm (Sayfa 31 - 36): Cezim (Sükûn / Sekin)
    private fun getSection6Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p31_1", "اَبْ", "Eb", "Eb", "Eb", "Eb", "Be cezimli", "Bê bi sekin"),
                ElifbaItem("p31_2", "اَتْ", "Et", "Et", "Et", "Et", "Te cezimli", "Tê bi sekin"),
                ElifbaItem("p31_3", "اَثْ", "Es", "Es", "Es (Peltek)", "Es (Nerm)", "Peltek", "Nerm"),
                ElifbaItem("p31_4", "اَجْ", "Ec", "Ec", "Ec", "Ec", "Kalkale", "Lerizîn")
            )
            2 -> listOf(
                ElifbaItem("p32_1", "اَحْ", "Eh", "Eh", "Eh", "Eh", "Boğaz nefesli", "Ji qirikê"),
                ElifbaItem("p32_2", "اَخْ", "Eh", "Ex", "Eh (Hırıltılı)", "Ex", "Hırıltılı", "X-ya kurdî"),
                ElifbaItem("p32_3", "اَدْ", "Ed", "Ed", "Ed", "Ed", "Kalkale ile", "Bi lerizîn"),
                ElifbaItem("p32_4", "اَذْ", "Ez", "Ez", "Ez (Peltek)", "Ez (Nerm)", "Peltek", "Nerm")
            )
            3 -> listOf(
                ElifbaItem("p33_1", "اَرْ", "Er", "Er", "Er", "Er", "Ra kalın tutulur", "Ra-ya qelew"),
                ElifbaItem("p33_2", "اَزْ", "Ez", "Ez", "Ez", "Ez", "Keskin", "Tûj"),
                ElifbaItem("p33_3", "اَسْ", "Es", "Es", "Es", "Es", "İnce S", "S-ya zirav"),
                ElifbaItem("p33_4", "اَشْ", "Eş", "Eş", "Eş", "Eş", "Ş sesi", "Tîpa Ş")
            )
            4 -> listOf(
                ElifbaItem("p34_1", "قُلْ", "Kul", "Qul", "Kul", "Qul", "'De ki'", "'Bêje'"),
                ElifbaItem("p34_2", "كُنْ", "Kün", "Kun", "Kün", "Kun", "'Ol'", "'Bibe'"),
                ElifbaItem("p34_3", "مِنْ", "Min", "Min", "Min", "Min", "'-den, -dan'", "'Ji'"),
                ElifbaItem("p34_4", "عَنْ", "An", "En", "An", "En", "Ayn ile", "Bi Eynê")
            )
            5 -> listOf(
                ElifbaItem("p35_1", "يَعْلَمُ", "Ya'lemü", "Ye'lemu", "Ya' - le - mü", "Ye' - le - mu", "Bilir", "Dizane"),
                ElifbaItem("p35_2", "يَسْمَعُ", "Yesme'u", "Yesme'u", "Yes - me - u", "Yes - me - u", "İşitir", "Dibihîze"),
                ElifbaItem("p35_3", "نَعْبُدُ", "Na'büdü", "Ne'budu", "Na' - bü - dü", "Ne' - bu - du", "Kulluk ederiz", "Îbadet dikin")
            )
            else -> listOf(
                ElifbaItem("p36_1", "اَقْ", "Kalkale Kaf", "Qelqele Qaf", "Ak (Sars)", "Aq (Bi lerizîn)", "Kalkale", "Qelqele"),
                ElifbaItem("p36_2", "اَطْ", "Kalkale Tı", "Qelqele Tı", "At (Sars)", "At (Bi lerizîn)", "Kalkale", "Qelqele"),
                ElifbaItem("p36_3", "اَبْ", "Kalkale Be", "Qelqele Bê", "Eb (Sars)", "Eb (Bi lerizîn)", "Kalkale", "Qelqele"),
                ElifbaItem("p36_4", "اَجْ", "Kalkale Cim", "Qelqele Cîm", "Ec (Sars)", "Ec (Bi lerizîn)", "Kalkale", "Qelqele"),
                ElifbaItem("p36_5", "اَدْ", "Kalkale Dal", "Qelqele Dal", "Ed (Sars)", "Ed (Bi lerizîn)", "Kalkale", "Qelqele")
            )
        }
    }

    // 7. Bölüm (Sayfa 37 - 42): Şedde (Tecdîd / Şedd)
    private fun getSection7Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p37_1", "اَبَّ", "Ebbe", "Ebbe", "Eb - be", "Eb - be", "İki kere", "Du caran"),
                ElifbaItem("p37_2", "اَتَّ", "Ette", "Ette", "Et - te", "Et - te", "İki kere", "Du caran"),
                ElifbaItem("p37_3", "اَثَّ", "Esse", "Esse", "Es - se", "Es - se", "Peltek", "Nerm"),
                ElifbaItem("p37_4", "اَجَّ", "Ecce", "Ecce", "Ec - ce", "Ec - ce", "Kuvvetli", "Bi hêz")
            )
            2 -> listOf(
                ElifbaItem("p38_1", "اَحَّ", "Ehha", "Ehha", "Eh - ha", "Eh - ha", "Boğaz Ha'sı", "Ji qirikê"),
                ElifbaItem("p38_2", "اَخَّ", "Exxa", "Exxa", "Eh - ha (Hırıltılı)", "Ex - xa", "Hırıltılı", "X-ya kurdî"),
                ElifbaItem("p38_3", "اَدَّ", "Edde", "Edde", "Ed - de", "Ed - de", "Dal şeddeli", "Dal bi şedd"),
                ElifbaItem("p38_4", "اَذَّ", "Ezze", "Ezze", "Ez - ze (Peltek)", "Ez - ze (Nerm)", "Peltek", "Nerm")
            )
            3 -> listOf(
                ElifbaItem("p39_1", "اَرَّ", "Erra", "Erra", "Er - ra", "Er - ra", "Kalın Ra", "Ra-ya qelew"),
                ElifbaItem("p39_2", "اَزَّ", "Ezze", "Ezze", "Ez - ze", "Ez - ze", "Keskin", "Tûj"),
                ElifbaItem("p39_3", "اَسَّ", "Esse", "Esse", "Es - se", "Es - se", "Akıcı Sin", "S-ya herikbar"),
                ElifbaItem("p39_4", "اَشَّ", "Eşşe", "Eşşe", "Eş - şe", "Eş - şe", "Ş şeddeli", "Ş bi şedd")
            )
            4 -> listOf(
                ElifbaItem("p40_1", "اَصَّ", "Assa", "Assa", "As - sa", "As - sa", "Kalın Sad", "Sad bi şedd"),
                ElifbaItem("p40_2", "اَضَّ", "Adda", "Adda", "Ad - da", "Ad - da", "Kalın Dad", "Dad bi şedd"),
                ElifbaItem("p40_3", "اَطَّ", "Atta", "Atta", "At - ta", "At - ta", "Kalın Tı", "Tı bi şedd"),
                ElifbaItem("p40_4", "اَظَّ", "Azza", "Azza", "Az - za", "Az - za", "Kalın Zı", "Zı bi şedd")
            )
            5 -> listOf(
                ElifbaItem("p41_1", "اِنَّ", "İnne", "Înne", "İn - ne", "În - ne", "1.5 elif tutulur (Ğunne)", "Bi dengê xûnneyê"),
                ElifbaItem("p41_2", "اَنَّ", "Enne", "Enne", "En - ne", "En - ne", "Ğunneli Nun", "Nûn bi xûnne"),
                ElifbaItem("p41_3", "ثُمَّ", "Sümme", "Summe", "Süm - me", "Sum - me", "Ğunneli Mim", "Mîm bi xûnne"),
                ElifbaItem("p41_4", "عَمَّ", "Amme", "Emme", "Am - me", "Em - me", "1.5 elif tut", "Girtina dengan")
            )
            else -> listOf(
                ElifbaItem("p42_1", "رَبِّ", "Rabbi", "Rebbî", "Rab - bi", "Reb - bî", "'Rabbim'", "'Rebbê min'"),
                ElifbaItem("p42_2", "كُلَّ", "Külle", "Kulle", "Kül - le", "Kul - le", "'Hepsi, her'", "'Hemû'"),
                ElifbaItem("p42_3", "حَقَّ", "Hakka", "Heqqe", "Hak - ka", "Heq - qe", "'Hak, gerçek'", "'Heq û rast'"),
                ElifbaItem("p42_4", "صَلَّى", "Sallâ", "Sella", "Sal - lâ", "Sel - la", "'Salât eyledi'", "'Silav lê kir'")
            )
        }
    }

    // 8. Bölüm (Sayfa 43 - 48): Med (Uzatma) Harfleri
    private fun getSection8Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p43_1", "بَا", "Bâ", "Ba", "Bâ (1 Elif Uzat)", "Ba (Dirêj bike)", "Med harfi Elif", "Tîpa Elîf"),
                ElifbaItem("p43_2", "تَا", "Tâ", "Ta", "Tâ (1 Elif Uzat)", "Ta (Dirêj bike)", "Med harfi Elif", "Tîpa Elîf"),
                ElifbaItem("p43_3", "ثَا", "Sâ", "Sa", "Sâ (Peltek Uzat)", "Sa (Nerm dirêj)", "Peltek", "Nerm"),
                ElifbaItem("p43_4", "جَا", "Câ", "Ca", "Câ (1 Elif Uzat)", "Ca (Dirêj bike)", "Med harfi Elif", "Tîpa Elîf")
            )
            2 -> listOf(
                ElifbaItem("p44_1", "دَا", "Dâ", "Da", "Dâ", "Da", "Uzat", "Dirêj bike"),
                ElifbaItem("p44_2", "ذَا", "Zâ", "Za", "Zâ (Peltek)", "Za (Nerm)", "Peltek uzatma", "Nerm"),
                ElifbaItem("p44_3", "رَا", "Râ", "Ra", "Râ (Kalın)", "Ra (Qalind)", "Kalın uzatılır", "Qalind"),
                ElifbaItem("p44_4", "سَا", "Sâ", "Sa", "Sâ", "Sa", "İnce uzatma", "Zirav")
            )
            3 -> listOf(
                ElifbaItem("p45_1", "بُو", "Bû", "Bû", "Bû (Vav ile uzat)", "Bû (Bi Wawê)", "Med harfi Vav", "Tîpa Wawê"),
                ElifbaItem("p45_2", "تُو", "Tû", "Tû", "Tû (Vav ile uzat)", "Tû (Bi Wawê)", "Med harfi Vav", "Tîpa Wawê"),
                ElifbaItem("p45_3", "ثُو", "Sû", "Sû", "Sû (Peltek)", "Sû (Nerm)", "Peltek", "Nerm"),
                ElifbaItem("p45_4", "جُو", "Cû", "Cû", "Cû", "Cû", "Vav ile uzat", "Bi Wawê")
            )
            4 -> listOf(
                ElifbaItem("p46_1", "دُو", "Dû", "Dû", "Dû", "Dû", "Uzat", "Dirêj bike"),
                ElifbaItem("p46_2", "رُو", "Rû", "Rû", "Rû", "Rû", "Kalın", "Qalind"),
                ElifbaItem("p46_3", "زُو", "Zû", "Zû", "Zû", "Zû", "İnce", "Zirav"),
                ElifbaItem("p46_4", "سُو", "Sû", "Sû", "Sû", "Sû", "İnce uzatma", "Zirav")
            )
            5 -> listOf(
                ElifbaItem("p47_1", "بِي", "Bî", "Bî", "Bî (Ye ile uzat)", "Bî (Bi Yê)", "Med harfi Ye", "Tîpa Yê"),
                ElifbaItem("p47_2", "تِي", "Tî", "Tî", "Tî (Ye ile uzat)", "Tî (Bi Yê)", "Med harfi Ye", "Tîpa Yê"),
                ElifbaItem("p47_3", "ثِي", "Sî", "Sî", "Sî (Peltek)", "Sî (Nerm)", "Peltek", "Nerm"),
                ElifbaItem("p47_4", "جِي", "Cî", "Cî", "Cî (Ye ile uzat)", "Cî (Bi Yê)", "Med harfi Ye", "Tîpa Yê")
            )
            else -> listOf(
                ElifbaItem("p48_1", "قَالَ", "Kâle", "Qale", "Kâ - le", "Qa - le", "'Dedi'", "'Got'"),
                ElifbaItem("p48_2", "قِيلَ", "Kîle", "Qîle", "Kî - le", "Qî - le", "'Denildi'", "'Hate gotin'"),
                ElifbaItem("p48_3", "يَقُولُ", "Yekûlü", "Yeqûlu", "Ye - kû - lü", "Ye - qû - lu", "'Söyler'", "'Dibêje'"),
                ElifbaItem("p48_4", "نُوحِيهَا", "Nûhîhâ", "Nûhîha", "Nû - hî - hâ", "Nû - hî - ha", "3 med harfi birden", "Her sê tîpên meddê")
            )
        }
    }

    // 9. Bölüm (Sayfa 49 - 54): Tenvin (İki Üstün, Esre, Ötre)
    private fun getSection9Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p49_1", "اَبًا", "Eben", "Eben", "E - ben", "E - ben", "İki üstün 'en' okutur", "Du ser 'en' dide xwendin"),
                ElifbaItem("p49_2", "تَمْرًا", "Tamran", "Temren", "Tam - ran", "Tem - ren", "Hurma", "Xurme"),
                ElifbaItem("p49_3", "اَجْرًا", "Ecran", "Ejren", "Ec - ran", "Ej - ren", "Mükâfat", "Xelat"),
                ElifbaItem("p49_4", "رِزْقًا", "Rizkan", "Rizqen", "Riz - kan", "Riz - qen", "Rızık", "Rizq")
            )
            2 -> listOf(
                ElifbaItem("p50_1", "بَيْتٍ", "Beytin", "Beytin", "Bey - tin", "Bey - tin", "İki esre 'in' okutur", "Du bin 'in' dide xwendin"),
                ElifbaItem("p50_2", "خَوْفٍ", "Havfin", "Xewfin", "Hav - fin", "Xew - fin", "Korku", "Tirs"),
                ElifbaItem("p50_3", "يَوْمٍ", "Yevmin", "Yewmin", "Yev - min", "Yew - min", "Gün", "Roj"),
                ElifbaItem("p50_4", "نَفْسٍ", "Nefsin", "Nefsin", "Nef - sin", "Nef - sin", "Can, nefis", "Can")
            )
            3 -> listOf(
                ElifbaItem("p51_1", "كِتَابٌ", "Kitâbün", "Kîtabun", "Ki - tâ - bün", "Kî - ta - bun", "İki ötre 'ün' okutur", "Du bêş 'un' dide xwendin"),
                ElifbaItem("p51_2", "رَسُولٌ", "Rasûlün", "Resûlun", "Ra - sû - lün", "Re - sû - lun", "Elçi", "Pêxember"),
                ElifbaItem("p51_3", "عَلِيمٌ", "Alîmün", "Elîmun", "A - lî - mün", "E - lî - mun", "Hakkıyla bilen", "Zana"),
                ElifbaItem("p51_4", "حَكِيمٌ", "Hakîmün", "Hekîmun", "Ha - kî - mün", "He - kî - mun", "Hikmet sahibi", "Hekîm")
            )
            4 -> listOf(
                ElifbaItem("p52_1", "غَفُورًا رَحِيمًا", "Gafûran Rahîmâ", "Xefûren Rehîma", "Ga-fû-ran Ra-hî-mâ", "Xe-fû-ren Re-hî-ma", "Bağışlayan ve esirgeyen", "Baxşîner û dilovan"),
                ElifbaItem("p52_2", "سَمِيعٌ عَلِيمٌ", "Semîun Alîm", "Semîun Elîm", "Se-mî-un A-lîm", "Se-mî-un E-lîm", "İşiten ve bilen", "Bihîstok û zana")
            )
            5 -> listOf(
                ElifbaItem("p53_1", "الصَّلٰوةُ", "Es-Salât", "Es-Selat", "Es - Sa - lât", "Es - Se - lat", "Vav üstü elif çekilir", "Waw wek elîf tê kişandin"),
                ElifbaItem("p53_2", "الزَّكٰوةُ", "Ez-Zekât", "Ez-Zekat", "Ez - Ze - kât", "Ez - Ze - kat", "Zekât", "Zekat"),
                ElifbaItem("p53_3", "الْهُدٰى", "El-Hudâ", "El-Huda", "El - Hu - dâ", "El - Hu - da", "Hidayet", "Hîdayet")
            )
            else -> listOf(
                ElifbaItem("p54_1", "رَحْمَةٌ", "Rahmetün", "Rehmetun", "Rah - me - tün", "Reh - me - tun", "Duruşta 'He' olur (Rahmeh)", "Di sekinê de dibe Hê"),
                ElifbaItem("p54_2", "جَنَّةٌ", "Cennetün", "Cennetun", "Cen - ne - tün", "Cen - ne - tun", "Cennet", "Bihuşt"),
                ElifbaItem("p54_3", "قِيَامَةٌ", "Kiyâmetün", "Qiyametun", "Ki - yâ - me - tün", "Qi - ya - me - tun", "Kıyamet", "Roja qiyametê")
            )
        }
    }

    // 10. Bölüm (Sayfa 55 - 60): Tecvid & Kur'an Okuma Alıştırmaları
    private fun getSection10Items(p: Int): List<ElifbaItem> {
        return when (p) {
            1 -> listOf(
                ElifbaItem("p55_1", "اللّٰهُ", "Allâh", "Allah", "Al - lâh (Kalın)", "Al - lah (Qalind)", "Önceki harf üstün/ötre ise kalın", "Qalind tê xwendin"),
                ElifbaItem("p55_2", "بِاللّٰهِ", "Billâhi", "Bîllahi", "Bil - lâ - hi (İnce)", "Bîl - la - hi (Zirav)", "Önceki harf esre ise ince", "Zirav tê xwendin"),
                ElifbaItem("p55_3", "فِي اللّٰهِ", "Fîllâhi", "Fîllahi", "Fîl - lâ - hi", "Fîl - la - hi", "Allah uğrunda", "Di riya Xwedê de")
            )
            2 -> listOf(
                ElifbaItem("p56_1", "لَهُ", "Lehû", "Lehû", "Le - hû (Uzatılır)", "Le - hû (Dirêj dibe)", "Önceki harf harekeli ise uzatılır", "Tîpa pêş bi tevger be dirêj dibe"),
                ElifbaItem("p56_2", "فِيهِ", "Fîhi", "Fîhi", "Fî - hi (Uzatılmaz)", "Fî - hi (Dirêj nabe)", "Önceki harf cezim/med ise uzatılmaz", "Dirêj nabe")
            )
            3 -> listOf(
                ElifbaItem("p57_1", "جَاءَ", "Câe", "Cae", "Cââ - e (4 Elif Uzat)", "Caa - e (4 caran dirêj)", "Medd-i Muttasıl (Bitişik uzatma)", "Medda Muttasıl"),
                ElifbaItem("p57_2", "يَا اَيُّهَا", "Yâ Eyyühe", "Ya Eyyuhe", "Yââ ey - yü - he", "Yaa ey - yu - he", "Medd-i Munfasıl (Ayrı uzatma)", "Medda Munfasıl")
            )
            4 -> listOf(
                ElifbaItem("p58_1", "قُلْ هُوَ اللّٰهُ اَحَدٌ", "İhlâs 1. Ayet", "Îxlas 1", "Kul hü-vel-lâ-hü e-had", "Qul hu-wel-la-hu e-hed", "De ki: 'O, Allah’tır, tektir.'", "Bibêje: Xwedê her yek e, tek e."),
                ElifbaItem("p58_2", "اَللّٰهُ الصَّمَدُ", "İhlâs 2. Ayet", "Îxlas 2", "Al-lâ-hüs-sa-med", "Al-la-hus-sa-med", "Allah sameddir.", "Her Xwedê ye bergeha hewcedaran."),
                ElifbaItem("p58_3", "لَمْ يَلِدْ وَلَمْ يُولَدْ", "İhlâs 3. Ayet", "Îxlas 3", "Lem ye-lid ve lem yû-led", "Lem ye-lîd we lem yû-led", "Doğurmamış ve doğmamıştır.", "Kes jê çênebûye û ew jî ji kesî çênebûye."),
                ElifbaItem("p58_4", "وَلَمْ يَكُنْ لَهُ كُفُوًا اَحَدٌ", "İhlâs 4. Ayet", "Îxlas 4", "Ve lem ye-kül-le-hû kü-fü-ven e-had", "We lem ye-kul-le-hû ku-fu-wen e-hed", "O’nun hiçbir dengi yoktur.", "Tu hemkûf û hevta jî jê re tun in.")
            )
            5 -> listOf(
                ElifbaItem("p59_1", "قُلْ اَعُوذُ بِرَبِّ الْفَلَقِ", "Felak 1. Ayet", "Feleq 1", "Kul e-û-zü bi-rab-bil-fa-lak", "Qul e-û-zu bi-rab-bîl-fe-leq", "De ki: 'Sabahın rabbine sığınırım;'", "Bibêje: Ez bi Xwedayê spêdeyê (şeveqê) xwe diparêzim."),
                ElifbaItem("p59_2", "قُلْ اَعُوذُ بِرَبِّ النَّاسِ", "Nâs 1. Ayet", "Nas 1", "Kul e-û-zü bi-rab-bin-nâs", "Qul e-û-zu bi-rab-bîn-nas", "İnsanların rabbine sığınırım!", "Bibêje: Ez bi Perwerdegarê mirovan xwe diparêzim…")
            )
            else -> listOf(
                ElifbaItem("p60_1", "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ", "Fâtiha 1. Ayet", "Fatîha 1", "Bis-mil-lâ-hir-rah-mâ-nir-ra-hîm", "Bîs-mîl-la-hîr-reh-ma-nîr-re-hîm", "Rahmân ve rahîm olan Allah’ın adıyla", "Bi Navê Xwedayê Reḥman ê Reḥîm."),
                ElifbaItem("p60_2", "اَلْحَمْدُ لِلّٰهِ رَبِّ الْعَالَمِينَ", "Fâtiha 2. Ayet", "Fatîha 2", "El-ham-dü lil-lâ-hi rab-bil-â-le-mîn", "El-hem-du lîl-la-hî reb-bîl-a-le-mîn", "Hamd, âlemlerin Rabbi olan Allah’a mahsustur.", "Hemd (pesn û spasî) ji Xwedê re be ku ew perwerdegarê ‘alemê ye."),
                ElifbaItem("p60_3", "اَلرَّحْمٰنِ الرَّحِيمِ", "Fâtiha 3. Ayet", "Fatîha 3", "Er-rah-mâ-nir-ra-hîm", "Er-reh-ma-nîr-re-hîm", "Rahmân ve rahîm", "Ew ê ku Rehman e, Rehîm e."),
                ElifbaItem("p60_4", "مَالِكِ يَوْمِ الدِّينِ", "Fâtiha 4. Ayet", "Fatîha 4", "Mâ-li-ki yev-mid-dîn", "Ma-lî-kî yew-mîd-dîn", "Ödül ve ceza gününün tek hâkimi.", "Ew ê ku xwediyê roja hesabdîtin û cizadanê ye.")
            )
        }
    }

    private fun getRuleTr(pageNum: Int, sectionNum: Int): String {
        return when (sectionNum) {
            1 -> "1. Bölüm (Müfred Harfler): Arapçada 28 harf vardır. Sağdan sola yazılır ve okunur."
            2 -> "2. Bölüm (Bitişme): 6 harf (Elif, Dal, Zel, Ra, Ze, Vav) kendinden sonraki harfe bitişmez."
            3 -> "3. Bölüm (Üstün): Harfin üstündeki çizgi ince harfleri 'e', kalın harfleri 'a' sesiyle okutur."
            4 -> "4. Bölüm (Esre): Harfin altındaki çizgi ince harfleri 'i', kalın harfleri 'ı/i' arası okutur."
            5 -> "5. Bölüm (Ötre): Harfin üstündeki küçük vav benzeri işaret harfleri 'u/ü' sesiyle okutur."
            6 -> "6. Bölüm (Cezim): Harfi hareketsiz olarak önceki harekeli harfe tutturarak durdurur."
            7 -> "7. Bölüm (Şedde): Harfi birincisi cezimli ikincisi harekeli olmak üzere iki kere okutur."
            8 -> "8. Bölüm (Med): Elif, Vav ve Ye harfleri harekesiz gelip önceki harfi 1 elif miktarı uzatır."
            9 -> "9. Bölüm (Tenvin): İki üstün (en/an), iki esre (in) ve iki ötre (ün/un) sesi verir."
            10 -> "10. Bölüm (Tecvid): Kur'an-ı Kerim'i usulüne uygun, tertil ve tecvidle okuma mezuniyet sayfasıdır."
            else -> "Kur'an Elifbası • Yaprak $pageNum / 60"
        }
    }

    private fun getRuleKu(pageNum: Int, sectionNum: Int): String {
        return when (sectionNum) {
            1 -> "Beşa 1 (Tîpên Erebî): Di zimanê erebî de 28 tîp hene. Ji rastê ber bi çepê têne nivîsandin."
            2 -> "Beşa 2 (Girêdan): 6 tîp (Elîf, Dal, Zel, Ra, Zê, Waw) bi tîpa pişt re nayên girêdan."
            3 -> "Beşa 3 (Ser): Tevgera li ser tîpan tîpên zirav bi 'e' û yên qalind bi 'a' dide xwendin."
            4 -> "Beşa 4 (Bin): Tevgera bin tîpan tîpên zirav bi 'î' û yên qalind bi 'i/î' dide xwendin."
            5 -> "Beşa 5 (Bêş): Tevgera mîna wawa biçûk tîpan bi 'u/û' dide xwendin."
            6 -> "Beşa 6 (Cezm): Tîpa bê tevger bi tîpa pêş ve girêdide û disekinîne."
            7 -> "Beşa 7 (Şedd): Tîpê cara yekem bi sekin û ya duyem bi tevger du caran dide xwendin."
            8 -> "Beşa 8 (Med): Tîpên Elîf, Waw û Yê tîpan bi qasî yek elîfê dirêj dikin."
            9 -> "Beşa 9 (Tenwîn): Du ser (en), du bin (in) û du bêş (un) dengê nûnê yê zêde didin."
            10 -> "Beşa 10 (Tecwîd): Rûpela xwendina Qur'anê ya bi tecwîd û hezkirinê. Pîroz be!"
            else -> "Elîfbaya Qur'anê • Rûpela $pageNum / 60"
        }
    }
}
