package com.example.data.repository

import android.content.Context
import com.example.data.local.BuiltinQuranData
import com.example.data.local.QuranPageMetadata
import com.example.data.model.AyahItem
import com.example.data.model.PageAyah
import com.example.data.model.QuranPageDetail
import com.example.data.model.SurahDetail
import com.example.data.model.SurahInfo
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.util.concurrent.ConcurrentHashMap

class QuranRepository(private val context: Context? = null) {

    // In-memory caches for fast, smooth page-flipping
    private val pageCache = ConcurrentHashMap<Int, QuranPageDetail>()
    private val surahCache = ConcurrentHashMap<Int, SurahDetail>()

    // Complete on-device 6,236 ayah maps (Loaded lazily from local assets)
    @Volatile
    private var assetKurdishMap: Map<String, String>? = null

    @Volatile
    private var assetTurkishMap: Map<String, String>? = null

    @Volatile
    private var assetArabicMap: Map<String, String>? = null

    private fun loadAssetJsonMap(fileName: String): Map<String, String> {
        val ctx = context ?: return emptyMap()
        return try {
            ctx.assets.open(fileName).use { inputStream ->
                BufferedReader(InputStreamReader(inputStream, Charsets.UTF_8)).use { reader ->
                    val content = reader.readText()
                    val json = JSONObject(content)
                    val map = HashMap<String, String>(json.length())
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        map[key] = json.getString(key)
                    }
                    map
                }
            }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    private fun getKurdishLatinMap(): Map<String, String> {
        assetKurdishMap?.let { return it }
        synchronized(this) {
            assetKurdishMap?.let { return it }
            val loaded = loadAssetJsonMap("quran_ku_latin.json")
            assetKurdishMap = loaded
            return loaded
        }
    }

    private fun getTurkishDiyanetMap(): Map<String, String> {
        assetTurkishMap?.let { return it }
        synchronized(this) {
            assetTurkishMap?.let { return it }
            val loaded = loadAssetJsonMap("quran_tr_diyanet.json")
            assetTurkishMap = loaded
            return loaded
        }
    }

    private fun getArabicMap(): Map<String, String> {
        assetArabicMap?.let { return it }
        synchronized(this) {
            assetArabicMap?.let { return it }
            val loaded = loadAssetJsonMap("quran_ar.json")
            assetArabicMap = loaded
            return loaded
        }
    }

    suspend fun getSurahs(query: String = ""): List<SurahInfo> = withContext(Dispatchers.Default) {
        val all = BuiltinQuranData.SURAH_LIST
        if (query.isBlank()) return@withContext all

        val q = query.trim().lowercase()
        all.filter {
            it.nameTr.lowercase().contains(q) ||
            it.nameKu.lowercase().contains(q) ||
            it.nameArabic.contains(q) ||
            it.number.toString() == q
        }
    }

    suspend fun getSurahDetail(surahNumber: Int): SurahDetail? = withContext(Dispatchers.IO) {
        val info = BuiltinQuranData.SURAH_LIST.find { it.number == surahNumber } ?: return@withContext null

        // 1. Check in-memory cache
        surahCache[surahNumber]?.let { return@withContext it }

        // 2. Build directly from complete offline assets (Instant, 100% complete for all 114 surahs)
        val kurdishMap = getKurdishLatinMap()
        val turkishMap = getTurkishDiyanetMap()
        val arabicMap = getArabicMap()

        if (kurdishMap.isNotEmpty() || turkishMap.isNotEmpty() || arabicMap.isNotEmpty()) {
            val ayahs = mutableListOf<AyahItem>()
            for (verseNum in 1..info.versesCount) {
                val key = "$surahNumber:$verseNum"
                val textAr = arabicMap[key]
                    ?: BuiltinQuranData.DETAILS_MAP[surahNumber]?.find { it.numberInSurah == verseNum }?.textArabic
                    ?: "﴿$verseNum﴾"
                val textTr = turkishMap[key]
                    ?: BuiltinQuranData.DETAILS_MAP[surahNumber]?.find { it.numberInSurah == verseNum }?.translationTr
                    ?: ""
                val rawKu = kurdishMap[key]
                    ?: BuiltinQuranData.DETAILS_MAP[surahNumber]?.find { it.numberInSurah == verseNum }?.translationKuLatin
                    ?: ""
                val textKu = rawKu.trim()

                ayahs.add(
                    AyahItem(
                        numberInSurah = verseNum,
                        textArabic = textAr.trim(),
                        translationTr = textTr.trim(),
                        translationKuLatin = textKu
                    )
                )
            }
            val detail = SurahDetail(info = info, ayahs = ayahs)
            surahCache[surahNumber] = detail
            return@withContext detail
        }

        // 3. Fallback to Builtin map if assets not accessible (e.g. unit test without Context)
        val builtinAyahs = BuiltinQuranData.DETAILS_MAP[surahNumber]
        if (!builtinAyahs.isNullOrEmpty()) {
            val detail = SurahDetail(info = info, ayahs = builtinAyahs)
            surahCache[surahNumber] = detail
            return@withContext detail
        }

        return@withContext SurahDetail(info = info, ayahs = emptyList())
    }

    suspend fun getPageDetail(pageNumber: Int): QuranPageDetail = withContext(Dispatchers.IO) {
        val safePage = pageNumber.coerceIn(1, 604)

        // 1. Check in-memory cache
        pageCache[safePage]?.let { return@withContext it }

        val pageMeta = QuranPageMetadata.getPage(safePage)
        val juzNum = pageMeta.juz
        val mainSurahNum = pageMeta.startSurah
        val mainSurahInfo = BuiltinQuranData.SURAH_LIST.find { it.number == mainSurahNum }

        // 2. Build directly from Medina Mushaf verse mapping + complete official Diyanet offline assets
        val kurdishMap = getKurdishLatinMap()
        val turkishMap = getTurkishDiyanetMap()
        val arabicMap = getArabicMap()

        val verseRefs = QuranPageMetadata.getVersesForPage(safePage)
        val pageAyahs = verseRefs.map { ref ->
            val sInfo = BuiltinQuranData.SURAH_LIST.find { it.number == ref.surah } ?: mainSurahInfo
            val sNameTr = sInfo?.nameTr ?: "Sure ${ref.surah}"
            val sNameKu = sInfo?.nameKu ?: "Sûre ${ref.surah}"
            val sNameAr = sInfo?.nameArabic ?: ""

            val key = "${ref.surah}:${ref.ayah}"

            val textArabic = (arabicMap[key]
                ?: BuiltinQuranData.DETAILS_MAP[ref.surah]?.find { it.numberInSurah == ref.ayah }?.textArabic
                ?: "﴿${ref.ayah}﴾").trim()

            val translationTr = (turkishMap[key]
                ?: BuiltinQuranData.DETAILS_MAP[ref.surah]?.find { it.numberInSurah == ref.ayah }?.translationTr
                ?: "").trim()

            val translationKuLatin = (kurdishMap[key]
                ?: BuiltinQuranData.DETAILS_MAP[ref.surah]?.find { it.numberInSurah == ref.ayah }?.translationKuLatin
                ?: "").trim()

            PageAyah(
                surahNumber = ref.surah,
                surahNameArabic = sNameAr,
                surahNameTr = sNameTr,
                surahNameKu = sNameKu,
                numberInSurah = ref.ayah,
                textArabic = textArabic,
                translationTr = translationTr,
                translationKuLatin = translationKuLatin
            )
        }

        val detail = QuranPageDetail(
            pageNumber = safePage,
            juzNumber = juzNum,
            mainSurahNumber = mainSurahNum,
            mainSurahNameArabic = mainSurahInfo?.nameArabic ?: "",
            mainSurahNameTr = mainSurahInfo?.nameTr ?: "",
            mainSurahNameKu = mainSurahInfo?.nameKu ?: "",
            ayahs = pageAyahs
        )
        pageCache[safePage] = detail
        return@withContext detail
    }

    fun normalizeDiyanetKurmanji(rawText: String): String {
        if (rawText.isBlank()) return ""
        return rawText
            .replace(Regex("\\[\\d+\\]"), "")
            .replace(Regex("\\(\\d+\\)"), "")
            .replace(Regex("(?i)peyxamber"), "pêxember")
            .replace(Regex("(?i)peyğamber"), "pêxember")
            .replace(Regex("(?i)yezd[eêaâ]n[eê]\\s+dilovan"), "Xwedayê Dilovan")
            .replace(Regex("(?i)yezd[eêaâ]n[eê]"), "Xwedayê")
            .replace(Regex("(?i)yezd[eêaâ]n[iî]"), "Xwedayî")
            .replace(Regex("(?i)yezd[eêaâ]n[aâ]"), "Xwedayan")
            .replace(Regex("(?i)yezd[eêaâ]n"), "Xwedê")
            .replace(Regex("(?i)yezd[eêaâ]"), "Xwedê")
            .replace(Regex("(?i)xw[eê]da"), "Xweda")
            .trim()
    }

    fun getAudioRecitationUrl(surahNumber: Int): String {
        return BuiltinQuranData.getAudioUrlForSurah(surahNumber)
    }
}
