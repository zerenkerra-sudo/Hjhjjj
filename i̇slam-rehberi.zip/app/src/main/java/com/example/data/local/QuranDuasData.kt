package com.example.data.local

import com.example.data.model.QuranDua
import java.util.Calendar

object QuranDuasData {

    val DUAS_LIST: List<QuranDua> = listOf(
        QuranDua(
            id = "dua_rabbena_atina",
            titleTr = "Dünya ve Ahiret İyiliği",
            titleKu = "Xêra Dinya û Axretê",
            surahNameTr = "Bakara Suresi",
            surahNameKu = "Sûreya Beqere",
            ayahReference = "2:201",
            arabicText = "رَبَّنَا آتِنَا فِي الدُّنْيَا حَسَنَةً وَفِي الْآخِرَةِ حَسَنَةً وَقِنَا عَذَابَ النَّارِ",
            translationTr = "Rabbimiz! Bize dünyada da ahirette de iyilik ver ve bizi ateş azabından koru.",
            translationKuLatin = "Rebbê me! Li dinyayê jî, li axretê jî qenciyê bide me û me ji ezabê agir biparêze.",
            themeTr = "Afiyet",
            themeKu = "Aşitî"
        ),
        QuranDua(
            id = "dua_ilim",
            titleTr = "İlim Artırma Duası",
            titleKu = "Duaya Zêdekirina Îlmê",
            surahNameTr = "Tâhâ Suresi",
            surahNameKu = "Sûreya Taha",
            ayahReference = "20:114",
            arabicText = "رَّبِّ زِدْنِي عِلْمًا",
            translationTr = "Rabbim! İlmimi artır.",
            translationKuLatin = "Rebbê min! Îlmê min zêde bike.",
            themeTr = "İlim",
            themeKu = "Îlm"
        ),
        QuranDua(
            id = "dua_kalp_sebat",
            titleTr = "Kalplerin Hidayeti",
            titleKu = "Sebata Dil û Îmanê",
            surahNameTr = "Âl-i İmrân Suresi",
            surahNameKu = "Sûreya Mala Îmran",
            ayahReference = "3:8",
            arabicText = "رَبَّنَا لَا تُزِغْ قُلُوبَنَا بَعْدَ إِذْ هَدَيْتَنَا وَهَبْ لَنَا مِن لَّدُنكَ رَحْمَةً",
            translationTr = "Rabbimiz! Bizi hidayete erdirdikten sonra kalplerimizi saptırma; katından bize rahmet ver.",
            translationKuLatin = "Rebbê me! Piştî ku Te rêya rast da me, dilên me şaş neke û ji bal Xwe ve rehmetê bide me.",
            themeTr = "Hidayet",
            themeKu = "Îman"
        ),
        QuranDua(
            id = "dua_musadua",
            titleTr = "Gönül Ferahlığı ve Kolaylık",
            titleKu = "Firehiya Dil û Hêsanî",
            surahNameTr = "Tâhâ Suresi",
            surahNameKu = "Sûreya Taha",
            ayahReference = "20:25-26",
            arabicText = "رَبِّ اشْرَحْ لِي صَدْرِي وَيَسِّرْ لِي أَمْرِي",
            translationTr = "Rabbim! Göğsümü genişlet ve işimi kolaylaştır.",
            translationKuLatin = "Rebbê min! Sînga min fireh bike û karê min hêsan bike.",
            themeTr = "Kolaylık",
            themeKu = "Hêsanî"
        ),
        QuranDua(
            id = "dua_namaz_nesil",
            titleTr = "Namaz ve Temiz Nesil",
            titleKu = "Duaya Nimêj û Nifşê Pak",
            surahNameTr = "İbrâhîm Suresi",
            surahNameKu = "Sûreya Îbrahîm",
            ayahReference = "14:40",
            arabicText = "رَبِّ اجْعَلْنِي مُقِيمَ الصَّلَاةِ وَمِن ذُرِّيَّتِي ۚ رَبَّنَا وَتَقَبَّلْ دُعَاءِ",
            translationTr = "Rabbim! Beni ve soyumu namazı dosdoğru kılanlardan eyle. Rabbimiz! Duamı kabul et.",
            translationKuLatin = "Rebbê min! Min û nifşê min bike nimêjker. Rebbê me! Duaya min qebûl bike.",
            themeTr = "Namaz",
            themeKu = "Nimêj"
        ),
        QuranDua(
            id = "dua_rabbanaghfirli",
            titleTr = "Bağışlanma ve Anne-Baba",
            titleKu = "Baxşandin û Dayik-Bav",
            surahNameTr = "İbrâhîm Suresi",
            surahNameKu = "Sûreya Îbrahîm",
            ayahReference = "14:41",
            arabicText = "رَبَّنَا اغْفِرْ لِي وَلِوَالِدَيَّ وَلِلْمُؤْمِنِينَ يَوْمَ يَقُومُ الْحِسَابُ",
            translationTr = "Rabbimiz! Hesap günü beni, anne-babamı ve tüm müminleri bağışla.",
            translationKuLatin = "Rebbê me! Roja hisabê min, dê û bavê min û hemû bawermendan bibexşîne.",
            themeTr = "Mağfiret",
            themeKu = "Lêborîn"
        ),
        QuranDua(
            id = "dua_yunus",
            titleTr = "Sıkıntıdan Kurtuluş Duası",
            titleKu = "Duaya Rizgariya ji Tengasiyê",
            surahNameTr = "Enbiyâ Suresi",
            surahNameKu = "Sûreya Enbiya",
            ayahReference = "21:87",
            arabicText = "لَّا إِلَٰهَ إِلَّا أَنتَ سُبْحَانَكَ إِنِّي كُنتُ مِنَ الظَّالِمِينَ",
            translationTr = "Senden başka ilah yoktur. Seni tenzih ederim. Gerçekten ben zalimlerden oldum.",
            translationKuLatin = "Ji Te pê ve tu îlah nîne; Tu pak î, bi rastî ez ji zaliman bûm.",
            themeTr = "Kurtuluş",
            themeKu = "Rizgarî"
        ),
        QuranDua(
            id = "dua_eyyub",
            titleTr = "Şifa ve Merhamet Duası",
            titleKu = "Duaya Şîfa û Rehmetê",
            surahNameTr = "Enbiyâ Suresi",
            surahNameKu = "Sûreya Enbiya",
            ayahReference = "21:83",
            arabicText = "أَنِّي مَسَّنِيَ الضُّرُّ وَأَنتَ أَرْحَمُ الرَّاحِمِينَ",
            translationTr = "Başıma bir zarar dokundu; Sen merhametlilerin en merhametlisisin.",
            translationKuLatin = "Ziyan gihîşte min; Tu dilovanê herî mezin î.",
            themeTr = "Şifa",
            themeKu = "Şîfa"
        ),
        QuranDua(
            id = "dua_ashabikehf",
            titleTr = "Rahmet ve Doğru Yol",
            titleKu = "Rehmet û Riya Rast",
            surahNameTr = "Kehf Suresi",
            surahNameKu = "Sûreya Kehf",
            ayahReference = "18:10",
            arabicText = "رَبَّنَا آتِنَا مِن لَّدُنكَ رَحْمَةً وَهَيِّئْ لَنَا مِنْ أَمْرِنَا رَشَدًا",
            translationTr = "Rabbimiz! Katından bize rahmet ver ve işimizde bize doğru yolu kolaylaştır.",
            translationKuLatin = "Rebbê me! Ji bal Xwe ve rehmetê bide me û di karê me de rêya rast hêsan bike.",
            themeTr = "Rehberlik",
            themeKu = "Rehmet"
        ),
        QuranDua(
            id = "dua_muminun_rahmet",
            titleTr = "Af ve Mağfiret Duası",
            titleKu = "Duaya Efû û Baxşandinê",
            surahNameTr = "Mü'minûn Suresi",
            surahNameKu = "Sûreya Mûminûn",
            ayahReference = "23:109",
            arabicText = "رَبَّنَا آمَنَّا فَاغْفِرْ لَنَا وَارْحَمْنَا وَأَنتَ خَيْرُ الرَّاحِمِينَ",
            translationTr = "Rabbimiz! İman ettik; bizi bağışla ve bize merhamet et. Sen merhametlilerin en hayırlısısın.",
            translationKuLatin = "Rebbê me! Me bawerî anî; me bibexşîne û li me bê rehmetê. Tu xêrtirînê dilovanan î.",
            themeTr = "Rahmet",
            themeKu = "Dilovanî"
        )
    )

    /**
     * Selects today's featured Quran Ayah Dua based on day of year.
     */
    fun getTodayDua(): QuranDua {
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        val index = (dayOfYear - 1).coerceAtLeast(0) % DUAS_LIST.size
        return DUAS_LIST[index]
    }
}
