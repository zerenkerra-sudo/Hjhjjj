package com.example.data.local

import com.example.data.model.City

/**
 * Built-in offline districts (İlçeler) for major Turkish provinces, Kurdish region provinces,
 * holy cities, and global diaspora metropolises so districts work instantaneously offline as well
 * as via live worldwide geocoding for every city and town on Earth.
 */
object WorldDistrictsData {

    private fun d(
        id: String,
        districtTr: String,
        districtKu: String,
        provinceTr: String,
        provinceKu: String,
        country: String,
        lat: Double,
        lng: Double
    ): City = City(
        id = id,
        nameTr = "$districtTr, $provinceTr",
        nameKu = "$districtKu, $provinceKu",
        country = country,
        latitude = lat,
        longitude = lng,
        isGps = false,
        provinceTr = provinceTr,
        provinceKu = provinceKu,
        isDistrict = true
    )

    val DISTRICTS_BY_CITY_ID: Map<String, List<City>> = mapOf(
        "diyarbakir" to listOf(
            d("diyarbakir_baglar", "Bağlar", "Baxlar", "Diyarbakır", "Amed", "Türkiye", 37.9070, 40.2130),
            d("diyarbakir_kayapinar", "Kayapınar", "Kayapinar", "Diyarbakır", "Amed", "Türkiye", 37.9345, 40.1755),
            d("diyarbakir_sur", "Sur", "Sûr", "Diyarbakır", "Amed", "Türkiye", 37.9102, 40.2367),
            d("diyarbakir_yenisehir", "Yenişehir", "Yenîşehîr", "Diyarbakır", "Amed", "Türkiye", 37.9255, 40.2286),
            d("diyarbakir_bismil", "Bismil", "Bismil", "Diyarbakır", "Amed", "Türkiye", 37.8467, 40.6661),
            d("diyarbakir_silvan", "Silvan", "Farqîn", "Diyarbakır", "Amed", "Türkiye", 38.1370, 41.0082),
            d("diyarbakir_ergani", "Ergani", "Erxenî", "Diyarbakır", "Amed", "Türkiye", 38.2683, 39.7611),
            d("diyarbakir_cinar", "Çınar", "Çinar", "Diyarbakır", "Amed", "Türkiye", 37.7244, 40.4139),
            d("diyarbakir_cermik", "Çermik", "Çêrmûg", "Diyarbakır", "Amed", "Türkiye", 38.1389, 39.4508),
            d("diyarbakir_dicle", "Dicle", "Pîran", "Diyarbakır", "Amed", "Türkiye", 38.3717, 40.0706),
            d("diyarbakir_egil", "Eğil", "Gêl", "Diyarbakır", "Amed", "Türkiye", 38.2572, 40.0789),
            d("diyarbakir_hani", "Hani", "Hênê", "Diyarbakır", "Amed", "Türkiye", 38.4119, 40.3917),
            d("diyarbakir_hazro", "Hazro", "Hezro", "Diyarbakır", "Amed", "Türkiye", 38.2519, 40.7744),
            d("diyarbakir_kocakoy", "Kocaköy", "Karaz", "Diyarbakır", "Amed", "Türkiye", 38.2939, 40.4992),
            d("diyarbakir_kulp", "Kulp", "Pasûr", "Diyarbakır", "Amed", "Türkiye", 38.4997, 41.0089),
            d("diyarbakir_lice", "Lice", "Licê", "Diyarbakır", "Amed", "Türkiye", 38.4597, 40.6408),
            d("diyarbakir_cungus", "Çüngüş", "Çungûş", "Diyarbakır", "Amed", "Türkiye", 38.2097, 39.2869)
        ),
        "istanbul" to listOf(
            d("istanbul_fatih", "Fatih", "Fatîh", "İstanbul", "Stembol", "Türkiye", 41.0186, 28.9497),
            d("istanbul_kadikoy", "Kadıköy", "Kadikoy", "İstanbul", "Stembol", "Türkiye", 40.9819, 29.0576),
            d("istanbul_uskudar", "Üsküdar", "Uskudar", "İstanbul", "Stembol", "Türkiye", 41.0234, 29.0151),
            d("istanbul_basaksehir", "Başakşehir", "Başakşehîr", "İstanbul", "Stembol", "Türkiye", 41.0977, 28.8062),
            d("istanbul_bagcilar", "Bağcılar", "Baxcilar", "İstanbul", "Stembol", "Türkiye", 41.0389, 28.8567),
            d("istanbul_esenler", "Esenler", "Esenler", "İstanbul", "Stembol", "Türkiye", 41.0439, 28.8764),
            d("istanbul_esenyurt", "Esenyurt", "Esenyûrt", "İstanbul", "Stembol", "Türkiye", 41.0289, 28.6725),
            d("istanbul_eyupsultan", "Eyüpsultan", "Eyûpsultan", "İstanbul", "Stembol", "Türkiye", 41.0480, 28.9333),
            d("istanbul_pendik", "Pendik", "Pendîk", "İstanbul", "Stembol", "Türkiye", 40.8753, 29.2336),
            d("istanbul_umraniye", "Ümraniye", "Umraniye", "İstanbul", "Stembol", "Türkiye", 41.0167, 29.1167),
            d("istanbul_besiktas", "Beşiktaş", "Beşîktaş", "İstanbul", "Stembol", "Türkiye", 41.0422, 29.0067),
            d("istanbul_bakirkoy", "Bakırköy", "Bakirkoy", "İstanbul", "Stembol", "Türkiye", 40.9808, 28.8722)
        ),
        "ankara" to listOf(
            d("ankara_cankaya", "Çankaya", "Çankaya", "Ankara", "Enqere", "Türkiye", 39.9179, 32.8627),
            d("ankara_kecioren", "Keçiören", "Keçîoren", "Ankara", "Enqere", "Türkiye", 39.9794, 32.8639),
            d("ankara_yenimahalle", "Yenimahalle", "Yenîmehalle", "Ankara", "Enqere", "Türkiye", 39.9692, 32.8114),
            d("ankara_mamak", "Mamak", "Mamak", "Ankara", "Enqere", "Türkiye", 39.9275, 32.9175),
            d("ankara_sincan", "Sincan", "Sîncan", "Ankara", "Enqere", "Türkiye", 39.9742, 32.5819),
            d("ankara_etimesgut", "Etimesgut", "Etîmesgût", "Ankara", "Enqere", "Türkiye", 39.9469, 32.6719),
            d("ankara_polatli", "Polatlı", "Polatlî", "Ankara", "Enqere", "Türkiye", 39.5844, 32.1472)
        ),
        "izmir" to listOf(
            d("izmir_konak", "Konak", "Konak", "İzmir", "Îzmîr", "Türkiye", 38.4189, 27.1287),
            d("izmir_bornova", "Bornova", "Bornova", "İzmir", "Îzmîr", "Türkiye", 38.4622, 27.2161),
            d("izmir_karsiyaka", "Karşıyaka", "Karşiyaka", "İzmir", "Îzmîr", "Türkiye", 38.4561, 27.1103),
            d("izmir_buca", "Buca", "Buca", "İzmir", "Îzmîr", "Türkiye", 38.3853, 27.1753),
            d("izmir_torbali", "Torbalı", "Torbalî", "İzmir", "Îzmîr", "Türkiye", 38.1536, 27.3622)
        ),
        "mardin" to listOf(
            d("mardin_artuklu", "Artuklu", "Artûklû", "Mardin", "Mêrdîn", "Türkiye", 37.3129, 40.7339),
            d("mardin_kiziltepe", "Kızıltepe", "Qoser", "Mardin", "Mêrdîn", "Türkiye", 37.1939, 40.5861),
            d("mardin_nusaybin", "Nusaybin", "Nisêbîn", "Mardin", "Mêrdîn", "Türkiye", 37.0750, 41.2153),
            d("mardin_midyat", "Midyat", "Midyad", "Mardin", "Mêrdîn", "Türkiye", 37.4200, 41.3397),
            d("mardin_derik", "Derik", "Dêrik", "Mardin", "Mêrdîn", "Türkiye", 37.3653, 40.2689),
            d("mardin_mazidagi", "Mazıdağı", "Şemrex", "Mardin", "Mêrdîn", "Türkiye", 37.4792, 40.4872),
            d("mardin_savur", "Savur", "Stewr", "Mardin", "Mêrdîn", "Türkiye", 37.5419, 40.8819),
            d("mardin_dargecit", "Dargeçit", "Kerboran", "Mardin", "Mêrdîn", "Türkiye", 37.5469, 41.7169)
        ),
        "sanliurfa" to listOf(
            d("urfa_haliliye", "Haliliye", "Xelîliye", "Şanlıurfa", "Riha", "Türkiye", 37.1683, 38.8011),
            d("urfa_eyyubiye", "Eyyübiye", "Eyûbiye", "Şanlıurfa", "Riha", "Türkiye", 37.1422, 38.7950),
            d("urfa_karakopru", "Karaköprü", "Karakopru", "Şanlıurfa", "Riha", "Türkiye", 37.2111, 38.7981),
            d("urfa_siverek", "Siverek", "Sêwreg", "Şanlıurfa", "Riha", "Türkiye", 37.7550, 39.3167),
            d("urfa_viransehir", "Viranşehir", "Wêranşar", "Şanlıurfa", "Riha", "Türkiye", 37.2353, 39.7653),
            d("urfa_suruc", "Suruç", "Pirsûs", "Şanlıurfa", "Riha", "Türkiye", 36.9761, 38.4239),
            d("urfa_birecik", "Birecik", "Bêrecûk", "Şanlıurfa", "Riha", "Türkiye", 37.0258, 37.9772),
            d("urfa_akcakale", "Akçakale", "Kaniya Xezalan", "Şanlıurfa", "Riha", "Türkiye", 36.7103, 38.9478),
            d("urfa_hilvan", "Hilvan", "Curnê Reş", "Şanlıurfa", "Riha", "Türkiye", 37.5869, 38.9550)
        ),
        "van" to listOf(
            d("van_ipekyolu", "İpekyolu", "Îpekyolû", "Van", "Wan", "Türkiye", 38.4942, 43.3800),
            d("van_tusba", "Tuşba", "Tûşba", "Van", "Wan", "Türkiye", 38.5322, 43.3519),
            d("van_edremit", "Edremit", "Artemêt", "Van", "Wan", "Türkiye", 38.4236, 43.2556),
            d("van_ercis", "Erciş", "Erdîş", "Van", "Wan", "Türkiye", 39.0289, 43.3586),
            d("van_ozalp", "Özalp", "Qelqelî", "Van", "Wan", "Türkiye", 38.6589, 43.9886),
            d("van_muradiye", "Muradiye", "Bêgirî", "Van", "Wan", "Türkiye", 38.9906, 43.7606),
            d("van_baskale", "Başkale", "Elbak", "Van", "Wan", "Türkiye", 38.0467, 44.0169)
        ),
        "batman" to listOf(
            d("batman_merkez", "Merkez", "Navenda Êlihê", "Batman", "Êlih", "Türkiye", 37.8812, 41.1293),
            d("batman_kozluk", "Kozluk", "Hazo", "Batman", "Êlih", "Türkiye", 38.1944, 41.4919),
            d("batman_sason", "Sason", "Qabilcewz", "Batman", "Êlih", "Türkiye", 38.3328, 41.4167),
            d("batman_besiri", "Beşiri", "Qubîn", "Batman", "Êlih", "Türkiye", 37.9219, 41.2922),
            d("batman_gercus", "Gercüş", "Kercews", "Batman", "Êlih", "Türkiye", 37.5681, 41.3811),
            d("batman_hasankeyf", "Hasankeyf", "Heskîf", "Batman", "Êlih", "Türkiye", 37.7114, 41.4150)
        ),
        "sirnak" to listOf(
            d("sirnak_cizre", "Cizre", "Cizîr", "Şırnak", "Şirnex", "Türkiye", 37.3300, 42.1856),
            d("sirnak_silopi", "Silopi", "Silopî", "Şırnak", "Şirnex", "Türkiye", 37.2483, 42.4694),
            d("sirnak_idil", "İdil", "Hezex", "Şırnak", "Şirnex", "Türkiye", 37.3392, 41.8894),
            d("sirnak_uludere", "Uludere", "Qileban", "Şırnak", "Şirnex", "Türkiye", 37.4411, 42.8528)
        ),
        "hakkari" to listOf(
            d("hakkari_yuksekova", "Yüksekova", "Gever", "Hakkâri", "Colemêrg", "Türkiye", 37.5736, 44.2872),
            d("hakkari_semdinli", "Şemdinli", "Şemzînan", "Hakkâri", "Colemêrg", "Türkiye", 37.3050, 44.5739),
            d("hakkari_cukurca", "Çukurca", "Çelê", "Hakkâri", "Colemêrg", "Türkiye", 37.2481, 43.6131)
        ),
        "siirt" to listOf(
            d("siirt_kurtalan", "Kurtalan", "Misirc", "Siirt", "Sêrt", "Türkiye", 37.9278, 41.7028),
            d("siirt_pervari", "Pervari", "Xisxêr", "Siirt", "Sêrt", "Türkiye", 37.9375, 42.5489),
            d("siirt_eruh", "Eruh", "Dihê", "Siirt", "Sêrt", "Türkiye", 37.7525, 42.1803),
            d("siirt_baykan", "Baykan", "Hêwedan", "Siirt", "Sêrt", "Türkiye", 38.1619, 41.7828),
            d("siirt_tillo", "Tillo", "Tilo", "Siirt", "Sêrt", "Türkiye", 37.9519, 42.0117)
        ),
        "bitlis" to listOf(
            d("bitlis_tatvan", "Tatvan", "Tetwan", "Bitlis", "Bedlîs", "Türkiye", 38.4919, 42.2814),
            d("bitlis_ahlat", "Ahlat", "Xelat", "Bitlis", "Bedlîs", "Türkiye", 38.7531, 42.4950),
            d("bitlis_guroymak", "Güroymak", "Norşîn", "Bitlis", "Bedlîs", "Türkiye", 38.5750, 42.0169),
            d("bitlis_hizan", "Hizan", "Xîzan", "Bitlis", "Bedlîs", "Türkiye", 38.2256, 42.4267)
        ),
        "mus" to listOf(
            d("mus_malazgirt", "Malazgirt", "Milazgir", "Muş", "Mûş", "Türkiye", 39.1464, 42.5333),
            d("mus_bulanik", "Bulanık", "Kop", "Muş", "Mûş", "Türkiye", 39.0928, 42.2739),
            d("mus_varto", "Varto", "Gimgim", "Muş", "Mûş", "Türkiye", 39.1708, 41.4547)
        ),
        "agri" to listOf(
            d("agri_dogubayazit", "Doğubayazıt", "Bazîd", "Ağrı", "Agirî", "Türkiye", 39.5469, 44.0842),
            d("agri_patnos", "Patnos", "Panos", "Ağrı", "Agirî", "Türkiye", 39.2344, 42.8639),
            d("agri_diyadin", "Diyadin", "Giyadîn", "Ağrı", "Agirî", "Türkiye", 39.5411, 43.6719)
        ),
        "antep" to listOf(
            d("antep_sahinbey", "Şahinbey", "Şahînbey", "Gaziantep", "Entab", "Türkiye", 37.0589, 37.3794),
            d("antep_sehitkamil", "Şehitkamil", "Şehîtkamîl", "Gaziantep", "Entab", "Türkiye", 37.0825, 37.3672),
            d("antep_nizip", "Nizip", "Bêlqîs", "Gaziantep", "Entab", "Türkiye", 37.0097, 37.7942)
        ),
        "adana" to listOf(
            d("adana_seyhan", "Seyhan", "Seyhan", "Adana", "Edene", "Türkiye", 36.9914, 35.3308),
            d("adana_cukurova", "Çukurova", "Çukurova", "Adana", "Edene", "Türkiye", 37.0500, 35.2833),
            d("adana_yuregir", "Yüreğir", "Yuregîr", "Adana", "Edene", "Türkiye", 36.9889, 35.3497),
            d("adana_ceyhan", "Ceyhan", "Ceyhan", "Adana", "Edene", "Türkiye", 37.0247, 35.8175)
        ),
        "antalya" to listOf(
            d("antalya_muratpasa", "Muratpaşa", "Muratpaşa", "Antalya", "Antalya", "Türkiye", 36.8841, 30.7056),
            d("antalya_alanya", "Alanya", "Alanya", "Antalya", "Antalya", "Türkiye", 36.5444, 31.9954),
            d("antalya_manavgat", "Manavgat", "Manavgat", "Antalya", "Antalya", "Türkiye", 36.7867, 31.4431),
            d("antalya_kepez", "Kepez", "Kepez", "Antalya", "Antalya", "Türkiye", 36.9278, 30.7186)
        ),
        "bursa" to listOf(
            d("bursa_osmangazi", "Osmangazi", "Osmangazî", "Bursa", "Bursa", "Türkiye", 40.1885, 29.0610),
            d("bursa_nilufer", "Nilüfer", "Nîlufer", "Bursa", "Bursa", "Türkiye", 40.2147, 28.9839),
            d("bursa_yildirim", "Yıldırım", "Yildirim", "Bursa", "Bursa", "Türkiye", 40.1856, 29.0869),
            d("bursa_inegol", "İnegöl", "Înegol", "Bursa", "Bursa", "Türkiye", 40.0781, 29.5133)
        ),
        "konya" to listOf(
            d("konya_selcuklu", "Selçuklu", "Selçûqlû", "Konya", "Qonye", "Türkiye", 37.9056, 32.4922),
            d("konya_meram", "Meram", "Meram", "Konya", "Qonye", "Türkiye", 37.8550, 32.4567),
            d("konya_karatay", "Karatay", "Karatay", "Konya", "Qonye", "Türkiye", 37.8711, 32.5189),
            d("konya_kulu", "Kulu", "Kûlû", "Konya", "Qonye", "Türkiye", 39.0928, 33.0794)
        ),
        "erbil" to listOf(
            d("erbil_soran", "Soran", "Soran", "Erbil", "Hewlêr", "Irak", 36.6528, 44.5441),
            d("erbil_shaqlawa", "Şaklava", "Şeqlawa", "Erbil", "Hewlêr", "Irak", 36.4044, 44.3247),
            d("erbil_koya", "Koysancak", "Koye", "Erbil", "Hewlêr", "Irak", 36.0828, 44.6286)
        ),
        "duhok" to listOf(
            d("duhok_akre", "Akre", "Akrê", "Duhok", "Duhok", "Irak", 36.7419, 43.8933),
            d("duhok_amedi", "Amediye", "Amêdî", "Duhok", "Duhok", "Irak", 37.0925, 43.4872),
            d("duhok_semele", "Semel", "Sêmêl", "Duhok", "Duhok", "Irak", 36.8589, 42.8519)
        ),
        "berlin" to listOf(
            d("berlin_mitte", "Mitte", "Mitte", "Berlin", "Berlîn", "Almanya", 52.5200, 13.4050),
            d("berlin_kreuzberg", "Kreuzberg", "Kreuzberg", "Berlin", "Berlîn", "Almanya", 52.4986, 13.4033),
            d("berlin_neukolln", "Neukölln", "Neukolln", "Berlin", "Berlîn", "Almanya", 52.4811, 13.4353),
            d("berlin_spandau", "Spandau", "Spandau", "Berlin", "Berlîn", "Almanya", 52.5356, 13.2003)
        ),
        "london" to listOf(
            d("london_westminster", "Westminster", "Westminster", "Londra", "London", "İngiltere", 51.4975, -0.1357),
            d("london_camden", "Camden", "Camden", "Londra", "London", "İngiltere", 51.5390, -0.1426),
            d("london_hackney", "Hackney", "Hackney", "Londra", "London", "İngiltere", 51.5450, -0.0553),
            d("london_greenwich", "Greenwich", "Greenwich", "Londra", "London", "İngiltere", 51.4826, 0.0077)
        ),
        "paris" to listOf(
            d("paris_centre", "Paris Merkez", "Navenda Parîsê", "Paris", "Parîs", "Fransa", 48.8566, 2.3522),
            d("paris_saintdenis", "Saint-Denis", "Saint-Denis", "Paris", "Parîs", "Fransa", 48.9362, 2.3574),
            d("paris_montreuil", "Montreuil", "Montreuil", "Paris", "Parîs", "Fransa", 48.8638, 2.4485)
        ),
        "newyork" to listOf(
            d("ny_manhattan", "Manhattan", "Manhattan", "New York", "New York", "ABD", 40.7831, -73.9712),
            d("ny_brooklyn", "Brooklyn", "Brooklyn", "New York", "New York", "ABD", 40.6782, -73.9442),
            d("ny_queens", "Queens", "Queens", "New York", "New York", "ABD", 40.7282, -73.7949)
        )
    )

    val ALL_DISTRICTS: List<City> by lazy {
        DISTRICTS_BY_CITY_ID.values.flatten()
    }

    fun getDistrictsForCity(cityId: String): List<City> =
        DISTRICTS_BY_CITY_ID[cityId].orEmpty()
}
