package com.example.data.model

enum class QuranReciter(
    val id: String,
    val nameTr: String,
    val nameKu: String,
    val nameArabic: String,
    val serverBaseUrl: String,
    val mirrorSlug: String
) {
    ALAFASY(
        id = "alafasy",
        nameTr = "Mişari Raşid el-Afasi",
        nameKu = "Mîşarî Reşîd el-Efasî",
        nameArabic = "مشاري راشد العفاسي",
        serverBaseUrl = "https://server8.mp3quran.net/afs/",
        mirrorSlug = "ar.alafasy"
    ),
    ABDULBASIT(
        id = "abdulbasit",
        nameTr = "Abdülbasit Abdüssamed",
        nameKu = "Ebdilbasit Ebdussemed",
        nameArabic = "عبد الباسط عبد الصمد",
        serverBaseUrl = "https://server7.mp3quran.net/basit/",
        mirrorSlug = "ar.abdulbasitmurattal"
    ),
    ALGHAMDI(
        id = "alghamdi",
        nameTr = "Saad el-Ghamdi",
        nameKu = "Se'd el-Xamîdî",
        nameArabic = "سعد الغامدي",
        serverBaseUrl = "https://server7.mp3quran.net/s_gmd/",
        mirrorSlug = "ar.saoodshuraym"
    ),
    ALMUAIQLY(
        id = "almuaiqly",
        nameTr = "Mahir el-Muaykili",
        nameKu = "Mahîr el-Mu'eyqilî",
        nameArabic = "ماهر المعيقلي",
        serverBaseUrl = "https://server12.mp3quran.net/maher/",
        mirrorSlug = "ar.mahermuaiqly"
    ),
    ALHUSSARY(
        id = "alhussary",
        nameTr = "Mahmud Halil el-Husari",
        nameKu = "Mehmûd Xelîl el-Husarî",
        nameArabic = "محمود خليل الحصري",
        serverBaseUrl = "https://server13.mp3quran.net/husr/",
        mirrorSlug = "ar.husary"
    );

    fun getDisplayName(language: AppLanguage): String {
        return when (language) {
            AppLanguage.TURKISH -> nameTr
            AppLanguage.KURMANJI -> nameKu
        }
    }

    fun getSurahAudioUrl(surahNumber: Int): String {
        val safeNum = surahNumber.coerceIn(1, 114)
        val padded = String.format("%03d", safeNum)
        return "$serverBaseUrl$padded.mp3"
    }

    fun getSurahAudioUrls(surahNumber: Int): List<String> {
        val safeNum = surahNumber.coerceIn(1, 114)
        val padded = String.format("%03d", safeNum)
        return listOf(
            "$serverBaseUrl$padded.mp3",
            "https://cdn.islamic.network/quran/audio-surah/128/$mirrorSlug/$safeNum.mp3"
        )
    }

    companion object {
        fun fromId(id: String?): QuranReciter {
            return entries.find { it.id.equals(id, ignoreCase = true) } ?: ALAFASY
        }
    }
}
