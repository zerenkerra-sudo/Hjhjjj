package com.example.data.model

import java.util.Calendar

data class PrayerTimes(
    val fajr: String,
    val sunrise: String,
    val dhuhr: String,
    val asr: String,
    val maghrib: String,
    val isha: String,
    val dateReadable: String,
    val hijriDate: String,
    val calculationMethod: String = "Astronomik Güneş Açısı (Fecr 18°, Yatsı 17°)",
    val isOffline: Boolean = false,
    val cityName: String = "İstanbul",
    val latitude: Double = 41.0082,
    val longitude: Double = 28.9784,
    val timezone: String = "",
    val dateIso: String = ""
) {
    fun getTimeFor(type: PrayerType): String {
        return when (type) {
            PrayerType.FAJR -> fajr
            PrayerType.SUNRISE -> sunrise
            PrayerType.DHUHR -> dhuhr
            PrayerType.ASR -> asr
            PrayerType.MAGHRIB -> maghrib
            PrayerType.ISHA -> isha
        }
    }

    fun getTargetTimeZone(): java.util.TimeZone {
        return com.example.data.repository.DiyanetCalculator.getTimeZoneForId(
            com.example.data.repository.DiyanetCalculator.resolveTimeZoneId(
                latitude = latitude,
                longitude = longitude,
                cityName = cityName,
                country = "",
                preferredTz = timezone
            )
        )
    }

    /**
     * Calculates the exact epoch time in milliseconds for the given prayer today.
     * Uses target location timezone when available to ensure worldwide exact alarms.
     */
    fun getPrayerMillis(type: PrayerType, forTomorrowIfPassed: Boolean = true): Long {
        val timeStr = getTimeFor(type)
        val parts = timeStr.split(":")
        if (parts.size < 2) return 0L

        val hour = parts[0].trim().toIntOrNull()?.takeIf { it in 0..23 } ?: return 0L
        val minute = parts[1].trim().take(2).toIntOrNull()?.takeIf { it in 0..59 } ?: return 0L

        val tz = getTargetTimeZone()

        val calendar = Calendar.getInstance(tz).apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (forTomorrowIfPassed && calendar.timeInMillis <= System.currentTimeMillis()) {
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        return calendar.timeInMillis
    }

    /**
     * Calculates the exact epoch time in milliseconds 30 minutes (or specified minutes)
     * before the given prayer time, accounting for today or tomorrow.
     */
    fun getPreAdhanReminderMillis(type: PrayerType, minutesBefore: Int = 30): Long {
        val now = System.currentTimeMillis()
        val todayPrayerMillis = getPrayerMillis(type, forTomorrowIfPassed = false)
        val todayPreReminder = todayPrayerMillis - (minutesBefore * 60 * 1000L)

        return if (todayPreReminder > now) {
            todayPreReminder
        } else {
            val tomorrowPrayerMillis = getPrayerMillis(type, forTomorrowIfPassed = true)
            val candidate = tomorrowPrayerMillis - (minutesBefore * 60 * 1000L)
            if (candidate > now) candidate else (tomorrowPrayerMillis + 24 * 3600 * 1000L - (minutesBefore * 60 * 1000L))
        }
    }

    fun getNextPrayer(date: java.util.Date = java.util.Date()): NextPrayerInfo {
        val now = date.time
        val prayers = listOf(
            PrayerType.FAJR,
            PrayerType.SUNRISE,
            PrayerType.DHUHR,
            PrayerType.ASR,
            PrayerType.MAGHRIB,
            PrayerType.ISHA
        )
        for (prayer in prayers) {
            val millis = getPrayerMillis(prayer, forTomorrowIfPassed = false)
            if (millis > now) {
                return NextPrayerInfo(
                    type = prayer,
                    time = getTimeFor(prayer),
                    millisRemaining = millis - now,
                    isCurrent = false
                )
            }
        }
        val tomorrowFajrMillis = getPrayerMillis(PrayerType.FAJR, forTomorrowIfPassed = true)
        return NextPrayerInfo(
            type = PrayerType.FAJR,
            time = fajr,
            millisRemaining = (tomorrowFajrMillis - now).coerceAtLeast(0L),
            isCurrent = false
        )
    }
}

data class NextPrayerInfo(
    val type: PrayerType,
    val time: String,
    val millisRemaining: Long,
    val isCurrent: Boolean = false
)
