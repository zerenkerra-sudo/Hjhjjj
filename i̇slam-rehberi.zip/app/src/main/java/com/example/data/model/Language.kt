package com.example.data.model

enum class AppLanguage(val code: String, val displayName: String, val nativeName: String) {
    TURKISH("tr", "Türkçe", "Türkçe"),
    KURMANJI("ku", "Kürtçe (Kurmancî)", "Kurmancî (Latînî)");

    companion object {
        fun fromCode(code: String): AppLanguage =
            entries.find { it.code == code } ?: TURKISH
    }
}
