package com.example.data.repository

import android.content.Context
import com.example.data.local.AppPreferences
import com.example.data.model.DailyForecastDay
import com.example.data.model.HourlyForecastPoint
import com.example.data.model.WeatherInfo
import com.example.data.remote.ApiClient
import com.example.data.remote.MetNorwayForecastResponse
import com.example.data.remote.OpenMeteoForecastResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.roundToInt

class WeatherRepository(
    private val preferences: AppPreferences,
    private val context: Context? = null
) {
    private val openMeteoApi = ApiClient.openMeteoWeatherApi
    private val metNorwayApi = ApiClient.metNorwayWeatherApi

    suspend fun getWeatherForLocation(
        latitude: Double,
        longitude: Double,
        locationName: String,
        country: String = "",
        forceRefresh: Boolean = false
    ): Result<WeatherInfo> = withContext(Dispatchers.IO) {
        val canUseNetwork = context == null ||
            com.example.util.NetworkUtils.isNetworkAvailable(context) ||
            forceRefresh

        if (canUseNetwork) {
            try {
                val (openMeteoResult, metNoResult) = coroutineScope {
                    val omDeferred = async {
                        runCatching {
                            openMeteoApi.getForecast(latitude = latitude, longitude = longitude)
                        }.getOrNull()
                    }
                    val metDeferred = async {
                        runCatching {
                            val latFormatted = String.format(Locale.US, "%.4f", latitude)
                            val lonFormatted = String.format(Locale.US, "%.4f", longitude)
                            metNorwayApi.getLocationForecast(latFormatted, lonFormatted)
                        }.getOrNull()
                    }
                    omDeferred.await() to metDeferred.await()
                }

                val nowMillis = System.currentTimeMillis()
                val omParsed = openMeteoResult?.let {
                    parseOpenMeteoForecast(
                        response = it,
                        latitude = latitude,
                        longitude = longitude,
                        locationName = locationName,
                        country = country,
                        nowMillis = nowMillis
                    )
                }
                val metParsed = metNoResult?.let {
                    parseMetNorwayResponse(
                        response = it,
                        latitude = latitude,
                        longitude = longitude,
                        locationName = locationName,
                        country = country,
                        nowMillis = nowMillis
                    )
                }

                val liveWeather = reconcileWeatherSources(omParsed, metParsed)
                if (liveWeather != null) {
                    preferences.saveCachedWeather(liveWeather)
                    return@withContext Result.success(liveWeather)
                }
            } catch (_: Exception) {
                // Fall back to strictly validated offline cache below
            }
        }

        val cached = getValidCachedWeather(
            preferences = preferences,
            latitude = latitude,
            longitude = longitude,
            locationName = locationName,
            country = country
        )
        if (cached != null) {
            return@withContext Result.success(cached)
        }

        Result.failure(Exception("Güncel hava durumu verisi alınamadı"))
    }

    companion object {
        const val MAX_CACHE_COORD_DELTA = 0.10 // ~11 km radius so nearby towns never share wrong cache
        const val MAX_CACHE_AGE_MS = 12 * 60 * 60 * 1000L // 12 hours max cache validity

        fun getValidCachedWeather(
            preferences: AppPreferences,
            latitude: Double,
            longitude: Double,
            locationName: String,
            country: String = "",
            nowMillis: Long = System.currentTimeMillis()
        ): WeatherInfo? {
            val cached = preferences.getCachedWeather() ?: return null
            val ageMs = nowMillis - cached.updatedAtMillis
            if (ageMs < 0 || ageMs > MAX_CACHE_AGE_MS) return null
            if (abs(cached.latitude - latitude) > MAX_CACHE_COORD_DELTA ||
                abs(cached.longitude - longitude) > MAX_CACHE_COORD_DELTA
            ) {
                return null
            }

            val tzId = cached.timezoneId.ifBlank {
                DiyanetCalculator.resolveTimeZoneId(latitude, longitude, locationName, country)
            }
            val tz = DiyanetCalculator.getTimeZoneForId(tzId)
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = tz
            }.format(Date(nowMillis))

            val validDaily = cached.dailyForecast.filter { it.dateIso >= todayIso }
            val todayForecast = validDaily.firstOrNull { it.dateIso == todayIso }
            val minTemp = minOf(todayForecast?.minTempC ?: cached.minTempC, cached.temperatureC)
            val maxTemp = maxOf(todayForecast?.maxTempC ?: cached.maxTempC, cached.temperatureC)

            return cached.copy(
                locationName = locationName,
                dailyForecast = validDaily.ifEmpty { cached.dailyForecast },
                minTempC = minTemp,
                maxTempC = maxTemp,
                isOfflineCache = true,
                timezoneId = tzId
            )
        }

        fun parseOpenMeteoForecast(
            response: OpenMeteoForecastResponse,
            latitude: Double,
            longitude: Double,
            locationName: String,
            country: String = "",
            nowMillis: Long = System.currentTimeMillis()
        ): WeatherInfo? {
            val current = response.current ?: return null
            val currentTemp = current.temperature2m ?: return null

            val tzId = DiyanetCalculator.resolveTimeZoneId(
                latitude = latitude,
                longitude = longitude,
                cityName = locationName,
                country = country,
                preferredTz = response.timezone.orEmpty()
            )
            val tz = DiyanetCalculator.getTimeZoneForId(tzId)
            val todayIso = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = tz
            }.format(Date(nowMillis))
            val nowHourPrefix = SimpleDateFormat("yyyy-MM-dd'T'HH", Locale.US).apply {
                timeZone = tz
            }.format(Date(nowMillis))
            val clockLabel = SimpleDateFormat("HH:mm", Locale.US).apply {
                timeZone = tz
            }.format(Date(nowMillis))

            // Hourly forecast (next 8 hours anchored to city's actual local current hour)
            val hourlyPoints = mutableListOf<HourlyForecastPoint>()
            val hTimes = response.hourly?.time.orEmpty()
            val hTemps = response.hourly?.temperature2m.orEmpty()
            val hCodes = response.hourly?.weatherCode.orEmpty()
            val hIsDays = response.hourly?.isDay.orEmpty()

            val currentIsoPrefix = current.time?.takeIf { it.length >= 13 }?.substring(0, 13)
            val startHourIdx = hTimes.indexOfFirst { it != null && it.startsWith(nowHourPrefix) }
                .takeIf { it >= 0 }
                ?: currentIsoPrefix?.let { prefix ->
                    hTimes.indexOfFirst { it != null && it.startsWith(prefix) }.takeIf { it >= 0 }
                }
                ?: 0
            val firstFutureIdx = (startHourIdx + 1).coerceAtMost(hTimes.size)
            val endHourIdx = minOf(firstFutureIdx + 8, hTimes.size, hTemps.size)
            for (i in firstFutureIdx until endHourIdx) {
                val tStr = hTimes[i] ?: continue
                val temp = hTemps[i] ?: continue
                val hhmm = if (tStr.contains("T")) tStr.substringAfter("T").take(5) else tStr
                hourlyPoints.add(
                    HourlyForecastPoint(
                        hourLabel = hhmm,
                        temperatureC = temp,
                        weatherCode = hCodes.getOrNull(i) ?: (current.weatherCode ?: 0),
                        isDay = (hIsDays.getOrNull(i) ?: 1) != 0
                    )
                )
            }

            // 7-day forecast starting from todayIso (never stale yesterday)
            val dailyPoints = mutableListOf<DailyForecastDay>()
            val dTimes = response.daily?.time.orEmpty()
            val dCodes = response.daily?.weatherCode.orEmpty()
            val dMax = response.daily?.temperature2mMax.orEmpty()
            val dMin = response.daily?.temperature2mMin.orEmpty()
            val dPrecip = response.daily?.precipitationProbabilityMax.orEmpty()

            val todayIdx = dTimes.indexOfFirst { it != null && it >= todayIso }.let { idx ->
                if (idx >= 0) idx else 0
            }
            val maxDailySize = minOf(dTimes.size, dMax.size, dMin.size)
            for (i in todayIdx until minOf(todayIdx + 7, maxDailySize)) {
                val dateStr = dTimes[i] ?: continue
                val maxT = dMax[i] ?: continue
                val minT = dMin[i] ?: continue
                dailyPoints.add(
                    DailyForecastDay(
                        dateIso = dateStr,
                        weatherCode = dCodes.getOrNull(i) ?: (current.weatherCode ?: 0),
                        minTempC = minOf(minT, maxT),
                        maxTempC = maxOf(minT, maxT),
                        precipitationChancePercent = (dPrecip.getOrNull(i) ?: 0).coerceIn(0, 100)
                    )
                )
            }

            // If today's hourly values contain current-hour temperature closer to now than 15-min model, verify bounds
            val todayMin = minOf(dailyPoints.firstOrNull()?.minTempC ?: currentTemp, currentTemp)
            val todayMax = maxOf(dailyPoints.firstOrNull()?.maxTempC ?: currentTemp, currentTemp)
            val alignedDaily = if (dailyPoints.isNotEmpty() && dailyPoints.first().dateIso == todayIso) {
                dailyPoints.mapIndexed { idx, day ->
                    if (idx == 0) day.copy(minTempC = todayMin, maxTempC = todayMax) else day
                }
            } else {
                dailyPoints
            }

            return WeatherInfo(
                locationName = locationName,
                temperatureC = currentTemp,
                apparentTemperatureC = current.apparentTemperature ?: currentTemp,
                humidityPercent = (current.relativeHumidity2m ?: 0).coerceIn(0, 100),
                windSpeedKmh = (current.windSpeed10m ?: 0.0).coerceAtLeast(0.0),
                weatherCode = current.weatherCode ?: 0,
                isDay = (current.isDay ?: 1) != 0,
                minTempC = todayMin,
                maxTempC = todayMax,
                hourlyForecast = hourlyPoints,
                dailyForecast = alignedDaily,
                latitude = latitude,
                longitude = longitude,
                updatedAtMillis = nowMillis,
                isOfflineCache = false,
                timezoneId = tzId,
                observationTimeLabel = clockLabel
            )
        }

        fun parseMetNorwayJson(
            rawJson: String,
            latitude: Double,
            longitude: Double,
            locationName: String,
            country: String = "",
            nowMillis: Long = System.currentTimeMillis()
        ): WeatherInfo? {
            return try {
                val moshi = Moshi.Builder().addLast(KotlinJsonAdapterFactory()).build()
                val parsed = moshi.adapter(MetNorwayForecastResponse::class.java).fromJson(rawJson)
                    ?: return null
                parseMetNorwayResponse(parsed, latitude, longitude, locationName, country, nowMillis)
            } catch (_: Exception) {
                null
            }
        }

        fun parseMetNorwayResponse(
            response: MetNorwayForecastResponse,
            latitude: Double,
            longitude: Double,
            locationName: String,
            country: String = "",
            nowMillis: Long = System.currentTimeMillis()
        ): WeatherInfo? {
            return try {
                val timeseries = response.properties?.timeseries.orEmpty()
                if (timeseries.isEmpty()) return null

                val tzId = DiyanetCalculator.resolveTimeZoneId(latitude, longitude, locationName, country)
                val tz = DiyanetCalculator.getTimeZoneForId(tzId)
                val isoUtc = SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'", Locale.US).apply {
                    timeZone = TimeZone.getTimeZone("UTC")
                }
                val localDateFmt = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                    timeZone = tz
                }
                val localHourFmt = SimpleDateFormat("HH:mm", Locale.US).apply {
                    timeZone = tz
                }
                val localHourOnlyFmt = SimpleDateFormat("HH", Locale.US).apply {
                    timeZone = tz
                }

                data class Entry(
                    val timeMillis: Long,
                    val dateIso: String,
                    val hourLabel: String,
                    val localHour: Int,
                    val tempC: Double,
                    val humidity: Int,
                    val windKmh: Double,
                    val wmoCode: Int,
                    val isDay: Boolean,
                    val precipMm: Double
                )

                val entries = mutableListOf<Entry>()
                for (item in timeseries) {
                    if (item == null) continue
                    val timeStr = item.time ?: continue
                    val epoch = runCatching { isoUtc.parse(timeStr)?.time }.getOrNull() ?: continue
                    val data = item.data ?: continue
                    val instant = data.instant?.details ?: continue
                    val tempC = instant.airTemperature ?: continue
                    val humidity = (instant.relativeHumidity ?: 50.0).roundToInt().coerceIn(0, 100)
                    val windMs = (instant.windSpeed ?: 0.0).coerceAtLeast(0.0)
                    val windKmh = windMs * 3.6

                    val next1h = data.next1Hours
                    val next6h = data.next6Hours
                    val symbol = next1h?.summary?.symbolCode?.takeIf { it.isNotBlank() }
                        ?: next6h?.summary?.symbolCode.orEmpty()
                    val precipMm = next1h?.details?.precipitationAmount
                        ?: next6h?.details?.precipitationAmount
                        ?: 0.0

                    val localDate = Date(epoch)
                    val localHour = localHourOnlyFmt.format(localDate).toIntOrNull() ?: 12
                    val (wmo, isDay) = mapMetSymbolToWmo(symbol, localHour)

                    entries.add(
                        Entry(
                            timeMillis = epoch,
                            dateIso = localDateFmt.format(localDate),
                            hourLabel = localHourFmt.format(localDate),
                            localHour = localHour,
                            tempC = tempC,
                            humidity = humidity,
                            windKmh = windKmh,
                            wmoCode = wmo,
                            isDay = isDay,
                            precipMm = precipMm
                        )
                    )
                }

                if (entries.isEmpty()) return null

                // Closest timeseries entry to nowMillis
                val currentEntry = entries.minByOrNull { abs(it.timeMillis - nowMillis) } ?: entries.first()
                val apparent = calculateApparentTempC(
                    tempC = currentEntry.tempC,
                    humidityPercent = currentEntry.humidity,
                    windKmh = currentEntry.windKmh
                )

                val hourlyPoints = entries
                    .filter { it.timeMillis > currentEntry.timeMillis }
                    .take(8)
                    .map {
                        HourlyForecastPoint(
                            hourLabel = it.hourLabel,
                            temperatureC = it.tempC,
                            weatherCode = it.wmoCode,
                            isDay = it.isDay
                        )
                    }

                val todayIso = localDateFmt.format(Date(nowMillis))
                val groupedByDate = entries
                    .filter { it.dateIso >= todayIso }
                    .groupBy { it.dateIso }

                val dailyPoints = groupedByDate.entries
                    .sortedBy { it.key }
                    .take(7)
                    .map { (dateStr, dayEntries) ->
                        val minT = dayEntries.minOf { it.tempC }
                        val maxT = dayEntries.maxOf { it.tempC }
                        val midday = dayEntries.minByOrNull { abs(it.localHour - 13) } ?: dayEntries.first()
                        val maxPrecipMm = dayEntries.maxOf { it.precipMm }
                        val precipChance = when {
                            maxPrecipMm >= 2.0 -> 85
                            maxPrecipMm >= 0.5 -> 65
                            maxPrecipMm > 0.0 -> 35
                            dayEntries.any { it.wmoCode >= 51 } -> 50
                            else -> 5
                        }
                        DailyForecastDay(
                            dateIso = dateStr,
                            weatherCode = midday.wmoCode,
                            minTempC = minT,
                            maxTempC = maxT,
                            precipitationChancePercent = precipChance
                        )
                    }

                val todayMin = minOf(dailyPoints.firstOrNull()?.minTempC ?: currentEntry.tempC, currentEntry.tempC)
                val todayMax = maxOf(dailyPoints.firstOrNull()?.maxTempC ?: currentEntry.tempC, currentEntry.tempC)
                val clockLabel = localHourFmt.format(Date(nowMillis))

                WeatherInfo(
                    locationName = locationName,
                    temperatureC = currentEntry.tempC,
                    apparentTemperatureC = apparent,
                    humidityPercent = currentEntry.humidity,
                    windSpeedKmh = currentEntry.windKmh,
                    weatherCode = currentEntry.wmoCode,
                    isDay = currentEntry.isDay,
                    minTempC = todayMin,
                    maxTempC = todayMax,
                    hourlyForecast = hourlyPoints,
                    dailyForecast = dailyPoints,
                    latitude = latitude,
                    longitude = longitude,
                    updatedAtMillis = nowMillis,
                    isOfflineCache = false,
                    timezoneId = tzId,
                    observationTimeLabel = clockLabel
                )
            } catch (_: Exception) {
                null
            }
        }

        fun reconcileWeatherSources(
            openMeteo: WeatherInfo?,
            metNorway: WeatherInfo?
        ): WeatherInfo? {
            if (openMeteo == null) return metNorway
            if (metNorway == null) return openMeteo

            val tempDelta = abs(openMeteo.temperatureC - metNorway.temperatureC)
            // If both high-res sources diverge noticeably (> 3.0°C), reconcile toward terrain-corrected MET Norway + Open-Meteo
            return if (tempDelta > 3.0) {
                val reconciledTemp = ((openMeteo.temperatureC * 0.4) + (metNorway.temperatureC * 0.6))
                val tempShift = reconciledTemp - openMeteo.temperatureC
                val newMin = minOf(openMeteo.minTempC, reconciledTemp)
                val newMax = maxOf(openMeteo.maxTempC, reconciledTemp)
                val updatedDaily = openMeteo.dailyForecast.mapIndexed { idx, day ->
                    if (idx == 0) day.copy(minTempC = newMin, maxTempC = newMax) else day
                }
                openMeteo.copy(
                    temperatureC = reconciledTemp,
                    apparentTemperatureC = openMeteo.apparentTemperatureC + tempShift,
                    minTempC = newMin,
                    maxTempC = newMax,
                    dailyForecast = updatedDaily
                )
            } else {
                openMeteo
            }
        }

        fun mapMetSymbolToWmo(symbolCode: String, localHour: Int): Pair<Int, Boolean> {
            val lower = symbolCode.lowercase(Locale.US)
            val isDay = when {
                lower.endsWith("_night") -> false
                lower.endsWith("_day") -> true
                else -> localHour in 6..18
            }
            val base = lower.removeSuffix("_day").removeSuffix("_night").removeSuffix("_polartwilight")
            val wmo = when {
                base.contains("thunder") -> 95
                base.contains("snow") || base.contains("sleet") -> 73
                base.contains("heavyrain") -> 65
                base.contains("lightrain") -> 51
                base.contains("rain") -> 61
                base == "fog" -> 45
                base == "cloudy" -> 3
                base == "partlycloudy" -> 2
                base == "fair" -> 1
                base == "clearsky" -> 0
                else -> 2
            }
            return wmo to isDay
        }

        private fun calculateApparentTempC(
            tempC: Double,
            humidityPercent: Int,
            windKmh: Double
        ): Double {
            val rh = humidityPercent.coerceIn(0, 100) / 100.0
            val e = rh * 6.105 * exp((17.27 * tempC) / (237.7 + tempC))
            val windMs = (windKmh / 3.6).coerceAtLeast(0.0)
            return tempC + 0.33 * e - 0.70 * windMs - 4.00
        }
    }
}
