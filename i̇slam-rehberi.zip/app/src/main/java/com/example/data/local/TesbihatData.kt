package com.example.data.local

import com.example.data.model.AppLanguage

data class TesbihatStep(
    val stepNumber: Int,
    val titleTr: String,
    val titleKu: String,
    val arabicText: String,
    val transliteration: String,
    val meaningTr: String,
    val meaningKu: String,
    val targetCount: Int
) {
    fun getTitle(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) titleKu else titleTr

    fun getMeaning(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) meaningKu else meaningTr
}

data class ZikirPreset(
    val id: String,
    val titleTr: String,
    val titleKu: String,
    val arabicText: String,
    val transliteration: String,
    val meaningTr: String,
    val meaningKu: String,
    val defaultTarget: Int
) {
    fun getTitle(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) titleKu else titleTr

    fun getMeaning(language: AppLanguage): String =
        if (language == AppLanguage.KURMANJI) meaningKu else meaningTr
}

object TesbihatData {

    val NAMAZ_TESBIHATI_STEPS: List<TesbihatStep> = listOf(
        TesbihatStep(
            stepNumber = 1,
            titleTr = "Selam Sonrası İstiğfar & Teslimiyet",
            titleKu = "Piştî Silavê Îstîxfar û Duaya Selamê",
            arabicText = "أَسْتَغْفِرُ اللّٰهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ ۝ اَللّٰهُمَّ أَنْتَ السَّلَامُ وَمِنْكَ السَّلَامُ، تَبَارَكْتَ يَا ذَا الْجَلَالِ وَالْإِكْرَامِ",
            transliteration = "Estağfirullâhel-azîm ve etûbü ileyh. Allâhümme entes-selâmü ve minkes-selâm, tebârekte yâ zel-celâli vel-ikrâm.",
            meaningTr = "Yüce Allah'tan bağışlanma diler ve O'na tövbe ederim. Allah'ım! Esenlik ve barış kaynağı Sensin, selamet Sendendir. Ey celal ve ikram sahibi, Sen çok yüce ve mübareksin.",
            meaningKu = "Ez ji Xwedayê Mezin lêborînê dixwazim û li Wî tobe dikim. Ya Reb! Tu çavkaniya aştî û selametê yî, selamet ji Te ye. Ey xwediyê mezinahî û keremê, Tu pîroz û bilind î.",
            targetCount = 1
        ),
        TesbihatStep(
            stepNumber = 2,
            titleTr = "Salavat-ı Şerife",
            titleKu = "Selewata Pîroz",
            arabicText = "عَلٰى رَسُولِنَا مُحَمَّدٍ صَلَوَاتٌ ۝ اَللّٰهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَعَلٰى آلِ سَيِّدِنَا مُحَمَّدٍ",
            transliteration = "Alâ Resûlinâ Muhammedin salavât. Allâhümme salli alâ Seyyidinâ Muhammedin ve alâ âli Seyyidinâ Muhammed.",
            meaningTr = "Peygamberimiz Hz. Muhammed'e (s.a.v.) salât ve selam olsun. Allah'ım! Efendimiz Muhammed'e ve âline rahmet ve bereket ihsan eyle.",
            meaningKu = "Silav û selewat li ser Pêxemberê me Muhemmed (s.a.v) bin. Ya Reb! Rehm û bereketê bide ser Seyîdê me Muhemmed û malbata wî.",
            targetCount = 1
        ),
        TesbihatStep(
            stepNumber = 3,
            titleTr = "Tesbih Duası",
            titleKu = "Duaya Tesbîhê",
            arabicText = "سُبْحَانَ اللّٰهِ وَالْحَمْدُ لِلّٰهِ وَلَا إِلٰهَ إِلَّا اللّٰهُ وَاللّٰهُ أَكْبَرُ، وَلَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ الْعَلِيِّ الْعَظِيمِ",
            transliteration = "Sübhânallâhi vel-hamdü lillâhi ve lâ ilâhe illallâhü vallâhü ekber. Ve lâ havle ve lâ kuvvete illâ billâhil-aliyyil-azîm.",
            meaningTr = "Allah bütün noksanlıklardan münezzehtir. Hamd Allah'a mahsustur. Allah'tan başka ilah yoktur ve Allah en büyüktür. Güç ve kuvvet ancak yüce ve ulu Allah'ın yardımıyladır.",
            meaningKu = "Allah ji hemû kêmasiyan dûr e. Hemd ji bo Allah e. Ji Allah pê ve tu îlah tune ye û Allah herî mezin e. Hêz û qewet tenê bi Allahê Bilind û Mezin e.",
            targetCount = 1
        ),
        TesbihatStep(
            stepNumber = 4,
            titleTr = "Âyetel Kürsî (Bakara, 255)",
            titleKu = "Ayeta Kursî (Beqere, 255)",
            arabicText = "اَللّٰهُ لَا إِلٰهَ إِلَّا هُوَ الْحَيُّ الْقَيُّومُ ۚ لَا تَأْخُذُهُ سِنَةٌ وَلَا نَوْمٌ ۚ لَهُ مَا فِي السَّمٰوَاتِ وَمَا فِي الْأَرْضِ ۗ مَنْ ذَا الَّذِي يَشْفَعُ عِنْدَهُ إِلَّا بِإِذْنِهِ ۚ يَعْلَمُ مَا بَيْنَ أَيْدِيهِمْ وَمَا خَلْفَهُمْ ۖ وَلَا يُحِيطُونَ بِشَيْءٍ مِنْ عِلْمِهِ إِلَّا بِمَا شَاءَ ۚ وَسِعَ كُرْسِيُّهُ السَّمٰوَاتِ وَالْأَرْضَ ۖ وَلَا يَؤُودُهُ حِفْظُهُمَا ۚ وَهُوَ الْعَلِيُّ الْعَظِيمُ",
            transliteration = "Allâhü lâ ilâhe illâ hüvel-hayyül-kayyûm. Lâ te'huzühû sinetün ve lâ nevm. Lehû mâ fis-semâvâti ve mâ fil-ard. Men zellezî yeşfeu indehû illâ bi-iznih. Ya'lemü mâ beyne eydîhim ve mâ halfehüm. Ve lâ yühîtûne bi-şey'in min ilmihî illâ bimâ şâe. Vesia kürsiyyühüs-semâvâti vel-ard. Ve lâ yeûdühû hıfzuhümâ ve hüvel-aliyyül-azîm.",
            meaningTr = "Allah, O'ndan başka ilah yoktur; diridir, her şeyin varlığı O'na bağlı ve dayalıdır. Ne uykusu gelir ne de uyur. Göklerde ve yerde ne varsa hepsi O'nundur. İzni olmadan katında kim şefaat edebilir? O, kullarının önlerindekini de arkalarındakini de bilir. O'nun ilminden dilediğinden başka hiçbir şeyi kavrayamazlar. O'nun kürsüsü bütün gökleri ve yeri kaplamıştır. Onları koruyup gözetmek O'na ağır gelmez. O, yücedir, büyüktür.",
            meaningKu = "Allah ew e ku ji Wî pê ve tu îlah tune ye; zindî ye û rêvebirê her tiştî ye. Ne xewnî û ne jî xew digire Wî. Çi li ezmanan û çi li erdê heye tev ê Wî ye. Bêyî destûra Wî kî dikare li cem Wî şefaetê bike? Tiştên li pêşiya wan û li paşiya wan dizane. Ji zanîna Wî ji bilî tiştê ku Wî xwestibe kes nikare bi tiştekî bigihêje. Kursiya Wî ezman û erd dorpêç kirine û parastina wan ji bo Wî ne giran e. Ew bilind û mezin e.",
            targetCount = 1
        ),
        TesbihatStep(
            stepNumber = 5,
            titleTr = "Sübhânallâh (33 Kere)",
            titleKu = "Subhanellah (33 Caran)",
            arabicText = "سُبْحَانَ اللّٰهِ",
            transliteration = "Sübhânallâh",
            meaningTr = "Allah her türlü eksiklik ve noksanlıktan uzaktır, münezzehtir. (33 defa)",
            meaningKu = "Allah ji hemû kêmasî û kêmahiyan pak û dûr e. (33 caran)",
            targetCount = 33
        ),
        TesbihatStep(
            stepNumber = 6,
            titleTr = "Elhamdülillâh (33 Kere)",
            titleKu = "Elhemdulîllah (33 Caran)",
            arabicText = "اَلْحَمْدُ لِلّٰهِ",
            transliteration = "Elhamdülillâh",
            meaningTr = "Bütün övgüler, şükürler ve hamd yalnızca Allah'a mahsustur. (33 defa)",
            meaningKu = "Hemû pesin, hemd û şukir tenê ji bo Allah in. (33 caran)",
            targetCount = 33
        ),
        TesbihatStep(
            stepNumber = 7,
            titleTr = "Allâhu Ekber (33 Kere)",
            titleKu = "Ellahu Ekber (33 Caran)",
            arabicText = "اَللّٰهُ أَكْبَرُ",
            transliteration = "Allâhu Ekber",
            meaningTr = "Allah en büyüktür; azameti ve yüceliği her şeyin üstündedir. (33 defa)",
            meaningKu = "Allah ji her tiştî mezintir û bilindtir e. (33 caran)",
            targetCount = 33
        ),
        TesbihatStep(
            stepNumber = 8,
            titleTr = "Tehlîl ve Namaz Duası (99 Tamamlayıcı)",
            titleKu = "Tehlîl û Duaya Dawiyê (Temamkirina 99)",
            arabicText = "لَا إِلٰهَ إِلَّا اللّٰهُ وَحْدَهُ لَا شَرِيكَ لَهُ، لَهُ الْمُلْكُ وَلَهُ الْحَمْدُ وَهُوَ عَلٰى كُلِّ شَيْءٍ قَدِيرٌ ۝ سُبْحَانَ رَبِّيَ الْعَلِيِّ الْأَعْلَى الْوَهَّابُ",
            transliteration = "Lâ ilâhe illallâhü vahdehû lâ şerîke leh, lehül-mülkü ve lehül-hamdü ve hüve alâ külli şey'in kadîr. Sübhâne Rabbiyel-aliyyil-a'lel-vehhâb.",
            meaningTr = "Allah'tan başka ilah yoktur; O tektir, eşi ve ortağı yoktur. Mülk O'nundur, hamd O'nadır. O'nun gücü her şeye hakkıyla yeter. Yüce, en üstün ve sonsuz ikram sahibi Rabbim her türlü noksanlıktan münezzehtir. Âmîn.",
            meaningKu = "Ji Allah pê ve tu îlah tune ye; Ew yek e û şirîkê Wî tune ye. Mulk ê Wî ye, hemd ji Wî re ye û Ew li ser her tiştî bi hêz e. Rebbê min ê Bilind û Bexşende ji hemû kêmasiyan pak e. Amîn.",
            targetCount = 1
        )
    )

    val ZIKIR_PRESETS: List<ZikirPreset> = listOf(
        ZikirPreset(
            id = "subhanallah",
            titleTr = "Sübhânallâh",
            titleKu = "Subhanellah",
            arabicText = "سُبْحَانَ اللّٰهِ",
            transliteration = "Sübhânallâh",
            meaningTr = "Allah bütün noksan sıfatlardan uzaktır.",
            meaningKu = "Allah ji hemû kêmasiyan dûr e.",
            defaultTarget = 33
        ),
        ZikirPreset(
            id = "elhamdulillah",
            titleTr = "Elhamdülillâh",
            titleKu = "Elhemdulîllah",
            arabicText = "اَلْحَمْدُ لِلّٰهِ",
            transliteration = "Elhamdülillâh",
            meaningTr = "Hamd ve şükür Allah'a mahsustur.",
            meaningKu = "Hemû hemd û şukir ji bo Allah in.",
            defaultTarget = 33
        ),
        ZikirPreset(
            id = "allahuekber",
            titleTr = "Allâhu Ekber",
            titleKu = "Ellahu Ekber",
            arabicText = "اَللّٰهُ أَكْبَرُ",
            transliteration = "Allâhu Ekber",
            meaningTr = "Allah en büyüktür.",
            meaningKu = "Allah ji her tiştî mezintir e.",
            defaultTarget = 33
        ),
        ZikirPreset(
            id = "tevhid",
            titleTr = "Kelime-i Tevhîd",
            titleKu = "Kelîmeya Tewhîdê",
            arabicText = "لَا إِلٰهَ إِلَّا اللّٰهُ",
            transliteration = "Lâ ilâhe illallâh",
            meaningTr = "Allah'tan başka hiçbir ilah yoktur.",
            meaningKu = "Ji Allah pê ve tu îlah tune ye.",
            defaultTarget = 100
        ),
        ZikirPreset(
            id = "istigfar",
            titleTr = "İstiğfar-ı Şerîf",
            titleKu = "Îstîxfar",
            arabicText = "أَسْتَغْفِرُ اللّٰهَ الْعَظِيمَ وَأَتُوبُ إِلَيْهِ",
            transliteration = "Estağfirullâhel-azîm ve etûbü ileyh",
            meaningTr = "Yüce Allah'tan bağışlanma diler ve O'na tövbe ederim.",
            meaningKu = "Ez ji Xwedayê Mezin lêborînê dixwazim û tobe dikim.",
            defaultTarget = 100
        ),
        ZikirPreset(
            id = "salavat",
            titleTr = "Salavât-ı Şerîfe",
            titleKu = "Selewata Pîroz",
            arabicText = "اَللّٰهُمَّ صَلِّ عَلٰى سَيِّدِنَا مُحَمَّدٍ وَعَلٰى آلِ سَيِّدِنَا مُحَمَّدٍ",
            transliteration = "Allâhümme salli alâ Seyyidinâ Muhammedin ve alâ âli Seyyidinâ Muhammed",
            meaningTr = "Allah'ım! Efendimiz Muhammed'e ve âline salât ve selam eyle.",
            meaningKu = "Ya Reb! Silav û rehma Xwe bide ser Seyîdê me Muhemmed û malbata wî.",
            defaultTarget = 100
        ),
        ZikirPreset(
            id = "subhanallahi_bihamdihi",
            titleTr = "Sübhânallâhi ve bihamdihî",
            titleKu = "Subhanellahî we bihemdîhî",
            arabicText = "سُبْحَانَ اللّٰهِ وَبِحَمْدِهِ سُبْحَانَ اللّٰهِ الْعَظِيمِ",
            transliteration = "Sübhânallâhi ve bihamdihî sübhânallâhil-azîm",
            meaningTr = "Allah'ı hamd ile tesbih ederim; yüce Allah noksanlıklardan münezzehtir.",
            meaningKu = "Bi hemdê Wî ez Allah tesbîh dikim, Allahê Mezin ji kêmasiyan dûr e.",
            defaultTarget = 100
        ),
        ZikirPreset(
            id = "hasbunallah",
            titleTr = "Hasbünallâhü ve ni'mel-vekîl",
            titleKu = "Hesbunellahu we nî'mel-wekîl",
            arabicText = "حَسْبُنَا اللّٰهُ وَنِعْمَ الْوَكِيلُ",
            transliteration = "Hasbünallâhü ve ni'mel-vekîl",
            meaningTr = "Allah bize yeter, O ne güzel vekildir.",
            meaningKu = "Allah besî me ye û Ew çi wekîlekî qenc e.",
            defaultTarget = 33
        ),
        ZikirPreset(
            id = "lahavle",
            titleTr = "Lâ havle ve lâ kuvvete illâ billâh",
            titleKu = "La hewle we la quwwete îlla bîllah",
            arabicText = "لَا حَوْلَ وَلَا قُوَّةَ إِلَّا بِاللّٰهِ",
            transliteration = "Lâ havle ve lâ kuvvete illâ billâh",
            meaningTr = "Güç ve kuvvet ancak Allah'ın yardımıyladır.",
            meaningKu = "Hêz û qewet tenê bi Allah e.",
            defaultTarget = 33
        ),
        ZikirPreset(
            id = "tesbih99",
            titleTr = "Toplu Tesbihat (99'luk)",
            titleKu = "Tesbîhata Giştî (99)",
            arabicText = "سُبْحَانَ اللّٰهِ وَالْحَمْدُ لِلّٰهِ وَاللّٰهُ أَكْبَرُ",
            transliteration = "Sübhânallâh • Elhamdülillâh • Allâhu Ekber",
            meaningTr = "Tek sayaçta 33 Sübhanallah, 33 Elhamdülillah, 33 Allahu Ekber çekimi.",
            meaningKu = "Di yek jimartinê de 33 Subhanellah, 33 Elhemdulîllah, 33 Ellahu Ekber.",
            defaultTarget = 99
        )
    )
}
