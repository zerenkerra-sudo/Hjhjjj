package com.example.data.repository

import com.example.data.model.City
import com.example.data.model.PrayerTimes
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.*

/**
 * High-precision astronomical solar ephemeris (Jean Meeus) implementing
 * official Turkish Diyanet parameters:
 * - Fajr sun depression angle: 18.0° (+0 min temkin)
 * - Sunrise apparent horizon: -0.833° (-7 min temkin)
 * - Dhuhr solar transit: 0° (+5 min temkin)
 * - Asr shadow ratio: 1 (Shafi/Cumhur, +4 min temkin)
 * - Maghrib apparent horizon: -0.833° (+7 min temkin)
 * - Isha sun depression angle: 17.0° (+0 min temkin)
 * - Exact IANA timezone & automatic DST resolution + high-latitude summer protection
 */
object DiyanetCalculator {

    private val AVAILABLE_TZ_IDS: Set<String> by lazy { TimeZone.getAvailableIDs().toSet() }

    data class RawSolarMinutes(
        val fajrMin: Int,
        val sunriseMin: Int,
        val dhuhrMin: Int,
        val asrMin: Int,
        val maghribMin: Int,
        val ishaMin: Int,
        val timezoneId: String,
        val dateIso: String
    )

    fun calculateTimes(
        latitude: Double,
        longitude: Double,
        date: Date = Date(),
        cityName: String = "Konum",
        country: String = "",
        preferredTz: String = "",
        isOfflineMode: Boolean = true
    ): PrayerTimes {
        val tzId = resolveTimeZoneId(
            latitude = latitude,
            longitude = longitude,
            cityName = cityName,
            country = country,
            preferredTz = preferredTz
        )
        val tz = getTimeZoneForId(tzId)
        val raw = calculateRawMinutesInternal(latitude, longitude, date, tz, applyTemkin = true)

        val df = SimpleDateFormat("dd MMMM yyyy", Locale("tr")).apply { timeZone = tz }
        val isoDf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }

        return PrayerTimes(
            fajr = formatMinutes(raw.fajrMin),
            sunrise = formatMinutes(raw.sunriseMin),
            dhuhr = formatMinutes(raw.dhuhrMin),
            asr = formatMinutes(raw.asrMin),
            maghrib = formatMinutes(raw.maghribMin),
            isha = formatMinutes(raw.ishaMin),
            dateReadable = df.format(date),
            hijriDate = formatOfflineHijriDate(date, tz),
            calculationMethod = if (isOfflineMode) {
                "Standart Astronomik Güneş Açısı (Çevrimdışı)"
            } else {
                "Standart Astronomik Güneş Açısı (Fecr 18°, Yatsı 17°)"
            },
            isOffline = isOfflineMode,
            cityName = cityName,
            latitude = latitude,
            longitude = longitude,
            timezone = tzId,
            dateIso = isoDf.format(date)
        )
    }

    /**
     * Returns raw astronomical minutes WITHOUT Diyanet temkin offsets (used to verify whether
     * an online API response already applied Diyanet temkin or returned raw angles).
     */
    fun calculateRawAstronomicalMinutes(
        latitude: Double,
        longitude: Double,
        date: Date,
        tz: TimeZone
    ): RawSolarMinutes {
        return calculateRawMinutesInternal(latitude, longitude, date, tz, applyTemkin = false)
    }

    private fun calculateRawMinutesInternal(
        latitude: Double,
        longitude: Double,
        date: Date,
        tz: TimeZone,
        applyTemkin: Boolean
    ): RawSolarMinutes {
        val cal = Calendar.getInstance(tz).apply { time = date }
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val day = cal.get(Calendar.DAY_OF_MONTH)

        val localNoonCal = Calendar.getInstance(tz).apply {
            set(Calendar.YEAR, year)
            set(Calendar.MONTH, month - 1)
            set(Calendar.DAY_OF_MONTH, day)
            set(Calendar.HOUR_OF_DAY, 12)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val tzOffsetHours = getTimezoneOffsetHours(tz, localNoonCal.timeInMillis)

        // Julian Day at 0h UT for target local date
        var jy = year
        var jm = month
        if (jm <= 2) {
            jy -= 1
            jm += 12
        }
        val ja = jy / 100
        val jb = 2 - ja + (ja / 4)
        val jd0 = floor(365.25 * (jy + 4716)) + floor(30.6001 * (jm + 1)) + day + jb - 1524.5

        fun sunPosition(jd: Double): Pair<Double, Double> {
            val d = jd - 2451545.0
            val gDeg = ((357.529 + 0.98560028 * d) % 360.0 + 360.0) % 360.0
            val g = Math.toRadians(gDeg)
            val q = ((280.459 + 0.98564736 * d) % 360.0 + 360.0) % 360.0
            val lDeg = ((q + 1.915 * sin(g) + 0.020 * sin(2.0 * g)) % 360.0 + 360.0) % 360.0
            val l = Math.toRadians(lDeg)
            val e = Math.toRadians(23.439 - 0.00000036 * d)
            val dec = asin((sin(e) * sin(l)).coerceIn(-1.0, 1.0))
            val raHours = ((Math.toDegrees(atan2(cos(e) * sin(l), cos(l))) / 15.0) % 24.0 + 24.0) % 24.0
            var eotHours = q / 15.0 - raHours
            while (eotHours > 12.0) eotHours -= 24.0
            while (eotHours < -12.0) eotHours += 24.0
            return dec to eotHours
        }

        val latRad = Math.toRadians(latitude.coerceIn(-89.5, 89.5))

        fun hourAngleHours(elevationDeg: Double, dec: Double): Double? {
            val denom = cos(latRad) * cos(dec)
            if (abs(denom) < 1e-12) return null
            val cosHA = (sin(Math.toRadians(elevationDeg)) - sin(latRad) * sin(dec)) / denom
            if (cosHA < -1.0 || cosHA > 1.0) return null
            return Math.toDegrees(acos(cosHA)) / 15.0
        }

        // Pass 1: Local solar noon
        val jdMid = jd0 + 0.5 - longitude / 360.0
        val (_, eotMid) = sunPosition(jdMid)
        val solarNoonPass1 = 12.0 + tzOffsetHours - longitude / 15.0 - eotMid

        // Pass 2: Iterative per-event sun ephemeris
        fun refineEvent(initialLocalHour: Double, sign: Double, angleProvider: (Double) -> Double): Double? {
            var estimate = initialLocalHour
            repeat(2) {
                val jdEvent = jd0 + (estimate - tzOffsetHours) / 24.0
                val (decI, eotI) = sunPosition(jdEvent)
                val noonI = 12.0 + tzOffsetHours - longitude / 15.0 - eotI
                val ha = hourAngleHours(angleProvider(decI), decI) ?: return null
                estimate = noonI + sign * ha
            }
            return estimate
        }

        val noonEst = refineEvent(solarNoonPass1, 0.0) { 90.0 } // unused ha, evaluate noon at exact noon JD
        val jdExactNoon = jd0 + (solarNoonPass1 - tzOffsetHours) / 24.0
        val (decNoon, eotExactNoon) = sunPosition(jdExactNoon)
        val solarNoon = 12.0 + tzOffsetHours - longitude / 15.0 - eotExactNoon

        val srInitHa = hourAngleHours(-0.833, decNoon) ?: 6.0
        val sunriseRaw = refineEvent(solarNoon - srInitHa, -1.0) { -0.833 }
            ?: run {
                // Polar regions fallback
                val jdEv = jd0 + (solarNoon - 6.0 - tzOffsetHours) / 24.0
                val (dEv, eEv) = sunPosition(jdEv)
                val nEv = 12.0 + tzOffsetHours - longitude / 15.0 - eEv
                val cosClamped = ((sin(Math.toRadians(-0.833)) - sin(latRad) * sin(dEv)) / (cos(latRad) * cos(dEv)).coerceAtLeast(1e-6)).coerceIn(-1.0, 1.0)
                nEv - Math.toDegrees(acos(cosClamped)) / 15.0
            }

        val sunsetRaw = refineEvent(solarNoon + srInitHa, +1.0) { -0.833 }
            ?: run {
                val jdEv = jd0 + (solarNoon + 6.0 - tzOffsetHours) / 24.0
                val (dEv, eEv) = sunPosition(jdEv)
                val nEv = 12.0 + tzOffsetHours - longitude / 15.0 - eEv
                val cosClamped = ((sin(Math.toRadians(-0.833)) - sin(latRad) * sin(dEv)) / (cos(latRad) * cos(dEv)).coerceAtLeast(1e-6)).coerceIn(-1.0, 1.0)
                nEv + Math.toDegrees(acos(cosClamped)) / 15.0
            }

        val fajrInitHa = hourAngleHours(-18.0, decNoon) ?: (srInitHa + 1.5)
        var fajrRaw = refineEvent(solarNoon - fajrInitHa, -1.0) { -18.0 }

        val ishaInitHa = hourAngleHours(-17.0, decNoon) ?: (srInitHa + 1.5)
        var ishaRaw = refineEvent(solarNoon + ishaInitHa, +1.0) { -17.0 }

        // High-latitude summer night adjustment (angle-based rule: angle / 60 of night)
        val nightHours = ((24.0 + sunriseRaw - sunsetRaw) % 24.0 + 24.0) % 24.0
        if (fajrRaw == null) {
            fajrRaw = sunriseRaw - (18.0 / 60.0) * nightHours
        }
        if (ishaRaw == null) {
            ishaRaw = sunsetRaw + (17.0 / 60.0) * nightHours
        }

        val asrElevationNoon = 90.0 - Math.toDegrees(atan(1.0 + tan(abs(latRad - decNoon))))
        val asrInitHa = hourAngleHours(asrElevationNoon, decNoon) ?: 3.5
        val asrRaw = refineEvent(solarNoon + asrInitHa, +1.0) { decI ->
            90.0 - Math.toDegrees(atan(1.0 + tan(abs(latRad - decI))))
        } ?: (solarNoon + asrInitHa)

        // Official Diyanet İşleri Başkanlığı temkin offsets (minutes)
        val fajrTemkin = if (applyTemkin) 0.0 else 0.0
        val sunriseTemkin = if (applyTemkin) -7.0 / 60.0 else 0.0
        val dhuhrTemkin = if (applyTemkin) 5.0 / 60.0 else 0.0
        val asrTemkin = if (applyTemkin) 4.0 / 60.0 else 0.0
        val maghribTemkin = if (applyTemkin) 7.0 / 60.0 else 0.0
        val ishaTemkin = if (applyTemkin) 0.0 else 0.0

        val fajrMin = toDayMinutes(fajrRaw + fajrTemkin)
        val sunriseMin = toDayMinutes(sunriseRaw + sunriseTemkin)
        val dhuhrMin = toDayMinutes(solarNoon + dhuhrTemkin)
        val asrMin = toDayMinutes(asrRaw + asrTemkin)
        val maghribMin = toDayMinutes(sunsetRaw + maghribTemkin)
        val ishaMin = toDayMinutes(ishaRaw + ishaTemkin)

        val isoDf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { timeZone = tz }
        return RawSolarMinutes(
            fajrMin = fajrMin,
            sunriseMin = sunriseMin,
            dhuhrMin = dhuhrMin,
            asrMin = asrMin,
            maghribMin = maghribMin,
            ishaMin = ishaMin,
            timezoneId = tz.id,
            dateIso = isoDf.format(date)
        )
    }

    private fun getTimezoneOffsetHours(tz: TimeZone, atMillis: Long): Double {
        // Turkey permanently stays on UTC+3 since late 2016 regardless of old device tzdata
        if (tz.id == "Europe/Istanbul" && atMillis >= 1477800000000L) {
            return 3.0
        }
        return tz.getOffset(atMillis) / 3_600_000.0
    }

    private fun toDayMinutes(hours: Double): Int {
        val total = (hours * 60.0).roundToInt()
        return ((total % 1440) + 1440) % 1440
    }

    private fun formatMinutes(minutesOfDay: Int): String {
        val norm = ((minutesOfDay % 1440) + 1440) % 1440
        val h = norm / 60
        val m = norm % 60
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    fun getTimeZoneForId(tzId: String): TimeZone {
        val cleaned = tzId.trim()
        if (cleaned.isEmpty()) return TimeZone.getDefault()
        if (cleaned == "Europe/Istanbul") {
            // SimpleTimeZone(3*3600_000, "Europe/Istanbul") guarantees permanent +03:00 even on outdated tzdb
            return TimeZone.getTimeZone("Europe/Istanbul").let { systemTz ->
                if (systemTz.id == "Europe/Istanbul" && systemTz.getOffset(System.currentTimeMillis()) == 3 * 3600_000) {
                    systemTz
                } else {
                    TimeZone.getTimeZone("GMT+03:00")
                }
            }
        }
        val gmtMatch = Regex("^GMT([+-])(\\d{1,2})(?::(\\d{2}))?$", RegexOption.IGNORE_CASE).matchEntire(cleaned)
        if (gmtMatch != null) {
            val sign = gmtMatch.groupValues[1]
            val h = gmtMatch.groupValues[2].padStart(2, '0')
            val m = gmtMatch.groupValues[3].ifEmpty { "00" }
            return TimeZone.getTimeZone("GMT$sign$h:$m")
        }
        val resolved = TimeZone.getTimeZone(cleaned)
        return if (resolved.id == "GMT" && !cleaned.equals("GMT", ignoreCase = true) && !cleaned.equals("UTC", ignoreCase = true)) {
            TimeZone.getDefault()
        } else {
            resolved
        }
    }

    /**
     * Resolves an exact IANA TimeZone ID for any city, country, or coordinate offline.
     */
    fun resolveTimeZoneId(
        latitude: Double,
        longitude: Double,
        cityName: String = "",
        country: String = "",
        preferredTz: String = ""
    ): String {
        val pref = preferredTz.trim()
        if (pref.isNotEmpty() && pref != "GMT" && (pref in AVAILABLE_TZ_IDS || pref.startsWith("GMT") || pref == "UTC")) {
            return pref
        }

        val cNorm = country.trim().lowercase(Locale("tr"))
        val cityNorm = cityName.trim().lowercase(Locale("tr"))

        // 1. Direct country name matching (Turkish + English + German)
        val byCountry = mapCountryToTimeZone(cNorm, latitude, longitude)
        if (byCountry != null) return byCountry

        // 2. Try matching city name or nearby city in DEFAULT_CITIES (within ~150 km)
        val nonGpsCities = City.DEFAULT_CITIES.filter { !it.isGps }
        val exactCityMatch = nonGpsCities.firstOrNull {
            cityNorm.isNotEmpty() && (
                cityNorm.contains(it.nameTr.lowercase(Locale("tr"))) ||
                    cityNorm.contains(it.nameKu.lowercase(Locale("tr")))
                )
        }
        if (exactCityMatch != null) {
            mapCountryToTimeZone(exactCityMatch.country.lowercase(Locale("tr")), exactCityMatch.latitude, exactCityMatch.longitude)?.let {
                return it
            }
        }

        // 3. Turkey & immediate neighboring region geographic boxes (guarantees permanent UTC+3)
        if (latitude in 37.35..42.25 && longitude in 25.6..44.9) {
            return "Europe/Istanbul"
        }
        if (latitude in 35.8..37.35 && longitude in 26.0..44.9) {
            return when {
                longitude >= 42.2 && latitude < 37.1 -> "Asia/Baghdad"
                longitude in 36.7..42.2 && latitude < 36.7 -> "Asia/Damascus"
                else -> "Europe/Istanbul"
            }
        }
        if (latitude in 29.0..37.3 && longitude in 38.8..48.6) return "Asia/Baghdad"
        if (latitude in 32.3..37.3 && longitude in 35.6..42.4) return "Asia/Damascus"
        if (latitude in 25.0..39.8 && longitude in 44.0..63.4) return "Asia/Tehran"

        // 4. Nearest known world hub within 180 km
        var bestCity: City? = null
        var bestDistKm = 180.0
        for (c in nonGpsCities) {
            val dLat = Math.toRadians(c.latitude - latitude)
            val dLon = Math.toRadians(c.longitude - longitude)
            val a = sin(dLat / 2).pow(2) +
                cos(Math.toRadians(latitude)) * cos(Math.toRadians(c.latitude)) * sin(dLon / 2).pow(2)
            val distKm = 6371.0 * 2.0 * atan2(sqrt(a), sqrt((1.0 - a).coerceAtLeast(0.0)))
            if (distKm < bestDistKm) {
                bestDistKm = distKm
                bestCity = c
            }
        }
        if (bestCity != null) {
            mapCountryToTimeZone(bestCity.country.lowercase(Locale("tr")), bestCity.latitude, bestCity.longitude)?.let {
                return it
            }
        }

        // 5. Broad regional boxes for Europe / UK so DST is handled offline
        if (latitude in 49.8..60.9 && longitude in -8.6..1.8) return "Europe/London"
        if (latitude in 42.3..51.1 && longitude in -4.8..8.3) return "Europe/Paris"
        if (latitude in 47.2..55.1 && longitude in 5.8..15.1) return "Europe/Berlin"
        if (latitude in 55.2..71.2 && longitude in 4.5..24.2) {
            return if (longitude < 11.2) "Europe/Oslo" else "Europe/Stockholm"
        }

        // 6. If device timezone matches approximate solar meridian within ±18°, prefer device timezone (captures DST)
        val sysTz = TimeZone.getDefault()
        val sysStdLon = (sysTz.rawOffset / 3_600_000.0) * 15.0
        if (abs(longitude - sysStdLon) <= 18.0 && sysTz.id != "GMT") {
            return sysTz.id
        }

        // 7. Last resort solar meridian offset
        val approxHours = round(longitude / 15.0).toInt().coerceIn(-12, 14)
        return if (approxHours >= 0) {
            "GMT+${approxHours.toString().padStart(2, '0')}:00"
        } else {
            "GMT-${(-approxHours).toString().padStart(2, '0')}:00"
        }
    }

    private fun mapCountryToTimeZone(cNorm: String, lat: Double, lng: Double): String? {
        return when {
            cNorm.isEmpty() -> null
            "türkiye" in cNorm || "turkey" in cNorm || "turkiye" in cNorm -> "Europe/Istanbul"
            "almanya" in cNorm || "germany" in cNorm || "deutschland" in cNorm -> "Europe/Berlin"
            "fransa" in cNorm || "france" in cNorm -> "Europe/Paris"
            "ingiltere" in cNorm || "united kingdom" in cNorm || "birleşik krallık" in cNorm || cNorm == "uk" -> "Europe/London"
            "hollanda" in cNorm || "netherlands" in cNorm -> "Europe/Amsterdam"
            "belçika" in cNorm || "belgium" in cNorm -> "Europe/Brussels"
            "avusturya" in cNorm || "austria" in cNorm -> "Europe/Vienna"
            "isviçre" in cNorm || "switzerland" in cNorm -> "Europe/Zurich"
            "isveç" in cNorm || "sweden" in cNorm -> "Europe/Stockholm"
            "norveç" in cNorm || "norway" in cNorm -> "Europe/Oslo"
            "danimarka" in cNorm || "denmark" in cNorm -> "Europe/Copenhagen"
            "bosna" in cNorm || "bosnia" in cNorm -> "Europe/Sarajevo"
            "makedonya" in cNorm || "macedonia" in cNorm -> "Europe/Skopje"
            "kosova" in cNorm || "kosovo" in cNorm || "sırbistan" in cNorm || "serbia" in cNorm -> "Europe/Belgrade"
            "arnavutluk" in cNorm || "albania" in cNorm -> "Europe/Tirane"
            "irak" in cNorm || "iraq" in cNorm -> "Asia/Baghdad"
            "suriye" in cNorm || "syria" in cNorm -> "Asia/Damascus"
            "iran" in cNorm || "İran" in cNorm -> "Asia/Tehran"
            "suudi" in cNorm || "saudi" in cNorm -> "Asia/Riyadh"
            "filistin" in cNorm || "palestine" in cNorm || "israil" in cNorm || "israel" in cNorm -> "Asia/Jerusalem"
            "arap emirlik" in cNorm || "emirates" in cNorm || "uae" in cNorm -> "Asia/Dubai"
            "katar" in cNorm || "qatar" in cNorm -> "Asia/Qatar"
            "kuveyt" in cNorm || "kuwait" in cNorm -> "Asia/Kuwait"
            "mısır" in cNorm || "egypt" in cNorm -> "Africa/Cairo"
            "libya" in cNorm -> "Africa/Tripoli"
            "tunus" in cNorm || "tunisia" in cNorm -> "Africa/Tunis"
            "cezayir" in cNorm || "algeria" in cNorm -> "Africa/Algiers"
            "fas" in cNorm || "morocco" in cNorm -> "Africa/Casablanca"
            "lübnan" in cNorm || "lebanon" in cNorm -> "Asia/Beirut"
            "ürdün" in cNorm || "jordan" in cNorm -> "Asia/Amman"
            "azerbaycan" in cNorm || "azerbaijan" in cNorm -> "Asia/Baku"
            "özbekistan" in cNorm || "uzbekistan" in cNorm -> "Asia/Tashkent"
            "kazakistan" in cNorm || "kazakhstan" in cNorm -> if (lng < 55.0) "Asia/Aqtau" else "Asia/Almaty"
            "kırgızistan" in cNorm || "kyrgyzstan" in cNorm -> "Asia/Bishkek"
            "tacikistan" in cNorm || "tajikistan" in cNorm -> "Asia/Dushanbe"
            "türkmenistan" in cNorm || "turkmenistan" in cNorm -> "Asia/Ashgabat"
            "pakistan" in cNorm -> "Asia/Karachi"
            "bangladeş" in cNorm || "bangladesh" in cNorm -> "Asia/Dhaka"
            "hindistan" in cNorm || "india" in cNorm -> "Asia/Kolkata"
            "endonezya" in cNorm || "indonesia" in cNorm -> "Asia/Jakarta"
            "malezya" in cNorm || "malaysia" in cNorm -> "Asia/Kuala_Lumpur"
            "japonya" in cNorm || "japan" in cNorm -> "Asia/Tokyo"
            "güney kore" in cNorm || "korea" in cNorm -> "Asia/Seoul"
            "avustralya" in cNorm || "australia" in cNorm -> if (lng < 140.0) "Australia/Perth" else "Australia/Sydney"
            "abd" in cNorm || "united states" in cNorm || "usa" in cNorm -> when {
                lng < -114.0 -> "America/Los_Angeles"
                lng < -101.0 -> "America/Denver"
                lng < -85.0 -> "America/Chicago"
                else -> "America/New_York"
            }
            "kanada" in cNorm || "canada" in cNorm -> when {
                lng < -115.0 -> "America/Vancouver"
                lng < -100.0 -> "America/Edmonton"
                lng < -85.0 -> "America/Winnipeg"
                else -> "America/Toronto"
            }
            else -> null
        }
    }

    /**
     * Standard Tabular/Kuwaiti Hijri date formatter for reliable offline display.
     */
    private fun formatOfflineHijriDate(date: Date, tz: TimeZone): String {
        val cal = Calendar.getInstance(tz).apply { time = date }
        val day = cal.get(Calendar.DAY_OF_MONTH)
        val month = cal.get(Calendar.MONTH) + 1
        val year = cal.get(Calendar.YEAR)

        var m = month
        var y = year
        if (m < 3) {
            y -= 1
            m += 12
        }
        val a = floor(y / 100.0)
        var b = 2 - a + floor(a / 4.0)
        if (y < 1583) b = 0.0
        val jd = floor(365.25 * (y + 4716)) + floor(30.6001 * (m + 1)) + day + b - 1524.0

        val z = jd - 1948440.0 + 10632.0
        val n = floor((z - 1.0) / 10631.0)
        val r = z - 10631.0 * n + 354.0
        val j = (floor((10985.0 - r) / 5316.0)) * (floor((50.0 * r) / 17719.0)) +
            (floor(r / 5670.0)) * (floor((43.0 * r) / 15238.0))
        val rAdj = r - (floor((30.0 - j) / 15.0)) * (floor((17719.0 * j) / 50.0)) -
            (floor(j / 16.0)) * (floor((15238.0 * j) / 43.0)) + 29.0
        val hMonth = floor((24.0 * rAdj) / 709.0).toInt().coerceIn(1, 12)
        val hDay = (rAdj - floor((709.0 * hMonth) / 24.0)).toInt().coerceIn(1, 30)
        val hYear = (30 * n + j - 30).toInt()

        val hijriMonths = listOf(
            "Muharrem", "Safer", "Rebiülevvel", "Rebiülahir",
            "Cemaziyelevvel", "Cemaziyelahir", "Recep", "Şaban",
            "Ramazan", "Şevval", "Zilkade", "Zilhicce"
        )
        return "$hDay ${hijriMonths[hMonth - 1]} $hYear"
    }
}
