package com.example.data.model

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

enum class AppTheme(
    val id: String,
    val titleTr: String,
    val titleKu: String,
    val subtitleTr: String,
    val subtitleKu: String,
    val primary: Color,
    val onPrimary: Color,
    val secondary: Color,
    val background: Color,
    val surface: Color,
    val surfaceVariant: Color,
    val cardBackground: Color,
    val cardBorder: Color,
    val accent: Color,
    val textPrimary: Color,
    val textSecondary: Color
) {
    EMERALD_GOLD(
        id = "emerald_gold",
        titleTr = "Zümrüt Yeşili & Altın",
        titleKu = "Keskê Zümrût & Zêr",
        subtitleTr = "Klasik Ravza-i Mutahhara Yeşili",
        subtitleKu = "Keskê Klasîk ê Îslamê",
        primary = Color(0xFF0F634E),
        onPrimary = Color(0xFFFFFFFF),
        secondary = Color(0xFFD4AF37),
        background = Color(0xFF03140F),
        surface = Color(0xFF07241C),
        surfaceVariant = Color(0xFF0C3026),
        cardBackground = Color(0xFF0A2B21),
        cardBorder = Color(0xFF18483A),
        accent = Color(0xFFF3CA52),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFFA1C6BA)
    ),
    MIDNIGHT_BLUE(
        id = "midnight_blue",
        titleTr = "Gece Mavisi & Gümüş",
        titleKu = "Şîna Şevê & Zîv",
        subtitleTr = "Kandil Geceleri & Gökyüzü",
        subtitleKu = "Şeva Pîroz & Esman",
        primary = Color(0xFF1A365D),
        onPrimary = Color(0xFFFFFFFF),
        secondary = Color(0xFFCBD5E0),
        background = Color(0xFF0A1128),
        surface = Color(0xFF0F1B3E),
        surfaceVariant = Color(0xFF162A5A),
        cardBackground = Color(0xFF132247),
        cardBorder = Color(0xFF233870),
        accent = Color(0xFF63B3ED),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFFA0AEC0)
    ),
    KAABA_BLACK_GOLD(
        id = "kaaba_black_gold",
        titleTr = "Kâbe Siyahı & Altın Varak",
        titleKu = "Reşê Kabeyê & Zêrê Zer",
        subtitleTr = "Kâbe-i Muazzama Kisvesi",
        subtitleKu = "Pêça Kabeya Pîroz",
        primary = Color(0xFF2B221B),
        onPrimary = Color(0xFFFFD700),
        secondary = Color(0xFFFFD700),
        background = Color(0xFF0D0D0D),
        surface = Color(0xFF161616),
        surfaceVariant = Color(0xFF222222),
        cardBackground = Color(0xFF1C1A17),
        cardBorder = Color(0xFF4A3E2A),
        accent = Color(0xFFFFE082),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFFD4AF37)
    ),
    ROSE_BURGUNDY(
        id = "rose_burgundy",
        titleTr = "Gül-i Muhammedî & Bordo",
        titleKu = "Gula Muhammedî & Bordo",
        subtitleTr = "Huzur Veren Peygamber Gülü",
        subtitleKu = "Rengê Gula Pêxember",
        primary = Color(0xFF5C1D24),
        onPrimary = Color(0xFFFFFFFF),
        secondary = Color(0xFFE2A1A8),
        background = Color(0xFF1A0A0C),
        surface = Color(0xFF241014),
        surfaceVariant = Color(0xFF33161C),
        cardBackground = Color(0xFF2C1217),
        cardBorder = Color(0xFF5E2630),
        accent = Color(0xFFF48FB1),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFFDDA7A5)
    ),
    SELJUK_TURQUOISE(
        id = "seljuk_turquoise",
        titleTr = "Selçuklu Turkuazı & Kubbe",
        titleKu = "Fîrozeya Selçûkî & Qube",
        subtitleTr = "Tarihi İslam Medeniyeti Çinileri",
        subtitleKu = "Kevirên Fîroze yên Îslamê",
        primary = Color(0xFF0D5C75),
        onPrimary = Color(0xFFFFFFFF),
        secondary = Color(0xFF4DD0E1),
        background = Color(0xFF041920),
        surface = Color(0xFF06232D),
        surfaceVariant = Color(0xFF0C3847),
        cardBackground = Color(0xFF082E3B),
        cardBorder = Color(0xFF134C5E),
        accent = Color(0xFF80DEEA),
        textPrimary = Color(0xFFFFFFFF),
        textSecondary = Color(0xFF80CBC4)
    );

    val deepTint: Color get() = lerp(background, primary, 0.25f)
    val darkTint: Color get() = lerp(background, primary, 0.55f)
    val lightTint: Color get() = lerp(primary, accent, 0.28f)
    val containerTint: Color get() = lerp(surfaceVariant, primary, 0.45f)
    val strongBorder: Color get() = lerp(cardBorder, accent, 0.22f)
    val accentWarm: Color get() = lerp(accent, secondary, 0.35f)
    val accentDark: Color get() = lerp(secondary, background, 0.56f)
    val accentContainer: Color get() = lerp(background, secondary, 0.24f)
    val accentMuted: Color get() = lerp(secondary, textSecondary, 0.28f)
    val translationPrimary: Color get() = lerp(textPrimary, accent, 0.14f)
    val translationSecondary: Color get() = lerp(textPrimary, textSecondary, 0.16f)

    fun getDisplayName(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) titleKu else titleTr
    fun getDisplaySubtitle(language: AppLanguage): String = if (language == AppLanguage.KURMANJI) subtitleKu else subtitleTr
}
