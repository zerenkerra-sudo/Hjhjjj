package com.example.data.repository

import android.content.Context
import android.text.Html
import com.example.data.local.AppPreferences
import com.example.data.local.HutbeData
import com.example.data.model.Hutbe
import com.example.data.remote.ApiClient
import com.example.util.NetworkUtils
import com.example.util.WordDocTextExtractor
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone

data class DiyanetHutbeLink(
    val detayId: Int,
    val url: String,
    val dateIso: String,
    val dateTr: String,
    val isBayram: Boolean = false
)

data class DiyanetDetayDocs(
    val htmlTitle: String,
    val turkishDocUrl: String?,
    val arabicDocUrl: String?,
    val audioUrl: String?
)

/**
 * Fetches complete, verbatim Friday Hutbes exclusively from T.C. Diyanet İşleri Başkanlığı's
 * official website (https://dinhizmetleri.diyanet.gov.tr/).
 * Automatically refreshes every Friday (and Thursday afternoon onwards), on stale caches,
 * and whenever network connectivity is restored.
 */
class DiyanetHutbeRepository(
    private val preferences: AppPreferences,
    private val context: Context,
    private val httpClient: OkHttpClient = ApiClient.httpClient
) {

    fun getAvailableHutbes(): List<Hutbe> {
        val cached = preferences.getCachedHutbes()
        val combined = mergeHutbes(cached, HutbeData.HUTBE_LIST)
        return combined.sortedWith(
            compareByDescending<Hutbe> { it.dateIso }
                .thenByDescending { it.isSyncedFromDiyanet }
        )
    }

    fun shouldAutoSync(nowMillis: Long = System.currentTimeMillis()): Boolean {
        val cached = preferences.getCachedHutbes()
        if (cached.isEmpty()) return true

        val latestCachedIso = cached.maxOfOrNull { it.dateIso } ?: ""
        val targetFridayIso = computeMostRecentFridayIso(nowMillis)
        if (latestCachedIso < targetFridayIso) return true

        val lastSyncMs = preferences.getLastHutbeSyncMillis()
        val ageMs = nowMillis - lastSyncMs
        if (ageMs < 0) return true

        val cal = Calendar.getInstance(TR_TIMEZONE).apply { timeInMillis = nowMillis }
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)
        val hour = cal.get(Calendar.HOUR_OF_DAY)

        // Thursday after 15:00 TRT (Diyanet uploads the upcoming Friday Hutbe) & all day Friday:
        // check every 90 minutes to catch new uploads or corrections right away.
        val isHutbeWindow = (dayOfWeek == Calendar.THURSDAY && hour >= 15) || dayOfWeek == Calendar.FRIDAY
        if (isHutbeWindow && ageMs > 90 * 60 * 1000L) return true

        // Otherwise refresh at least once every 12 hours
        return ageMs > 12 * 60 * 60 * 1000L
    }

    suspend fun syncLatestHutbes(forceRefresh: Boolean = false): Result<List<Hutbe>> = withContext(Dispatchers.IO) {
        val currentAvailable = getAvailableHutbes()
        if (!forceRefresh && !shouldAutoSync()) {
            return@withContext Result.success(currentAvailable)
        }
        if (!NetworkUtils.isNetworkAvailable(context)) {
            return@withContext Result.failure(IllegalStateException("İnternet bağlantısı yok"))
        }

        try {
            val homeHtml = fetchText(BASE_URL)
                ?: return@withContext Result.failure(IllegalStateException("Hutbe sayfasına ulaşılamadı"))

            val discoveredLinks = parseHutbeLinksFromHtml(homeHtml)
            if (discoveredLinks.isEmpty()) {
                return@withContext Result.failure(IllegalStateException("Güncel hutbe bağlantısı bulunamadı"))
            }

            val existingById = preferences.getCachedHutbes().associateBy { it.id }.toMutableMap()
            val targetLinks = discoveredLinks.take(MAX_ARCHIVED_HUTBES)
            var fetchedCount = 0

            for ((index, link) in targetLinks.withIndex()) {
                val id = "diyanet_${link.detayId}"
                val cachedItem = existingById[id]
                // Re-fetch top 1 (latest Friday) on forceRefresh to capture any Diyanet revisions;
                // otherwise only download entries missing complete text.
                val needsFetch = (forceRefresh && index == 0) ||
                    cachedItem == null ||
                    !cachedItem.isSyncedFromDiyanet ||
                    cachedItem.fullTextTr.isBlank() ||
                    cachedItem.arabicHeaderImageBase64.isBlank()

                if (!needsFetch) continue

                val fetched = fetchSingleHutbe(link)
                if (fetched != null) {
                    existingById[id] = fetched
                    fetchedCount++
                }
            }

            val merged = mergeHutbes(existingById.values.toList(), HutbeData.HUTBE_LIST)
                .sortedWith(
                    compareByDescending<Hutbe> { it.dateIso }
                        .thenByDescending { it.isSyncedFromDiyanet }
                )
                .take(12)

            if (fetchedCount > 0 || existingById.isNotEmpty()) {
                preferences.saveCachedHutbes(merged)
            } else {
                preferences.setLastHutbeSyncMillis(System.currentTimeMillis())
            }

            Result.success(merged)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun fetchSingleHutbe(link: DiyanetHutbeLink): Hutbe? {
        val detailHtml = fetchText(link.url) ?: return null
        val docs = parseDocumentLinksFromDetailHtml(detailHtml)
        val trUrl = docs.turkishDocUrl ?: return null

        val trBytes = fetchBytes(trUrl) ?: return null
        val trDoc = WordDocTextExtractor.extract(trBytes) ?: return null
        if (trDoc.fullBodyText.isBlank()) return null

        val cleanedTrBody = HutbeData.cleanHutbeBodyText(trDoc.fullBodyText)
        val arDoc = docs.arabicDocUrl?.let { arUrl ->
            fetchBytes(arUrl)?.let { bytes ->
                WordDocTextExtractor.extract(bytes)
            }
        }
        val arText = arDoc?.fullBodyText?.let { HutbeData.cleanHutbeBodyText(it) }.orEmpty()

        val headerImgBytes = trDoc.headerImageBytes ?: arDoc?.headerImageBytes
        val headerImageBase64 = if (headerImgBytes != null && headerImgBytes.isNotEmpty()) {
            try {
                android.util.Base64.encodeToString(headerImgBytes, android.util.Base64.NO_WRAP)
            } catch (_: Throwable) {
                // Fallback for pure JVM unit test environment where android.util.Base64 is unmocked
                java.util.Base64.getEncoder().encodeToString(headerImgBytes)
            }
        } else {
            ""
        }

        val cleanTitle = pickCleanTitle(docs.htmlTitle, trDoc.title)
        val formattedDate = formatDisplayDate(link.dateIso, trDoc.dateDisplay.ifBlank { link.dateTr })
        val cleanParagraphs = cleanedTrBody.split("\n\n").filter { it.isNotBlank() }
        val summary = cleanParagraphs
            .dropWhile { it.length < 30 }
            .firstOrNull()
            ?.take(220)
            ?.let { if (it.length == 220) "$it..." else it }
            ?: cleanParagraphs.firstOrNull().orEmpty()

        val openingQuote = extractOpeningArabicOrVerse(arText, cleanParagraphs)

        return Hutbe(
            id = "diyanet_${link.detayId}",
            date = formattedDate,
            titleTr = cleanTitle,
            titleKu = cleanTitle,
            source = OFFICIAL_SOURCE_LABEL,
            arabicVerseOrHadith = openingQuote,
            summaryTr = summary,
            summaryKu = summary,
            fullTextTr = cleanedTrBody,
            fullTextKu = cleanedTrBody,
            dateIso = link.dateIso,
            officialUrl = link.url,
            audioUrl = docs.audioUrl.orEmpty(),
            arabicFullText = arText,
            footnotes = "",
            isSyncedFromDiyanet = true,
            fetchedAtMillis = System.currentTimeMillis(),
            arabicHeaderImageBase64 = headerImageBase64
        )
    }

    private fun extractOpeningArabicOrVerse(arabicDocText: String, paragraphs: List<String>): String {
        if (arabicDocText.isNotBlank()) {
            // Pull quoted Quranic verse / prophetic Hadith from the Arabic sermon text as accessible text fallback
            val quotedRegex = Regex("""\"([^\"]{12,260})\"""")
            val quoted = quotedRegex.findAll(arabicDocText)
                .map { it.groupValues[1].trim() }
                .filter { it.any { c -> c.code in 0x0600..0x06FF } }
                .take(2)
                .toList()
            if (quoted.isNotEmpty()) {
                return buildString {
                    append("بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ")
                    quoted.forEach { q ->
                        append("\n").append(q)
                    }
                }
            }
        }
        return "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحِيمِ"
    }

    private fun pickCleanTitle(htmlHeading: String, docHeading: String): String {
        val fromHtml = htmlHeading
            .replace(Regex("^\\d{2}\\.\\d{2}\\.\\d{4}\\s+Cuma\\s+Hutbesi\\s*:\\s*", RegexOption.IGNORE_CASE), "")
            .replace(Regex("\\s*\\(Sesli Hutbe.*\\)\\s*$", RegexOption.IGNORE_CASE), "")
            .trim()
        if (fromHtml.isNotBlank() && !fromHtml.contains("Din Hizmetleri", ignoreCase = true)) {
            return fromHtml
        }
        return docHeading.ifBlank { "Cuma Hutbesi" }
    }

    private fun mergeHutbes(primary: List<Hutbe>, fallback: List<Hutbe>): List<Hutbe> {
        val byDateOrId = LinkedHashMap<String, Hutbe>()
        for (item in primary) {
            val key = item.dateIso.ifBlank { item.id }
            byDateOrId[key] = item
        }
        for (item in fallback) {
            val key = item.dateIso.ifBlank { item.id }
            if (!byDateOrId.containsKey(key)) {
                byDateOrId[key] = item
            }
        }
        return byDateOrId.values.toList()
    }

    private fun fetchText(rawUrl: String): String? {
        val bytes = fetchBytes(rawUrl) ?: return null
        return String(bytes, Charsets.UTF_8)
    }

    private fun fetchBytes(rawUrl: String): ByteArray? {
        val safeUrl = encodeDiyanetUrl(rawUrl) ?: return null
        val req = Request.Builder()
            .url(safeUrl)
            .header("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/120.0.0.0 Mobile Safari/537.36")
            .header("Accept", "text/html,application/msword,application/vnd.openxmlformats-officedocument.wordprocessingml.document,*/*")
            .build()
        httpClient.newCall(req).execute().use { resp ->
            if (!resp.isSuccessful) return null
            return resp.body?.bytes()
        }
    }

    companion object {
        const val BASE_URL = "https://dinhizmetleri.diyanet.gov.tr/"
        const val OFFICIAL_SOURCE_LABEL = "T.C. Diyanet İşleri Başkanlığı (dinhizmetleri.diyanet.gov.tr)"
        private const val MAX_ARCHIVED_HUTBES = 6

        private val TR_TIMEZONE: TimeZone = TimeZone.getTimeZone("Europe/Istanbul")

        private val DETAY_LINK_REGEX = Regex(
            """href=["']((?:https?://dinhizmetleri\.diyanet\.gov\.tr)?/Detay/(\d+)/([^"'>]+))["']""",
            RegexOption.IGNORE_CASE
        )
        private val DATE_SLUG_REGEX = Regex("""^(\d{2})(\d{2})(\d{4})-(.+)$""")
        private val DOCUMENT_LINK_REGEX = Regex(
            """href=["']((?:https?://dinhizmetleri\.diyanet\.gov\.tr)?/Documents/[^"'>]+)["']""",
            RegexOption.IGNORE_CASE
        )
        private val PAGE_TITLE_REGEX = Regex("""<title>\s*(.*?)\s*</title>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        private val H1_TITLE_REGEX = Regex("""<h1[^>]*>\s*(.*?)\s*</h1>""", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))

        fun computeMostRecentFridayIso(nowMillis: Long = System.currentTimeMillis()): String {
            val cal = Calendar.getInstance(TR_TIMEZONE).apply { timeInMillis = nowMillis }
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            // Days back to reach most recent Friday (Friday -> 0, Saturday -> 1, ..., Thursday -> 6)
            val daysSinceFriday = (dow - Calendar.FRIDAY + 7) % 7
            cal.add(Calendar.DAY_OF_YEAR, -daysSinceFriday)
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply {
                timeZone = TR_TIMEZONE
            }
            return sdf.format(cal.time)
        }

        fun parseHutbeLinksFromHtml(html: String): List<DiyanetHutbeLink> {
            val byId = LinkedHashMap<Int, DiyanetHutbeLink>()
            for (match in DETAY_LINK_REGEX.findAll(html)) {
                val rawHref = decodeHtmlEntities(match.groupValues[1])
                val id = match.groupValues[2].toIntOrNull() ?: continue
                val rawSlug = decodeHtmlEntities(match.groupValues[3])
                val slugLower = rawSlug.lowercase(Locale("tr"))

                if (!slugLower.contains("cuma-hutbesi") && !slugLower.contains("hutbe")) continue
                if (byId.containsKey(id)) continue

                val dateMatch = DATE_SLUG_REGEX.find(rawSlug)
                val dateIso: String
                val dateTr: String
                if (dateMatch != null) {
                    val dd = dateMatch.groupValues[1]
                    val mm = dateMatch.groupValues[2]
                    val yyyy = dateMatch.groupValues[3]
                    dateIso = "$yyyy-$mm-$dd"
                    dateTr = "$dd.$mm.$yyyy"
                } else if (slugLower.contains("cuma-hutbesi")) {
                    dateIso = ""
                    dateTr = ""
                } else {
                    continue
                }

                val fullUrl = if (rawHref.startsWith("http", ignoreCase = true)) {
                    rawHref
                } else {
                    "https://dinhizmetleri.diyanet.gov.tr$rawHref"
                }

                byId[id] = DiyanetHutbeLink(
                    detayId = id,
                    url = fullUrl,
                    dateIso = dateIso,
                    dateTr = dateTr,
                    isBayram = slugLower.contains("bayram")
                )
            }

            return byId.values.sortedWith(
                compareByDescending<DiyanetHutbeLink> { it.dateIso }
                    .thenByDescending { it.detayId }
            )
        }

        fun parseDocumentLinksFromDetailHtml(html: String): DiyanetDetayDocs {
            // Focus on main article section when present to skip global footer reports
            val contentSection = html.substringBefore("class=\"footer").ifBlank { html }

            val h1Raw = H1_TITLE_REGEX.find(contentSection)?.groupValues?.get(1).orEmpty()
            val titleTagRaw = PAGE_TITLE_REGEX.find(html)?.groupValues?.get(1).orEmpty()
            val rawHeading = decodeHtmlEntities(
                stripTags(h1Raw.ifBlank { titleTagRaw })
            ).substringBefore(" - ").trim()

            val seenUrls = LinkedHashSet<String>()
            for (match in DOCUMENT_LINK_REGEX.findAll(contentSection)) {
                val rawHref = decodeHtmlEntities(match.groupValues[1]).trim()
                val full = if (rawHref.startsWith("http", ignoreCase = true)) {
                    rawHref
                } else {
                    "https://dinhizmetleri.diyanet.gov.tr$rawHref"
                }
                seenUrls.add(full)
            }

            val audioUrl = seenUrls.firstOrNull {
                it.endsWith(".mp3", ignoreCase = true)
            }

            val wordDocs = seenUrls.filter {
                val lower = it.lowercase(Locale.ROOT)
                lower.endsWith(".doc") || lower.endsWith(".docx")
            }

            // First non-Arabic .doc/.docx on Diyanet Detay pages is always Turkish;
            // the Arabic .doc/.docx contains Arabic Unicode script characters.
            val turkishDocUrl = wordDocs.firstOrNull { !containsArabicScript(it) }
            val arabicDocUrl = wordDocs.firstOrNull { containsArabicScript(it) }

            return DiyanetDetayDocs(
                htmlTitle = rawHeading,
                turkishDocUrl = turkishDocUrl,
                arabicDocUrl = arabicDocUrl,
                audioUrl = audioUrl
            )
        }

        fun encodeDiyanetUrl(rawUrl: String): String? {
            val cleaned = decodeHtmlEntitiesExact(rawUrl.trim())
            val parsed = cleaned.toHttpUrlOrNull() ?: return null
            val segments = parsed.pathSegments.filter { it.isNotEmpty() }
            val builder = parsed.newBuilder().encodedPath("/")
            for (seg in segments) {
                builder.addPathSegment(seg)
            }
            return builder.build().toString()
        }

        fun formatDisplayDate(dateIso: String, fallbackDisplay: String): String {
            if (dateIso.isBlank()) return fallbackDisplay.ifBlank { "Cuma Hutbesi" }
            return try {
                val parser = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                val formatter = SimpleDateFormat("dd MMMM yyyy", Locale("tr"))
                val parsed = parser.parse(dateIso) ?: return fallbackDisplay
                "Cuma, ${formatter.format(parsed)}"
            } catch (_: Exception) {
                fallbackDisplay.ifBlank { dateIso }
            }
        }

        private fun containsArabicScript(text: String): Boolean {
            return text.any { ch -> ch.code in 0x0600..0x06FF }
        }

        private fun stripTags(input: String): String {
            return input.replace(Regex("<[^>]+>"), " ").replace(Regex("\\s+"), " ").trim()
        }

        private fun decodeHtmlEntities(input: String): String {
            return try {
                Html.fromHtml(input, Html.FROM_HTML_MODE_LEGACY).toString()
            } catch (_: Throwable) {
                decodeHtmlEntitiesExact(input)
            }
        }

        private fun decodeHtmlEntitiesExact(input: String): String {
            var out = input
                .replace("&amp;", "&")
                .replace("&quot;", "\"")
                .replace("&#39;", "'")
                .replace("&apos;", "'")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&nbsp;", " ")
            out = Regex("&#(\\d+);").replace(out) { m ->
                val code = m.groupValues[1].toIntOrNull()
                if (code != null && code in 32..0x10FFFF) {
                    String(Character.toChars(code))
                } else {
                    m.value
                }
            }
            out = Regex("&#x([0-9a-fA-F]+);").replace(out) { m ->
                val code = m.groupValues[1].toIntOrNull(16)
                if (code != null && code in 32..0x10FFFF) {
                    String(Character.toChars(code))
                } else {
                    m.value
                }
            }
            return out
        }
    }
}
