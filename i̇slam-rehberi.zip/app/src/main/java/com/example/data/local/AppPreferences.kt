package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONObject

class AppPreferences(context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("islam_rehberi_prefs", Context.MODE_PRIVATE)

    private val _languageFlow = MutableStateFlow(getLanguage())
    val languageFlow: StateFlow<AppLanguage> = _languageFlow.asStateFlow()

    fun getLanguage(): AppLanguage {
        val code = prefs.getString(KEY_LANGUAGE, AppLanguage.TURKISH.code) ?: AppLanguage.TURKISH.code
        return AppLanguage.fromCode(code)
    }

    fun setLanguage(language: AppLanguage) {
        prefs.edit().putString(KEY_LANGUAGE, language.code).apply()
        _languageFlow.value = language
    }

    fun getSelectedCityId(): String {
        return prefs.getString(KEY_CITY_ID, "istanbul") ?: "istanbul"
    }

    fun setSelectedCityId(cityId: String) {
        prefs.edit().putString(KEY_CITY_ID, cityId).apply()
    }

    fun saveSelectedCity(city: City) {
        val json = JSONObject().apply {
            put("id", city.id)
            put("nameTr", city.nameTr)
            put("nameKu", city.nameKu)
            put("country", city.country)
            put("latitude", city.latitude)
            put("longitude", city.longitude)
            put("isGps", city.isGps)
            put("provinceTr", city.provinceTr)
            put("provinceKu", city.provinceKu)
            put("isDistrict", city.isDistrict)
        }
        prefs.edit()
            .putString(KEY_CITY_ID, city.id)
            .putString(KEY_SELECTED_CITY_JSON, json.toString())
            .apply()
    }

    fun getSelectedCity(): City {
        val raw = prefs.getString(KEY_SELECTED_CITY_JSON, null)
        if (!raw.isNullOrBlank()) {
            try {
                val json = JSONObject(raw)
                return City(
                    id = json.optString("id", "istanbul"),
                    nameTr = json.optString("nameTr", "İstanbul"),
                    nameKu = json.optString("nameKu", "Stembol"),
                    country = json.optString("country", "Türkiye"),
                    latitude = json.optDouble("latitude", 41.0082),
                    longitude = json.optDouble("longitude", 28.9784),
                    isGps = json.optBoolean("isGps", false),
                    provinceTr = json.optString("provinceTr", ""),
                    provinceKu = json.optString("provinceKu", ""),
                    isDistrict = json.optBoolean("isDistrict", false)
                )
            } catch (_: Exception) {
            }
        }
        val savedId = getSelectedCityId()
        return City.DEFAULT_CITIES.find { it.id == savedId }
            ?: com.example.data.local.WorldDistrictsData.ALL_DISTRICTS.find { it.id == savedId }
            ?: City.DEFAULT_CITIES[2]
    }

    fun getLastLatitude(): Double {
        return prefs.getString(KEY_LAT, "41.0082")?.toDoubleOrNull() ?: 41.0082
    }

    fun getLastLongitude(): Double {
        return prefs.getString(KEY_LNG, "28.9784")?.toDoubleOrNull() ?: 28.9784
    }

    fun setLastCoordinates(lat: Double, lng: Double) {
        prefs.edit()
            .putString(KEY_LAT, lat.toString())
            .putString(KEY_LNG, lng.toString())
            .apply()
    }

    fun isAdhanEnabled(prayerType: PrayerType): Boolean {
        if (!prayerType.hasAdhan) return false
        val key = "adhan_enabled_${prayerType.key}"
        return prefs.getBoolean(key, prayerType.defaultAdhanEnabled)
    }

    fun setAdhanEnabled(prayerType: PrayerType, enabled: Boolean) {
        val key = "adhan_enabled_${prayerType.key}"
        prefs.edit().putBoolean(key, enabled).apply()
    }

    fun getQuranFontSize(): Float {
        if (!prefs.getBoolean(KEY_QURAN_LARGE_FONT_MIGRATED_V5, false)) {
            val existing = prefs.getFloat(KEY_QURAN_FONT_SIZE, 58f)
            val upgraded = if (existing < 58f) 58f else existing.coerceIn(32f, 92f)
            prefs.edit()
                .putFloat(KEY_QURAN_FONT_SIZE, upgraded)
                .putBoolean(KEY_QURAN_LARGE_FONT_MIGRATED_V5, true)
                .apply()
            return upgraded
        }
        return prefs.getFloat(KEY_QURAN_FONT_SIZE, 58f).coerceIn(32f, 92f)
    }

    fun setQuranFontSize(size: Float) {
        prefs.edit()
            .putFloat(KEY_QURAN_FONT_SIZE, size.coerceIn(32f, 92f))
            .putBoolean(KEY_QURAN_LARGE_FONT_MIGRATED_V5, true)
            .apply()
    }

    fun getQuranTranslationMode(): String {
        if (!prefs.getBoolean(KEY_SEPARATE_QURAN_LANG_MIGRATED_V1, false)) {
            prefs.edit()
                .putString(KEY_QURAN_TRANS_MODE, "AR")
                .putBoolean(KEY_SEPARATE_QURAN_LANG_MIGRATED_V1, true)
                .apply()
            return "AR"
        }
        val saved = prefs.getString(KEY_QURAN_TRANS_MODE, "AR") ?: "AR"
        return if (saved in VALID_QURAN_MODES) saved else "AR"
    }

    fun setQuranTranslationMode(mode: String) {
        val normalized = if (mode in VALID_QURAN_MODES) mode else "AR"
        prefs.edit()
            .putString(KEY_QURAN_TRANS_MODE, normalized)
            .putBoolean(KEY_SEPARATE_QURAN_LANG_MIGRATED_V1, true)
            .apply()
    }

    fun isQuranRtlMode(): Boolean {
        return prefs.getBoolean(KEY_QURAN_RTL_MODE, true) // Default: Sağdan Sola (RTL) Kur'an-ı Kerim yönü
    }

    fun setQuranRtlMode(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_QURAN_RTL_MODE, enabled).apply()
    }

    fun isElifbaRtlMode(): Boolean {
        if (!prefs.getBoolean(KEY_ELIFBA_RTL_MIGRATED_V1, false)) {
            prefs.edit()
                .putBoolean(KEY_ELIFBA_RTL_MODE, true)
                .putBoolean(KEY_ELIFBA_RTL_MIGRATED_V1, true)
                .apply()
            return true
        }
        return prefs.getBoolean(KEY_ELIFBA_RTL_MODE, true) // Default: Sağdan Sola (RTL) Elifba yönü
    }

    fun setElifbaRtlMode(enabled: Boolean) {
        prefs.edit()
            .putBoolean(KEY_ELIFBA_RTL_MODE, enabled)
            .putBoolean(KEY_ELIFBA_RTL_MIGRATED_V1, true)
            .apply()
    }

    // Offline Prayer Times Caching
    fun saveCachedPrayerTimes(times: PrayerTimes) {
        val json = JSONObject().apply {
            put("fajr", times.fajr)
            put("sunrise", times.sunrise)
            put("dhuhr", times.dhuhr)
            put("asr", times.asr)
            put("maghrib", times.maghrib)
            put("isha", times.isha)
            put("dateReadable", times.dateReadable)
            put("hijriDate", times.hijriDate)
            put("calculationMethod", times.calculationMethod)
            put("cityName", times.cityName)
            put("latitude", times.latitude)
            put("longitude", times.longitude)
            put("timezone", times.timezone)
            put("dateIso", times.dateIso)
        }
        prefs.edit().putString(KEY_CACHED_TIMINGS, json.toString()).apply()
    }

    fun getCachedPrayerTimes(): PrayerTimes? {
        val raw = prefs.getString(KEY_CACHED_TIMINGS, null) ?: return null
        return try {
            val json = JSONObject(raw)
            PrayerTimes(
                fajr = json.optString("fajr", "05:30"),
                sunrise = json.optString("sunrise", "07:00"),
                dhuhr = json.optString("dhuhr", "12:50"),
                asr = json.optString("asr", "15:45"),
                maghrib = json.optString("maghrib", "18:15"),
                isha = json.optString("isha", "19:40"),
                dateReadable = json.optString("dateReadable", ""),
                hijriDate = json.optString("hijriDate", ""),
                calculationMethod = json.optString("calculationMethod", "Standart Astronomik Güneş Açısı (Fecr 18°, Yatsı 17°)"),
                isOffline = true,
                cityName = json.optString("cityName", "İstanbul"),
                latitude = json.optDouble("latitude", 41.0082),
                longitude = json.optDouble("longitude", 28.9784),
                timezone = json.optString("timezone", ""),
                dateIso = json.optString("dateIso", "")
            )
        } catch (e: Exception) {
            null
        }
    }

    fun saveCachedWeather(weather: com.example.data.model.WeatherInfo) {
        val hourlyArr = org.json.JSONArray()
        weather.hourlyForecast.forEach { h ->
            hourlyArr.put(JSONObject().apply {
                put("hourLabel", h.hourLabel)
                put("temperatureC", h.temperatureC)
                put("weatherCode", h.weatherCode)
                put("isDay", h.isDay)
            })
        }
        val dailyArr = org.json.JSONArray()
        weather.dailyForecast.forEach { d ->
            dailyArr.put(JSONObject().apply {
                put("dateIso", d.dateIso)
                put("weatherCode", d.weatherCode)
                put("minTempC", d.minTempC)
                put("maxTempC", d.maxTempC)
                put("precipProb", d.precipitationChancePercent)
            })
        }
        val json = JSONObject().apply {
            put("locationName", weather.locationName)
            put("temperatureC", weather.temperatureC)
            put("apparentTemperatureC", weather.apparentTemperatureC)
            put("humidityPercent", weather.humidityPercent)
            put("windSpeedKmh", weather.windSpeedKmh)
            put("weatherCode", weather.weatherCode)
            put("isDay", weather.isDay)
            put("minTempC", weather.minTempC)
            put("maxTempC", weather.maxTempC)
            put("latitude", weather.latitude)
            put("longitude", weather.longitude)
            put("updatedAtMillis", weather.updatedAtMillis)
            put("timezoneId", weather.timezoneId)
            put("observationTimeLabel", weather.observationTimeLabel)
            put("hourly", hourlyArr)
            put("daily", dailyArr)
        }
        prefs.edit().putString(KEY_CACHED_WEATHER, json.toString()).apply()
    }

    fun getCachedWeather(): com.example.data.model.WeatherInfo? {
        val raw = prefs.getString(KEY_CACHED_WEATHER, null) ?: return null
        return try {
            val json = JSONObject(raw)
            val hourlyList = mutableListOf<com.example.data.model.HourlyForecastPoint>()
            val hourlyArr = json.optJSONArray("hourly")
            if (hourlyArr != null) {
                for (i in 0 until hourlyArr.length()) {
                    val obj = hourlyArr.optJSONObject(i) ?: continue
                    hourlyList.add(
                        com.example.data.model.HourlyForecastPoint(
                            hourLabel = obj.optString("hourLabel", ""),
                            temperatureC = obj.optDouble("temperatureC", 0.0),
                            weatherCode = obj.optInt("weatherCode", 0),
                            isDay = obj.optBoolean("isDay", true)
                        )
                    )
                }
            }
            val dailyList = mutableListOf<com.example.data.model.DailyForecastDay>()
            val dailyArr = json.optJSONArray("daily")
            if (dailyArr != null) {
                for (i in 0 until dailyArr.length()) {
                    val obj = dailyArr.optJSONObject(i) ?: continue
                    dailyList.add(
                        com.example.data.model.DailyForecastDay(
                            dateIso = obj.optString("dateIso", ""),
                            weatherCode = obj.optInt("weatherCode", 0),
                            minTempC = obj.optDouble("minTempC", 0.0),
                            maxTempC = obj.optDouble("maxTempC", 0.0),
                            precipitationChancePercent = obj.optInt("precipProb", 0)
                        )
                    )
                }
            }
            com.example.data.model.WeatherInfo(
                locationName = json.optString("locationName", ""),
                temperatureC = json.optDouble("temperatureC", 0.0),
                apparentTemperatureC = json.optDouble("apparentTemperatureC", 0.0),
                humidityPercent = json.optInt("humidityPercent", 0),
                windSpeedKmh = json.optDouble("windSpeedKmh", 0.0),
                weatherCode = json.optInt("weatherCode", 0),
                isDay = json.optBoolean("isDay", true),
                minTempC = json.optDouble("minTempC", 0.0),
                maxTempC = json.optDouble("maxTempC", 0.0),
                hourlyForecast = hourlyList,
                dailyForecast = dailyList,
                latitude = json.optDouble("latitude", 0.0),
                longitude = json.optDouble("longitude", 0.0),
                updatedAtMillis = json.optLong("updatedAtMillis", System.currentTimeMillis()),
                isOfflineCache = true,
                timezoneId = json.optString("timezoneId", ""),
                observationTimeLabel = json.optString("observationTimeLabel", "")
            )
        } catch (_: Exception) {
            null
        }
    }

    // Friday and Religious Days Reminders
    fun isFridayReminderEnabled(): Boolean {
        return prefs.getBoolean(KEY_FRIDAY_REMINDER, true)
    }

    fun setFridayReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_FRIDAY_REMINDER, enabled).apply()
    }

    fun isReligiousDaysReminderEnabled(): Boolean {
        return prefs.getBoolean(KEY_RELIGIOUS_DAYS_REMINDER, true)
    }

    fun setReligiousDaysReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_RELIGIOUS_DAYS_REMINDER, enabled).apply()
    }

    fun isPrayerBarNotificationEnabled(): Boolean {
        return prefs.getBoolean(KEY_PRAYER_BAR_NOTIFICATION, true)
    }

    fun setPrayerBarNotificationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PRAYER_BAR_NOTIFICATION, enabled).apply()
    }

    fun getLastElifbaPage(): Int {
        return prefs.getInt(KEY_LAST_ELIFBA_PAGE, 1).coerceIn(1, 60)
    }

    fun setLastElifbaPage(page: Int) {
        prefs.edit().putInt(KEY_LAST_ELIFBA_PAGE, page.coerceIn(1, 60)).apply()
    }

    fun getAppTheme(): com.example.data.model.AppTheme {
        val id = prefs.getString(KEY_APP_THEME, com.example.data.model.AppTheme.EMERALD_GOLD.id)
            ?: com.example.data.model.AppTheme.EMERALD_GOLD.id
        return com.example.data.model.AppTheme.entries.find { it.id == id }
            ?: com.example.data.model.AppTheme.EMERALD_GOLD
    }

    fun setAppTheme(theme: com.example.data.model.AppTheme) {
        prefs.edit().putString(KEY_APP_THEME, theme.id).apply()
    }

    // Pre-Adhan 30 Minutes Approaching Reminder Preferences
    fun isPreAdhanReminderEnabled(): Boolean {
        return prefs.getBoolean(KEY_PRE_ADHAN_REMINDER, true)
    }

    fun setPreAdhanReminderEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_PRE_ADHAN_REMINDER, enabled).apply()
    }

    fun isPreAdhanForPrayer(prayerType: PrayerType): Boolean {
        if (!prayerType.hasAdhan) return false
        val key = "pre_adhan_enabled_${prayerType.key}"
        return prefs.getBoolean(key, true)
    }

    fun setPreAdhanForPrayer(prayerType: PrayerType, enabled: Boolean) {
        val key = "pre_adhan_enabled_${prayerType.key}"
        prefs.edit().putBoolean(key, enabled).apply()
    }

    // Official Diyanet Cuma Hutbesi Caching
    fun saveCachedHutbes(hutbes: List<com.example.data.model.Hutbe>) {
        val arr = org.json.JSONArray()
        hutbes.forEach { h ->
            arr.put(JSONObject().apply {
                put("id", h.id)
                put("date", h.date)
                put("titleTr", h.titleTr)
                put("titleKu", h.titleKu)
                put("source", h.source)
                put("arabicVerseOrHadith", h.arabicVerseOrHadith)
                put("summaryTr", h.summaryTr)
                put("summaryKu", h.summaryKu)
                put("fullTextTr", h.fullTextTr)
                put("fullTextKu", h.fullTextKu)
                put("dateIso", h.dateIso)
                put("officialUrl", h.officialUrl)
                put("audioUrl", h.audioUrl)
                put("arabicFullText", h.arabicFullText)
                put("footnotes", h.footnotes)
                put("isSyncedFromDiyanet", h.isSyncedFromDiyanet)
                put("fetchedAtMillis", h.fetchedAtMillis)
                put("arabicHeaderImageBase64", h.arabicHeaderImageBase64)
            })
        }
        prefs.edit()
            .putString(KEY_CACHED_HUTBES, arr.toString())
            .putLong(KEY_LAST_HUTBE_SYNC_MS, System.currentTimeMillis())
            .putBoolean(KEY_HUTBE_CACHE_VERSION_V2, true)
            .apply()
    }

    fun getCachedHutbes(): List<com.example.data.model.Hutbe> {
        if (!prefs.getBoolean(KEY_HUTBE_CACHE_VERSION_V2, false)) {
            prefs.edit()
                .remove(KEY_CACHED_HUTBES)
                .remove(KEY_LAST_HUTBE_SYNC_MS)
                .putBoolean(KEY_HUTBE_CACHE_VERSION_V2, true)
                .apply()
            return emptyList()
        }
        val raw = prefs.getString(KEY_CACHED_HUTBES, null) ?: return emptyList()
        return try {
            val arr = org.json.JSONArray(raw)
            val list = mutableListOf<com.example.data.model.Hutbe>()
            for (i in 0 until arr.length()) {
                val obj = arr.optJSONObject(i) ?: continue
                val fullTr = obj.optString("fullTextTr", "")
                if (fullTr.isBlank()) continue
                list.add(
                    com.example.data.model.Hutbe(
                        id = obj.optString("id", ""),
                        date = obj.optString("date", ""),
                        titleTr = obj.optString("titleTr", ""),
                        titleKu = obj.optString("titleKu", ""),
                        source = obj.optString("source", "T.C. Diyanet İşleri Başkanlığı (dinhizmetleri.diyanet.gov.tr)"),
                        arabicVerseOrHadith = obj.optString("arabicVerseOrHadith", ""),
                        summaryTr = obj.optString("summaryTr", ""),
                        summaryKu = obj.optString("summaryKu", ""),
                        fullTextTr = fullTr,
                        fullTextKu = obj.optString("fullTextKu", fullTr),
                        dateIso = obj.optString("dateIso", ""),
                        officialUrl = obj.optString("officialUrl", ""),
                        audioUrl = obj.optString("audioUrl", ""),
                        arabicFullText = obj.optString("arabicFullText", ""),
                        footnotes = obj.optString("footnotes", ""),
                        isSyncedFromDiyanet = obj.optBoolean("isSyncedFromDiyanet", true),
                        fetchedAtMillis = obj.optLong("fetchedAtMillis", 0L),
                        arabicHeaderImageBase64 = obj.optString("arabicHeaderImageBase64", "")
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getLastHutbeSyncMillis(): Long {
        return prefs.getLong(KEY_LAST_HUTBE_SYNC_MS, 0L)
    }

    fun setLastHutbeSyncMillis(millis: Long) {
        prefs.edit().putLong(KEY_LAST_HUTBE_SYNC_MS, millis).apply()
    }

    // Tesbihat & Zikirmatik Preferences
    fun getTesbihatStepIndex(): Int =
        prefs.getInt(KEY_TESBIHAT_STEP_INDEX, 0).coerceAtLeast(0)

    fun setTesbihatStepIndex(index: Int) {
        prefs.edit().putInt(KEY_TESBIHAT_STEP_INDEX, index.coerceAtLeast(0)).apply()
    }

    fun getTesbihatStepCount(): Int =
        prefs.getInt(KEY_TESBIHAT_STEP_COUNT, 0).coerceAtLeast(0)

    fun setTesbihatStepCount(count: Int) {
        prefs.edit().putInt(KEY_TESBIHAT_STEP_COUNT, count.coerceAtLeast(0)).apply()
    }

    fun getTesbihatCompletedRounds(): Int =
        prefs.getInt(KEY_TESBIHAT_COMPLETED_ROUNDS, 0).coerceAtLeast(0)

    fun incrementTesbihatCompletedRounds(): Int {
        val next = getTesbihatCompletedRounds() + 1
        prefs.edit().putInt(KEY_TESBIHAT_COMPLETED_ROUNDS, next).apply()
        return next
    }

    fun getZikirSelectedId(): String =
        prefs.getString(KEY_ZIKIR_SELECTED_ID, "subhanallah") ?: "subhanallah"

    fun setZikirSelectedId(id: String) {
        prefs.edit().putString(KEY_ZIKIR_SELECTED_ID, id).apply()
    }

    fun getZikirCurrentCount(): Int =
        prefs.getInt(KEY_ZIKIR_CURRENT_COUNT, 0).coerceAtLeast(0)

    fun setZikirCurrentCount(count: Int) {
        prefs.edit().putInt(KEY_ZIKIR_CURRENT_COUNT, count.coerceAtLeast(0)).apply()
    }

    fun getZikirTarget(): Int =
        prefs.getInt(KEY_ZIKIR_TARGET, 33).coerceAtLeast(0)

    fun setZikirTarget(target: Int) {
        prefs.edit().putInt(KEY_ZIKIR_TARGET, target.coerceAtLeast(0)).apply()
    }

    fun getCustomZikirTitle(): String =
        prefs.getString(KEY_ZIKIR_CUSTOM_TITLE, "") ?: ""

    fun setCustomZikirTitle(title: String) {
        prefs.edit().putString(KEY_ZIKIR_CUSTOM_TITLE, title.trim()).apply()
    }

    fun isTesbihatVibrationEnabled(): Boolean =
        prefs.getBoolean(KEY_TESBIHAT_VIBRATION, true)

    fun setTesbihatVibrationEnabled(enabled: Boolean) {
        prefs.edit().putBoolean(KEY_TESBIHAT_VIBRATION, enabled).apply()
    }

    private fun todayDateKey(): String {
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
    }

    fun getTesbihatDailyTotal(): Int {
        val today = todayDateKey()
        val storedDate = prefs.getString(KEY_TESBIHAT_DAILY_DATE, "")
        return if (storedDate == today) prefs.getInt(KEY_TESBIHAT_DAILY_TOTAL, 0).coerceAtLeast(0) else 0
    }

    fun getTesbihatLifetimeTotal(): Long =
        prefs.getLong(KEY_TESBIHAT_LIFETIME_TOTAL, 0L).coerceAtLeast(0L)

    fun recordTesbihatTap(delta: Int): Pair<Int, Long> {
        val today = todayDateKey()
        val storedDate = prefs.getString(KEY_TESBIHAT_DAILY_DATE, "")
        val currentDaily = if (storedDate == today) prefs.getInt(KEY_TESBIHAT_DAILY_TOTAL, 0) else 0
        val newDaily = (currentDaily + delta).coerceAtLeast(0)
        val newLifetime = (getTesbihatLifetimeTotal() + delta).coerceAtLeast(0L)
        prefs.edit()
            .putString(KEY_TESBIHAT_DAILY_DATE, today)
            .putInt(KEY_TESBIHAT_DAILY_TOTAL, newDaily)
            .putLong(KEY_TESBIHAT_LIFETIME_TOTAL, newLifetime)
            .apply()
        return newDaily to newLifetime
    }

    companion object {
        private const val KEY_LANGUAGE = "key_app_language"
        private const val KEY_CITY_ID = "key_selected_city_id"
        private const val KEY_LAT = "key_last_lat"
        private const val KEY_LNG = "key_last_lng"
        private const val KEY_QURAN_FONT_SIZE = "key_quran_font_size"
        private const val KEY_QURAN_TRANS_MODE = "key_quran_trans_mode"
        private const val KEY_CACHED_TIMINGS = "key_cached_timings"
        private const val KEY_FRIDAY_REMINDER = "key_friday_reminder"
        private const val KEY_RELIGIOUS_DAYS_REMINDER = "key_religious_days_reminder"
        private const val KEY_PRAYER_BAR_NOTIFICATION = "key_prayer_bar_notification"
        private const val KEY_LAST_ELIFBA_PAGE = "key_last_elifba_page"
        private const val KEY_APP_THEME = "key_app_theme"
        private const val KEY_PRE_ADHAN_REMINDER = "key_pre_adhan_reminder"
        private const val KEY_QURAN_RTL_MODE = "key_quran_rtl_mode"
        private const val KEY_ELIFBA_RTL_MODE = "key_elifba_rtl_mode"
        private const val KEY_ELIFBA_RTL_MIGRATED_V1 = "key_elifba_rtl_migrated_v1"
        private const val KEY_SEPARATE_QURAN_LANG_MIGRATED_V1 = "key_separate_quran_lang_migrated_v1"
        private const val KEY_QURAN_LARGE_FONT_MIGRATED_V2 = "key_quran_large_font_migrated_v2"
        private const val KEY_QURAN_LARGE_FONT_MIGRATED_V3 = "key_quran_large_font_migrated_v3"
        private const val KEY_QURAN_LARGE_FONT_MIGRATED_V4 = "key_quran_large_font_migrated_v4"
        private const val KEY_QURAN_LARGE_FONT_MIGRATED_V5 = "key_quran_large_font_migrated_v5"
        private val VALID_QURAN_MODES = setOf("AR", "KU", "TR")
        private const val KEY_SELECTED_CITY_JSON = "key_selected_city_json_v1"
        private const val KEY_CACHED_WEATHER = "key_cached_weather_v1"
        private const val KEY_CACHED_HUTBES = "key_cached_hutbes_v1"
        private const val KEY_LAST_HUTBE_SYNC_MS = "key_last_hutbe_sync_ms_v1"
        private const val KEY_HUTBE_CACHE_VERSION_V2 = "key_hutbe_cache_version_v2"
        private const val KEY_TESBIHAT_STEP_INDEX = "key_tesbihat_step_index_v1"
        private const val KEY_TESBIHAT_STEP_COUNT = "key_tesbihat_step_count_v1"
        private const val KEY_TESBIHAT_COMPLETED_ROUNDS = "key_tesbihat_completed_rounds_v1"
        private const val KEY_ZIKIR_SELECTED_ID = "key_zikir_selected_id_v1"
        private const val KEY_ZIKIR_CURRENT_COUNT = "key_zikir_current_count_v1"
        private const val KEY_ZIKIR_TARGET = "key_zikir_target_v1"
        private const val KEY_ZIKIR_CUSTOM_TITLE = "key_zikir_custom_title_v1"
        private const val KEY_TESBIHAT_VIBRATION = "key_tesbihat_vibration_v1"
        private const val KEY_TESBIHAT_DAILY_DATE = "key_tesbihat_daily_date_v1"
        private const val KEY_TESBIHAT_DAILY_TOTAL = "key_tesbihat_daily_total_v1"
        private const val KEY_TESBIHAT_LIFETIME_TOTAL = "key_tesbihat_lifetime_total_v1"
    }
}
