package com.example

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import com.example.data.model.AppLanguage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import com.example.ui.components.AppBottomNavBar
import com.example.ui.components.NavScreen
import com.example.ui.screens.ElifbaScreen
import com.example.ui.screens.EsmaUlHusnaScreen
import com.example.ui.screens.HutbeScreen
import com.example.ui.screens.PrayerScreen
import com.example.ui.screens.QiblaScreen
import com.example.ui.screens.QuranScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.screens.TesbihatScreen
import com.example.ui.theme.IslamRehberiTheme
import com.example.ui.viewmodel.ElifbaViewModel
import com.example.ui.viewmodel.PrayerViewModel
import com.example.ui.viewmodel.QiblaViewModel
import com.example.ui.viewmodel.QuranViewModel
import com.example.ui.viewmodel.SettingsViewModel
import com.google.android.gms.location.LocationServices

class MainActivity : ComponentActivity() {

    private val prayerViewModel: PrayerViewModel by viewModels()
    private val qiblaViewModel: QiblaViewModel by viewModels()
    private val quranViewModel: QuranViewModel by viewModels()
    private val elifbaViewModel: ElifbaViewModel by viewModels()
    private val settingsViewModel: SettingsViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Ensure volume rocker buttons control media volume (STREAM_MUSIC), not ringtone/alarm
        volumeControlStream = android.media.AudioManager.STREAM_MUSIC
        enableEdgeToEdge()

        setContent {
            val settingsUiState by settingsViewModel.uiState.collectAsState()
            val language = settingsUiState.language

            var currentScreen by remember { mutableStateOf<NavScreen>(NavScreen.Prayer) }
            var isQuranFullScreen by remember { mutableStateOf(false) }

            LaunchedEffect(currentScreen) {
                if (currentScreen != NavScreen.Quran && isQuranFullScreen) {
                    isQuranFullScreen = false
                }
            }

            // Location permission launcher
            val locationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestMultiplePermissions()
            ) { permissions ->
                val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
                val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
                if (fineGranted || coarseGranted) {
                    fetchCurrentGpsLocation()
                }
            }

            // Notification permission launcher for Android 13+
            val notificationPermissionLauncher = rememberLauncherForActivityResult(
                contract = ActivityResultContracts.RequestPermission()
            ) { granted ->
                if (granted) {
                    val pState = prayerViewModel.uiState.value
                    com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                        this@MainActivity,
                        pState.prayerTimes,
                        pState.selectedCity,
                        settingsViewModel.uiState.value.language
                    )
                }
                settingsViewModel.refreshPermissions()
            }

            LaunchedEffect(Unit) {
                // Ensure the upgraded max-loudness pre-Adhan notification channel is created for every user
                com.example.notification.PrayerNotificationManager.ensurePreAdhanChannel(this@MainActivity)

                // Request Notification Permission on Android 13+ for Adhan alarms and persistent prayer notification
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                    if (ContextCompat.checkSelfPermission(
                            this@MainActivity,
                            Manifest.permission.POST_NOTIFICATIONS
                        ) != PackageManager.PERMISSION_GRANTED
                    ) {
                        notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                    }
                }

                // Schedule Friday reminders and Religious Days notifications
                val eventScheduler = com.example.alarm.EventNotificationScheduler(
                    this@MainActivity,
                    prayerViewModel.preferences
                )
                eventScheduler.rescheduleAll()

                // Auto-refresh live GPS location & weather on launch if GPS mode is active and permitted
                if (prayerViewModel.uiState.value.isGpsActive) {
                    val fineOk = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_FINE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                    val coarseOk = ContextCompat.checkSelfPermission(
                        this@MainActivity,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    ) == PackageManager.PERMISSION_GRANTED
                    if (fineOk || coarseOk) {
                        fetchCurrentGpsLocation()
                    }
                }
            }

            val prayerUiState by prayerViewModel.uiState.collectAsState()

            LaunchedEffect(prayerUiState.prayerTimes, language) {
                val times = prayerUiState.prayerTimes
                if (times != null) {
                    com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                        this@MainActivity,
                        times,
                        prayerUiState.selectedCity,
                        language
                    )
                }
            }

            // Back button handling: exit Quran full-screen first, then return to Prayer screen
            BackHandler(enabled = currentScreen != NavScreen.Prayer) {
                if (currentScreen == NavScreen.Quran && isQuranFullScreen) {
                    isQuranFullScreen = false
                } else {
                    currentScreen = NavScreen.Prayer
                }
            }

            val isDarkTheme = androidx.compose.foundation.isSystemInDarkTheme()
            IslamRehberiTheme(appTheme = settingsUiState.appTheme, darkTheme = isDarkTheme) {
                val view = androidx.compose.ui.platform.LocalView.current
                if (!view.isInEditMode) {
                    SideEffect {
                        val window = (view.context as? android.app.Activity)?.window
                        if (window != null) {
                            val controller = androidx.core.view.WindowCompat.getInsetsController(window, view)
                            controller.isAppearanceLightStatusBars = !isDarkTheme
                            controller.isAppearanceLightNavigationBars = !isDarkTheme
                        }
                    }
                }
                Scaffold(
                    modifier = Modifier.fillMaxSize(),
                    containerColor = com.example.ui.theme.DarkBackground,
                    contentWindowInsets = WindowInsets.safeDrawing,
                    bottomBar = {
                        if (!(currentScreen == NavScreen.Quran && isQuranFullScreen)) {
                            AppBottomNavBar(
                                currentRoute = currentScreen.route,
                                language = language,
                                onNavigate = { screen ->
                                    currentScreen = screen
                                }
                            )
                        }
                    }
                ) { innerPadding ->
                    when (currentScreen) {
                        NavScreen.Prayer -> {
                            PrayerScreen(
                                state = prayerUiState,
                                language = language,
                                onSelectCity = { city ->
                                    prayerViewModel.selectCity(city)
                                    qiblaViewModel.refreshCoordinates()
                                },
                                onRequestGps = {
                                    requestGpsLocation {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                onToggleAdhan = { prayer, enabled ->
                                    prayerViewModel.toggleAdhan(prayer, enabled)
                                    settingsViewModel.toggleAdhan(prayer, enabled)
                                },
                                onRefresh = {
                                    prayerViewModel.refreshAll()
                                },
                                onOpenAlarmSettings = {
                                    settingsViewModel.openExactAlarmSettings(this@MainActivity)
                                },
                                preferences = prayerViewModel.preferences,
                                onNavigateToScreen = { screen ->
                                    currentScreen = screen
                                },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Qibla -> {
                            QiblaScreen(
                                viewModel = qiblaViewModel,
                                language = language,
                                onSelectCity = { city ->
                                    prayerViewModel.selectCity(city)
                                    qiblaViewModel.refreshCoordinates()
                                },
                                onRequestGps = {
                                    requestGpsLocation {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Quran -> {
                            QuranScreen(
                                viewModel = quranViewModel,
                                language = language,
                                isFullScreen = isQuranFullScreen,
                                onToggleFullScreen = { isQuranFullScreen = it },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Elifba -> {
                            ElifbaScreen(
                                viewModel = elifbaViewModel,
                                language = language,
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Hutbe -> {
                            HutbeScreen(
                                language = language,
                                onBack = { currentScreen = NavScreen.Prayer },
                                currentHutbe = prayerUiState.currentHutbe,
                                hutbeArchive = prayerUiState.hutbeArchive,
                                isLoading = prayerUiState.isHutbeLoading,
                                syncError = prayerUiState.hutbeSyncError,
                                lastUpdatedMillis = prayerUiState.hutbeLastUpdatedMillis,
                                isOnline = prayerUiState.isNetworkOnline,
                                onSelectHutbe = { selected ->
                                    prayerViewModel.selectHutbe(selected)
                                },
                                onRefreshHutbe = {
                                    prayerViewModel.syncWeeklyHutbe(forceRefresh = true)
                                },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Tesbihat -> {
                            TesbihatScreen(
                                language = language,
                                preferences = prayerViewModel.preferences,
                                onBack = { currentScreen = NavScreen.Prayer },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.EsmaUlHusna -> {
                            EsmaUlHusnaScreen(
                                language = language,
                                onBack = { currentScreen = NavScreen.Prayer },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }

                        NavScreen.Settings -> {
                            SettingsScreen(
                                viewModel = settingsViewModel,
                                selectedCity = prayerUiState.selectedCity,
                                onSelectCity = { city ->
                                    prayerViewModel.selectCity(city)
                                    qiblaViewModel.refreshCoordinates()
                                },
                                onRequestGps = {
                                    requestGpsLocation {
                                        locationPermissionLauncher.launch(
                                            arrayOf(
                                                Manifest.permission.ACCESS_FINE_LOCATION,
                                                Manifest.permission.ACCESS_COARSE_LOCATION
                                            )
                                        )
                                    }
                                },
                                modifier = Modifier.padding(innerPadding)
                            )
                        }
                    }
                }
            }
        }
    }

    private fun requestGpsLocation(onPermissionRequired: () -> Unit) {
        val fineGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
        val coarseGranted = ContextCompat.checkSelfPermission(
            this,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED

        if (fineGranted || coarseGranted) {
            fetchCurrentGpsLocation()
        } else {
            onPermissionRequired()
        }
    }

    @SuppressLint("MissingPermission")
    private fun fetchCurrentGpsLocation() {
        try {
            val fusedClient = LocationServices.getFusedLocationProviderClient(this)
            fusedClient.lastLocation
                .addOnSuccessListener { location ->
                    val twoMinutesMs = 2 * 60 * 1000L
                    val isFresh = location != null &&
                        (System.currentTimeMillis() - location.time) in 0..twoMinutesMs
                    if (location != null && (System.currentTimeMillis() - location.time) < 15 * 60 * 1000L) {
                        resolveAndSetGpsLocation(location.latitude, location.longitude)
                    }
                    if (!isFresh) {
                        fusedClient.getCurrentLocation(
                            com.google.android.gms.location.Priority.PRIORITY_HIGH_ACCURACY,
                            null
                        ).addOnSuccessListener { activeLoc ->
                            if (activeLoc != null) {
                                resolveAndSetGpsLocation(activeLoc.latitude, activeLoc.longitude)
                            } else if (location == null) {
                                fetchOfflineHardwareGpsLocation()
                            }
                        }.addOnFailureListener {
                            if (location == null) {
                                fetchOfflineHardwareGpsLocation()
                            }
                        }
                    }
                }
                .addOnFailureListener {
                    fetchOfflineHardwareGpsLocation()
                }
        } catch (_: Exception) {
            fetchOfflineHardwareGpsLocation()
        }
    }

    @SuppressLint("MissingPermission")
    @Suppress("DEPRECATION")
    private fun fetchOfflineHardwareGpsLocation() {
        try {
            val lm = getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return
            val providers = listOf(
                LocationManager.GPS_PROVIDER,
                LocationManager.NETWORK_PROVIDER,
                LocationManager.PASSIVE_PROVIDER
            )
            var bestLocation: android.location.Location? = null
            for (provider in providers) {
                if (runCatching { lm.isProviderEnabled(provider) }.getOrDefault(false) ||
                    provider == LocationManager.PASSIVE_PROVIDER
                ) {
                    val candidate = runCatching { lm.getLastKnownLocation(provider) }.getOrNull()
                    if (candidate != null && (bestLocation == null || candidate.time > bestLocation.time)) {
                        bestLocation = candidate
                    }
                }
            }
            if (bestLocation != null) {
                resolveAndSetGpsLocation(bestLocation.latitude, bestLocation.longitude)
            }

            // Also trigger a fresh hardware satellite GPS fix completely offline
            if (runCatching { lm.isProviderEnabled(LocationManager.GPS_PROVIDER) }.getOrDefault(false)) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                    lm.getCurrentLocation(
                        LocationManager.GPS_PROVIDER,
                        null,
                        ContextCompat.getMainExecutor(this)
                    ) { freshLoc ->
                        if (freshLoc != null) {
                            resolveAndSetGpsLocation(freshLoc.latitude, freshLoc.longitude)
                        }
                    }
                } else {
                    lm.requestSingleUpdate(
                        LocationManager.GPS_PROVIDER,
                        { freshLoc ->
                            resolveAndSetGpsLocation(freshLoc.latitude, freshLoc.longitude)
                        },
                        android.os.Looper.getMainLooper()
                    )
                }
            }
        } catch (_: Exception) {
        }
    }

    @Suppress("DEPRECATION")
    private fun resolveAndSetGpsLocation(lat: Double, lng: Double) {
        // Immediately persist coordinates so offline Qibla & Prayer calculations update without waiting for network Geocoder
        prayerViewModel.preferences.setLastCoordinates(lat, lng)
        qiblaViewModel.refreshCoordinates()

        lifecycleScope.launch {
            val resolvedName = withContext(Dispatchers.IO) {
                var name = findNearestOfflinePlaceName(lat, lng)
                try {
                    val geocoder = android.location.Geocoder(this@MainActivity, java.util.Locale.getDefault())
                    val addresses = geocoder.getFromLocation(lat, lng, 1)
                    if (!addresses.isNullOrEmpty()) {
                        val addr = addresses[0]
                        val district = addr.subLocality?.takeIf { it.isNotBlank() }
                            ?: addr.subAdminArea?.takeIf { it.isNotBlank() }
                            ?: addr.locality?.takeIf { it.isNotBlank() }
                        val province = addr.adminArea?.takeIf { it.isNotBlank() }
                            ?: addr.locality?.takeIf { it.isNotBlank() }
                        val country = addr.countryName?.takeIf { it.isNotBlank() }
                        val geoName = when {
                            !district.isNullOrBlank() && !province.isNullOrBlank() && !district.equals(province, ignoreCase = true) ->
                                "$district, $province"
                            !district.isNullOrBlank() && !country.isNullOrBlank() ->
                                "$district, $country"
                            !province.isNullOrBlank() && !country.isNullOrBlank() ->
                                "$province, $country"
                            !district.isNullOrBlank() -> district
                            !province.isNullOrBlank() -> province
                            else -> null
                        }
                        if (!geoName.isNullOrBlank()) {
                            name = geoName
                        }
                    }
                } catch (_: Exception) {
                    // Offline Geocoder fallback preserves nearest local city/district or GPS label
                }
                name
            }
            prayerViewModel.updateGpsCoordinates(lat, lng, resolvedName)
            qiblaViewModel.refreshCoordinates()
        }
    }

    private fun findNearestOfflinePlaceName(lat: Double, lng: Double): String {
        val candidates = com.example.data.local.WorldDistrictsData.ALL_DISTRICTS +
            com.example.data.model.City.DEFAULT_CITIES.filter { !it.isGps }
        var closest: com.example.data.model.City? = null
        var bestDistKm = 35.0
        for (c in candidates) {
            val dLat = Math.toRadians(c.latitude - lat)
            val dLon = Math.toRadians(c.longitude - lng)
            val a = kotlin.math.sin(dLat / 2) * kotlin.math.sin(dLat / 2) +
                kotlin.math.cos(Math.toRadians(lat)) * kotlin.math.cos(Math.toRadians(c.latitude)) *
                kotlin.math.sin(dLon / 2) * kotlin.math.sin(dLon / 2)
            val distKm = 6371.0 * 2.0 * kotlin.math.atan2(kotlin.math.sqrt(a), kotlin.math.sqrt(1.0 - a))
            if (distKm < bestDistKm) {
                bestDistKm = distKm
                closest = c
            }
        }
        return closest?.getDisplayName(settingsViewModel.uiState.value.language) ?: "GPS Konumu"
    }

    override fun onResume() {
        super.onResume()
        prayerViewModel.checkExactAlarmPermission()
        prayerViewModel.onAppResumed()
        settingsViewModel.refreshPermissions()
        val pState = prayerViewModel.uiState.value
        if (pState.isGpsActive) {
            val fineOk = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_FINE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            val coarseOk = ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.ACCESS_COARSE_LOCATION
            ) == PackageManager.PERMISSION_GRANTED
            if (fineOk || coarseOk) {
                fetchCurrentGpsLocation()
            }
        }
        if (pState.prayerTimes != null) {
            com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                this,
                pState.prayerTimes,
                pState.selectedCity,
                settingsViewModel.uiState.value.language
            )
        }
    }
}
