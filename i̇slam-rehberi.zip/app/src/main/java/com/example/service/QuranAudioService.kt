package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppPreferences
import com.example.data.local.BuiltinQuranData
import com.example.data.local.QuranOfflineAudioManager
import com.example.data.model.AppLanguage
import com.example.data.model.AyahItem
import com.example.data.model.QuranReciter
import com.example.data.repository.QuranRepository
import com.example.util.NetworkUtils
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

enum class AudioPlaybackSource {
    NONE,
    LOCAL_MP3,
    ONLINE_STREAM,
    OFFLINE_RECITATION
}

enum class OfflineVoiceMode(val id: String) {
    AUTO_ARABIC("auto_arabic"),
    TURKISH_MEAL("turkish_meal");

    companion object {
        fun fromId(id: String?): OfflineVoiceMode {
            return entries.find { it.id == id } ?: AUTO_ARABIC
        }
    }
}

class QuranAudioService : Service(), TextToSpeech.OnInitListener {

    private var mediaPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var progressTrackerJob: Job? = null
    private var loadJob: Job? = null

    private lateinit var quranRepository: QuranRepository

    // Built-in Offline Ayah-by-Ayah TTS Engine
    private var textToSpeech: TextToSpeech? = null
    private var isTtsInitialized = false
    private var ttsAvailable = false
    private var pendingOfflineStart: Pair<Int, Int>? = null
    private var currentOfflineAyahs: List<AyahItem> = emptyList()
    private var currentOfflineAyahIndex: Int = 0
    private var activeUtteranceToken: String? = null
    private var isOfflineRecitationMode = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        quranRepository = QuranRepository(applicationContext)
        createNotificationChannel()
        initTextToSpeech()
    }

    private fun initTextToSpeech() {
        try {
            textToSpeech = TextToSpeech(applicationContext, this).apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
            }
        } catch (_: Exception) {
            isTtsInitialized = true
            ttsAvailable = false
        }
    }

    override fun onInit(status: Int) {
        isTtsInitialized = true
        ttsAvailable = status == TextToSpeech.SUCCESS
        if (ttsAvailable) {
            textToSpeech?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}

                override fun onDone(utteranceId: String?) {
                    if (utteranceId == null || utteranceId != activeUtteranceToken) return
                    serviceScope.launch {
                        handleOfflineAyahCompleted()
                    }
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    if (utteranceId == null || utteranceId != activeUtteranceToken) return
                    serviceScope.launch {
                        handleOfflineAyahCompleted()
                    }
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    if (utteranceId == null || utteranceId != activeUtteranceToken) return
                    serviceScope.launch {
                        handleOfflineAyahCompleted()
                    }
                }
            })
        }

        val pending = pendingOfflineStart
        if (pending != null) {
            pendingOfflineStart = null
            startOfflineRecitationInternal(pending.first, pending.second)
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: return START_NOT_STICKY

        when (action) {
            ACTION_PLAY -> {
                val surahNumber = intent.getIntExtra(EXTRA_SURAH_NUMBER, _currentSurahNumberFlow.value)
                val reciterId = intent.getStringExtra(EXTRA_RECITER_ID) ?: _currentReciterFlow.value.id
                val reciter = QuranReciter.fromId(reciterId)
                val forceOfflineRecitation = intent.getBooleanExtra(EXTRA_FORCE_OFFLINE_RECITATION, false)
                playSurahInternal(surahNumber, reciter, forceOfflineRecitation)
            }
            ACTION_PAUSE -> pauseInternal()
            ACTION_RESUME -> resumeInternal()
            ACTION_NEXT -> {
                val nextSurah = if (_currentSurahNumberFlow.value < 114) _currentSurahNumberFlow.value + 1 else 1
                val keepMealMode = _offlineVoiceModeFlow.value == OfflineVoiceMode.TURKISH_MEAL &&
                    _playbackSourceFlow.value == AudioPlaybackSource.OFFLINE_RECITATION
                playSurahInternal(nextSurah, _currentReciterFlow.value, keepMealMode)
            }
            ACTION_PREVIOUS -> {
                val prevSurah = if (_currentSurahNumberFlow.value > 1) _currentSurahNumberFlow.value - 1 else 114
                val keepMealMode = _offlineVoiceModeFlow.value == OfflineVoiceMode.TURKISH_MEAL &&
                    _playbackSourceFlow.value == AudioPlaybackSource.OFFLINE_RECITATION
                playSurahInternal(prevSurah, _currentReciterFlow.value, keepMealMode)
            }
            ACTION_SEEK_FRACTION -> {
                val fraction = intent.getFloatExtra(EXTRA_SEEK_FRACTION, 0f)
                seekToFractionInternal(fraction)
            }
            ACTION_SEEK_FORWARD_10 -> seekByOffsetInternal(10000)
            ACTION_SEEK_BACKWARD_10 -> seekByOffsetInternal(-10000)
            ACTION_SET_RECITER -> {
                val reciterId = intent.getStringExtra(EXTRA_RECITER_ID)
                val reciter = QuranReciter.fromId(reciterId)
                _currentReciterFlow.value = reciter
                if (_isPlayingFlow.value) {
                    playSurahInternal(_currentSurahNumberFlow.value, reciter, false)
                }
            }
            ACTION_TOGGLE_AUTO_ADVANCE -> {
                val auto = intent.getBooleanExtra(EXTRA_AUTO_ADVANCE, !_isAutoAdvanceFlow.value)
                _isAutoAdvanceFlow.value = auto
            }
            ACTION_SET_SPEED -> {
                val speed = intent.getFloatExtra(EXTRA_SPEED, 1.0f)
                setSpeedInternal(speed)
            }
            ACTION_SET_OFFLINE_VOICE_MODE -> {
                val modeId = intent.getStringExtra(EXTRA_OFFLINE_VOICE_MODE)
                val mode = OfflineVoiceMode.fromId(modeId)
                _offlineVoiceModeFlow.value = mode
                if (_isPlayingFlow.value && mode == OfflineVoiceMode.TURKISH_MEAL) {
                    playSurahInternal(_currentSurahNumberFlow.value, _currentReciterFlow.value, true)
                } else if (_isPlayingFlow.value && isOfflineRecitationMode) {
                    playSurahInternal(_currentSurahNumberFlow.value, _currentReciterFlow.value, false)
                }
            }
            ACTION_STOP -> {
                stopInternal()
                stopSelf()
            }
        }

        return START_NOT_STICKY
    }

    private fun startForegroundCompat(surahNumber: Int, reciter: QuranReciter, isPlaying: Boolean) {
        val notification = buildForegroundNotification(surahNumber, reciter, isPlaying)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    private fun playSurahInternal(
        surahNumber: Int,
        reciter: QuranReciter,
        forceOfflineRecitation: Boolean = false
    ) {
        val safeSurah = surahNumber.coerceIn(1, 114)
        _currentSurahNumberFlow.value = safeSurah
        _currentReciterFlow.value = reciter
        _isBufferingFlow.value = true
        _errorMessageFlow.value = null
        _currentAyahLabelFlow.value = null

        acquireWakeLock()
        startForegroundCompat(safeSurah, reciter, isPlaying = true)

        stopCurrentEnginesOnly()

        // If user explicitly chose Turkish Meal listening, run built-in offline ayah reader immediately
        if (forceOfflineRecitation || _offlineVoiceModeFlow.value == OfflineVoiceMode.TURKISH_MEAL) {
            startOfflineRecitationInternal(safeSurah, 0)
            return
        }

        // 1. Check device-local cached/downloaded Hafiz MP3 (100% offline, instant!)
        val localFile = QuranOfflineAudioManager.getLocalSurahFile(applicationContext, reciter, safeSurah)
        if (localFile != null) {
            playMp3SourceList(
                surahNumber = safeSurah,
                reciter = reciter,
                sources = listOf(localFile.absolutePath),
                sourceIndex = 0,
                isLocalFile = true
            )
            return
        }

        // 2. If online, stream Hafiz MP3 with multi-mirror failover and background offline caching
        if (NetworkUtils.isNetworkAvailable(applicationContext)) {
            val urls = reciter.getSurahAudioUrls(safeSurah)
            playMp3SourceList(
                surahNumber = safeSurah,
                reciter = reciter,
                sources = urls,
                sourceIndex = 0,
                isLocalFile = false
            )
        } else {
            // 3. Zero-internet built-in fallback: Recite bundled Surah ayahs completely offline!
            startOfflineRecitationInternal(safeSurah, 0)
        }
    }

    private fun playMp3SourceList(
        surahNumber: Int,
        reciter: QuranReciter,
        sources: List<String>,
        sourceIndex: Int,
        isLocalFile: Boolean
    ) {
        if (sourceIndex >= sources.size) {
            // All network mirrors failed: seamlessly fall back to built-in offline ayah recitation
            startOfflineRecitationInternal(surahNumber, 0)
            return
        }

        isOfflineRecitationMode = false
        val dataSource = sources[sourceIndex]

        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(dataSource)
                setOnPreparedListener { mp ->
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                        try {
                            mp.playbackParams = mp.playbackParams.setSpeed(_playbackSpeedFlow.value)
                        } catch (_: Exception) {}
                    }
                    mp.start()
                    _isPlayingFlow.value = true
                    _isBufferingFlow.value = false
                    _durationMsFlow.value = mp.duration
                    _playbackSourceFlow.value = if (isLocalFile) {
                        AudioPlaybackSource.LOCAL_MP3
                    } else {
                        AudioPlaybackSource.ONLINE_STREAM
                    }
                    startProgressTracker()
                    updateNotification(surahNumber, reciter, isPlaying = true)

                    // Auto-cache this Surah in background for future offline listening
                    if (!isLocalFile) {
                        QuranOfflineAudioManager.cacheSurahInBackground(applicationContext, reciter, surahNumber)
                    }
                }
                setOnCompletionListener {
                    handleSurahCompleted()
                }
                setOnErrorListener { _, _, _ ->
                    // Try next mirror URL or fall back to built-in offline recitation
                    playMp3SourceList(surahNumber, reciter, sources, sourceIndex + 1, isLocalFile)
                    true
                }
                prepareAsync()
            }
        } catch (_: Exception) {
            playMp3SourceList(surahNumber, reciter, sources, sourceIndex + 1, isLocalFile)
        }
    }

    private fun startOfflineRecitationInternal(surahNumber: Int, startAyahIdx: Int) {
        isOfflineRecitationMode = true
        _playbackSourceFlow.value = AudioPlaybackSource.OFFLINE_RECITATION

        if (!isTtsInitialized) {
            pendingOfflineStart = Pair(surahNumber, startAyahIdx)
            return
        }

        loadJob?.cancel()
        loadJob = serviceScope.launch {
            val detail = quranRepository.getSurahDetail(surahNumber)
            val ayahs = detail?.ayahs.orEmpty()
            if (ayahs.isEmpty() || !ttsAvailable) {
                _isPlayingFlow.value = false
                _isBufferingFlow.value = false
                _errorMessageFlow.value = if (!ttsAvailable) {
                    "Çevrimdışı ses motoru bu cihazda hazır değil. İnternet varken sureleri indirerek çevrimdışı dinleyebilirsiniz."
                } else {
                    "Sure verisi yüklenemedi."
                }
                updateNotification(surahNumber, _currentReciterFlow.value, isPlaying = false)
                return@launch
            }

            currentOfflineAyahs = ayahs
            currentOfflineAyahIndex = startAyahIdx.coerceIn(0, ayahs.lastIndex)
            _durationMsFlow.value = ayahs.size * 1000 // Virtual timeline: 1s unit per ayah
            _isBufferingFlow.value = false
            _isPlayingFlow.value = true

            speakCurrentOfflineAyah()
        }
    }

    private fun speakCurrentOfflineAyah() {
        val tts = textToSpeech
        if (tts == null || !ttsAvailable || currentOfflineAyahs.isEmpty()) {
            _isPlayingFlow.value = false
            return
        }

        val total = currentOfflineAyahs.size
        if (currentOfflineAyahIndex >= total) {
            handleSurahCompleted()
            return
        }

        val ayah = currentOfflineAyahs[currentOfflineAyahIndex]
        val appLanguage = AppPreferences(applicationContext).getLanguage()
        val useMealOnly = _offlineVoiceModeFlow.value == OfflineVoiceMode.TURKISH_MEAL

        var textToSpeak: String
        if (!useMealOnly) {
            val arLocale = Locale("ar", "SA")
            val arCheck = tts.isLanguageAvailable(arLocale)
            if (arCheck >= TextToSpeech.LANG_AVAILABLE) {
                tts.language = arLocale
                textToSpeak = ayah.textArabic
            } else {
                // Device lacks Arabic TTS pack -> seamlessly read bundled Turkish or Kurmanji meal instead of failing!
                val trLocale = Locale("tr", "TR")
                if (tts.isLanguageAvailable(trLocale) >= TextToSpeech.LANG_AVAILABLE) {
                    tts.language = trLocale
                }
                textToSpeak = if (appLanguage == AppLanguage.KURMANJI && ayah.translationKuLatin.isNotBlank()) {
                    ayah.translationKuLatin
                } else {
                    ayah.translationTr
                }
            }
        } else {
            val trLocale = Locale("tr", "TR")
            if (tts.isLanguageAvailable(trLocale) >= TextToSpeech.LANG_AVAILABLE) {
                tts.language = trLocale
            }
            textToSpeak = if (appLanguage == AppLanguage.KURMANJI && ayah.translationKuLatin.isNotBlank()) {
                ayah.translationKuLatin
            } else {
                ayah.translationTr
            }
        }

        if (textToSpeak.isBlank()) {
            textToSpeak = ayah.textArabic
        }

        tts.setSpeechRate(_playbackSpeedFlow.value)

        val token = UUID.randomUUID().toString()
        activeUtteranceToken = token

        _currentAyahLabelFlow.value = "Ayet ${ayah.numberInSurah} / $total"
        _currentTimeMsFlow.value = (currentOfflineAyahIndex + 1) * 1000
        _durationMsFlow.value = total * 1000
        _progressFlow.value = ((currentOfflineAyahIndex + 1).toFloat() / total.toFloat()).coerceIn(0f, 1f)
        _isPlayingFlow.value = true
        _isBufferingFlow.value = false

        updateNotification(_currentSurahNumberFlow.value, _currentReciterFlow.value, isPlaying = true)

        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, android.media.AudioManager.STREAM_MUSIC)
        }
        tts.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, token)
    }

    private fun handleOfflineAyahCompleted() {
        if (!isOfflineRecitationMode || !_isPlayingFlow.value) return
        if (currentOfflineAyahIndex + 1 < currentOfflineAyahs.size) {
            currentOfflineAyahIndex++
            speakCurrentOfflineAyah()
        } else {
            handleSurahCompleted()
        }
    }

    private fun handleSurahCompleted() {
        if (_isAutoAdvanceFlow.value) {
            val current = _currentSurahNumberFlow.value
            if (current < 114) {
                val forceMeal = isOfflineRecitationMode && _offlineVoiceModeFlow.value == OfflineVoiceMode.TURKISH_MEAL
                playSurahInternal(current + 1, _currentReciterFlow.value, forceMeal)
            } else {
                stopInternal()
                stopSelf()
            }
        } else {
            stopInternal()
            stopSelf()
        }
    }

    private fun pauseInternal() {
        try {
            if (isOfflineRecitationMode) {
                activeUtteranceToken = null
                textToSpeech?.stop()
            } else {
                mediaPlayer?.pause()
            }
            _isPlayingFlow.value = false
            _isBufferingFlow.value = false
            updateNotification(_currentSurahNumberFlow.value, _currentReciterFlow.value, isPlaying = false)
        } catch (_: Exception) {}
    }

    private fun resumeInternal() {
        try {
            if (isOfflineRecitationMode && currentOfflineAyahs.isNotEmpty()) {
                speakCurrentOfflineAyah()
                return
            }
            mediaPlayer?.let { mp ->
                mp.start()
                _isPlayingFlow.value = true
                _isBufferingFlow.value = false
                startProgressTracker()
                updateNotification(_currentSurahNumberFlow.value, _currentReciterFlow.value, isPlaying = true)
            } ?: run {
                playSurahInternal(_currentSurahNumberFlow.value, _currentReciterFlow.value, false)
            }
        } catch (_: Exception) {
            playSurahInternal(_currentSurahNumberFlow.value, _currentReciterFlow.value, false)
        }
    }

    private fun seekToFractionInternal(fraction: Float) {
        val safeFrac = fraction.coerceIn(0f, 1f)
        if (isOfflineRecitationMode && currentOfflineAyahs.isNotEmpty()) {
            val targetIdx = (safeFrac * (currentOfflineAyahs.size - 1)).toInt()
                .coerceIn(0, currentOfflineAyahs.lastIndex)
            currentOfflineAyahIndex = targetIdx
            _progressFlow.value = safeFrac
            if (_isPlayingFlow.value) {
                speakCurrentOfflineAyah()
            } else {
                val total = currentOfflineAyahs.size
                _currentAyahLabelFlow.value = "Ayet ${currentOfflineAyahs[targetIdx].numberInSurah} / $total"
                _currentTimeMsFlow.value = (targetIdx + 1) * 1000
            }
            return
        }

        val mp = mediaPlayer ?: return
        try {
            val dur = mp.duration
            val targetMs = (safeFrac * dur).toInt()
            mp.seekTo(targetMs)
            _currentTimeMsFlow.value = targetMs
            _progressFlow.value = safeFrac
        } catch (_: Exception) {}
    }

    private fun seekByOffsetInternal(offsetMs: Int) {
        if (isOfflineRecitationMode && currentOfflineAyahs.isNotEmpty()) {
            val step = if (offsetMs >= 0) 1 else -1
            currentOfflineAyahIndex = (currentOfflineAyahIndex + step).coerceIn(0, currentOfflineAyahs.lastIndex)
            if (_isPlayingFlow.value) {
                speakCurrentOfflineAyah()
            } else {
                val total = currentOfflineAyahs.size
                _currentAyahLabelFlow.value = "Ayet ${currentOfflineAyahs[currentOfflineAyahIndex].numberInSurah} / $total"
                _progressFlow.value = (currentOfflineAyahIndex + 1).toFloat() / total.toFloat()
            }
            return
        }

        val mp = mediaPlayer ?: return
        try {
            val target = (mp.currentPosition + offsetMs).coerceIn(0, mp.duration)
            mp.seekTo(target)
            _currentTimeMsFlow.value = target
            val total = mp.duration.coerceAtLeast(1)
            _progressFlow.value = target.toFloat() / total.toFloat()
        } catch (_: Exception) {}
    }

    private fun setSpeedInternal(speed: Float) {
        val safeSpeed = speed.coerceIn(0.75f, 2.0f)
        _playbackSpeedFlow.value = safeSpeed
        if (isOfflineRecitationMode) {
            textToSpeech?.setSpeechRate(safeSpeed)
            if (_isPlayingFlow.value) {
                speakCurrentOfflineAyah()
            }
            return
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            try {
                mediaPlayer?.let { mp ->
                    if (mp.isPlaying) {
                        mp.playbackParams = mp.playbackParams.setSpeed(safeSpeed)
                    }
                }
            } catch (_: Exception) {}
        }
    }

    private fun stopCurrentEnginesOnly() {
        progressTrackerJob?.cancel()
        loadJob?.cancel()
        activeUtteranceToken = null
        pendingOfflineStart = null
        try {
            textToSpeech?.stop()
        } catch (_: Exception) {}
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (_: Exception) {}
    }

    private fun stopInternal() {
        stopCurrentEnginesOnly()
        releaseWakeLock()
        isOfflineRecitationMode = false
        currentOfflineAyahs = emptyList()
        currentOfflineAyahIndex = 0

        _isPlayingFlow.value = false
        _isBufferingFlow.value = false
        _progressFlow.value = 0f
        _currentTimeMsFlow.value = 0
        _currentAyahLabelFlow.value = null
        _playbackSourceFlow.value = AudioPlaybackSource.NONE

        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun startProgressTracker() {
        progressTrackerJob?.cancel()
        progressTrackerJob = serviceScope.launch {
            while (isActive) {
                delay(400L)
                val mp = mediaPlayer
                if (mp != null && mp.isPlaying) {
                    val current = mp.currentPosition
                    val total = mp.duration.coerceAtLeast(1)
                    _currentTimeMsFlow.value = current
                    _durationMsFlow.value = total
                    _progressFlow.value = current.toFloat() / total.toFloat()
                }
            }
        }
    }

    private fun acquireWakeLock() {
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        if (wakeLock == null) {
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "IslamRehberi:QuranAudioWakeLock"
            )?.apply {
                setReferenceCounted(false)
            }
        }
        wakeLock?.acquire(3 * 60 * 60 * 1000L)
    }

    private fun releaseWakeLock() {
        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (_: Exception) {}
    }

    private fun buildForegroundNotification(
        surahNumber: Int,
        reciter: QuranReciter,
        isPlaying: Boolean
    ): Notification {
        val appPrefs = AppPreferences(this)
        val language = appPrefs.getLanguage()
        val isKurmanji = language == AppLanguage.KURMANJI

        val surahInfo = BuiltinQuranData.SURAH_LIST.find { it.number == surahNumber }
        val surahTitle = if (surahInfo != null) {
            "${surahInfo.number}. ${surahInfo.getDisplayName(language)} (${surahInfo.nameArabic})"
        } else {
            if (isKurmanji) "Sûreya $surahNumber" else "$surahNumber. Sure"
        }

        val ayahStatus = _currentAyahLabelFlow.value
        val sourceTag = when (_playbackSourceFlow.value) {
            AudioPlaybackSource.LOCAL_MP3 -> if (isKurmanji) "Bê Înternet (Ji Cîhazê)" else "Çevrimdışı Hafız"
            AudioPlaybackSource.OFFLINE_RECITATION -> if (isKurmanji) "Xwendina Bê Înternet" else "Çevrimdışı Ses"
            else -> reciter.getDisplayName(language)
        }
        val content = if (ayahStatus != null) {
            "$sourceTag • $ayahStatus"
        } else {
            if (isKurmanji) "Qur'ana Pîroz • $sourceTag" else "Kur'an-ı Kerim • $sourceTag"
        }

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val prevIntent = Intent(this, QuranAudioService::class.java).apply { action = ACTION_PREVIOUS }
        val prevPending = PendingIntent.getService(this, 1, prevIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val playPauseIntent = Intent(this, QuranAudioService::class.java).apply {
            action = if (isPlaying) ACTION_PAUSE else ACTION_RESUME
        }
        val playPausePending = PendingIntent.getService(this, 2, playPauseIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        val nextIntent = Intent(this, QuranAudioService::class.java).apply { action = ACTION_NEXT }
        val nextPending = PendingIntent.getService(this, 3, nextIntent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_asset)
            .setContentTitle(surahTitle)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openPendingIntent)
            .setOngoing(isPlaying)
            .setAutoCancel(false)
            .addAction(android.R.drawable.ic_media_previous, if (isKurmanji) "Pêş" else "Önceki", prevPending)
            .addAction(
                if (isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play,
                if (isPlaying) (if (isKurmanji) "Bisekine" else "Duraklat") else (if (isKurmanji) "Bixwîne" else "Oynat"),
                playPausePending
            )
            .addAction(android.R.drawable.ic_media_next, if (isKurmanji) "Paş" else "Sonraki", nextPending)
            .setStyle(
                NotificationCompat.BigTextStyle()
                    .bigText("$surahTitle\n$content")
            )
            .build()
    }

    private fun updateNotification(surahNumber: Int, reciter: QuranReciter, isPlaying: Boolean) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
        manager?.notify(NOTIFICATION_ID, buildForegroundNotification(surahNumber, reciter, isPlaying))
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Kur'an-ı Kerim Tilaveti",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Kur'an-ı Kerim sure ve hatim sesli oynatma kontrolleri"
                enableVibration(false)
                setSound(null, null)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }
            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopInternal()
        try {
            textToSpeech?.shutdown()
            textToSpeech = null
        } catch (_: Exception) {}
        serviceScope.cancel()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "quran_audio_channel"
        const val NOTIFICATION_ID = 2027

        const val ACTION_PLAY = "com.example.islamrehberi.ACTION_QURAN_PLAY"
        const val ACTION_PAUSE = "com.example.islamrehberi.ACTION_QURAN_PAUSE"
        const val ACTION_RESUME = "com.example.islamrehberi.ACTION_QURAN_RESUME"
        const val ACTION_NEXT = "com.example.islamrehberi.ACTION_QURAN_NEXT"
        const val ACTION_PREVIOUS = "com.example.islamrehberi.ACTION_QURAN_PREVIOUS"
        const val ACTION_SEEK_FRACTION = "com.example.islamrehberi.ACTION_QURAN_SEEK_FRACTION"
        const val ACTION_SEEK_FORWARD_10 = "com.example.islamrehberi.ACTION_QURAN_SEEK_FORWARD_10"
        const val ACTION_SEEK_BACKWARD_10 = "com.example.islamrehberi.ACTION_QURAN_SEEK_BACKWARD_10"
        const val ACTION_SET_RECITER = "com.example.islamrehberi.ACTION_QURAN_SET_RECITER"
        const val ACTION_TOGGLE_AUTO_ADVANCE = "com.example.islamrehberi.ACTION_QURAN_TOGGLE_AUTO_ADVANCE"
        const val ACTION_SET_SPEED = "com.example.islamrehberi.ACTION_QURAN_SET_SPEED"
        const val ACTION_SET_OFFLINE_VOICE_MODE = "com.example.islamrehberi.ACTION_QURAN_SET_OFFLINE_VOICE_MODE"
        const val ACTION_STOP = "com.example.islamrehberi.ACTION_QURAN_STOP"

        const val EXTRA_SURAH_NUMBER = "extra_surah_number"
        const val EXTRA_RECITER_ID = "extra_reciter_id"
        const val EXTRA_SEEK_FRACTION = "extra_seek_fraction"
        const val EXTRA_AUTO_ADVANCE = "extra_auto_advance"
        const val EXTRA_SPEED = "extra_speed"
        const val EXTRA_FORCE_OFFLINE_RECITATION = "extra_force_offline_recitation"
        const val EXTRA_OFFLINE_VOICE_MODE = "extra_offline_voice_mode"

        private val _isPlayingFlow = MutableStateFlow(false)
        val isPlayingFlow: StateFlow<Boolean> = _isPlayingFlow.asStateFlow()

        private val _isBufferingFlow = MutableStateFlow(false)
        val isBufferingFlow: StateFlow<Boolean> = _isBufferingFlow.asStateFlow()

        private val _currentSurahNumberFlow = MutableStateFlow(1)
        val currentSurahNumberFlow: StateFlow<Int> = _currentSurahNumberFlow.asStateFlow()

        private val _currentReciterFlow = MutableStateFlow(QuranReciter.ALAFASY)
        val currentReciterFlow: StateFlow<QuranReciter> = _currentReciterFlow.asStateFlow()

        private val _progressFlow = MutableStateFlow(0f)
        val progressFlow: StateFlow<Float> = _progressFlow.asStateFlow()

        private val _currentTimeMsFlow = MutableStateFlow(0)
        val currentTimeMsFlow: StateFlow<Int> = _currentTimeMsFlow.asStateFlow()

        private val _durationMsFlow = MutableStateFlow(0)
        val durationMsFlow: StateFlow<Int> = _durationMsFlow.asStateFlow()

        private val _isAutoAdvanceFlow = MutableStateFlow(true)
        val isAutoAdvanceFlow: StateFlow<Boolean> = _isAutoAdvanceFlow.asStateFlow()

        private val _playbackSpeedFlow = MutableStateFlow(1.0f)
        val playbackSpeedFlow: StateFlow<Float> = _playbackSpeedFlow.asStateFlow()

        private val _playbackSourceFlow = MutableStateFlow(AudioPlaybackSource.NONE)
        val playbackSourceFlow: StateFlow<AudioPlaybackSource> = _playbackSourceFlow.asStateFlow()

        private val _currentAyahLabelFlow = MutableStateFlow<String?>(null)
        val currentAyahLabelFlow: StateFlow<String?> = _currentAyahLabelFlow.asStateFlow()

        private val _offlineVoiceModeFlow = MutableStateFlow(OfflineVoiceMode.AUTO_ARABIC)
        val offlineVoiceModeFlow: StateFlow<OfflineVoiceMode> = _offlineVoiceModeFlow.asStateFlow()

        private val _errorMessageFlow = MutableStateFlow<String?>(null)
        val errorMessageFlow: StateFlow<String?> = _errorMessageFlow.asStateFlow()

        fun playSurah(
            context: Context,
            surahNumber: Int,
            reciter: QuranReciter = _currentReciterFlow.value,
            forceOfflineRecitation: Boolean = false
        ) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_PLAY
                putExtra(EXTRA_SURAH_NUMBER, surahNumber)
                putExtra(EXTRA_RECITER_ID, reciter.id)
                putExtra(EXTRA_FORCE_OFFLINE_RECITATION, forceOfflineRecitation)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun pause(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_PAUSE }
            context.startService(intent)
        }

        fun resume(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_RESUME }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun next(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_NEXT }
            context.startService(intent)
        }

        fun previous(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_PREVIOUS }
            context.startService(intent)
        }

        fun seekTo(context: Context, fraction: Float) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_SEEK_FRACTION
                putExtra(EXTRA_SEEK_FRACTION, fraction)
            }
            context.startService(intent)
        }

        fun seekForward10s(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_SEEK_FORWARD_10 }
            context.startService(intent)
        }

        fun seekBackward10s(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_SEEK_BACKWARD_10 }
            context.startService(intent)
        }

        fun setReciter(context: Context, reciter: QuranReciter) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_SET_RECITER
                putExtra(EXTRA_RECITER_ID, reciter.id)
            }
            context.startService(intent)
        }

        fun setAutoAdvance(context: Context, enabled: Boolean) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_TOGGLE_AUTO_ADVANCE
                putExtra(EXTRA_AUTO_ADVANCE, enabled)
            }
            context.startService(intent)
        }

        fun setSpeed(context: Context, speed: Float) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_SET_SPEED
                putExtra(EXTRA_SPEED, speed)
            }
            context.startService(intent)
        }

        fun setOfflineVoiceMode(context: Context, mode: OfflineVoiceMode) {
            val intent = Intent(context, QuranAudioService::class.java).apply {
                action = ACTION_SET_OFFLINE_VOICE_MODE
                putExtra(EXTRA_OFFLINE_VOICE_MODE, mode.id)
            }
            context.startService(intent)
        }

        fun stop(context: Context) {
            val intent = Intent(context, QuranAudioService::class.java).apply { action = ACTION_STOP }
            context.startService(intent)
        }
    }
}
