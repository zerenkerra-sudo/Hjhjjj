package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.MediaPlayer
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppPreferences
import com.example.data.model.AppLanguage
import com.example.data.model.PrayerType
import com.example.notification.PrayerNotificationManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class AdhanPlayerService : Service() {

    private var mediaPlayer: MediaPlayer? = null
    private var preAdhanAlertPlayer: MediaPlayer? = null
    private var wakeLock: PowerManager.WakeLock? = null
    private var previousAlarmVolume: Int = -1
    private val mainHandler = Handler(Looper.getMainLooper())
    private var preAdhanAutoStopRunnable: Runnable? = null
    private var activePreAdhanNotificationId: Int = -1

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val action = intent?.action ?: ACTION_PLAY_ADHAN

        when (action) {
            ACTION_STOP_ADHAN -> {
                stopPreAdhanAlert(removeNotification = false)
                stopAdhanPlayback()
                stopSelf()
                return START_NOT_STICKY
            }
            ACTION_STOP_PRE_ADHAN_ALERT -> {
                val notifId = intent?.getIntExtra(EXTRA_NOTIFICATION_ID, activePreAdhanNotificationId)
                    ?: activePreAdhanNotificationId
                stopPreAdhanAlert(removeNotification = true, notificationIdToCancel = notifId)
                if (!_isPlayingFlow.value) {
                    stopSelf()
                }
                return START_NOT_STICKY
            }
            ACTION_PRE_ADHAN_ALERT -> {
                val prayerKey = intent?.getStringExtra(EXTRA_PRAYER_KEY) ?: PrayerType.DHUHR.key
                val prayer = PrayerType.entries.find { it.key == prayerKey } ?: PrayerType.DHUHR
                val time = intent?.getStringExtra(EXTRA_TIME) ?: ""
                startPreAdhanAlert(prayer, time)
            }
            ACTION_TEST_ADHAN -> {
                stopPreAdhanAlert(removeNotification = false)
                val soundAsset = intent?.getStringExtra(EXTRA_SOUND_ASSET) ?: "adhan.mp3"
                startAdhanPlayback(
                    prayerName = "Ezan Testi",
                    prayerNameKu = "Ceribandina Bangê",
                    time = "--:--",
                    soundAsset = soundAsset
                )
            }
            ACTION_PLAY_ADHAN -> {
                stopPreAdhanAlert(removeNotification = false)
                val prayerName = intent?.getStringExtra(EXTRA_PRAYER_NAME) ?: "Namaz Vakti"
                val prayerNameKu = intent?.getStringExtra(EXTRA_PRAYER_NAME_KU) ?: "Wextê Nimêjê"
                val time = intent?.getStringExtra(EXTRA_TIME) ?: ""
                val soundAsset = intent?.getStringExtra(EXTRA_SOUND_ASSET) ?: "adhan.mp3"

                startAdhanPlayback(prayerName, prayerNameKu, time, soundAsset)
            }
        }

        return START_NOT_STICKY
    }

    private fun startAdhanPlayback(
        prayerName: String,
        prayerNameKu: String,
        time: String,
        soundAsset: String
    ) {
        // Acquire partial wake lock during playback
        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "IslamRehberi:AdhanPlayerWakeLock"
        )?.apply {
            setReferenceCounted(false)
            acquire(10 * 60 * 1000L) // max 10 minutes safety timeout
        }

        val notification = buildForegroundNotification(prayerName, prayerNameKu, time)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }

        try {
            mediaPlayer?.release()
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                        .build()
                )

                // Robust 3-tier audio loading: Direct Asset FD -> Extracted Cache File -> System Alarm Ringtone
                try {
                    val afd = assets.openFd(soundAsset)
                    setDataSource(afd.fileDescriptor, afd.startOffset, afd.length)
                    afd.close()
                } catch (e1: Exception) {
                    try {
                        val cacheFile = java.io.File(cacheDir, soundAsset)
                        if (!cacheFile.exists() || cacheFile.length() == 0L) {
                            assets.open(soundAsset).use { input ->
                                java.io.FileOutputStream(cacheFile).use { output ->
                                    input.copyTo(output)
                                }
                            }
                        }
                        setDataSource(cacheFile.absolutePath)
                    } catch (e2: Exception) {
                        val fallbackUri = android.media.RingtoneManager.getDefaultUri(android.media.RingtoneManager.TYPE_NOTIFICATION)
                        setDataSource(this@AdhanPlayerService, fallbackUri)
                    }
                }

                isLooping = false
                setOnCompletionListener {
                    stopAdhanPlayback()
                    stopSelf()
                }
                setOnErrorListener { _, _, _ ->
                    stopAdhanPlayback()
                    stopSelf()
                    true
                }
                prepare()
                start()
            }

            _isPlayingFlow.value = true
            _currentPrayerNameFlow.value = prayerName
        } catch (e: Exception) {
            e.printStackTrace()
            stopAdhanPlayback()
            stopSelf()
        }
    }

    private fun stopAdhanPlayback() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            mediaPlayer = null
        } catch (e: Exception) {
        }

        try {
            if (wakeLock?.isHeld == true) {
                wakeLock?.release()
            }
        } catch (e: Exception) {
        }

        _isPlayingFlow.value = false
        _currentPrayerNameFlow.value = ""
        stopForeground(STOP_FOREGROUND_REMOVE)
    }

    private fun startPreAdhanAlert(prayer: PrayerType, time: String) {
        stopPreAdhanAlert(removeNotification = false)

        val powerManager = getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "IslamRehberi:PreAdhanAlertWakeLock"
        )?.apply {
            setReferenceCounted(false)
            acquire(10 * 1000L)
        }
        this.wakeLock = wakeLock

        val notifId = 5000 + prayer.ordinal
        activePreAdhanNotificationId = notifId
        val appPrefs = AppPreferences(this)
        val notification = PrayerNotificationManager.buildPreAdhanNotification(
            context = this,
            prayer = prayer,
            time = time,
            language = appPrefs.getLanguage(),
            includeSilenceAction = true,
            silenceNotificationSound = true
        )

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                notifId,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK
            )
        } else {
            startForeground(notifId, notification)
        }

        // Boost STREAM_ALARM to maximum volume temporarily so every user hears the alert loudly
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
        if (audioManager != null) {
            val maxAlarmVol = audioManager.getStreamMaxVolume(AudioManager.STREAM_ALARM)
            val currentAlarmVol = audioManager.getStreamVolume(AudioManager.STREAM_ALARM)
            if (maxAlarmVol > 0 && currentAlarmVol < maxAlarmVol) {
                previousAlarmVolume = currentAlarmVol
                try {
                    audioManager.setStreamVolume(AudioManager.STREAM_ALARM, maxAlarmVol, 0)
                } catch (_: SecurityException) {
                    previousAlarmVolume = -1
                }
            }
        }

        // Trigger a concise vibration burst that finishes cleanly within the 3-second alert window
        triggerPreAdhanVibration()

        try {
            val alertUri = PrayerNotificationManager.resolveLoudAlertUri()
            preAdhanAlertPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AdhanPlayerService, alertUri)
                setVolume(1.0f, 1.0f)
                isLooping = true
                setOnErrorListener { _, _, _ ->
                    stopPreAdhanAlert(removeNotification = false)
                    stopSelf()
                    true
                }
                prepare()
                start()
            }

            // Stop loud ringing cleanly after exact 3 seconds while keeping the visual reminder in tray
            val stopTask = Runnable {
                stopPreAdhanAlert(removeNotification = false)
                if (!_isPlayingFlow.value) {
                    stopSelf()
                }
            }
            preAdhanAutoStopRunnable = stopTask
            mainHandler.postDelayed(stopTask, PRE_ADHAN_ALERT_DURATION_MS)
        } catch (e: Exception) {
            e.printStackTrace()
            stopPreAdhanAlert(removeNotification = false)
            if (!_isPlayingFlow.value) {
                stopSelf()
            }
        }
    }

    private fun triggerPreAdhanVibration() {
        try {
            val pattern = longArrayOf(0L, 450L, 120L, 450L, 120L, 600L)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    vibrator?.vibrate(VibrationEffect.createWaveform(pattern, -1))
                } else {
                    @Suppress("DEPRECATION")
                    vibrator?.vibrate(pattern, -1)
                }
            }
        } catch (_: Exception) {
        }
    }

    private fun cancelPreAdhanVibration() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vm = getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
                vm?.defaultVibrator?.cancel()
            } else {
                @Suppress("DEPRECATION")
                val vibrator = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
                vibrator?.cancel()
            }
        } catch (_: Exception) {
        }
    }

    private fun stopPreAdhanAlert(removeNotification: Boolean, notificationIdToCancel: Int = activePreAdhanNotificationId) {
        preAdhanAutoStopRunnable?.let { mainHandler.removeCallbacks(it) }
        preAdhanAutoStopRunnable = null

        try {
            preAdhanAlertPlayer?.stop()
            preAdhanAlertPlayer?.release()
        } catch (_: Exception) {
        } finally {
            preAdhanAlertPlayer = null
        }

        cancelPreAdhanVibration()

        if (previousAlarmVolume >= 0) {
            try {
                val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager
                audioManager?.setStreamVolume(AudioManager.STREAM_ALARM, previousAlarmVolume, 0)
            } catch (_: SecurityException) {
            } finally {
                previousAlarmVolume = -1
            }
        }

        try {
            if (wakeLock?.isHeld == true && !_isPlayingFlow.value) {
                wakeLock?.release()
            }
        } catch (_: Exception) {
        }

        if (activePreAdhanNotificationId != -1) {
            val flags = if (removeNotification) {
                ServiceCompat.STOP_FOREGROUND_REMOVE
            } else {
                ServiceCompat.STOP_FOREGROUND_DETACH
            }
            try {
                ServiceCompat.stopForeground(this, flags)
            } catch (_: Exception) {
            }
            activePreAdhanNotificationId = -1
        }

        if (removeNotification && notificationIdToCancel > 0) {
            try {
                val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
                manager?.cancel(notificationIdToCancel)
            } catch (_: Exception) {
            }
        }
    }

    private fun buildForegroundNotification(
        prayerName: String,
        prayerNameKu: String,
        time: String
    ): Notification {
        val appPrefs = AppPreferences(this)
        val isKurmanji = appPrefs.getLanguage() == AppLanguage.KURMANJI

        val title = if (isKurmanji) {
            "Wext Hat: $prayerNameKu"
        } else {
            "Vakit Girdi: $prayerName"
        }

        val content = if (isKurmanji) {
            "Banga şerîf dixwîne ($time) - Nimêja xwe ji bîr mekin."
        } else {
            "Ezan-ı Şerif okunuyor ($time) - Haydin namaza, haydin kurtuluşa."
        }

        val stopLabel = if (isKurmanji) "Bangê Bisekine" else "Ezanı Durdur"

        val openIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val openPendingIntent = PendingIntent.getActivity(
            this,
            0,
            openIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopIntent = Intent(this, AdhanPlayerService::class.java).apply {
            action = ACTION_STOP_ADHAN
        }
        val stopPendingIntent = PendingIntent.getService(
            this,
            1,
            stopIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_launcher_asset)
            .setContentTitle(title)
            .setContentText(content)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setContentIntent(openPendingIntent)
            .addAction(
                android.R.drawable.ic_media_pause,
                stopLabel,
                stopPendingIntent
            )
            .setOngoing(true)
            .setAutoCancel(false)
            .build()
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Ezan Vakitleri ve Bildirimleri",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Namaz vakitlerinde ezan sesi ve hatırlatıcı bildirimler"
                enableVibration(true)
                setSound(null, null) // Sound is played directly through MediaPlayer via USAGE_MEDIA (Medya akışı)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
            }

            val manager = getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager
            manager?.createNotificationChannel(channel)
        }
    }

    override fun onDestroy() {
        stopPreAdhanAlert(removeNotification = false)
        stopAdhanPlayback()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL_ID = "adhan_prayer_channel"
        const val NOTIFICATION_ID = 2026
        const val PRE_ADHAN_ALERT_DURATION_MS = 3000L

        const val ACTION_PLAY_ADHAN = "com.example.islamrehberi.ACTION_PLAY_ADHAN"
        const val ACTION_STOP_ADHAN = "com.example.islamrehberi.ACTION_STOP_ADHAN"
        const val ACTION_TEST_ADHAN = "com.example.islamrehberi.ACTION_TEST_ADHAN"
        const val ACTION_PRE_ADHAN_ALERT = "com.example.islamrehberi.ACTION_PRE_ADHAN_ALERT"
        const val ACTION_STOP_PRE_ADHAN_ALERT = "com.example.islamrehberi.ACTION_STOP_PRE_ADHAN_ALERT"

        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_PRAYER_NAME_KU = "extra_prayer_name_ku"
        const val EXTRA_PRAYER_KEY = "extra_prayer_key"
        const val EXTRA_TIME = "extra_time"
        const val EXTRA_SOUND_ASSET = "extra_sound_asset"
        const val EXTRA_NOTIFICATION_ID = "extra_notification_id"

        private val _isPlayingFlow = MutableStateFlow(false)
        val isPlayingFlow: StateFlow<Boolean> = _isPlayingFlow.asStateFlow()

        private val _currentPrayerNameFlow = MutableStateFlow("")
        val currentPrayerNameFlow: StateFlow<String> = _currentPrayerNameFlow.asStateFlow()

        fun stopAdhan(context: Context) {
            val intent = Intent(context, AdhanPlayerService::class.java).apply {
                action = ACTION_STOP_ADHAN
            }
            context.startService(intent)
        }

        fun testAdhan(context: Context, soundAsset: String = "adhan.mp3") {
            val intent = Intent(context, AdhanPlayerService::class.java).apply {
                action = ACTION_TEST_ADHAN
                putExtra(EXTRA_SOUND_ASSET, soundAsset)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun playPreAdhanAlert(context: Context, prayer: PrayerType, time: String): Boolean {
            val intent = Intent(context, AdhanPlayerService::class.java).apply {
                action = ACTION_PRE_ADHAN_ALERT
                putExtra(EXTRA_PRAYER_KEY, prayer.key)
                putExtra(EXTRA_TIME, time)
            }
            return try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    ContextCompat.startForegroundService(context, intent)
                } else {
                    context.startService(intent)
                }
                true
            } catch (e: Exception) {
                e.printStackTrace()
                false
            }
        }
    }
}
