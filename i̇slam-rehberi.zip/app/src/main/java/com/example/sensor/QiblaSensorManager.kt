package com.example.sensor

import android.content.Context
import android.hardware.GeomagneticField
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.display.DisplayManager
import android.os.Handler
import android.os.Looper
import android.view.Display
import android.view.Surface
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.*

data class QiblaCompassState(
    val deviceHeading: Float = 0f,       // 0..360 azimuth from True North
    val qiblaBearing: Float = 0f,        // 0..360 angle to Kaaba from True North
    val qiblaAngleOffset: Float = 0f,    // Signed angle difference (-180..+180, 0 = facing Kaaba)
    val isFacingQibla: Boolean = false,  // Within +/- 3.5 degrees
    val distanceKm: Double = 0.0,        // Distance to Makkah in km
    val magneticDeclination: Float = 0f, // Local Magnetic -> True North offset in degrees
    val sensorAccuracy: Int = SensorManager.SENSOR_STATUS_ACCURACY_HIGH,
    val hasSensor: Boolean = true
)

class QiblaSensorManager(context: Context) : SensorEventListener {

    private val appContext = context.applicationContext
    private val sensorManager = appContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager
    private val displayManager = appContext.getSystemService(Context.DISPLAY_SERVICE) as? DisplayManager
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _compassState = MutableStateFlow(QiblaCompassState())
    val compassState: StateFlow<QiblaCompassState> = _compassState.asStateFlow()

    private var currentLatitude: Double = 41.0082 // default Istanbul
    private var currentLongitude: Double = 28.9784
    private var currentDeclination: Float = computeMagneticDeclination(41.0082, 28.9784)

    private val rotationMatrix = FloatArray(9)
    private val remappedRotationMatrix = FloatArray(9)
    private val fallbackRotationMatrix = FloatArray(9)
    private val fallbackInclinationMatrix = FloatArray(9)

    // Fallback sensors if rotation vector is missing or unresponsive
    private var lastAccelerometer: FloatArray? = null
    private var lastMagnetometer: FloatArray? = null

    private var hasInitialHeading = false
    private var smoothedHeading = 0f
    private var usingRotationVector = false
    private var receivedRotationVectorEvent = false
    private var isUprightMode = false

    private val fallbackTimeoutRunnable = Runnable {
        if (!receivedRotationVectorEvent && usingRotationVector) {
            sensorManager?.unregisterListener(this)
            startAccelMagnetFallback()
        }
    }

    companion object {
        const val KAABA_LATITUDE = 21.422487
        const val KAABA_LONGITUDE = 39.826206
        private const val EARTH_RADIUS_KM = 6371.0
        private const val UPRIGHT_ENTER_THRESHOLD = 0.82f
        private const val UPRIGHT_EXIT_THRESHOLD = 0.72f

        fun computeMagneticDeclination(lat: Double, lon: Double): Float {
            return try {
                GeomagneticField(
                    lat.toFloat(),
                    lon.toFloat(),
                    0f,
                    System.currentTimeMillis()
                ).declination
            } catch (_: Exception) {
                0f
            }
        }

        /**
         * Great Circle Forward Azimuth from (lat, lon) to Kaaba (21.422487, 39.826206) relative to True North
         */
        fun calculateQiblaAzimuth(lat: Double, lon: Double): Float {
            val lat1 = Math.toRadians(lat)
            val lon1 = Math.toRadians(lon)
            val lat2 = Math.toRadians(KAABA_LATITUDE)
            val lon2 = Math.toRadians(KAABA_LONGITUDE)

            val dLon = lon2 - lon1
            val y = sin(dLon) * cos(lat2)
            val x = cos(lat1) * sin(lat2) - sin(lat1) * cos(lat2) * cos(dLon)

            val azimuthRad = atan2(y, x)
            val azimuthDeg = (Math.toDegrees(azimuthRad) + 360.0) % 360.0
            return azimuthDeg.toFloat()
        }

        fun calculateDistanceToKaaba(lat: Double, lon: Double): Double {
            val dLat = Math.toRadians(KAABA_LATITUDE - lat)
            val dLon = Math.toRadians(KAABA_LONGITUDE - lon)
            val a = sin(dLat / 2).pow(2.0) +
                    cos(Math.toRadians(lat)) * cos(Math.toRadians(KAABA_LATITUDE)) *
                    sin(dLon / 2).pow(2.0)
            val c = 2 * atan2(sqrt(a), sqrt(1 - a))
            return EARTH_RADIUS_KM * c
        }

        fun magneticToTrueNorth(magneticAzimuth: Float, declination: Float): Float {
            return ((magneticAzimuth + declination) % 360f + 360f) % 360f
        }

        /**
         * Gimbal-lock-free azimuth computation directly from 3x3 world rotation matrix R (device -> East, North, Up).
         * - When flat/normal tilt: projects device top edge (+Y = [r[1], r[4]]) onto East-North plane.
         * - When upright vertical: projects rear camera (-Z = [-r[2], -r[5]]) onto East-North plane (no 180° flip).
         */
        fun computeAzimuthFromRotationMatrix(
            r: FloatArray,
            useRearVector: Boolean = abs(r[7]) >= 0.80f
        ): Float {
            val east: Float
            val north: Float
            if (useRearVector) {
                east = -r[2]
                north = -r[5]
            } else {
                east = r[1]
                north = r[4]
            }
            val azimuthDeg = (Math.toDegrees(atan2(east.toDouble(), north.toDouble())) + 360.0) % 360.0
            return azimuthDeg.toFloat()
        }
    }

    fun updateCoordinates(latitude: Double, longitude: Double) {
        currentLatitude = latitude
        currentLongitude = longitude
        currentDeclination = computeMagneticDeclination(latitude, longitude)
        recalculateQiblaBearing(smoothedHeading, _compassState.value.sensorAccuracy, _compassState.value.hasSensor)
    }

    fun startListening() {
        mainHandler.removeCallbacks(fallbackTimeoutRunnable)
        sensorManager?.unregisterListener(this)

        hasInitialHeading = false
        isUprightMode = false
        receivedRotationVectorEvent = false
        lastAccelerometer = null
        lastMagnetometer = null

        if (sensorManager == null) {
            recalculateQiblaBearing(smoothedHeading, SensorManager.SENSOR_STATUS_UNRELIABLE, hasSensor = false)
            return
        }

        val rotationVectorSensor = sensorManager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
            ?: sensorManager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)

        if (rotationVectorSensor != null) {
            usingRotationVector = true
            sensorManager.registerListener(
                this,
                rotationVectorSensor,
                SensorManager.SENSOR_DELAY_GAME
            )
            // Monitor magnetometer accuracy independently for Figure-8 calibration guidance
            sensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)?.let { mag ->
                sensorManager.registerListener(this, mag, SensorManager.SENSOR_DELAY_NORMAL)
            }
            recalculateQiblaBearing(smoothedHeading, _compassState.value.sensorAccuracy, hasSensor = true)
            // Watchdog: if rotation vector fails to emit events within 1.5s, switch to Accel + Magnetometer
            mainHandler.postDelayed(fallbackTimeoutRunnable, 1500L)
        } else {
            startAccelMagnetFallback()
        }
    }

    private fun startAccelMagnetFallback() {
        usingRotationVector = false
        val sm = sensorManager
        if (sm == null) {
            recalculateQiblaBearing(smoothedHeading, SensorManager.SENSOR_STATUS_UNRELIABLE, hasSensor = false)
            return
        }
        val accelSensor = sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        val magnetSensor = sm.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD)

        if (accelSensor != null && magnetSensor != null) {
            sm.registerListener(this, accelSensor, SensorManager.SENSOR_DELAY_GAME)
            sm.registerListener(this, magnetSensor, SensorManager.SENSOR_DELAY_GAME)
            recalculateQiblaBearing(smoothedHeading, _compassState.value.sensorAccuracy, hasSensor = true)
        } else {
            recalculateQiblaBearing(smoothedHeading, SensorManager.SENSOR_STATUS_UNRELIABLE, hasSensor = false)
        }
    }

    fun stopListening() {
        mainHandler.removeCallbacks(fallbackTimeoutRunnable)
        sensorManager?.unregisterListener(this)
        hasInitialHeading = false
        receivedRotationVectorEvent = false
        lastAccelerometer = null
        lastMagnetometer = null
    }

    override fun onSensorChanged(event: SensorEvent?) {
        if (event == null) return

        var rawMagneticAzimuth: Float? = null

        when (event.sensor.type) {
            Sensor.TYPE_ROTATION_VECTOR,
            Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR -> {
                if (!receivedRotationVectorEvent) {
                    receivedRotationVectorEvent = true
                    mainHandler.removeCallbacks(fallbackTimeoutRunnable)
                }
                val vector = if (event.values.size > 4) event.values.copyOf(4) else event.values
                SensorManager.getRotationMatrixFromVector(rotationMatrix, vector)
                rawMagneticAzimuth = extractAzimuthFromMatrix(rotationMatrix)
            }
            Sensor.TYPE_ACCELEROMETER -> {
                if (!usingRotationVector) {
                    lastAccelerometer = lowPassVector(event.values, lastAccelerometer, 0.15f)
                }
            }
            Sensor.TYPE_MAGNETIC_FIELD -> {
                if (!usingRotationVector) {
                    lastMagnetometer = lowPassVector(event.values, lastMagnetometer, 0.15f)
                } else {
                    if (_compassState.value.sensorAccuracy != event.accuracy) {
                        _compassState.value = _compassState.value.copy(sensorAccuracy = event.accuracy)
                    }
                    return
                }
            }
        }

        if (!usingRotationVector && rawMagneticAzimuth == null) {
            val accel = lastAccelerometer
            val mag = lastMagnetometer
            if (accel != null && mag != null &&
                SensorManager.getRotationMatrix(fallbackRotationMatrix, fallbackInclinationMatrix, accel, mag)
            ) {
                rawMagneticAzimuth = extractAzimuthFromMatrix(fallbackRotationMatrix)
            }
        }

        if (rawMagneticAzimuth != null && rawMagneticAzimuth.isFinite()) {
            val trueAzimuth = magneticToTrueNorth(rawMagneticAzimuth, currentDeclination)
            if (!hasInitialHeading) {
                smoothedHeading = trueAzimuth
                hasInitialHeading = true
            } else {
                smoothedHeading = smoothAngle(smoothedHeading, trueAzimuth, 0.18f)
            }
            val accuracyToReport = if (usingRotationVector) _compassState.value.sensorAccuracy else event.accuracy
            recalculateQiblaBearing(smoothedHeading, accuracyToReport, hasSensor = true)
        }
    }

    private fun extractAzimuthFromMatrix(r: FloatArray): Float {
        remapForDisplayRotation(r, remappedRotationMatrix, getDisplayRotation())
        val verticalComponent = abs(remappedRotationMatrix[7])
        if (!isUprightMode && verticalComponent >= UPRIGHT_ENTER_THRESHOLD) {
            isUprightMode = true
        } else if (isUprightMode && verticalComponent <= UPRIGHT_EXIT_THRESHOLD) {
            isUprightMode = false
        }
        return computeAzimuthFromRotationMatrix(remappedRotationMatrix, useRearVector = isUprightMode)
    }

    private fun getDisplayRotation(): Int {
        return try {
            @Suppress("DEPRECATION")
            displayManager?.getDisplay(Display.DEFAULT_DISPLAY)?.rotation ?: Surface.ROTATION_0
        } catch (_: Exception) {
            Surface.ROTATION_0
        }
    }

    private fun remapForDisplayRotation(inR: FloatArray, outR: FloatArray, rotation: Int) {
        val remapped = when (rotation) {
            Surface.ROTATION_90 -> SensorManager.remapCoordinateSystem(
                inR, SensorManager.AXIS_Y, SensorManager.AXIS_MINUS_X, outR
            )
            Surface.ROTATION_180 -> SensorManager.remapCoordinateSystem(
                inR, SensorManager.AXIS_MINUS_X, SensorManager.AXIS_MINUS_Y, outR
            )
            Surface.ROTATION_270 -> SensorManager.remapCoordinateSystem(
                inR, SensorManager.AXIS_MINUS_Y, SensorManager.AXIS_X, outR
            )
            else -> false
        }
        if (!remapped) {
            inR.copyInto(outR)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        if (sensor?.type == Sensor.TYPE_MAGNETIC_FIELD ||
            sensor?.type == Sensor.TYPE_ROTATION_VECTOR ||
            sensor?.type == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR
        ) {
            _compassState.value = _compassState.value.copy(sensorAccuracy = accuracy)
        }
    }

    private fun recalculateQiblaBearing(heading: Float, accuracy: Int, hasSensor: Boolean) {
        val qiblaBearing = calculateQiblaAzimuth(currentLatitude, currentLongitude)
        val distance = calculateDistanceToKaaba(currentLatitude, currentLongitude)

        // Signed shortest angle difference (-180..+180)
        var offset = (qiblaBearing - heading + 360f) % 360f
        if (offset > 180f) offset -= 360f

        val isFacing = hasSensor && abs(offset) <= 3.5f

        _compassState.value = QiblaCompassState(
            deviceHeading = heading,
            qiblaBearing = qiblaBearing,
            qiblaAngleOffset = offset,
            isFacingQibla = isFacing,
            distanceKm = distance,
            magneticDeclination = currentDeclination,
            sensorAccuracy = accuracy,
            hasSensor = hasSensor
        )
    }

    private fun lowPassVector(input: FloatArray, output: FloatArray?, alpha: Float): FloatArray {
        val size = minOf(input.size, 3)
        if (output == null || output.size < size) {
            return input.copyOf(size)
        }
        for (i in 0 until size) {
            output[i] = output[i] + alpha * (input[i] - output[i])
        }
        return output
    }

    private fun smoothAngle(current: Float, target: Float, alpha: Float): Float {
        var diff = (target - current) % 360f
        if (diff > 180f) diff -= 360f
        if (diff < -180f) diff += 360f
        return (current + diff * alpha + 360f) % 360f
    }
}
