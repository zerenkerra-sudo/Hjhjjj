package com.example.notification

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.RingtoneManager
import android.net.Uri
import android.os.Build
import android.os.SystemClock
import android.provider.Settings
import android.widget.RemoteViews
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import com.example.MainActivity
import com.example.R
import com.example.data.local.AppPreferences
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import com.example.service.AdhanPlayerService
import java.util.Locale

object PrayerNotificationManager {

    private const val CHANNEL_ID = "prayer_times_persistent_channel"
    private const val NOTIFICATION_ID = 9999
    private const val LEGACY_CHANNEL_PRE_ADHAN_ID = "prayer_reminder_30min_channel"
    const val CHANNEL_PRE_ADHAN_ID = "prayer_reminder_30min_max_v3"
    private val PRE_ADHAN_VIBRATION_PATTERN = longArrayOf(0L, 450L, 120L, 450L, 120L, 600L)

    fun formatSingleLinePrayerTimes(times: PrayerTimes, language: AppLanguage): String {
        return if (language == AppLanguage.KURMANJI) {
            "Ber ${times.fajr} · Roj ${times.sunrise} · Nîv ${times.dhuhr} · Esr ${times.asr} · Êvr ${times.maghrib} · Xef ${times.isha}"
        } else {
            "İms ${times.fajr} · Gün ${times.sunrise} · Öğl ${times.dhuhr} · İkn ${times.asr} · Akş ${times.maghrib} · Yat ${times.isha}"
        }
    }

    fun formatRemainingHms(millisRemaining: Long): String {
        val totalSeconds = (millisRemaining.coerceAtLeast(0L)) / 1000L
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L
        return String.format(Locale.US, "%02d:%02d:%02d", hours, minutes, seconds)
    }

    fun formatChronometerPattern(millisRemaining: Long): String {
        return if (millisRemaining < 3_600_000L) "00:%s" else "%s"
    }

    fun buildSingleLineFallbackSummary(
        times: PrayerTimes,
        language: AppLanguage,
        millisRemaining: Long
    ): String {
        return "${formatSingleLinePrayerTimes(times, language)} | ${formatRemainingHms(millisRemaining)}"
    }

    fun updatePrayerNotification(
        context: Context,
        times: PrayerTimes?,
        city: City?,
        language: AppLanguage
    ) {
        val prefs = AppPreferences(context)
        if (!prefs.isPrayerBarNotificationEnabled()) {
            cancelPrayerNotification(context)
            return
        }

        if (times == null) return

        // Check notification permission for Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPerm = ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
            if (!hasPerm) return
        }

        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        createNotificationChannel(context, notificationManager)

        val cityName = city?.getDisplayName(language) ?: "Namaz Vakitleri"

        // Calculate next prayer and remaining milliseconds
        val nextInfo = times.getNextPrayer(java.util.Date())
        val nextPrayerName = nextInfo.type.getName(language)
        val nextPrayerTime = nextInfo.time
        val remainingMillis = nextInfo.millisRemaining.coerceAtLeast(0L)

        val singleLineTimes = formatSingleLinePrayerTimes(times, language)
        val remainingHms = formatRemainingHms(remainingMillis)
        val headerSubText = "$cityName • $nextPrayerName ($nextPrayerTime)"
        val fallbackTitle = "$headerSubText • $remainingHms"

        val remoteViews = RemoteViews(context.packageName, R.layout.notification_prayer_single_line).apply {
            setTextViewText(R.id.notif_prayer_times_line, singleLineTimes)
            val baseElapsed = SystemClock.elapsedRealtime() + remainingMillis
            setChronometer(
                R.id.notif_countdown_chronometer,
                baseElapsed,
                formatChronometerPattern(remainingMillis),
                true
            )
            setChronometerCountDown(R.id.notif_countdown_chronometer, true)
        }

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }

        val pendingIntent = PendingIntent.getActivity(
            context,
            0,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_prayer)
            .setContentTitle(fallbackTitle)
            .setContentText(singleLineTimes)
            .setSubText(headerSubText)
            .setCustomContentView(remoteViews)
            .setCustomBigContentView(remoteViews)
            .setStyle(NotificationCompat.DecoratedCustomViewStyle())
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setShowWhen(false)
            .setAutoCancel(false)
            .setPriority(NotificationCompat.PRIORITY_LOW) // Silent ongoing notification bar item
            .setCategory(NotificationCompat.CATEGORY_STATUS)
            .setColor(0xFFD4AF37.toInt())
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .build()

        try {
            notificationManager.notify(NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun cancelPrayerNotification(context: Context) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        try {
            notificationManager.cancel(NOTIFICATION_ID)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun createNotificationChannel(context: Context, manager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Namaz Vakitleri Bildirim Çubuğu / Demên Nimêjê",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Telefonun bildirim çubuğunda güncel namaz vakitlerini ve sıradaki vakti sürekli gösterir."
                setShowBadge(false)
                enableVibration(false)
                enableLights(false)
            }
            manager.createNotificationChannel(channel)
        }
    }

    /**
     * Resolves the loudest alert sound URI on the user's device (Alarm -> Ringtone -> Notification).
     */
    fun resolveLoudAlertUri(): Uri {
        return RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE)
            ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            ?: Settings.System.DEFAULT_ALARM_ALERT_URI
            ?: Settings.System.DEFAULT_NOTIFICATION_URI
    }

    /**
     * Ensures the maximum-priority pre-Adhan notification channel exists for every user.
     */
    fun ensurePreAdhanChannel(context: Context) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return
        createPreAdhanChannel(notificationManager)
    }

    /**
     * Builds the PRIORITY_MAX / CATEGORY_ALARM notification for 30 minutes before Adhan.
     */
    fun buildPreAdhanNotification(
        context: Context,
        prayer: PrayerType,
        time: String,
        language: AppLanguage,
        includeSilenceAction: Boolean = true,
        silenceNotificationSound: Boolean = false
    ): Notification {
        ensurePreAdhanChannel(context)
        val prayerName = prayer.getName(language)
        val title = AppStrings.preAdhanNotificationTitle(prayerName, language)
        val content = AppStrings.preAdhanNotificationContent(prayerName, time, language)
        val loudUri = resolveLoudAlertUri()
        val notifId = 5000 + prayer.ordinal

        val intent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            notifId,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(context, CHANNEL_PRE_ADHAN_ID)
            .setSmallIcon(R.drawable.ic_notification_prayer)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setContentIntent(pendingIntent)
            .setPriority(NotificationCompat.PRIORITY_MAX)
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setVisibility(NotificationCompat.VISIBILITY_PUBLIC)
            .setLights(0xFFFFD54F.toInt(), 800, 400)
            .setColor(0xFFD4AF37.toInt())
            .setOnlyAlertOnce(false)
            .setAutoCancel(true)

        if (silenceNotificationSound) {
            // Audio + vibration are handled for exact 3 seconds by AdhanPlayerService
            builder.setSilent(true)
        } else {
            builder
                .setSound(loudUri, AudioManager.STREAM_ALARM)
                .setVibrate(PRE_ADHAN_VIBRATION_PATTERN)
        }

        if (includeSilenceAction) {
            val stopIntent = Intent(context, AdhanPlayerService::class.java).apply {
                action = AdhanPlayerService.ACTION_STOP_PRE_ADHAN_ALERT
                putExtra(AdhanPlayerService.EXTRA_NOTIFICATION_ID, notifId)
            }
            val stopPendingIntent = PendingIntent.getService(
                context,
                notifId + 100,
                stopIntent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val stopLabel = if (language == AppLanguage.KURMANJI) "Dengê Bisekine" else "Sesi Sustur"
            builder.addAction(android.R.drawable.ic_lock_silent_mode, stopLabel, stopPendingIntent)
        }

        return builder.build()
    }

    /**
     * Shows the maximum-priority 30-minute pre-Adhan notification ("Ezana Az Kaldı!")
     * and triggers a 3-second high-volume alarm-stream sound alert so every user hears it cleanly.
     */
    fun showPreAdhanNotification(
        context: Context,
        prayer: PrayerType,
        time: String,
        language: AppLanguage,
        triggerLoudAlertSound: Boolean = true
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return

        createPreAdhanChannel(notificationManager)

        val playedViaService = if (triggerLoudAlertSound) {
            AdhanPlayerService.playPreAdhanAlert(
                context = context,
                prayer = prayer,
                time = time
            )
        } else {
            false
        }

        val canPostVisual = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }

        if (canPostVisual) {
            val notification = buildPreAdhanNotification(
                context = context,
                prayer = prayer,
                time = time,
                language = language,
                includeSilenceAction = triggerLoudAlertSound,
                silenceNotificationSound = playedViaService
            )
            try {
                notificationManager.notify(5000 + prayer.ordinal, notification)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun createPreAdhanChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            // Remove older quieter channel so Android applies the new max-loudness alarm attributes
            try {
                manager.deleteNotificationChannel(LEGACY_CHANNEL_PRE_ADHAN_ID)
            } catch (_: Exception) {
            }

            val loudAlarmUri = resolveLoudAlertUri()
            val alarmAttrs = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_ALARM)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            val channel = NotificationChannel(
                CHANNEL_PRE_ADHAN_ID,
                "Ezana Az Kaldı • 30 Dk Yüksek Sesli Uyarı",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Namaz vaktine 30 dakika kaldığında en yüksek sesli ve öncelikli hazırlık bildirimi gönderir."
                setSound(loudAlarmUri, alarmAttrs)
                setBypassDnd(true)
                lockscreenVisibility = Notification.VISIBILITY_PUBLIC
                enableVibration(true)
                vibrationPattern = PRE_ADHAN_VIBRATION_PATTERN
                enableLights(true)
                lightColor = 0xFFFFD54F.toInt()
                setShowBadge(true)
            }
            manager.createNotificationChannel(channel)
        }
    }
}
