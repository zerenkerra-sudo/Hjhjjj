package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import com.example.data.local.AppPreferences
import com.example.data.local.ReligiousDaysData
import com.example.receiver.EventNotificationReceiver
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

class EventNotificationScheduler(
    private val context: Context,
    private val preferences: AppPreferences
) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager

    fun rescheduleAll() {
        if (preferences.isFridayReminderEnabled()) {
            scheduleNextFridayReminder()
        } else {
            cancelFridayReminder()
        }

        if (preferences.isReligiousDaysReminderEnabled()) {
            scheduleUpcomingReligiousDays()
        } else {
            cancelReligiousDays()
        }
    }

    /**
     * Schedules notification for next Friday at 10:30 AM
     */
    fun scheduleNextFridayReminder() {
        val now = Calendar.getInstance()
        val target = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, Calendar.FRIDAY)
            set(Calendar.HOUR_OF_DAY, 10)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (target.before(now)) {
            // Next Friday
            target.add(Calendar.WEEK_OF_YEAR, 1)
        }

        val intent = Intent(context, EventNotificationReceiver::class.java).apply {
            action = EventNotificationReceiver.ACTION_FRIDAY_NOTIFICATION
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            EventNotificationReceiver.REQUEST_CODE_FRIDAY,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        scheduleAlarm(target.timeInMillis, pendingIntent)
    }

    fun cancelFridayReminder() {
        val intent = Intent(context, EventNotificationReceiver::class.java).apply {
            action = EventNotificationReceiver.ACTION_FRIDAY_NOTIFICATION
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            EventNotificationReceiver.REQUEST_CODE_FRIDAY,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }

    /**
     * Schedules the next upcoming religious day notification for 08:30 AM
     */
    fun scheduleUpcomingReligiousDays() {
        val upcoming = ReligiousDaysData.getNextUpcomingReligiousDay() ?: return
        val day = upcoming.first
        val daysLeft = upcoming.second

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
        val targetDate = try {
            dateFormat.parse(day.gregorianDateStr)
        } catch (e: Exception) {
            null
        } ?: return

        val targetCal = Calendar.getInstance().apply {
            time = targetDate
            set(Calendar.HOUR_OF_DAY, 8)
            set(Calendar.MINUTE, 30)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }

        if (targetCal.timeInMillis <= System.currentTimeMillis()) {
            return
        }

        val intent = Intent(context, EventNotificationReceiver::class.java).apply {
            action = EventNotificationReceiver.ACTION_RELIGIOUS_DAY_NOTIFICATION
            putExtra(EventNotificationReceiver.EXTRA_EVENT_NAME_TR, day.nameTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_NAME_KU, day.nameKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_DESC_TR, day.descriptionTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_DESC_KU, day.descriptionKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_SIGNIFICANCE_TR, day.significanceTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_SIGNIFICANCE_KU, day.significanceKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_CELEBRATION_TR, day.celebrationMessageTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_CELEBRATION_KU, day.celebrationMessageKu)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            EventNotificationReceiver.REQUEST_CODE_RELIGIOUS_DAY,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        scheduleAlarm(targetCal.timeInMillis, pendingIntent)
    }

    /**
     * Sends an immediate test notification for the given religious day so the user can verify it instantly
     */
    fun sendInstantTestReligiousDayNotification(day: com.example.data.model.ReligiousDay) {
        val intent = Intent(context, EventNotificationReceiver::class.java).apply {
            action = EventNotificationReceiver.ACTION_RELIGIOUS_DAY_NOTIFICATION
            putExtra(EventNotificationReceiver.EXTRA_EVENT_NAME_TR, day.nameTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_NAME_KU, day.nameKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_DESC_TR, day.descriptionTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_DESC_KU, day.descriptionKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_SIGNIFICANCE_TR, day.significanceTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_SIGNIFICANCE_KU, day.significanceKu)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_CELEBRATION_TR, day.celebrationMessageTr)
            putExtra(EventNotificationReceiver.EXTRA_EVENT_CELEBRATION_KU, day.celebrationMessageKu)
        }
        context.sendBroadcast(intent)
    }

    fun cancelReligiousDays() {
        val intent = Intent(context, EventNotificationReceiver::class.java).apply {
            action = EventNotificationReceiver.ACTION_RELIGIOUS_DAY_NOTIFICATION
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            EventNotificationReceiver.REQUEST_CODE_RELIGIOUS_DAY,
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
        }
    }

    private fun scheduleAlarm(triggerAtMillis: Long, pendingIntent: PendingIntent) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            if (alarmManager.canScheduleExactAlarms()) {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            } else {
                alarmManager.setAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    triggerAtMillis,
                    pendingIntent
                )
            }
        } else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            alarmManager.setExactAndAllowWhileIdle(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        } else {
            alarmManager.setExact(
                AlarmManager.RTC_WAKEUP,
                triggerAtMillis,
                pendingIntent
            )
        }
    }
}
