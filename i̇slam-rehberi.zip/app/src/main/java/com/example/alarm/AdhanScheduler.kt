package com.example.alarm

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Settings
import com.example.data.local.AppPreferences
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import com.example.receiver.AdhanAlarmReceiver

class AdhanScheduler(
    private val context: Context,
    private val preferences: AppPreferences
) {
    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as? AlarmManager

    fun canScheduleExactAlarms(): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            alarmManager?.canScheduleExactAlarms() ?: false
        } else {
            true
        }
    }

    /**
     * Schedules all enabled adhan prayer alarms for the given prayer times.
     */
    fun scheduleAllAlarms(prayerTimes: PrayerTimes) {
        if (alarmManager == null) return

        for (prayer in PrayerType.entries) {
            if (!prayer.hasAdhan) continue

            // 1. Regular adhan alarm
            val isEnabled = preferences.isAdhanEnabled(prayer)
            if (isEnabled) {
                schedulePrayerAlarm(prayer, prayerTimes)
            } else {
                cancelPrayerAlarm(prayer)
            }

            // 2. Pre-adhan 30-minute approaching reminder alarm
            val isPreReminderEnabled = preferences.isPreAdhanReminderEnabled() && preferences.isPreAdhanForPrayer(prayer)
            if (isPreReminderEnabled) {
                schedulePreAdhanAlarm(prayer, prayerTimes)
            } else {
                cancelPreAdhanAlarm(prayer)
            }
        }
    }

    fun schedulePrayerAlarm(prayer: PrayerType, prayerTimes: PrayerTimes) {
        if (alarmManager == null || !prayer.hasAdhan) return

        val triggerMillis = prayerTimes.getPrayerMillis(prayer, forTomorrowIfPassed = true)
        if (triggerMillis <= 0L) return

        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_ADHAN_ALARM
            putExtra(EXTRA_PRAYER_KEY, prayer.key)
            putExtra(EXTRA_PRAYER_NAME, prayer.turkishName)
            putExtra(EXTRA_PRAYER_NAME_KU, prayer.kurmanjiName)
            putExtra(EXTRA_SOUND_ASSET, prayer.soundAsset)
            putExtra(EXTRA_TIME, prayerTimes.getTimeFor(prayer))
        }

        val requestCode = getRequestCode(prayer)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            // setAlarmClock provides maximum reliability across Doze mode and all Android versions
            val showIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val showPendingIntent = PendingIntent.getActivity(
                context,
                requestCode + 500,
                showIntent ?: Intent(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerMillis, showPendingIntent)
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
        } catch (e: SecurityException) {
            // Fallback if exact alarm permission is restricted
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
                }
            } catch (ignored: Exception) {
            }
        } catch (e: Exception) {
            // Other vendor exception fallback
        }
    }

    fun cancelPrayerAlarm(prayer: PrayerType) {
        if (alarmManager == null || !prayer.hasAdhan) return

        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_ADHAN_ALARM
        }
        val requestCode = getRequestCode(prayer)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    /**
     * Schedules a reminder 30 minutes before the prayer time.
     */
    fun schedulePreAdhanAlarm(prayer: PrayerType, prayerTimes: PrayerTimes) {
        if (alarmManager == null || !prayer.hasAdhan) return

        val triggerMillis = prayerTimes.getPreAdhanReminderMillis(prayer, minutesBefore = 30)
        if (triggerMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_PRE_ADHAN_REMINDER
            putExtra(EXTRA_PRAYER_KEY, prayer.key)
            putExtra(EXTRA_PRAYER_NAME, prayer.turkishName)
            putExtra(EXTRA_PRAYER_NAME_KU, prayer.kurmanjiName)
            putExtra(EXTRA_TIME, prayerTimes.getTimeFor(prayer))
        }

        val requestCode = getPreAdhanRequestCode(prayer)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            val showIntent = context.packageManager.getLaunchIntentForPackage(context.packageName)
            val showPendingIntent = PendingIntent.getActivity(
                context,
                requestCode + 500,
                showIntent ?: Intent(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )

            val alarmClockInfo = AlarmManager.AlarmClockInfo(triggerMillis, showPendingIntent)
            alarmManager.setAlarmClock(alarmClockInfo, pendingIntent)
        } catch (e: SecurityException) {
            try {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        triggerMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.set(AlarmManager.RTC_WAKEUP, triggerMillis, pendingIntent)
                }
            } catch (ignored: Exception) {
            }
        } catch (e: Exception) {
        }
    }

    fun cancelPreAdhanAlarm(prayer: PrayerType) {
        if (alarmManager == null || !prayer.hasAdhan) return

        val intent = Intent(context, AdhanAlarmReceiver::class.java).apply {
            action = ACTION_PRE_ADHAN_REMINDER
        }
        val requestCode = getPreAdhanRequestCode(prayer)
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager.cancel(pendingIntent)
        pendingIntent.cancel()
    }

    private fun getRequestCode(prayer: PrayerType): Int {
        return when (prayer) {
            PrayerType.FAJR -> 1001
            PrayerType.SUNRISE -> 1000 // unused
            PrayerType.DHUHR -> 1002
            PrayerType.ASR -> 1003
            PrayerType.MAGHRIB -> 1004
            PrayerType.ISHA -> 1005
        }
    }

    private fun getPreAdhanRequestCode(prayer: PrayerType): Int {
        return when (prayer) {
            PrayerType.FAJR -> 5001
            PrayerType.SUNRISE -> 5000 // unused
            PrayerType.DHUHR -> 5002
            PrayerType.ASR -> 5003
            PrayerType.MAGHRIB -> 5004
            PrayerType.ISHA -> 5005
        }
    }

    companion object {
        const val ACTION_ADHAN_ALARM = "com.example.islamrehberi.ACTION_ADHAN_ALARM"
        const val ACTION_PRE_ADHAN_REMINDER = "com.example.islamrehberi.ACTION_PRE_ADHAN_REMINDER"
        const val EXTRA_PRAYER_KEY = "extra_prayer_key"
        const val EXTRA_PRAYER_NAME = "extra_prayer_name"
        const val EXTRA_PRAYER_NAME_KU = "extra_prayer_name_ku"
        const val EXTRA_SOUND_ASSET = "extra_sound_asset"
        const val EXTRA_TIME = "extra_time"
    }
}
