package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.PowerManager
import androidx.core.content.ContextCompat
import com.example.alarm.AdhanScheduler
import com.example.data.local.AppPreferences
import com.example.data.model.PrayerType
import com.example.service.AdhanPlayerService

class AdhanAlarmReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val intentAction = intent.action
        val prayerKey = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_KEY) ?: return
        val prayerName = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_NAME) ?: "Namaz Vakti"
        val prayerNameKu = intent.getStringExtra(AdhanScheduler.EXTRA_PRAYER_NAME_KU) ?: "Wextê Nimêjê"
        val soundAsset = intent.getStringExtra(AdhanScheduler.EXTRA_SOUND_ASSET) ?: "adhan.mp3"
        val time = intent.getStringExtra(AdhanScheduler.EXTRA_TIME) ?: ""

        val preferences = AppPreferences(context)
        val prayerType = PrayerType.entries.find { it.key == prayerKey }

        // Handle 30-Minute Approaching Reminder Notification ("Her Ezana 30 dakika kaldığında yüksek sesli uyarı")
        if (intentAction == AdhanScheduler.ACTION_PRE_ADHAN_REMINDER) {
            val preWakeLock = (context.getSystemService(Context.POWER_SERVICE) as? PowerManager)?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK,
                "IslamRehberi:PreAdhanReceiverWakeLock"
            )
            preWakeLock?.acquire(15000L)
            try {
                if (prayerType != null) {
                    com.example.notification.PrayerNotificationManager.showPreAdhanNotification(
                        context = context,
                        prayer = prayerType,
                        time = time,
                        language = preferences.getLanguage(),
                        triggerLoudAlertSound = true
                    )
                }

                // Reschedule next pre-adhan reminder using today's validated timings
                if (prayerType != null && preferences.isPreAdhanReminderEnabled()) {
                    val freshTimes = com.example.data.repository.PrayerRepository.resolveCurrentPrayerTimesForAlarms(preferences)
                    val scheduler = AdhanScheduler(context, preferences)
                    scheduler.schedulePreAdhanAlarm(prayerType, freshTimes)
                }
            } finally {
                try {
                    if (preWakeLock?.isHeld == true) {
                        preWakeLock.release()
                    }
                } catch (_: Exception) {
                }
            }
            return
        }

        val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
        val wakeLock = powerManager?.newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK,
            "IslamRehberi:AdhanAlarmReceiverWakeLock"
        )
        wakeLock?.acquire(15000L) // 15 seconds to safely start foreground service

        val serviceIntent = Intent(context, AdhanPlayerService::class.java).apply {
            action = AdhanPlayerService.ACTION_PLAY_ADHAN
            putExtra(AdhanPlayerService.EXTRA_PRAYER_NAME, prayerName)
            putExtra(AdhanPlayerService.EXTRA_PRAYER_NAME_KU, prayerNameKu)
            putExtra(AdhanPlayerService.EXTRA_TIME, time)
            putExtra(AdhanPlayerService.EXTRA_SOUND_ASSET, soundAsset)
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ContextCompat.startForegroundService(context, serviceIntent)
            } else {
                context.startService(serviceIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        } finally {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock.release()
                }
            } catch (ignored: Exception) {}
        }

        // Reschedule alarm for next day's prayer using validated timings
        if (prayerType != null) {
            val freshTimes = com.example.data.repository.PrayerRepository.resolveCurrentPrayerTimesForAlarms(preferences)
            val scheduler = AdhanScheduler(context, preferences)
            scheduler.schedulePrayerAlarm(prayerType, freshTimes)
        }
    }
}
