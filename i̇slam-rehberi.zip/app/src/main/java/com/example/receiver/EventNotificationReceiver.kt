package com.example.receiver

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.example.MainActivity
import com.example.R
import com.example.alarm.EventNotificationScheduler
import com.example.data.local.AppPreferences
import com.example.data.local.AppStrings
import com.example.data.local.HutbeData
import com.example.data.local.ReligiousDaysData
import com.example.data.model.AppLanguage

class EventNotificationReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        val preferences = AppPreferences(context)
        val language = preferences.getLanguage()

        when (action) {
            ACTION_FRIDAY_NOTIFICATION -> {
                if (!preferences.isFridayReminderEnabled()) return
                showFridayNotification(context, language)
                // Schedule next Friday
                EventNotificationScheduler(context, preferences).scheduleNextFridayReminder()
            }
            ACTION_RELIGIOUS_DAY_NOTIFICATION -> {
                if (!preferences.isReligiousDaysReminderEnabled()) return
                val eventNameTr = intent.getStringExtra(EXTRA_EVENT_NAME_TR) ?: "Mübarek Gün"
                val eventNameKu = intent.getStringExtra(EXTRA_EVENT_NAME_KU) ?: "Roja Pîroz"
                val eventDescTr = intent.getStringExtra(EXTRA_EVENT_DESC_TR) ?: ""
                val eventDescKu = intent.getStringExtra(EXTRA_EVENT_DESC_KU) ?: ""
                val eventSignificanceTr = intent.getStringExtra(EXTRA_EVENT_SIGNIFICANCE_TR) ?: ""
                val eventSignificanceKu = intent.getStringExtra(EXTRA_EVENT_SIGNIFICANCE_KU) ?: ""
                val eventCelebrationTr = intent.getStringExtra(EXTRA_EVENT_CELEBRATION_TR) ?: ""
                val eventCelebrationKu = intent.getStringExtra(EXTRA_EVENT_CELEBRATION_KU) ?: ""

                showReligiousDayNotification(
                    context,
                    language,
                    eventNameTr,
                    eventNameKu,
                    eventDescTr,
                    eventDescKu,
                    eventSignificanceTr,
                    eventSignificanceKu,
                    eventCelebrationTr,
                    eventCelebrationKu
                )
                // Reschedule upcoming events
                EventNotificationScheduler(context, preferences).scheduleUpcomingReligiousDays()
            }
        }
    }

    private fun showFridayNotification(context: Context, language: AppLanguage) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel(notificationManager)

        val title = if (language == AppLanguage.KURMANJI) {
            "Hayırlı Cumalar • În a We Pîroz Be"
        } else {
            "Hayırlı Cumalar • Cumanız Mübarek Olsun"
        }

        val activeHutbe = HutbeData.getCurrentWeekHutbe()
        val hutbeTitle = activeHutbe.getTitle(language)

        val content = if (language == AppLanguage.KURMANJI) {
            "Xutbeya Hefteyê: \"$hutbeTitle\". Wextê nimêja înê nêzîk dibe; silav û duayan ji bîr nekin."
        } else {
            "Haftanın Hutbesi: \"$hutbeTitle\". Cuma namazı vakti yaklaşıyor; dualarınız kabul olsun."
        }

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            REQUEST_CODE_FRIDAY,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_FRIDAY, notification)
    }

    private fun showReligiousDayNotification(
        context: Context,
        language: AppLanguage,
        nameTr: String,
        nameKu: String,
        descTr: String,
        descKu: String,
        significanceTr: String = "",
        significanceKu: String = "",
        celebrationTr: String = "",
        celebrationKu: String = ""
    ) {
        val notificationManager =
            context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        createNotificationChannel(notificationManager)

        val title = if (language == AppLanguage.KURMANJI) {
            "$nameKu Pîroz Be!"
        } else {
            "$nameTr Mübarek Olsun!"
        }

        val content = if (language == AppLanguage.KURMANJI) {
            buildString {
                if (celebrationKu.isNotBlank()) append(celebrationKu).append("\n\n")
                if (significanceKu.isNotBlank()) append("Wate û Girîngî: ").append(significanceKu)
                else if (descKu.isNotBlank()) append(descKu)
            }
        } else {
            buildString {
                if (celebrationTr.isNotBlank()) append(celebrationTr).append("\n\n")
                if (significanceTr.isNotBlank()) append("Anlam ve Önemi: ").append(significanceTr)
                else if (descTr.isNotBlank()) append(descTr)
            }
        }

        val mainIntent = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context,
            REQUEST_CODE_RELIGIOUS_DAY,
            mainIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(if (language == AppLanguage.KURMANJI) (celebrationKu.ifBlank { descKu }) else (celebrationTr.ifBlank { descTr }))
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(NOTIFICATION_ID_RELIGIOUS_DAY, notification)
    }

    private fun createNotificationChannel(manager: NotificationManager) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "İslami Hatırlatmalar & Cuma",
                NotificationManager.IMPORTANCE_HIGH
            ).apply {
                description = "Cuma günleri ve kandil/bayram bildirimleri"
                enableVibration(true)
            }
            manager.createNotificationChannel(channel)
        }
    }

    companion object {
        const val CHANNEL_ID = "islam_events_channel"
        const val ACTION_FRIDAY_NOTIFICATION = "com.example.islamrehberi.ACTION_FRIDAY_REMINDER"
        const val ACTION_RELIGIOUS_DAY_NOTIFICATION = "com.example.islamrehberi.ACTION_RELIGIOUS_DAY_REMINDER"

        const val EXTRA_EVENT_NAME_TR = "extra_event_name_tr"
        const val EXTRA_EVENT_NAME_KU = "extra_event_name_ku"
        const val EXTRA_EVENT_DESC_TR = "extra_event_desc_tr"
        const val EXTRA_EVENT_DESC_KU = "extra_event_desc_ku"
        const val EXTRA_EVENT_SIGNIFICANCE_TR = "extra_event_significance_tr"
        const val EXTRA_EVENT_SIGNIFICANCE_KU = "extra_event_significance_ku"
        const val EXTRA_EVENT_CELEBRATION_TR = "extra_event_celebration_tr"
        const val EXTRA_EVENT_CELEBRATION_KU = "extra_event_celebration_ku"

        const val REQUEST_CODE_FRIDAY = 2001
        const val REQUEST_CODE_RELIGIOUS_DAY = 2002
        const val NOTIFICATION_ID_FRIDAY = 3001
        const val NOTIFICATION_ID_RELIGIOUS_DAY = 3002
    }
}
