package com.example.receiver

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.example.alarm.AdhanScheduler
import com.example.data.local.AppPreferences
import com.example.data.repository.PrayerRepository

class BootReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action == Intent.ACTION_BOOT_COMPLETED ||
            action == Intent.ACTION_LOCKED_BOOT_COMPLETED ||
            action == Intent.ACTION_MY_PACKAGE_REPLACED ||
            action == Intent.ACTION_TIME_CHANGED ||
            action == Intent.ACTION_TIMEZONE_CHANGED ||
            action == Intent.ACTION_DATE_CHANGED
        ) {
            val preferences = AppPreferences(context)
            val scheduler = AdhanScheduler(context, preferences)

            val prayerTimes = PrayerRepository.resolveCurrentPrayerTimesForAlarms(preferences)

            scheduler.scheduleAllAlarms(prayerTimes)

            val eventScheduler = com.example.alarm.EventNotificationScheduler(context, preferences)
            eventScheduler.rescheduleAll()
        }
    }
}
