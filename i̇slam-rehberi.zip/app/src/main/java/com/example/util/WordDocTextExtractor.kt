package com.example.util

import java.io.ByteArrayInputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.charset.Charset
import java.util.zip.ZipInputStream
import javax.xml.parsers.DocumentBuilderFactory

data class ExtractedHutbeDoc(
    val dateDisplay: String,
    val title: String,
    val paragraphs: List<String>,
    val fullBodyText: String,
    val footnotes: String,
    val headerImageBytes: ByteArray? = null
) {
    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is ExtractedHutbeDoc) return false
        return dateDisplay == other.dateDisplay &&
            title == other.title &&
            paragraphs == other.paragraphs &&
            fullBodyText == other.fullBodyText &&
            footnotes == other.footnotes &&
            headerImageBytes.contentEquals(other.headerImageBytes)
    }

    override fun hashCode(): Int {
        var result = dateDisplay.hashCode()
        result = 31 * result + title.hashCode()
        result = 31 * result + paragraphs.hashCode()
        result = 31 * result + fullBodyText.hashCode()
        result = 31 * result + footnotes.hashCode()
        result = 31 * result + (headerImageBytes?.contentHashCode() ?: 0)
        return result
    }
}

/**
 * Pure Kotlin Word (.doc OLE2 Word 97-2003 & .docx OOXML) text extractor.
 * Extracts verbatim body text, footnotes, and endnotes from official Diyanet documents
 * without external heavyweight POI dependencies.
 */
object WordDocTextExtractor {

    private val OLE2_MAGIC = byteArrayOf(
        0xD0.toByte(), 0xCF.toByte(), 0x11.toByte(), 0xE0.toByte(),
        0xA1.toByte(), 0xB1.toByte(), 0x1A.toByte(), 0xE1.toByte()
    )
    private val ZIP_MAGIC = byteArrayOf(0x50, 0x4B, 0x03, 0x04)
    private val WINDOWS_1254: Charset = Charset.forName("windows-1254")
    private const val SPECIAL_SEC_THRESHOLD = 0xFFFFFFFAL

    fun extract(bytes: ByteArray): ExtractedHutbeDoc? {
        if (bytes.size < 64) return null
        return when {
            bytes.startsWith(OLE2_MAGIC) -> extractOle2Doc(bytes)
            bytes.startsWith(ZIP_MAGIC) -> extractDocx(bytes)
            else -> null
        }
    }

    private fun extractOle2Doc(data: ByteArray): ExtractedHutbeDoc? {
        if (data.size < 512) return null
        val hdr = ByteBuffer.wrap(data, 0, 512).order(ByteOrder.LITTLE_ENDIAN)

        val sectorShift = hdr.getShort(0x1E).toInt() and 0xFFFF
        if (sectorShift !in 9..16) return null
        val sectorSize = 1 shl sectorShift

        val miniSectorShift = hdr.getShort(0x20).toInt() and 0xFFFF
        val miniSectorSize = 1 shl (miniSectorShift.coerceIn(4, 10))

        val numFatSectors = hdr.getInt(0x2C).toLong() and 0xFFFFFFFFL
        val firstDirSector = hdr.getInt(0x30).toLong() and 0xFFFFFFFFL
        val miniCutoff = hdr.getInt(0x38).toLong() and 0xFFFFFFFFL
        val firstMiniFatSector = hdr.getInt(0x3C).toLong() and 0xFFFFFFFFL
        val numMiniFatSectors = hdr.getInt(0x40).toLong() and 0xFFFFFFFFL
        val firstDifatSector = hdr.getInt(0x44).toLong() and 0xFFFFFFFFL
        val numDifatSectors = hdr.getInt(0x48).toLong() and 0xFFFFFFFFL

        val difat = ArrayList<Long>(128)
        for (i in 0 until 109) {
            difat.add(hdr.getInt(0x4C + i * 4).toLong() and 0xFFFFFFFFL)
        }
        var curDifat = firstDifatSector
        var difatLoops = 0
        while (curDifat < SPECIAL_SEC_THRESHOLD && difatLoops < numDifatSectors.coerceAtMost(64) && difat.size < numFatSectors) {
            difatLoops++
            val off = 512 + (curDifat.toInt() * sectorSize)
            if (off < 512 || off + sectorSize > data.size) break
            val buf = ByteBuffer.wrap(data, off, sectorSize).slice().order(ByteOrder.LITTLE_ENDIAN)
            val entriesPerSec = (sectorSize / 4) - 1
            for (i in 0 until entriesPerSec) {
                difat.add(buf.getInt(i * 4).toLong() and 0xFFFFFFFFL)
            }
            curDifat = buf.getInt(entriesPerSec * 4).toLong() and 0xFFFFFFFFL
        }

        val fat = ArrayList<Long>()
        val fatLimit = numFatSectors.toInt().coerceAtMost(difat.size)
        for (idx in 0 until fatLimit) {
            val sec = difat[idx]
            if (sec >= SPECIAL_SEC_THRESHOLD) continue
            val off = 512 + (sec.toInt() * sectorSize)
            if (off < 512 || off + sectorSize > data.size) continue
            val buf = ByteBuffer.wrap(data, off, sectorSize).slice().order(ByteOrder.LITTLE_ENDIAN)
            val count = sectorSize / 4
            for (i in 0 until count) {
                fat.add(buf.getInt(i * 4).toLong() and 0xFFFFFFFFL)
            }
        }
        if (fat.isEmpty()) return null

        fun readChain(startSector: Long, maxBytes: Int = 32 * 1024 * 1024): ByteArray {
            if (startSector >= SPECIAL_SEC_THRESHOLD) return ByteArray(0)
            val out = java.io.ByteArrayOutputStream()
            var sec = startSector
            val visited = HashSet<Long>()
            while (sec < SPECIAL_SEC_THRESHOLD && visited.add(sec) && out.size() < maxBytes) {
                val off = 512 + (sec.toInt() * sectorSize)
                if (off < 512 || off >= data.size) break
                val len = (data.size - off).coerceAtMost(sectorSize)
                out.write(data, off, len)
                sec = if (sec.toInt() in fat.indices) fat[sec.toInt()] else SPECIAL_SEC_THRESHOLD
            }
            return out.toByteArray()
        }

        val dirBytes = readChain(firstDirSector)
        if (dirBytes.size < 128) return null

        val miniFat = ArrayList<Long>()
        if (firstMiniFatSector < SPECIAL_SEC_THRESHOLD && numMiniFatSectors > 0) {
            val mfBytes = readChain(firstMiniFatSector)
            val mfBuf = ByteBuffer.wrap(mfBytes).order(ByteOrder.LITTLE_ENDIAN)
            for (i in 0 until (mfBytes.size / 4)) {
                miniFat.add(mfBuf.getInt(i * 4).toLong() and 0xFFFFFFFFL)
            }
        }

        data class OleStream(val startSector: Long, val size: Long)
        val streams = HashMap<String, OleStream>()
        var rootMiniContainer = ByteArray(0)

        val numEntries = dirBytes.size / 128
        for (i in 0 until numEntries) {
            val base = i * 128
            val entryBuf = ByteBuffer.wrap(dirBytes, base, 128).slice().order(ByteOrder.LITTLE_ENDIAN)
            val nameLen = entryBuf.getShort(0x40).toInt() and 0xFFFF
            if (nameLen < 2 || nameLen > 64) continue
            val name = String(dirBytes, base, nameLen - 2, Charsets.UTF_16LE)
            val objType = dirBytes[base + 0x42].toInt() and 0xFF
            val startSec = entryBuf.getInt(0x74).toLong() and 0xFFFFFFFFL
            val streamSize = entryBuf.getInt(0x78).toLong() and 0xFFFFFFFFL

            if (objType == 5) { // Root Entry
                val rawRoot = readChain(startSec)
                val targetLen = streamSize.toInt().coerceIn(0, rawRoot.size)
                rootMiniContainer = rawRoot.copyOf(targetLen)
            } else if (objType == 2) { // Stream Object
                streams[name] = OleStream(startSec, streamSize)
            }
        }

        fun getStreamBytes(name: String): ByteArray? {
            val st = streams[name] ?: return null
            val targetSize = st.size.toInt().coerceIn(0, 32 * 1024 * 1024)
            if (targetSize == 0) return ByteArray(0)
            if (st.size < miniCutoff && miniFat.isNotEmpty() && rootMiniContainer.isNotEmpty()) {
                val out = java.io.ByteArrayOutputStream(targetSize)
                var sec = st.startSector
                val visited = HashSet<Long>()
                while (sec < SPECIAL_SEC_THRESHOLD && visited.add(sec) && out.size() < targetSize) {
                    val off = sec.toInt() * miniSectorSize
                    if (off < 0 || off >= rootMiniContainer.size) break
                    val len = (rootMiniContainer.size - off).coerceAtMost(miniSectorSize)
                    out.write(rootMiniContainer, off, len)
                    sec = if (sec.toInt() in miniFat.indices) miniFat[sec.toInt()] else SPECIAL_SEC_THRESHOLD
                }
                val res = out.toByteArray()
                return res.copyOf(targetSize.coerceAtMost(res.size))
            }
            val full = readChain(st.startSector, targetSize + sectorSize)
            return full.copyOf(targetSize.coerceAtMost(full.size))
        }

        val wordDoc = getStreamBytes("WordDocument") ?: return null
        if (wordDoc.size < 0x01AA) return null

        val fib = ByteBuffer.wrap(wordDoc).order(ByteOrder.LITTLE_ENDIAN)
        val flags = fib.getShort(0x0A).toInt() and 0xFFFF
        val tableName = if ((flags and 0x0200) != 0) "1Table" else "0Table"
        val tableStream = getStreamBytes(tableName)

        val ccpText = fib.getInt(0x4C).coerceAtLeast(0)
        val ccpFtn = fib.getInt(0x50).coerceAtLeast(0)
        val ccpHdr = fib.getInt(0x54).coerceAtLeast(0)
        val ccpMcr = fib.getInt(0x58).coerceAtLeast(0)
        val ccpAtn = fib.getInt(0x5C).coerceAtLeast(0)
        val ccpEdn = fib.getInt(0x60).coerceAtLeast(0)
        val fcClx = fib.getInt(0x01A2).toLong() and 0xFFFFFFFFL
        val lcbClx = fib.getInt(0x01A6).toLong() and 0xFFFFFFFFL

        val fullText: String = if (tableStream != null && lcbClx > 0 && fcClx + lcbClx <= tableStream.size) {
            extractPieceTableText(wordDoc, tableStream, fcClx.toInt(), lcbClx.toInt())
        } else {
            // Simple non-piece-table Word doc fallback
            val fcMin = fib.getInt(0x18).coerceIn(0, wordDoc.size)
            val fcMac = fib.getInt(0x1C).coerceIn(fcMin, wordDoc.size)
            String(wordDoc, fcMin, fcMac - fcMin, WINDOWS_1254)
        }

        if (fullText.isBlank()) return null

        val bodyEnd = ccpText.coerceIn(0, fullText.length)
        val bodyRaw = fullText.substring(0, bodyEnd)

        val ftnStart = bodyEnd
        val ftnEnd = (ftnStart + ccpFtn).coerceIn(ftnStart, fullText.length)
        val ftnRaw = if (ccpFtn > 0) fullText.substring(ftnStart, ftnEnd) else ""

        val ednStart = (ccpText.toLong() + ccpFtn + ccpHdr + ccpMcr + ccpAtn)
            .coerceIn(0L, fullText.length.toLong()).toInt()
        val ednEnd = (ednStart + ccpEdn).coerceIn(ednStart, fullText.length)
        val ednRaw = if (ccpEdn > 0) fullText.substring(ednStart, ednEnd) else ""

        val combinedNotesRaw = listOf(ftnRaw, ednRaw).filter { it.isNotBlank() }.joinToString("\r")
        val dataStream = getStreamBytes("Data")
        val headerImageBytes = dataStream?.let { extractBannerImageFromStream(it) }
        return buildStructuredDoc(bodyRaw, combinedNotesRaw, headerImageBytes)
    }

    private fun extractPieceTableText(
        wordDoc: ByteArray,
        tableStream: ByteArray,
        fcClx: Int,
        lcbClx: Int
    ): String {
        val clxEnd = (fcClx + lcbClx).coerceAtMost(tableStream.size)
        val tblBuf = ByteBuffer.wrap(tableStream).order(ByteOrder.LITTLE_ENDIAN)
        var pos = fcClx
        while (pos < clxEnd && (tableStream[pos].toInt() and 0xFF) == 1) {
            if (pos + 3 > clxEnd) break
            val cbGrpprl = tblBuf.getShort(pos + 1).toInt() and 0xFFFF
            pos += 3 + cbGrpprl
        }
        if (pos + 5 > clxEnd || (tableStream[pos].toInt() and 0xFF) != 2) return ""
        val lcbPcd = tblBuf.getInt(pos + 1).coerceAtLeast(0)
        val pcdStart = pos + 5
        val pcdEnd = (pcdStart + lcbPcd).coerceAtMost(tableStream.size)
        val actualLcb = pcdEnd - pcdStart
        if (actualLcb < 16) return ""

        val pieceCount = (actualLcb - 4) / 12
        val sb = StringBuilder()
        for (i in 0 until pieceCount) {
            val cpStart = tblBuf.getInt(pcdStart + i * 4)
            val cpNext = tblBuf.getInt(pcdStart + (i + 1) * 4)
            val cpLen = cpNext - cpStart
            if (cpLen <= 0) continue

            val pcdEntryPos = pcdStart + (pieceCount + 1) * 4 + i * 8
            if (pcdEntryPos + 8 > pcdEnd) break
            val fcRaw = tblBuf.getInt(pcdEntryPos + 2).toLong() and 0xFFFFFFFFL
            val compressed = (fcRaw and 0x40000000L) != 0L
            val fc = (fcRaw and 0x3FFFFFFFL).toInt()

            if (compressed) {
                val byteOff = fc / 2
                if (byteOff in wordDoc.indices) {
                    val safeLen = cpLen.coerceAtMost(wordDoc.size - byteOff)
                    sb.append(String(wordDoc, byteOff, safeLen, WINDOWS_1254))
                }
            } else {
                if (fc in wordDoc.indices) {
                    val safeByteLen = (cpLen * 2).coerceAtMost(wordDoc.size - fc)
                    val evenLen = safeByteLen - (safeByteLen % 2)
                    sb.append(String(wordDoc, fc, evenLen, Charsets.UTF_16LE))
                }
            }
        }
        return sb.toString()
    }

    private fun extractDocx(bytes: ByteArray): ExtractedHutbeDoc? {
        var docXml: ByteArray? = null
        var footnotesXml: ByteArray? = null
        var endnotesXml: ByteArray? = null
        val mediaImages = ArrayList<ByteArray>()

        ZipInputStream(ByteArrayInputStream(bytes)).use { zis ->
            var entry = zis.nextEntry
            while (entry != null) {
                val lowerName = entry.name.lowercase(java.util.Locale.ROOT)
                when {
                    lowerName == "word/document.xml" -> docXml = zis.readBytes()
                    lowerName == "word/footnotes.xml" -> footnotesXml = zis.readBytes()
                    lowerName == "word/endnotes.xml" -> endnotesXml = zis.readBytes()
                    lowerName.startsWith("word/media/") &&
                        (lowerName.endsWith(".png") || lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg")) -> {
                        val imgBytes = zis.readBytes()
                        if (imgBytes.size >= 3000) {
                            mediaImages.add(imgBytes)
                        }
                    }
                }
                entry = zis.nextEntry
            }
        }

        val mainBytes = docXml ?: return null
        val bodyParagraphs = parseWordprocessingParagraphs(mainBytes, noteMode = false)
        if (bodyParagraphs.isEmpty()) return null

        val noteLines = ArrayList<String>()
        footnotesXml?.let { noteLines.addAll(parseWordprocessingParagraphs(it, noteMode = true)) }
        endnotesXml?.let { noteLines.addAll(parseWordprocessingParagraphs(it, noteMode = true)) }

        val bestHeaderImg = pickBestBannerCandidate(mediaImages)
        return structureLines(bodyParagraphs, noteLines, bestHeaderImg)
    }

    private fun parseWordprocessingParagraphs(xmlBytes: ByteArray, noteMode: Boolean): List<String> {
        val factory = DocumentBuilderFactory.newInstance().apply {
            isNamespaceAware = false
        }
        val doc = factory.newDocumentBuilder().parse(ByteArrayInputStream(xmlBytes))
        val pNodes = doc.getElementsByTagName("w:p")
        val result = ArrayList<String>()
        var noteNum = 1
        for (i in 0 until pNodes.length) {
            val pEl = pNodes.item(i)
            val sb = StringBuilder()
            collectTextRuns(pEl, sb, noteMode) {
                sb.append("[${noteNum++}]")
            }
            val line = sb.toString().replace(Regex("\\s+"), " ").trim()
            if (line.isNotBlank()) {
                result.add(line)
            }
        }
        return result
    }

    private fun collectTextRuns(
        node: org.w3c.dom.Node,
        sb: StringBuilder,
        noteMode: Boolean,
        onRef: () -> Unit
    ) {
        val name = node.nodeName
        when {
            name == "w:t" || name == "w:delText" -> {
                sb.append(node.textContent ?: "")
            }
            name == "w:tab" -> sb.append(' ')
            name == "w:br" -> sb.append('\n')
            !noteMode && (name == "w:footnoteReference" || name == "w:endnoteReference") -> {
                onRef()
            }
            else -> {
                val children = node.childNodes
                for (i in 0 until children.length) {
                    collectTextRuns(children.item(i), sb, noteMode, onRef)
                }
            }
        }
    }

    private fun buildStructuredDoc(
        bodyRaw: String,
        notesRaw: String,
        headerImageBytes: ByteArray? = null
    ): ExtractedHutbeDoc? {
        val cleanedBody = cleanWordStreamText(bodyRaw, numberFootnoteRefs = true)
        val cleanedNotes = cleanWordStreamText(notesRaw, numberFootnoteRefs = true)

        val bodyLines = cleanedBody.split('\n')
            .map { it.replace(Regex("[ \\t]+"), " ").trim() }
            .filter { it.isNotBlank() }

        val noteLines = cleanedNotes.split('\n')
            .map { it.replace(Regex("[ \\t]+"), " ").trim() }
            .filter { it.isNotBlank() }

        return structureLines(bodyLines, noteLines, headerImageBytes)
    }

    private fun cleanWordStreamText(raw: String, numberFootnoteRefs: Boolean): String {
        val sb = StringBuilder(raw.length)
        var noteCounter = 1
        var fieldDepth = 0
        var inFieldCode = false

        for (ch in raw) {
            when (ch) {
                '\u0013' -> { // Field begin
                    fieldDepth++
                    inFieldCode = true
                }
                '\u0014' -> { // Field separator -> visible text follows
                    inFieldCode = false
                }
                '\u0015' -> { // Field end
                    if (fieldDepth > 0) fieldDepth--
                    if (fieldDepth == 0) inFieldCode = false
                }
                else -> {
                    if (inFieldCode) continue
                    when (ch) {
                        '\u0002' -> {
                            if (numberFootnoteRefs) {
                                if (sb.isNotEmpty() && !sb.last().isWhitespace()) {
                                    sb.append(' ')
                                }
                                sb.append("[${noteCounter++}] ")
                            }
                        }
                        '\r', '\u000B', '\u000C', '\u000E' -> sb.append('\n')
                        '\u0007', '\t' -> sb.append(' ')
                        '\u0001', '\u0003', '\u0004', '\u0005', '\u0008', '\u001E', '\u001F' -> Unit
                        else -> {
                            if (ch.code >= 0x20 || ch == '\n') {
                                sb.append(ch)
                            }
                        }
                    }
                }
            }
        }
        return sb.toString()
    }

    private fun structureLines(
        bodyLines: List<String>,
        noteLines: List<String>,
        headerImageBytes: ByteArray? = null
    ): ExtractedHutbeDoc? {
        if (bodyLines.isEmpty()) return null

        var idx = 0
        var dateDisplay = ""
        val dateRegex = Regex("^(?:Tarih|التَّارِيخُ|التاريخ)\\s*:\\s*(.+)$", RegexOption.IGNORE_CASE)
        val firstMatch = dateRegex.find(bodyLines[idx])
        if (firstMatch != null) {
            dateDisplay = firstMatch.groupValues[1].trim()
            idx++
        } else {
            // Also search top 2 lines in case an empty/punctuation marker preceded Tarih:
            val secondDateIdx = bodyLines.take(3).indexOfFirst { dateRegex.containsMatchIn(it) }
            if (secondDateIdx >= 0) {
                dateDisplay = dateRegex.find(bodyLines[secondDateIdx])!!.groupValues[1].trim()
                idx = secondDateIdx + 1
            }
        }

        val title = if (idx < bodyLines.size) {
            bodyLines[idx++].trim()
        } else {
            ""
        }

        val paragraphs = bodyLines.drop(idx).filter { it.isNotBlank() }
        val finalParagraphs = if (paragraphs.isNotEmpty()) paragraphs else bodyLines

        return ExtractedHutbeDoc(
            dateDisplay = dateDisplay,
            title = title,
            paragraphs = finalParagraphs,
            fullBodyText = finalParagraphs.joinToString("\n\n"),
            footnotes = noteLines.joinToString("\n"),
            headerImageBytes = headerImageBytes
        )
    }

    private fun extractBannerImageFromStream(stream: ByteArray): ByteArray? {
        val candidates = ArrayList<ByteArray>()

        // 1. Scan for embedded PNG images
        val pngSig = byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A)
        val pngEnd = byteArrayOf(0x49, 0x45, 0x4E, 0x44, 0xAE.toByte(), 0x42, 0x60, 0x82.toByte())
        var searchIdx = 0
        while (searchIdx < stream.size - 32) {
            val start = indexOfBytes(stream, pngSig, searchIdx)
            if (start < 0) break
            val end = indexOfBytes(stream, pngEnd, start + pngSig.size)
            val sliceEnd = if (end >= 0) end + pngEnd.size else stream.size
            val len = sliceEnd - start
            if (len >= 2000) {
                candidates.add(stream.copyOfRange(start, sliceEnd))
            }
            searchIdx = if (end >= 0) sliceEnd else stream.size
        }

        // 2. Scan for embedded JPEG images (skip 24x24 tiny thumbnails)
        val jpgSig = byteArrayOf(0xFF.toByte(), 0xD8.toByte(), 0xFF.toByte())
        searchIdx = 0
        while (searchIdx < stream.size - 64) {
            val start = indexOfBytes(stream, jpgSig, searchIdx)
            if (start < 0) break
            val jpgSlice = extractJpegSlice(stream, start)
            if (jpgSlice != null && jpgSlice.size >= 2000) {
                candidates.add(jpgSlice)
                searchIdx = start + jpgSlice.size
            } else {
                searchIdx = start + 3
            }
        }

        return pickBestBannerCandidate(candidates)
    }

    private fun extractJpegSlice(data: ByteArray, start: Int): ByteArray? {
        if (start + 4 >= data.size) return null
        var pos = start + 2
        while (pos + 1 < data.size) {
            if ((data[pos].toInt() and 0xFF) != 0xFF) {
                pos++
                continue
            }
            val marker = data[pos + 1].toInt() and 0xFF
            if (marker == 0xD9) {
                return data.copyOfRange(start, (pos + 2).coerceAtMost(data.size))
            }
            if (marker == 0x00 || marker == 0x01 || marker in 0xD0..0xD8) {
                pos += 2
                continue
            }
            if (marker == 0xDA) {
                // Start of Scan: scan forward for EOI (FF D9) that isn't byte-stuffed (FF 00) or RSTn
                var scan = pos + 2
                while (scan + 1 < data.size) {
                    if ((data[scan].toInt() and 0xFF) == 0xFF) {
                        val next = data[scan + 1].toInt() and 0xFF
                        if (next == 0xD9) {
                            return data.copyOfRange(start, scan + 2)
                        }
                        if (next != 0x00 && next !in 0xD0..0xD7 && next != 0xFF) {
                            // Another marker inside scan? Jump out cleanly
                            break
                        }
                    }
                    scan++
                }
                // Fallback to last FF D9 if scan loop ended
                for (k in (data.size - 2) downTo (start + 4)) {
                    if ((data[k].toInt() and 0xFF) == 0xFF && (data[k + 1].toInt() and 0xFF) == 0xD9) {
                        return data.copyOfRange(start, k + 2)
                    }
                }
                return null
            }
            if (pos + 4 > data.size) break
            val segLen = ((data[pos + 2].toInt() and 0xFF) shl 8) or (data[pos + 3].toInt() and 0xFF)
            if (segLen < 2) break
            pos += 2 + segLen
        }
        return null
    }

    private fun pickBestBannerCandidate(candidates: List<ByteArray>): ByteArray? {
        if (candidates.isEmpty()) return null
        var best: ByteArray? = null
        var bestScore = -1
        for (img in candidates) {
            val dims = readImageDimensions(img) ?: continue
            val (w, h) = dims
            // Diyanet Arabic header banners are wide rectangles (e.g., 286x199 to 834x476)
            if (w < 150 || h < 80) continue
            val wideBonus = if (w > h) 1_000_000 else 0
            val score = wideBonus + img.size
            if (score > bestScore) {
                bestScore = score
                best = img
            }
        }
        return best ?: candidates.maxByOrNull { it.size }
    }

    private fun readImageDimensions(bytes: ByteArray): Pair<Int, Int>? {
        if (bytes.size >= 24 && bytes.startsWith(byteArrayOf(0x89.toByte(), 0x50, 0x4E, 0x47))) {
            val w = ByteBuffer.wrap(bytes, 16, 4).order(ByteOrder.BIG_ENDIAN).int
            val h = ByteBuffer.wrap(bytes, 20, 4).order(ByteOrder.BIG_ENDIAN).int
            if (w > 0 && h > 0) return w to h
        }
        if (bytes.size >= 16 && (bytes[0].toInt() and 0xFF) == 0xFF && (bytes[1].toInt() and 0xFF) == 0xD8) {
            var pos = 2
            while (pos + 9 < bytes.size) {
                if ((bytes[pos].toInt() and 0xFF) != 0xFF) {
                    pos++
                    continue
                }
                val marker = bytes[pos + 1].toInt() and 0xFF
                if (marker == 0xC0 || marker == 0xC1 || marker == 0xC2 || marker == 0xC3) {
                    val h = ((bytes[pos + 5].toInt() and 0xFF) shl 8) or (bytes[pos + 6].toInt() and 0xFF)
                    val w = ((bytes[pos + 7].toInt() and 0xFF) shl 8) or (bytes[pos + 8].toInt() and 0xFF)
                    if (w > 0 && h > 0) return w to h
                    return null
                }
                if (marker == 0xD9 || marker == 0xDA) break
                if (marker == 0x00 || marker == 0x01 || marker in 0xD0..0xD8) {
                    pos += 2
                    continue
                }
                val segLen = ((bytes[pos + 2].toInt() and 0xFF) shl 8) or (bytes[pos + 3].toInt() and 0xFF)
                if (segLen < 2) break
                pos += 2 + segLen
            }
        }
        return null
    }

    private fun indexOfBytes(haystack: ByteArray, needle: ByteArray, fromIndex: Int): Int {
        if (needle.isEmpty() || fromIndex < 0 || fromIndex > haystack.size - needle.size) return -1
        outer@ for (i in fromIndex..(haystack.size - needle.size)) {
            for (j in needle.indices) {
                if (haystack[i + j] != needle[j]) continue@outer
            }
            return i
        }
        return -1
    }

    private fun ByteArray.startsWith(prefix: ByteArray): Boolean {
        if (size < prefix.size) return false
        for (i in prefix.indices) {
            if (this[i] != prefix[i]) return false
        }
        return true
    }
}
