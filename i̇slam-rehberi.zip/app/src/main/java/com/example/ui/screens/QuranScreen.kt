package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.local.QuranNavigationData
import com.example.data.local.QuranPageMetadata
import com.example.data.model.AppLanguage
import com.example.data.model.AyahItem
import com.example.data.model.QuranReciter
import com.example.data.model.SurahInfo
import com.example.ui.components.JuzListView
import com.example.ui.components.MushafPageView
import com.example.ui.components.PageNavigatorView
import com.example.ui.components.QuranBottomAudioBar
import com.example.ui.dialogs.FullQuranAudioDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.QuranUiState
import com.example.ui.viewmodel.QuranViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QuranScreen(
    viewModel: QuranViewModel,
    language: AppLanguage,
    isFullScreen: Boolean = false,
    onToggleFullScreen: (Boolean) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val state by viewModel.uiState.collectAsState()
    var selectedTab by remember { mutableIntStateOf(0) } // 0: Sayfalar, 1: Sureler, 2: Cüzler
    var showAllSurahsDialog by remember { mutableStateOf(false) }
    var showSearchJumpDialog by remember { mutableStateOf(false) }
    var showFullAudioDialog by remember { mutableStateOf(false) }
    var isSearchActive by remember { mutableStateOf(false) }

    val currentSurah = state.selectedSurah
    val surahInfo = currentSurah?.info

    val isKurmanji = language == AppLanguage.KURMANJI

    Surface(
        modifier = modifier
            .fillMaxSize()
            .testTag("quran_screen"),
        color = DarkBackground
    ) {
        Column(modifier = Modifier.fillMaxSize()) {
            // Single Compact Top Toolbar + Tabs (Hidden completely in Full-Screen reading mode)
            if (!isFullScreen) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    Text(
                        text = AppStrings.navQuran(language),
                        color = GoldBright,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )

                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showSearchJumpDialog = true }
                            .testTag("quran_hero_search_bar"),
                        color = EmeraldContainer,
                        border = BorderStroke(0.8.dp, GoldBright.copy(alpha = 0.8f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Search,
                                contentDescription = "Cüz, Ayet, Sayfa Ara",
                                tint = GoldBright,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (isKurmanji) "Lêbigere" else "Ara",
                                color = GoldBright,
                                fontSize = 13.sp,
                                softWrap = false,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showFullAudioDialog = true }
                            .testTag("full_quran_listen_hero_banner"),
                        color = DarkCard,
                        border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.7f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (state.isAudioPlaying) Icons.Filled.GraphicEq else Icons.Filled.Headphones,
                                contentDescription = "Kur'an Dinle",
                                tint = if (state.isAudioPlaying) GoldWarm else GoldBright,
                                modifier = Modifier.size(15.dp)
                            )
                            Spacer(modifier = Modifier.width(3.dp))
                            Text(
                                text = if (state.isAudioPlaying) {
                                    "${state.activeAudioSurah}."
                                } else {
                                    if (isKurmanji) "Guhdarî" else "Dinle"
                                },
                                color = GoldBright,
                                fontSize = 13.sp,
                                softWrap = false,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    IconButton(
                        onClick = { showAllSurahsDialog = true },
                        modifier = Modifier
                            .size(38.dp)
                            .testTag("all_surahs_button")
                    ) {
                        Icon(
                            Icons.Filled.List,
                            contentDescription = "Sureler",
                            tint = GoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Surface(
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onToggleFullScreen(true) }
                            .testTag("quran_fullscreen_button"),
                        color = GoldBright
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Fullscreen,
                                contentDescription = if (isKurmanji) "Dîmendera tam" else "Tam ekran oku",
                                tint = DarkBackground,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Text(
                                text = if (isKurmanji) "Tam" else "Tam",
                                color = DarkBackground,
                                fontSize = 13.sp,
                                softWrap = false,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }

                // Compact Navigation Tabs: Sayfalar (604) • Sureler (114) • Cüzler (30)
                TabRow(
                    selectedTabIndex = selectedTab,
                    containerColor = DarkSurface,
                    contentColor = GoldBright,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
                            color = GoldBright,
                            height = 2.5.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        modifier = Modifier.heightIn(min = 42.dp),
                        text = {
                            Text(
                                text = AppStrings.tabPages(language),
                                fontWeight = if (selectedTab == 0) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 15.sp
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        modifier = Modifier.heightIn(min = 42.dp),
                        text = {
                            Text(
                                text = AppStrings.tabSurahs(language),
                                fontWeight = if (selectedTab == 1) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 15.sp
                            )
                        }
                    )
                    Tab(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        modifier = Modifier.heightIn(min = 42.dp),
                        text = {
                            Text(
                                text = AppStrings.tabJuzs(language),
                                fontWeight = if (selectedTab == 2) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 15.sp
                            )
                        }
                    )
                }
            }

            // Main Reading Content Area
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
            ) {
                when (selectedTab) {
                    0 -> {
                        // Sayfalar (604 Pages) Authentic Mushaf Page Reader
                        MushafPageView(
                            pageDetail = state.currentPageDetail,
                            isLoading = state.isPageLoading,
                            language = language,
                            translationMode = state.translationMode,
                            fontSize = state.fontSize,
                            isRtlMode = state.isRtlMode,
                            isFullScreen = isFullScreen,
                            onPreviousPage = { viewModel.previousPage() },
                            onNextPage = { viewModel.nextPage() },
                            onJumpToPage = { page -> viewModel.loadPage(page) },
                            onToggleTranslationMode = { mode -> viewModel.setTranslationMode(mode) },
                            onToggleRtlMode = { viewModel.toggleRtlMode() },
                            onToggleFullScreen = { onToggleFullScreen(!isFullScreen) },
                            onIncreaseFontSize = { viewModel.increaseFontSize() },
                            onDecreaseFontSize = { viewModel.decreaseFontSize() }
                        )
                    }

                    2 -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (isFullScreen) {
                                FullScreenExitStrip(
                                    title = if (isKurmanji) "30 Ciz" else "30 Cüz",
                                    isKurmanji = isKurmanji,
                                    onExitFullScreen = { onToggleFullScreen(false) }
                                )
                            }
                            JuzListView(
                                language = language,
                                onSelectJuz = { juz ->
                                    viewModel.selectJuz(juz.number)
                                    selectedTab = 0
                                },
                                onPlayJuz = { juz ->
                                    viewModel.selectJuz(juz.number)
                                    viewModel.playSurahAudio(juz.startSurahNumber)
                                },
                                onDownloadJuz = { juz ->
                                    viewModel.downloadJuzAudio(juz.number)
                                },
                                downloadedSurahs = state.activeReciterDownloadedSurahs
                            )
                        }
                    }

                    1 -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            if (isFullScreen) {
                                FullScreenExitStrip(
                                    title = surahInfo?.let { "${it.number}. ${it.getDisplayName(language)}" }
                                        ?: AppStrings.tabSurahs(language),
                                    isKurmanji = isKurmanji,
                                    onExitFullScreen = { onToggleFullScreen(false) }
                                )
                            } else {
                                // Search Input if active
                                AnimatedVisibility(visible = isSearchActive) {
                                    OutlinedTextField(
                                        value = state.searchQuery,
                                        onValueChange = { viewModel.loadSurahs(it) },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 4.dp)
                                            .testTag("quran_search_text_input"),
                                        placeholder = {
                                            Text(AppStrings.searchSurah(language), color = TextMutedEmerald)
                                        },
                                        leadingIcon = {
                                            Icon(Icons.Filled.Search, contentDescription = null, tint = GoldBright)
                                        },
                                        singleLine = true,
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedTextColor = TextWhite,
                                            unfocusedTextColor = TextWhite,
                                            focusedBorderColor = GoldBright,
                                            unfocusedBorderColor = EmeraldBorder,
                                            focusedContainerColor = DarkSurfaceVariant,
                                            unfocusedContainerColor = DarkSurfaceVariant
                                        ),
                                        shape = RoundedCornerShape(12.dp)
                                    )
                                }

                                // Quick Surah Selector Row
                                LazyRow(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp),
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    items(state.surahs) { surah ->
                                        val isSelected = surahInfo?.number == surah.number
                                        Surface(
                                            modifier = Modifier
                                                .clip(RoundedCornerShape(12.dp))
                                                .clickable { viewModel.selectSurah(surah.number) }
                                                .testTag("quick_surah_chip_${surah.number}"),
                                            color = if (isSelected) EmeraldPrimary else DarkSurface,
                                            border = BorderStroke(
                                                1.dp,
                                                if (isSelected) GoldBright else DarkCardBorder
                                            )
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(
                                                    text = "${surah.number}. ",
                                                    color = GoldBright,
                                                    fontSize = 15.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = surah.getDisplayName(language),
                                                    color = if (isSelected) GoldBright else TextWhite,
                                                    fontSize = 15.sp,
                                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            // Reading Language Selector + Font Zoom + Full-Screen toggle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 4.dp),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TranslationFilterChip(
                                    label = if (language == AppLanguage.KURMANJI) "Erebî" else "Arapça",
                                    isSelected = state.translationMode == "AR",
                                    onClick = { viewModel.setTranslationMode("AR") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("surah_lang_chip_ar")
                                )
                                TranslationFilterChip(
                                    label = if (language == AppLanguage.KURMANJI) "Kurmancî" else "Kürtçe",
                                    isSelected = state.translationMode == "KU",
                                    onClick = { viewModel.setTranslationMode("KU") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("surah_lang_chip_ku")
                                )
                                TranslationFilterChip(
                                    label = "Türkçe",
                                    isSelected = state.translationMode == "TR",
                                    onClick = { viewModel.setTranslationMode("TR") },
                                    modifier = Modifier
                                        .weight(1f)
                                        .testTag("surah_lang_chip_tr")
                                )

                                Surface(
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .clip(RoundedCornerShape(9.dp))
                                        .clickable(enabled = state.fontSize > 32f) { viewModel.decreaseFontSize() }
                                        .testTag("surah_font_decrease"),
                                    color = DarkSurfaceVariant,
                                    border = BorderStroke(0.9.dp, GoldClassic.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "A-",
                                        color = if (state.fontSize > 32f) GoldBright else TextMutedEmerald.copy(alpha = 0.4f),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                    )
                                }

                                Surface(
                                    modifier = Modifier
                                        .minimumInteractiveComponentSize()
                                        .clip(RoundedCornerShape(9.dp))
                                        .clickable(enabled = state.fontSize < 92f) { viewModel.increaseFontSize() }
                                        .testTag("surah_font_increase"),
                                    color = DarkSurfaceVariant,
                                    border = BorderStroke(0.9.dp, GoldClassic.copy(alpha = 0.6f))
                                ) {
                                    Text(
                                        text = "A+",
                                        color = if (state.fontSize < 92f) GoldBright else TextMutedEmerald.copy(alpha = 0.4f),
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            // Surah Content List
                            LazyColumn(
                                modifier = Modifier
                                    .fillMaxSize()
                                    .padding(horizontal = if (isFullScreen) 2.dp else 4.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                if (surahInfo != null) {
                                    if (!isFullScreen) {
                                        item {
                                            SurahHeaderCard(
                                                surah = surahInfo,
                                                language = language,
                                                reciter = state.activeReciter,
                                                isAudioPlaying = state.isAudioPlaying && state.activeAudioSurah == surahInfo.number,
                                                isBuffering = state.isAudioBuffering && state.activeAudioSurah == surahInfo.number,
                                                audioProgress = if (state.activeAudioSurah == surahInfo.number) state.audioProgress else 0f,
                                                onToggleAudio = { viewModel.toggleAudioPlayback(surahInfo.number) },
                                                onSeek = { viewModel.seekAudio(it) },
                                                onOpenMushafPage = { page ->
                                                    viewModel.loadPage(page)
                                                    selectedTab = 0
                                                },
                                                onOpenFullPlayer = { showFullAudioDialog = true }
                                            )
                                        }
                                    }

                                    // Basmala (except Surah At-Tawbah #9 and Al-Fatiha #1)
                                    if (surahInfo.number != 9 && surahInfo.number != 1) {
                                        val basmalaSize = (state.fontSize * 0.80f).coerceIn(32f, 56f)
                                        item {
                                            Surface(
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(12.dp),
                                                color = DarkSurface
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(12.dp),
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    when (state.translationMode) {
                                                        "KU" -> Column(
                                                            horizontalAlignment = Alignment.CenterHorizontally
                                                        ) {
                                                            Text(
                                                                text = "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحٖیمِ",
                                                                style = TextStyle(
                                                                    fontFamily = DiyanetMushafFontFamily,
                                                                    color = GoldBright,
                                                                    fontSize = basmalaSize.sp,
                                                                    lineHeight = (basmalaSize * 1.7f).sp,
                                                                    letterSpacing = 0.sp,
                                                                    fontWeight = FontWeight.Normal,
                                                                    textAlign = TextAlign.Center,
                                                                    textDirection = TextDirection.Rtl
                                                                )
                                                            )
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = "Bi Navê Xwedayê Reḥman ê Reḥîm.",
                                                                color = TextWhite.copy(alpha = 0.92f),
                                                                fontSize = 18.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                textAlign = TextAlign.Center
                                                            )
                                                        }
                                                        "TR" -> Column(
                                                            horizontalAlignment = Alignment.CenterHorizontally
                                                        ) {
                                                            Text(
                                                                text = "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحٖیمِ",
                                                                style = TextStyle(
                                                                    fontFamily = DiyanetMushafFontFamily,
                                                                    color = GoldBright,
                                                                    fontSize = basmalaSize.sp,
                                                                    lineHeight = (basmalaSize * 1.7f).sp,
                                                                    letterSpacing = 0.sp,
                                                                    fontWeight = FontWeight.Normal,
                                                                    textAlign = TextAlign.Center,
                                                                    textDirection = TextDirection.Rtl
                                                                )
                                                            )
                                                            Spacer(modifier = Modifier.height(4.dp))
                                                            Text(
                                                                text = "Rahmân ve rahîm olan Allah’ın adıyla",
                                                                color = TextWhite.copy(alpha = 0.92f),
                                                                fontSize = 18.sp,
                                                                fontWeight = FontWeight.SemiBold,
                                                                textAlign = TextAlign.Center
                                                            )
                                                        }
                                                        else -> Text(
                                                            text = "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحٖیمِ",
                                                            style = TextStyle(
                                                                fontFamily = DiyanetMushafFontFamily,
                                                                color = GoldBright,
                                                                fontSize = basmalaSize.sp,
                                                                lineHeight = (basmalaSize * 1.7f).sp,
                                                                letterSpacing = 0.sp,
                                                                fontWeight = FontWeight.Normal,
                                                                textAlign = TextAlign.Center,
                                                                textDirection = TextDirection.Rtl
                                                            )
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }

                                    val ayahs = currentSurah.ayahs
                                    if (ayahs.isNotEmpty()) {
                                        items(ayahs) { ayah ->
                                            AyahItemCard(
                                                ayah = ayah,
                                                translationMode = state.translationMode,
                                                fontSize = state.fontSize
                                            )
                                        }
                                    } else {
                                        item {
                                            Surface(
                                                modifier = Modifier.fillMaxWidth(),
                                                shape = RoundedCornerShape(14.dp),
                                                color = DarkSurfaceVariant,
                                                border = BorderStroke(1.dp, EmeraldBorder)
                                            ) {
                                                Column(
                                                    modifier = Modifier.padding(18.dp),
                                                    horizontalAlignment = Alignment.CenterHorizontally
                                                ) {
                                                    Text(
                                                        text = surahInfo.nameArabic,
                                                        color = GoldBright,
                                                        fontSize = 32.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                    Spacer(modifier = Modifier.height(10.dp))
                                                    Text(
                                                        text = if (language == AppLanguage.KURMANJI)
                                                            "${surahInfo.nameKu} (${surahInfo.versesCount} Ayet • Rûpela ${surahInfo.startPage} • Ciz ${surahInfo.startJuz})\nJi bo guhdarîkirina vê sûreyê bi dengê Mîşarî Reşîd bişkoka lêxistinê ya jorîn bikirtînin."
                                                        else
                                                            "${surahInfo.nameTr} Suresi (${surahInfo.versesCount} Ayet • Sayfa ${surahInfo.startPage} • ${surahInfo.startJuz}. Cüz)\nBu surenin tamamını Şeyh Mişari Raşid tilavetiyle dinlemek için yukarıdaki ses oynatıcıyı başlatabilirsiniz.",
                                                        color = TextWhite,
                                                        fontSize = 17.sp,
                                                        textAlign = TextAlign.Center,
                                                        lineHeight = 24.sp
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }

                                item {
                                    Spacer(modifier = Modifier.height(20.dp))
                                }
                            }
                        }
                    }
                }
            }

            // Docked Bottom Audio Bar inside Column so it never hides Mushaf page navigation controls
            QuranBottomAudioBar(
                isVisible = state.isAudioActive || state.isAudioPlaying,
                surahNumber = state.activeAudioSurah,
                reciter = state.activeReciter,
                isPlaying = state.isAudioPlaying,
                isBuffering = state.isAudioBuffering,
                progress = state.audioProgress,
                currentTimeMs = state.audioCurrentTimeMs,
                durationMs = state.audioDurationMs,
                playbackSource = state.playbackSource,
                currentAyahLabel = state.currentAyahLabel,
                language = language,
                onTogglePlayPause = { viewModel.toggleAudioPlayback() },
                onPrevious = { viewModel.previousAudioSurah() },
                onNext = { viewModel.nextAudioSurah() },
                onOpenFullPlayer = { showFullAudioDialog = true },
                onClose = { viewModel.stopAudio() },
                modifier = Modifier.padding(bottom = 4.dp)
            )
        }
    }

    if (showAllSurahsDialog) {
        AllSurahsDialog(
            surahs = state.surahs,
            language = language,
            onDismiss = { showAllSurahsDialog = false },
            onSelectSurah = { num ->
                viewModel.selectSurah(num)
                selectedTab = 0
                showAllSurahsDialog = false
            },
            onPlaySurah = { num ->
                viewModel.selectSurah(num)
                viewModel.playSurahAudio(num)
                showAllSurahsDialog = false
            }
        )
    }

    if (showFullAudioDialog) {
        FullQuranAudioDialog(
            currentSurahNumber = state.activeAudioSurah,
            currentReciter = state.activeReciter,
            isPlaying = state.isAudioPlaying,
            isBuffering = state.isAudioBuffering,
            progress = state.audioProgress,
            currentTimeMs = state.audioCurrentTimeMs,
            durationMs = state.audioDurationMs,
            isAutoAdvance = state.isAutoAdvance,
            playbackSpeed = state.playbackSpeed,
            playbackSource = state.playbackSource,
            currentAyahLabel = state.currentAyahLabel,
            offlineVoiceMode = state.offlineVoiceMode,
            downloadedSurahs = state.activeReciterDownloadedSurahs,
            totalStorageBytes = state.totalAudioStorageBytes,
            downloadState = state.downloadState,
            audioErrorMessage = state.audioErrorMessage,
            language = language,
            onTogglePlayPause = { viewModel.toggleAudioPlayback() },
            onNext = { viewModel.nextAudioSurah() },
            onPrevious = { viewModel.previousAudioSurah() },
            onSeek = { viewModel.seekAudio(it) },
            onSeekForward10 = { viewModel.seekForward10s() },
            onSeekBackward10 = { viewModel.seekBackward10s() },
            onSelectSurah = { surahNumber ->
                viewModel.selectSurah(surahNumber)
                viewModel.playSurahAudio(surahNumber)
            },
            onSelectReciter = { reciter ->
                viewModel.setReciter(reciter)
            },
            onToggleAutoAdvance = {
                viewModel.toggleAutoAdvance()
            },
            onSetPlaybackSpeed = { speed ->
                viewModel.setPlaybackSpeed(speed)
            },
            onSetOfflineVoiceMode = { mode ->
                viewModel.setOfflineVoiceMode(mode)
            },
            onDownloadSurah = { surahNum ->
                viewModel.downloadSurahAudio(surahNum)
            },
            onDownloadAllSurahs = {
                viewModel.downloadAllSurahsAudio()
            },
            onCancelDownload = {
                viewModel.cancelAudioDownload()
            },
            onDeleteReciterDownloads = {
                viewModel.deleteReciterAudio()
            },
            onOpenMushafPage = { page ->
                viewModel.loadPage(page)
                selectedTab = 0
                showFullAudioDialog = false
            },
            onDismiss = { showFullAudioDialog = false }
        )
    }

    if (showSearchJumpDialog) {
        QuranSearchJumpDialog(
            currentPage = state.selectedPage,
            language = language,
            allSurahs = state.surahs,
            onDismiss = { showSearchJumpDialog = false },
            onJumpToPage = { targetPage ->
                viewModel.loadPage(targetPage)
                selectedTab = 0
                showSearchJumpDialog = false
            }
        )
    }
}

@Composable
private fun FullScreenExitStrip(
    title: String,
    isKurmanji: Boolean,
    onExitFullScreen: () -> Unit
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        color = DarkSurface,
        border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.4f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                text = title,
                color = GoldBright,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = GoldBright,
                modifier = Modifier
                    .minimumInteractiveComponentSize()
                    .clip(RoundedCornerShape(8.dp))
                    .clickable(onClick = onExitFullScreen)
                    .testTag("surah_fullscreen_exit")
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Filled.FullscreenExit,
                        contentDescription = if (isKurmanji) "Dîmendera tam bigire" else "Tam ekrandan çık",
                        tint = DarkBackground,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = if (isKurmanji) "Biçûk" else "Küçült",
                        color = DarkBackground,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun TranslationFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 40.dp)
            .clip(RoundedCornerShape(9.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) GoldBright else DarkSurface,
        border = BorderStroke(1.dp, if (isSelected) GoldWarm else DarkCardBorder)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                color = if (isSelected) DarkBackground else TextWhite,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 14.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SurahHeaderCard(
    surah: SurahInfo,
    language: AppLanguage,
    reciter: QuranReciter,
    isAudioPlaying: Boolean,
    isBuffering: Boolean,
    audioProgress: Float,
    onToggleAudio: () -> Unit,
    onSeek: (Float) -> Unit,
    onOpenMushafPage: (Int) -> Unit,
    onOpenFullPlayer: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp)),
        color = DarkCard,
        border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.6f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(EmeraldPrimary.copy(alpha = 0.4f), DarkCard)
                    )
                )
                .padding(18.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = surah.nameArabic,
                    color = GoldBright,
                    fontSize = 36.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${surah.number}. ${surah.getDisplayName(language)} - ${surah.getMeaning(language)}",
                    color = TextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = "${surah.versesCount} Ayet • ${if (isKurmanji) "Ciz" else "Cüz"} ${surah.startJuz} • ${if (isKurmanji) "Rûpel" else "Sayfa"} ${surah.startPage} • ${surah.getRevelation(language)}",
                    color = TextMutedEmerald,
                    fontSize = 16.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Button to jump directly to this Surah in the Mushaf Page Reader
                OutlinedButton(
                    onClick = { onOpenMushafPage(surah.startPage) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 44.dp)
                        .testTag("open_mushaf_page_button_${surah.number}"),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, GoldClassic),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldBright)
                ) {
                    Icon(Icons.Filled.AutoStories, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isKurmanji) "Mûshefê Veke (Rûpela ${surah.startPage})" else "Mushaf Sayfasını Oku (Sayfa ${surah.startPage})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Audio Recitation Player Card with Reciter display and Hatim Hub link
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(0.8.dp, EmeraldBorder)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 10.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(
                                onClick = onToggleAudio,
                                modifier = Modifier
                                    .size(44.dp)
                                    .background(GoldBright, CircleShape)
                                    .testTag("quran_audio_play_button")
                            ) {
                                if (isBuffering) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = DarkBackground,
                                        strokeWidth = 2.dp
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isAudioPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                        contentDescription = "Oynat/Durdur",
                                        tint = DarkBackground
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(12.dp))

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = reciter.getDisplayName(language),
                                        color = TextWhite,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                    IconButton(
                                        onClick = onOpenFullPlayer,
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.OpenInFull,
                                            contentDescription = "Hatim & Tilavet Merkezi",
                                            tint = GoldBright,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Slider(
                                    value = audioProgress,
                                    onValueChange = onSeek,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(20.dp),
                                    colors = SliderDefaults.colors(
                                        thumbColor = GoldBright,
                                        activeTrackColor = GoldBright,
                                        inactiveTrackColor = EmeraldBorder
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AyahItemCard(
    ayah: AyahItem,
    translationMode: String,
    fontSize: Float
) {
    val mealTextSize = (fontSize * 0.48f).coerceIn(20f, 36f)
    val markerColor = GoldBright
    val arabicWithMarker = remember(ayah.textArabic, ayah.numberInSurah, fontSize, markerColor) {
        buildAnnotatedString {
            append(ayah.textArabic)
            withStyle(
                SpanStyle(
                    color = markerColor,
                    fontFamily = DiyanetMushafFontFamily,
                    fontWeight = FontWeight.Normal,
                    fontSize = (fontSize * 0.82f).sp,
                    letterSpacing = 0.sp
                )
            ) {
                append("\u00A0\uFD3F${ayah.numberInSurah}\uFD3E")
            }
        }
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .testTag("ayah_card_${ayah.numberInSurah}"),
        color = MushafPaperSurface,
        border = BorderStroke(0.7.dp, DarkCardBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 10.dp)
        ) {
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                Text(
                    text = arabicWithMarker,
                    style = TextStyle(
                        fontFamily = DiyanetMushafFontFamily,
                        color = TextWhite,
                        fontSize = fontSize.sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Start,
                        textDirection = TextDirection.Rtl,
                        lineHeight = (fontSize * 1.90f).sp,
                        letterSpacing = 0.sp
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }

            if (translationMode == "KU" || translationMode == "TR") {
                Spacer(modifier = Modifier.height(8.dp))
                HorizontalDivider(
                    color = GoldClassic.copy(alpha = 0.25f),
                    thickness = 0.8.dp
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.Top
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (translationMode == "KU") GoldContainer else EmeraldContainer,
                        border = BorderStroke(0.9.dp, GoldBright),
                        modifier = Modifier
                            .padding(top = 3.dp)
                            .size(30.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = ayah.numberInSurah.toString(),
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (translationMode == "KU") ayah.translationKuLatin else ayah.translationTr,
                        color = TextWhite.copy(alpha = 0.96f),
                        fontSize = mealTextSize.sp,
                        lineHeight = (mealTextSize * 1.48f).sp,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }
    }
}

@Composable
private fun AllSurahsDialog(
    surahs: List<SurahInfo>,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSelectSurah: (Int) -> Unit,
    onPlaySurah: (Int) -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isKurmanji) "Hemû Sûre (114)" else "Bütün Sureler (114 Sure)",
                color = GoldBright,
                fontSize = 21.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(420.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(surahs) { surah ->
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onSelectSurah(surah.number) },
                        color = DarkSurface
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "${surah.number}.",
                                    color = GoldBright,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(38.dp)
                                )
                                Column {
                                    Text(
                                        text = surah.getDisplayName(language),
                                        color = TextWhite,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 17.sp
                                    )
                                    Text(
                                        text = "${surah.versesCount} Ayet • ${if (isKurmanji) "Rûpel" else "Sayfa"} ${surah.startPage}",
                                        color = TextMutedEmerald,
                                        fontSize = 14.sp
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = surah.nameArabic,
                                    color = GoldWarm,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                IconButton(
                                    onClick = { onPlaySurah(surah.number) },
                                    modifier = Modifier
                                        .size(36.dp)
                                        .background(GoldBright.copy(alpha = 0.15f), CircleShape)
                                        .testTag("play_surah_dialog_${surah.number}")
                                ) {
                                    Icon(
                                        Icons.Filled.PlayArrow,
                                        contentDescription = "Dinle",
                                        tint = GoldBright,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isKurmanji) "Girtin" else "Kapat", color = GoldBright)
            }
        },
        containerColor = DarkCard
    )
}

@Composable
private fun QuranSearchJumpDialog(
    currentPage: Int,
    language: AppLanguage,
    allSurahs: List<SurahInfo>,
    onDismiss: () -> Unit,
    onJumpToPage: (Int) -> Unit
) {
    var selectedSearchTab by remember { mutableIntStateOf(0) } // 0: Sayfa, 1: Cüz, 2: Ayet
    val isKurmanji = language == AppLanguage.KURMANJI

    // Tab 0 State: Sayfa
    var pageInput by remember { mutableStateOf(currentPage.toString()) }
    var pageSlider by remember { mutableFloatStateOf(currentPage.toFloat()) }

    // Tab 1 State: Cüz
    val juzList = remember { QuranNavigationData.JUZ_LIST }

    // Tab 2 State: Sure & Ayet
    var surahSearchQuery by remember { mutableStateOf("") }
    var selectedSurah by remember { mutableStateOf<SurahInfo?>(allSurahs.firstOrNull()) }
    var ayahInput by remember { mutableStateOf("1") }

    val filteredSurahs = remember(surahSearchQuery, allSurahs) {
        if (surahSearchQuery.isBlank()) allSurahs
        else allSurahs.filter {
            it.nameTr.contains(surahSearchQuery, ignoreCase = true) ||
            it.nameKu.contains(surahSearchQuery, ignoreCase = true) ||
            it.nameArabic.contains(surahSearchQuery, ignoreCase = true) ||
            it.number.toString() == surahSearchQuery.trim()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.FindInPage,
                    contentDescription = null,
                    tint = GoldBright,
                    modifier = Modifier.size(24.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (isKurmanji) "Lêgerîna Ciz, Ayet û Rûpelan" else "Cüz, Ayet ve Sayfa Arama",
                    color = GoldBright,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .height(440.dp)
            ) {
                // 3 Tabs: Sayfa • Cüz • Ayet
                TabRow(
                    selectedTabIndex = selectedSearchTab,
                    containerColor = DarkSurface,
                    contentColor = GoldBright,
                    indicator = { tabPositions ->
                        TabRowDefaults.SecondaryIndicator(
                            Modifier.tabIndicatorOffset(tabPositions[selectedSearchTab]),
                            color = GoldBright,
                            height = 2.5.dp
                        )
                    }
                ) {
                    Tab(
                        selected = selectedSearchTab == 0,
                        onClick = { selectedSearchTab = 0 },
                        text = {
                            Text(
                                text = if (isKurmanji) "Rûpel" else "Sayfa",
                                fontSize = 14.sp,
                                fontWeight = if (selectedSearchTab == 0) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                    Tab(
                        selected = selectedSearchTab == 1,
                        onClick = { selectedSearchTab = 1 },
                        text = {
                            Text(
                                text = if (isKurmanji) "Ciz (30)" else "Cüz (30)",
                                fontSize = 14.sp,
                                fontWeight = if (selectedSearchTab == 1) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                    Tab(
                        selected = selectedSearchTab == 2,
                        onClick = { selectedSearchTab = 2 },
                        text = {
                            Text(
                                text = if (isKurmanji) "Ayet & Sûre" else "Ayet & Sure",
                                fontSize = 14.sp,
                                fontWeight = if (selectedSearchTab == 2) FontWeight.Bold else FontWeight.Medium
                            )
                        }
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                when (selectedSearchTab) {
                    // TAB 0: SAYFAYA GİT
                    0 -> {
                        Column(
                            modifier = Modifier.fillMaxSize(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = "${pageSlider.toInt()} / 604",
                                color = GoldBright,
                                fontSize = 34.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            Text(
                                text = if (isKurmanji) "Rûpelên Qur'anê" else "Medine Mushaf Sayfası",
                                color = TextMutedEmerald,
                                fontSize = 14.sp
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Slider(
                                value = pageSlider,
                                onValueChange = {
                                    pageSlider = it
                                    pageInput = it.toInt().toString()
                                },
                                valueRange = 1f..604f,
                                colors = SliderDefaults.colors(
                                    thumbColor = GoldBright,
                                    activeTrackColor = GoldBright,
                                    inactiveTrackColor = DarkCardBorder
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                OutlinedTextField(
                                    value = pageInput,
                                    onValueChange = { str ->
                                        pageInput = str
                                        str.toIntOrNull()?.let {
                                            if (it in 1..604) pageSlider = it.toFloat()
                                        }
                                    },
                                    label = { Text(if (isKurmanji) "Hejmar (1 - 604)" else "Sayfa No (1 - 604)", color = TextMutedEmerald) },
                                    singleLine = true,
                                    colors = OutlinedTextFieldDefaults.colors(
                                        focusedTextColor = TextWhite,
                                        unfocusedTextColor = TextWhite,
                                        focusedBorderColor = GoldBright,
                                        unfocusedBorderColor = EmeraldBorder
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier.width(140.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = {
                                        val p = pageInput.toIntOrNull()?.coerceIn(1, 604) ?: pageSlider.toInt()
                                        onJumpToPage(p)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = GoldBright, contentColor = DarkBackground),
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Text(if (isKurmanji) "Here" else "Git", fontWeight = FontWeight.Bold)
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = if (isKurmanji) "Rûpelên Girîng:" else "Hızlı Sayfalar:",
                                color = GoldWarm,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))

                            val quickJumpItems = listOf(
                                1 to "Fâtiha (1)",
                                2 to "Bakara (2)",
                                42 to "Ayetel-Kürsi (42)",
                                440 to "Yâsîn (440)",
                                562 to "Mülk (562)",
                                604 to "İhlâs (604)"
                            )
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                quickJumpItems.chunked(3).forEach { rowItems ->
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                                    ) {
                                        rowItems.forEach { (pg, lbl) ->
                                            Surface(
                                                shape = RoundedCornerShape(8.dp),
                                                color = DarkSurface,
                                                border = BorderStroke(0.6.dp, GoldWarm.copy(alpha = 0.5f)),
                                                modifier = Modifier
                                                    .weight(1f)
                                                    .clickable { onJumpToPage(pg) }
                                            ) {
                                                Text(
                                                    text = lbl,
                                                    color = TextWhite,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Medium,
                                                    maxLines = 1,
                                                    overflow = TextOverflow.Ellipsis,
                                                    textAlign = TextAlign.Center,
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 6.dp, vertical = 6.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // TAB 1: CÜZE GİT
                    1 -> {
                        LazyColumn(
                            modifier = Modifier.fillMaxSize(),
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            items(juzList) { juz ->
                                Surface(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onJumpToPage(juz.startPage) }
                                        .testTag("jump_juz_card_${juz.number}"),
                                    color = DarkSurface,
                                    border = BorderStroke(0.6.dp, GoldClassic.copy(alpha = 0.3f))
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 12.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Surface(
                                                shape = CircleShape,
                                                color = EmeraldContainer,
                                                border = BorderStroke(1.dp, GoldBright),
                                                modifier = Modifier.size(32.dp)
                                            ) {
                                                Box(contentAlignment = Alignment.Center) {
                                                    Text(
                                                        text = juz.number.toString(),
                                                        color = GoldBright,
                                                        fontSize = 14.sp,
                                                        fontWeight = FontWeight.Bold
                                                    )
                                                }
                                            }
                                            Spacer(modifier = Modifier.width(10.dp))
                                            Column {
                                                Text(
                                                    text = if (isKurmanji) "${juz.number}. Ciz" else "${juz.number}. Cüz",
                                                    color = TextWhite,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.SemiBold
                                                )
                                                Text(
                                                    text = "${if (isKurmanji) juz.startSurahNameKu else juz.startSurahNameTr} (${juz.startAyah}) → ${if (isKurmanji) juz.endSurahNameKu else juz.endSurahNameTr} (${juz.endAyah})",
                                                    color = TextMutedEmerald,
                                                    fontSize = 13.sp
                                                )
                                            }
                                        }

                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = GoldContainer,
                                            border = BorderStroke(0.6.dp, GoldBright)
                                        ) {
                                            Text(
                                                text = "${if (isKurmanji) "Rûpel" else "Sayfa"} ${juz.startPage}",
                                                color = GoldBright,
                                                fontSize = 13.sp,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // TAB 2: AYET VE SUREYE GİT
                    2 -> {
                        Column(modifier = Modifier.fillMaxSize()) {
                            // Surah search input
                            OutlinedTextField(
                                value = surahSearchQuery,
                                onValueChange = { surahSearchQuery = it },
                                placeholder = {
                                    Text(if (isKurmanji) "Sûre lêbigere (mînak: Beqere, Yasîn...)" else "Sure ara (örn: Bakara, Yasin...)", color = TextMutedEmerald, fontSize = 15.sp)
                                },
                                leadingIcon = {
                                    Icon(Icons.Filled.Search, contentDescription = null, tint = GoldBright, modifier = Modifier.size(18.dp))
                                },
                                singleLine = true,
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = TextWhite,
                                    unfocusedTextColor = TextWhite,
                                    focusedBorderColor = GoldBright,
                                    unfocusedBorderColor = EmeraldBorder
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 52.dp)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Selected Surah & Ayah Input Card
                            if (selectedSurah != null) {
                                val surah = selectedSurah!!
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(10.dp),
                                    color = EmeraldContainer,
                                    border = BorderStroke(1.dp, GoldBright)
                                ) {
                                    Column(modifier = Modifier.padding(10.dp)) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Column {
                                                Text(
                                                    text = "${surah.number}. ${surah.getDisplayName(language)}",
                                                    color = GoldBright,
                                                    fontSize = 16.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                                Text(
                                                    text = "${surah.versesCount} Ayet",
                                                    color = TextWhite,
                                                    fontSize = 14.sp
                                                )
                                            }
                                            Text(
                                                text = surah.nameArabic,
                                                color = GoldWarm,
                                                fontSize = 18.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))

                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            OutlinedTextField(
                                                value = ayahInput,
                                                onValueChange = { ayahInput = it },
                                                label = {
                                                    Text(
                                                        if (isKurmanji) "Ayet (1 - ${surah.versesCount})" else "Ayet No (1 - ${surah.versesCount})",
                                                        color = TextMutedEmerald,
                                                        fontSize = 14.sp
                                                    )
                                                },
                                                singleLine = true,
                                                colors = OutlinedTextFieldDefaults.colors(
                                                    focusedTextColor = TextWhite,
                                                    unfocusedTextColor = TextWhite,
                                                    focusedBorderColor = GoldBright,
                                                    unfocusedBorderColor = EmeraldBorder
                                                ),
                                                shape = RoundedCornerShape(8.dp),
                                                modifier = Modifier.weight(1f)
                                            )

                                            Spacer(modifier = Modifier.width(8.dp))

                                            Button(
                                                onClick = {
                                                    val aNum = ayahInput.toIntOrNull()?.coerceIn(1, surah.versesCount) ?: 1
                                                    val targetPage = QuranPageMetadata.getPageForVerse(surah.number, aNum)
                                                    onJumpToPage(targetPage)
                                                },
                                                colors = ButtonDefaults.buttonColors(containerColor = GoldBright, contentColor = DarkBackground),
                                                shape = RoundedCornerShape(8.dp)
                                            ) {
                                                Text(if (isKurmanji) "Ayete Here" else "Ayete Git", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = if (isKurmanji) "Sûre Hilbijêre:" else "Sure Seç:",
                                color = GoldWarm,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )

                            Spacer(modifier = Modifier.height(4.dp))

                            LazyColumn(
                                modifier = Modifier.weight(1f),
                                verticalArrangement = Arrangement.spacedBy(4.dp)
                            ) {
                                items(filteredSurahs) { surah ->
                                    val isSelected = selectedSurah?.number == surah.number
                                    Surface(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .clickable { selectedSurah = surah },
                                        color = if (isSelected) EmeraldPrimary else DarkSurface,
                                        border = BorderStroke(0.6.dp, if (isSelected) GoldBright else DarkCardBorder)
                                    ) {
                                        Row(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .padding(horizontal = 8.dp, vertical = 6.dp),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Row(verticalAlignment = Alignment.CenterVertically) {
                                                Text(
                                                    text = "${surah.number}.",
                                                    color = GoldBright,
                                                    fontSize = 14.sp,
                                                    fontWeight = FontWeight.Bold,
                                                    modifier = Modifier.width(32.dp)
                                                )
                                                Text(
                                                    text = surah.getDisplayName(language),
                                                    color = if (isSelected) GoldBright else TextWhite,
                                                    fontSize = 15.sp,
                                                    fontWeight = FontWeight.Medium
                                                )
                                            }
                                            Text(
                                                text = "${surah.versesCount} Ayet",
                                                color = TextMutedEmerald,
                                                fontSize = 13.sp
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isKurmanji) "Girtin" else "Kapat", color = GoldBright)
            }
        },
        containerColor = DarkCard
    )
}
