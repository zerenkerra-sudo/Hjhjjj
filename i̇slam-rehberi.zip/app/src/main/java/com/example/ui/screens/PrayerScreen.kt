package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.Notifications
import androidx.compose.material.icons.outlined.NotificationsOff
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppPreferences
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import com.example.service.AdhanPlayerService
import com.example.ui.components.NavScreen
import com.example.ui.components.WeatherVisualCard
import com.example.ui.dialogs.CitySelectionDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.PrayerUiState

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PrayerScreen(
    state: PrayerUiState,
    language: AppLanguage,
    onSelectCity: (City) -> Unit,
    onRequestGps: () -> Unit,
    onToggleAdhan: (PrayerType, Boolean) -> Unit,
    onRefresh: () -> Unit,
    onOpenAlarmSettings: () -> Unit,
    preferences: AppPreferences,
    onNavigateToScreen: (NavScreen) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showCityDialog by remember { mutableStateOf(false) }
    var showAllDuasDialog by remember { mutableStateOf(false) }
    var showHutbeDialog by remember { mutableStateOf(false) }
    var showReligiousDaysDialog by remember { mutableStateOf(false) }
    var selectedReligiousDayDetail by remember { mutableStateOf<com.example.data.model.ReligiousDay?>(null) }

    val isAdhanPlaying by AdhanPlayerService.isPlayingFlow.collectAsState()
    val playingPrayerName by AdhanPlayerService.currentPrayerNameFlow.collectAsState()

    val times = state.prayerTimes

    Scaffold(
        modifier = modifier.testTag("prayer_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = AppStrings.appTitle(language),
                            color = GoldBright,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = times?.dateReadable ?: "",
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }
                },
                actions = {
                    // City & District selector badge button
                    Surface(
                        modifier = Modifier
                            .widthIn(max = 175.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { showCityDialog = true }
                            .testTag("select_city_chip"),
                        color = EmeraldContainer,
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (state.isGpsActive) Icons.Filled.MyLocation else Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = state.selectedCity.getDisplayName(language),
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Spacer(modifier = Modifier.width(2.dp))
                            Icon(
                                Icons.Filled.ArrowDropDown,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    IconButton(
                        onClick = onRefresh,
                        modifier = Modifier.testTag("refresh_prayer_button")
                    ) {
                        Icon(Icons.Filled.Refresh, contentDescription = "Yenile", tint = GoldBright)
                    }

                    IconButton(
                        onClick = { onNavigateToScreen(NavScreen.Settings) },
                        modifier = Modifier.testTag("settings_button")
                    ) {
                        Icon(Icons.Filled.Settings, contentDescription = "Ayarlar", tint = GoldBright)
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Live Adhan Playing Banner
            item {
                AnimatedVisibility(visible = isAdhanPlaying) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(16.dp))
                            .testTag("live_adhan_playing_banner"),
                        color = GoldDark,
                        border = BorderStroke(1.5.dp, GoldBright)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Filled.VolumeUp,
                                    contentDescription = null,
                                    tint = TextWhite,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (language == AppLanguage.KURMANJI) "Bang Dixwîne!" else "Ezan Okunuyor!",
                                        color = TextWhite,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                    Text(
                                        text = "$playingPrayerName • " + (if (language == AppLanguage.KURMANJI) "Dengê Medyayê" else "Medya Sesi"),
                                        color = GoldBright,
                                        fontSize = 15.sp
                                    )
                                }
                            }

                            Button(
                                onClick = { AdhanPlayerService.stopAdhan(context) },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = DarkBackground,
                                    contentColor = GoldBright
                                ),
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.testTag("stop_live_adhan_button")
                            ) {
                                Text(
                                    text = if (language == AppLanguage.KURMANJI) "Bisekine" else "Durdur",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // Exact Alarm Permission Warning
            if (state.exactAlarmPermissionNeeded) {
                item {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp)),
                        color = Color(0xFF4A1208),
                        border = BorderStroke(1.dp, Color(0xFFFF7043))
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                Icons.Filled.Warning,
                                contentDescription = null,
                                tint = Color(0xFFFFAB91),
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(12.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = AppStrings.permissionExactAlarmTitle(language),
                                    color = TextWhite,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                )
                                Text(
                                    text = AppStrings.permissionExactAlarmDesc(language),
                                    color = Color(0xFFFFCCBC),
                                    fontSize = 15.sp,
                                    lineHeight = 20.sp
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = onOpenAlarmSettings,
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF7043)),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = AppStrings.grantPermission(language),
                                    color = TextWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 1. Günün Duası (Kısa ve Net Kur'an Ayeti)
            item {
                val todayDua = remember { com.example.data.local.QuranDuasData.getTodayDua() }
                DailyQuranDuaCard(
                    dua = todayDua,
                    language = language,
                    onViewAllDuas = { showAllDuasDialog = true }
                )
            }

            // 2. Günün Namaz Saatleri (Sıradaki Vakit + 6 Vakit Kartları)
            item {
                HeroPrayerCard(
                    times = times,
                    nextPrayer = state.nextPrayer,
                    language = language
                )
            }

            if (times?.isOffline == true) {
                item {
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(10.dp),
                        color = DarkSurface,
                        border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            Text(
                                text = AppStrings.offlineBadge(language),
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            item {
                Text(
                    text = if (language == AppLanguage.KURMANJI) "Demên Nimêjê Yên Îro" else "Günün Namaz Saatleri",
                    color = GoldBright,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.padding(top = 4.dp, bottom = 2.dp)
                )
            }

            items(PrayerType.entries) { prayer ->
                val timeStr = times?.getTimeFor(prayer) ?: "--:--"
                val isCurrent = state.activePrayer == prayer
                val isAdhanOn = if (prayer.hasAdhan) preferences.isAdhanEnabled(prayer) else false

                PrayerTimeRowItem(
                    prayer = prayer,
                    time = timeStr,
                    isCurrent = isCurrent,
                    language = language,
                    isAdhanEnabled = isAdhanOn,
                    onToggleAdhan = { enabled ->
                        onToggleAdhan(prayer, enabled)
                    }
                )
            }

            // 3. 7 Günlük Görsel Hava Durumu Sistemi (Namaz saatlerinin altında)
            item {
                WeatherVisualCard(
                    weather = state.weatherInfo,
                    selectedCity = state.selectedCity,
                    isLoading = state.isWeatherLoading,
                    errorMessage = state.weatherError,
                    language = language,
                    todayIso = times?.dateIso,
                    onChangeLocation = { showCityDialog = true },
                    onRefreshWeather = onRefresh
                )
            }

            // 4. Quick Islamic Services Dashboard Grid (Kur'an Mushaf, Elifba, Cuma Hutbesi, Kıble, Dini Günler, Dualar)
            item {
                IslamicServicesDashboard(
                    language = language,
                    onNavigateToQuran = { onNavigateToScreen(NavScreen.Quran) },
                    onNavigateToElifba = { onNavigateToScreen(NavScreen.Elifba) },
                    onNavigateToQibla = { onNavigateToScreen(NavScreen.Qibla) },
                    onOpenHutbe = { onNavigateToScreen(NavScreen.Hutbe) },
                    onOpenReligiousDays = { showReligiousDaysDialog = true },
                    onOpenDuas = { showAllDuasDialog = true },
                    onOpenTesbihat = { onNavigateToScreen(NavScreen.Tesbihat) },
                    onOpenEsma = { onNavigateToScreen(NavScreen.EsmaUlHusna) }
                )
            }

            // 5. Haftanın Cuma Hutbesi Card
            item {
                WeeklyHutbeCard(
                    hutbe = state.currentHutbe,
                    language = language,
                    isLoading = state.isHutbeLoading,
                    onReadHutbe = { onNavigateToScreen(NavScreen.Hutbe) }
                )
            }

            // 6. Yaklaşan Dini Günler ve Kandiller Card
            item {
                val nextEvent = remember { com.example.data.local.ReligiousDaysData.getNextUpcomingReligiousDay() }
                if (nextEvent != null) {
                    UpcomingReligiousDayCard(
                        eventPair = nextEvent,
                        language = language,
                        onOpenDetail = { selectedReligiousDayDetail = nextEvent.first },
                        onViewCalendar = { showReligiousDaysDialog = true }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    if (showCityDialog) {
        CitySelectionDialog(
            language = language,
            currentCity = state.selectedCity,
            onDismiss = { showCityDialog = false },
            onSelectCity = onSelectCity,
            onRequestGps = onRequestGps
        )
    }

    if (showAllDuasDialog) {
        com.example.ui.dialogs.AllDuasDialog(
            language = language,
            onDismiss = { showAllDuasDialog = false }
        )
    }

    if (showHutbeDialog) {
        com.example.ui.dialogs.HutbeDetailDialog(
            hutbe = state.currentHutbe,
            language = language,
            archive = state.hutbeArchive,
            onDismiss = { showHutbeDialog = false }
        )
    }

    if (showReligiousDaysDialog) {
        com.example.ui.dialogs.ReligiousDaysDialog(
            language = language,
            onDismiss = { showReligiousDaysDialog = false }
        )
    }

    selectedReligiousDayDetail?.let { day ->
        com.example.ui.dialogs.ReligiousDayDetailDialog(
            day = day,
            language = language,
            onDismiss = { selectedReligiousDayDetail = null }
        )
    }
}

@Composable
private fun HeroPrayerCard(
    times: PrayerTimes?,
    nextPrayer: com.example.data.model.NextPrayerInfo?,
    language: AppLanguage
) {
    val nextType = nextPrayer?.type ?: PrayerType.FAJR
    val nextName = nextType.getName(language)
    val nextTime = nextPrayer?.time ?: (times?.fajr ?: "--:--")
    val millis = nextPrayer?.millisRemaining ?: 0L

    val hours = millis / (1000 * 60 * 60)
    val minutes = (millis / (1000 * 60)) % 60
    val seconds = (millis / 1000) % 60

    val countdownText = if (language == AppLanguage.KURMANJI) {
        String.format("%02d st %02d xul %02d çrk ma", hours, minutes, seconds)
    } else {
        String.format("%02d sa %02d dk %02d sn kaldı", hours, minutes, seconds)
    }

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(24.dp))
            .testTag("hero_next_prayer_card"),
        color = DarkCard,
        border = BorderStroke(1.2.dp, Brush.linearGradient(listOf(GoldBright, GoldDark, EmeraldBorder)))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.verticalGradient(
                        listOf(EmeraldPrimary.copy(alpha = 0.5f), DarkCard)
                    )
                )
                .padding(20.dp)
        ) {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top row with Hijri date and next indicator
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = GoldContainer
                    ) {
                        Text(
                            text = AppStrings.nextPrayer(language),
                            color = GoldBright,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    if (!times?.hijriDate.isNullOrBlank()) {
                        Text(
                            text = times?.hijriDate ?: "",
                            color = TextMutedEmerald,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Next prayer name & big time
                Text(
                    text = nextName.uppercase(),
                    color = GoldBright,
                    fontSize = 27.sp,
                    fontWeight = FontWeight.ExtraBold,
                    letterSpacing = 1.5.sp
                )

                Spacer(modifier = Modifier.height(4.dp))

                Text(
                    text = nextTime,
                    color = TextWhite,
                    fontSize = 48.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )

                Spacer(modifier = Modifier.height(12.dp))

                // Countdown Pill
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.HourglassTop,
                            contentDescription = null,
                            tint = GoldWarm,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = countdownText,
                            color = TextWhite,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun PrayerTimeRowItem(
    prayer: PrayerType,
    time: String,
    isCurrent: Boolean,
    language: AppLanguage,
    isAdhanEnabled: Boolean,
    onToggleAdhan: (Boolean) -> Unit
) {
    val borderColor by animateColorAsState(
        targetValue = if (isCurrent) GoldBright else DarkCardBorder,
        label = "border"
    )
    val bgColor by animateColorAsState(
        targetValue = if (isCurrent) EmeraldPrimary.copy(alpha = 0.35f) else DarkSurface,
        label = "bg"
    )

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .testTag("prayer_row_${prayer.key}"),
        color = bgColor,
        border = BorderStroke(if (isCurrent) 1.5.dp else 1.dp, borderColor)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            // Prayer icon & Name
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(
                    shape = CircleShape,
                    color = if (isCurrent) GoldBright else EmeraldContainer,
                    modifier = Modifier.size(36.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Icon(
                            imageVector = when (prayer) {
                                PrayerType.FAJR -> Icons.Filled.WbTwilight
                                PrayerType.SUNRISE -> Icons.Filled.WbSunny
                                PrayerType.DHUHR -> Icons.Filled.BrightnessHigh
                                PrayerType.ASR -> Icons.Filled.BrightnessMedium
                                PrayerType.MAGHRIB -> Icons.Filled.NightsStay
                                PrayerType.ISHA -> Icons.Filled.Bedtime
                            },
                            contentDescription = null,
                            tint = if (isCurrent) DarkBackground else GoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(14.dp))

                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = prayer.getName(language),
                            color = if (isCurrent) GoldBright else TextWhite,
                            fontSize = 19.sp,
                            fontWeight = if (isCurrent) FontWeight.Bold else FontWeight.SemiBold
                        )
                        if (isCurrent) {
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = GoldBright
                            ) {
                                Text(
                                    text = if (language == AppLanguage.KURMANJI) "Wext" else "Vakit",
                                    color = DarkBackground,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 7.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    // Alternate language subtitle for educational enrichment
                    val altName = if (language == AppLanguage.TURKISH) prayer.kurmanjiName else prayer.turkishName
                    Text(
                        text = altName,
                        color = TextMutedEmerald,
                        fontSize = 14.sp
                    )
                }
            }

            // Time and Adhan Toggle
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    text = time,
                    color = if (isCurrent) GoldBright else TextWhite,
                    fontSize = 23.sp,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 0.5.sp
                )

                if (prayer.hasAdhan) {
                    Spacer(modifier = Modifier.width(12.dp))
                    IconButton(
                        onClick = { onToggleAdhan(!isAdhanEnabled) },
                        modifier = Modifier
                            .size(36.dp)
                            .testTag("adhan_toggle_${prayer.key}")
                    ) {
                        Icon(
                            imageVector = if (isAdhanEnabled) Icons.Filled.NotificationsActive else Icons.Outlined.NotificationsOff,
                            contentDescription = "Ezan",
                            tint = if (isAdhanEnabled) GoldBright else TextMutedEmerald.copy(alpha = 0.4f),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                } else {
                    Spacer(modifier = Modifier.width(48.dp))
                }
            }
        }
    }
}

@Composable
private fun DailyQuranDuaCard(
    dua: com.example.data.model.QuranDua,
    language: AppLanguage,
    onViewAllDuas: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .testTag("daily_quran_dua_card"),
        color = DarkCard,
        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = GoldBright.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.AutoStories,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = AppStrings.dailyDuaTitle(language),
                            color = GoldBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "${dua.getSurah(language)} [${dua.ayahReference}]",
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }
                }

                TextButton(
                    onClick = onViewAllDuas,
                    modifier = Modifier.testTag("view_all_duas_button")
                ) {
                    Text(
                        text = AppStrings.viewAllDuas(language),
                        color = GoldBright,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Arabic Text
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = DarkSurface,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(14.dp)
            ) {
                Text(
                    text = dua.arabicText,
                    color = TextWhite,
                    fontSize = 22.sp,
                    lineHeight = 34.sp,
                    fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Meaning
            Text(
                text = dua.getTranslation(language),
                color = TextWhite.copy(alpha = 0.9f),
                fontSize = 16.sp,
                lineHeight = 24.sp
            )
        }
    }
}

@Composable
private fun WeeklyHutbeCard(
    hutbe: com.example.data.model.Hutbe,
    language: AppLanguage,
    isLoading: Boolean = false,
    onReadHutbe: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .testTag("weekly_hutbe_card"),
        color = DarkSurface,
        border = BorderStroke(1.dp, EmeraldBorder)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Surface(
                        shape = CircleShape,
                        color = EmeraldContainer,
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.RecordVoiceOver,
                                contentDescription = null,
                                tint = GoldWarm,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = AppStrings.weeklyHutbeTitle(language),
                            color = GoldBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = hutbe.date,
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EmeraldContainer
                ) {
                    Text(
                        text = when {
                            isLoading -> if (language == AppLanguage.KURMANJI) "Tê nûkirin" else "Güncelleniyor"
                            else -> if (language == AppLanguage.KURMANJI) "Nû" else "Güncel"
                        },
                        color = GoldWarm,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = hutbe.getTitle(language),
                color = TextWhite,
                fontSize = 18.sp,
                lineHeight = 24.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = hutbe.getSummary(language),
                color = TextWhite.copy(alpha = 0.75f),
                fontSize = 16.sp,
                lineHeight = 23.sp,
                maxLines = 3,
                overflow = TextOverflow.Ellipsis
            )

            Spacer(modifier = Modifier.height(12.dp))

            Button(
                onClick = onReadHutbe,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 46.dp)
                    .testTag("read_hutbe_button"),
                shape = RoundedCornerShape(10.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = EmeraldContainer,
                    contentColor = GoldBright
                ),
                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f))
            ) {
                Icon(
                    Icons.Filled.MenuBook,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.readHutbe(language),
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            }
        }
    }
}

@Composable
private fun UpcomingReligiousDayCard(
    eventPair: Pair<com.example.data.model.ReligiousDay, Long>,
    language: AppLanguage,
    onOpenDetail: () -> Unit,
    onViewCalendar: () -> Unit
) {
    val day = eventPair.first
    val daysLeft = eventPair.second

    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable(onClick = onOpenDetail)
            .testTag("upcoming_religious_day_card"),
        color = DarkSurface,
        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Surface(
                        shape = CircleShape,
                        color = GoldBright.copy(alpha = 0.15f),
                        modifier = Modifier.size(32.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Icon(
                                Icons.Filled.Celebration,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = AppStrings.upcomingReligiousDayTitle(language),
                            color = GoldBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = day.getDisplayDate(language),
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }
                }

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = GoldContainer,
                    border = BorderStroke(0.8.dp, GoldBright)
                ) {
                    Text(
                        text = AppStrings.daysLeftFormat(daysLeft, language),
                        color = GoldBright,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = day.getName(language),
                color = TextWhite,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = day.getDescription(language),
                color = TextWhite.copy(alpha = 0.8f),
                fontSize = 15.sp,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(12.dp))

            OutlinedButton(
                onClick = onViewCalendar,
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(min = 44.dp)
                    .testTag("view_calendar_button"),
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldBright)
            ) {
                Icon(
                    Icons.Filled.CalendarMonth,
                    contentDescription = null,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.viewReligiousCalendar(language),
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun IslamicServicesDashboard(
    language: AppLanguage,
    onNavigateToQuran: () -> Unit = {},
    onNavigateToElifba: () -> Unit = {},
    onNavigateToQibla: () -> Unit = {},
    onOpenHutbe: () -> Unit = {},
    onOpenReligiousDays: () -> Unit = {},
    onOpenDuas: () -> Unit = {},
    onOpenTesbihat: () -> Unit = {},
    onOpenEsma: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    Column(
        modifier = modifier
            .fillMaxWidth()
            .testTag("islamic_services_dashboard"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Filled.Star,
                    contentDescription = null,
                    tint = GoldBright,
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = AppStrings.quickServicesTitle(language),
                    color = GoldBright,
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Row 1: Kur'an-ı Kerim & Elifba
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickQuranTitle(language),
                subtitle = AppStrings.quickQuranDesc(language),
                badge = if (isKurmanji) "604 Rûpel" else "604 Sayfa",
                icon = Icons.Filled.MenuBook,
                onClick = onNavigateToQuran,
                testTag = "quick_card_quran"
            )
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickElifbaTitle(language),
                subtitle = AppStrings.quickElifbaDesc(language),
                badge = if (isKurmanji) "60 Rûpel" else "60 Yaprak",
                icon = Icons.Filled.School,
                onClick = onNavigateToElifba,
                testTag = "quick_card_elifba"
            )
        }

        // Row 2: Cuma Hutbesi & Kıble Pusulası
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickHutbeTitle(language),
                subtitle = AppStrings.quickHutbeDesc(language),
                badge = if (language == AppLanguage.KURMANJI) "În" else "Cuma",
                icon = Icons.Filled.Campaign,
                onClick = onOpenHutbe,
                testTag = "quick_card_hutbe"
            )
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickQiblaTitle(language),
                subtitle = AppStrings.quickQiblaDesc(language),
                badge = if (isKurmanji) "Sensora Zindî" else "Canlı Sensör",
                icon = Icons.Filled.CompassCalibration,
                onClick = onNavigateToQibla,
                testTag = "quick_card_qibla"
            )
        }

        // Row 3: Dini Günler & Kur'an Duaları
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickReligiousDaysTitle(language),
                subtitle = AppStrings.quickReligiousDaysDesc(language),
                badge = if (isKurmanji) "17 Roj" else "17 Gün",
                icon = Icons.Filled.CalendarMonth,
                onClick = onOpenReligiousDays,
                testTag = "quick_card_religious_days"
            )
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickDuasTitle(language),
                subtitle = AppStrings.quickDuasDesc(language),
                badge = if (isKurmanji) "10 Dûa" else "10 Dua",
                icon = Icons.Filled.Favorite,
                onClick = onOpenDuas,
                testTag = "quick_card_duas"
            )
        }

        // Row 4: Namaz Tesbihatı & Esmâ-ül Hüsnâ
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickTesbihatTitle(language),
                subtitle = AppStrings.quickTesbihatDesc(language),
                badge = if (isKurmanji) "33×3 • Zikirmatîk" else "33×3 • Zikir",
                icon = Icons.Filled.Grain,
                onClick = onOpenTesbihat,
                testTag = "quick_card_tesbihat"
            )
            ServiceDashboardCard(
                modifier = Modifier.weight(1f),
                title = AppStrings.quickEsmaTitle(language),
                subtitle = AppStrings.quickEsmaDesc(language),
                badge = if (isKurmanji) "99 Nav" else "99 İsim",
                icon = Icons.Filled.AutoAwesome,
                onClick = onOpenEsma,
                testTag = "quick_card_esma"
            )
        }
    }
}

@Composable
private fun ServiceDashboardCard(
    title: String,
    subtitle: String,
    badge: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = EmeraldContainer,
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.8f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = GoldContainer,
                    border = BorderStroke(0.8.dp, GoldBright)
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = GoldBright,
                        modifier = Modifier
                            .padding(6.dp)
                            .size(18.dp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = DarkSurface
                ) {
                    Text(
                        text = badge,
                        color = GoldWarm,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = title,
                color = TextWhite,
                fontSize = 16.sp,
                lineHeight = 20.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = subtitle,
                color = TextMutedEmerald,
                fontSize = 14.sp,
                lineHeight = 19.sp,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

