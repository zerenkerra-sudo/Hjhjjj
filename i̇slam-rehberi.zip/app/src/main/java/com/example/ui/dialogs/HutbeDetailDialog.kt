package com.example.ui.dialogs

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.AppStrings
import com.example.data.local.HutbeData
import com.example.data.model.AppLanguage
import com.example.data.model.Hutbe
import com.example.ui.components.HutbeArabicHeaderCard
import com.example.ui.theme.*

@Composable
fun HutbeDetailDialog(
    hutbe: Hutbe,
    language: AppLanguage,
    archive: List<Hutbe> = HutbeData.HUTBE_LIST,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var selectedLanguage by remember { mutableStateOf(language) }
    var activeHutbe by remember(hutbe) { mutableStateOf(hutbe) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.92f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.2.dp, IslamicGold.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
            color = IslamicGreenDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AppStrings.weeklyHutbeTitle(selectedLanguage),
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGold
                        )
                        Text(
                            text = activeHutbe.date,
                            fontSize = 15.sp,
                            color = TextWhite.copy(alpha = 0.7f)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_hutbe_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = AppStrings.close(selectedLanguage),
                            tint = TextWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Language Selector Tabs (Türkçe / Kurmancî)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(IslamicGreenSurface, RoundedCornerShape(12.dp))
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { selectedLanguage = AppLanguage.TURKISH },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLanguage == AppLanguage.TURKISH) IslamicGold else Color.Transparent,
                            contentColor = if (selectedLanguage == AppLanguage.TURKISH) IslamicGreenDark else TextWhite
                        )
                    ) {
                        Text("Türkçe", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }

                    Button(
                        onClick = { selectedLanguage = AppLanguage.KURMANJI },
                        modifier = Modifier
                            .weight(1f)
                            .heightIn(min = 42.dp),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (selectedLanguage == AppLanguage.KURMANJI) IslamicGold else Color.Transparent,
                            contentColor = if (selectedLanguage == AppLanguage.KURMANJI) IslamicGreenDark else TextWhite
                        )
                    ) {
                        Text("Kurmancî (Latînî)", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Hutbe Archive Selector Row
                Text(
                    text = if (selectedLanguage == AppLanguage.KURMANJI) "Arşîva Xutbeyên Înê:" else "Cuma Hutbeleri Arşivi:",
                    fontSize = 14.sp,
                    color = TextWhite.copy(alpha = 0.7f),
                    fontWeight = FontWeight.Medium
                )
                Spacer(modifier = Modifier.height(6.dp))

                LazyRow(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(archive) { item ->
                        val isSelected = activeHutbe.id == item.id
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isSelected) IslamicGold else IslamicGreenSurface,
                            border = BorderStroke(0.8.dp, if (isSelected) IslamicGold else TextWhite.copy(alpha = 0.2f)),
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable { activeHutbe = item }
                        ) {
                            Text(
                                text = item.getTitle(selectedLanguage),
                                color = if (isSelected) IslamicGreenDark else TextWhite,
                                fontSize = 14.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content Scrollable
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState())
                ) {
                    // Week-specific Official Arabic Header (Besmele + Quran Ayah + Hadith)
                    HutbeArabicHeaderCard(
                        hutbe = activeHutbe,
                        isKurmanji = selectedLanguage == AppLanguage.KURMANJI
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Sermon Title
                    Text(
                        text = activeHutbe.getTitle(selectedLanguage),
                        fontSize = 21.sp,
                        lineHeight = 28.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = TextWhite
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Diyanet Arabic Minber Intro Box ("Arapça Hutbe Girişi")
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    color = MushafPaperSurface,
                                    shape = RoundedCornerShape(14.dp)
                                )
                                .border(1.dp, IslamicGold.copy(alpha = 0.4f), RoundedCornerShape(14.dp))
                                .padding(14.dp)
                        ) {
                            Column(
                                modifier = Modifier.fillMaxWidth(),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Text(
                                    text = HutbeData.DIYANET_ARABIC_HUTBE_INTRO,
                                    fontSize = 19.sp,
                                    lineHeight = 32.sp,
                                    color = IslamicGold,
                                    textAlign = TextAlign.Right,
                                    modifier = Modifier.fillMaxWidth()
                                )
                                HorizontalDivider(color = IslamicGold.copy(alpha = 0.25f), thickness = 0.8.dp)
                                Text(
                                    text = HutbeData.DIYANET_ARABIC_BESMELE,
                                    fontSize = 18.sp,
                                    lineHeight = 29.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextWhite.copy(alpha = 0.92f),
                                    textAlign = TextAlign.Center,
                                    modifier = Modifier.fillMaxWidth()
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Summary Card
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        colors = CardDefaults.cardColors(containerColor = IslamicGreenSurface),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = if (selectedLanguage == AppLanguage.KURMANJI) "Kurteya Xutbeyê" else "Hutbenin Özeti",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = activeHutbe.getSummary(selectedLanguage),
                                fontSize = 16.sp,
                                lineHeight = 24.sp,
                                color = TextWhite.copy(alpha = 0.9f)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Full Text (clean, without bottom footnotes/sources)
                    val cleanFullText = HutbeData.cleanHutbeBodyText(activeHutbe.getFullText(selectedLanguage))
                    Text(
                        text = if (selectedLanguage == AppLanguage.KURMANJI) "Metna Tevahî ya Xutbeyê" else "Hutbenin Tam Metni",
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = cleanFullText,
                        fontSize = 17.sp,
                        lineHeight = 28.sp,
                        color = TextWhite.copy(alpha = 0.95f)
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Bottom Action: Copy Sermon
                Button(
                    onClick = {
                        val fullShareText = buildString {
                            append(activeHutbe.getTitle(selectedLanguage)).append("\n")
                            append("${activeHutbe.date}\n\n")
                            if (activeHutbe.arabicVerseOrHadith.isNotBlank()) {
                                append(activeHutbe.arabicVerseOrHadith).append("\n\n")
                            }
                            append(HutbeData.DIYANET_ARABIC_HUTBE_INTRO).append("\n")
                            append(HutbeData.DIYANET_ARABIC_BESMELE).append("\n\n")
                            append(HutbeData.cleanHutbeBodyText(activeHutbe.getFullText(selectedLanguage)))
                        }
                        val clipboard =
                            context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("Hutbe", fullShareText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(
                            context,
                            AppStrings.copiedToClipboard(selectedLanguage),
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(46.dp)
                        .testTag("copy_hutbe_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = IslamicGold)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = null,
                        tint = IslamicGreenDark,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = AppStrings.copy(selectedLanguage),
                        color = IslamicGreenDark,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            }
        }
    }
}
