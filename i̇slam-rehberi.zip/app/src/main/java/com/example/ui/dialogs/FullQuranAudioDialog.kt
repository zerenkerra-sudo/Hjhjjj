package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.BuiltinQuranData
import com.example.data.local.OfflineDownloadState
import com.example.data.local.QuranOfflineAudioManager
import com.example.data.model.AppLanguage
import com.example.data.model.QuranReciter
import com.example.service.AudioPlaybackSource
import com.example.service.OfflineVoiceMode
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun FullQuranAudioDialog(
    currentSurahNumber: Int,
    currentReciter: QuranReciter,
    isPlaying: Boolean,
    isBuffering: Boolean,
    progress: Float,
    currentTimeMs: Int,
    durationMs: Int,
    isAutoAdvance: Boolean,
    playbackSpeed: Float,
    playbackSource: AudioPlaybackSource,
    currentAyahLabel: String?,
    offlineVoiceMode: OfflineVoiceMode,
    downloadedSurahs: Set<Int>,
    totalStorageBytes: Long,
    downloadState: OfflineDownloadState,
    audioErrorMessage: String?,
    language: AppLanguage,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onSeekForward10: () -> Unit,
    onSeekBackward10: () -> Unit,
    onSelectSurah: (Int) -> Unit,
    onSelectReciter: (QuranReciter) -> Unit,
    onToggleAutoAdvance: () -> Unit,
    onSetPlaybackSpeed: (Float) -> Unit,
    onSetOfflineVoiceMode: (OfflineVoiceMode) -> Unit,
    onDownloadSurah: (Int) -> Unit,
    onDownloadAllSurahs: () -> Unit,
    onCancelDownload: () -> Unit,
    onDeleteReciterDownloads: () -> Unit,
    onOpenMushafPage: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val surahInfo = BuiltinQuranData.SURAH_LIST.find { it.number == currentSurahNumber }
    var searchQuery by remember { mutableStateOf("") }
    var showReciterPicker by remember { mutableStateOf(false) }
    var showOfflineManager by remember { mutableStateOf(false) }

    val filteredSurahs = remember(searchQuery) {
        if (searchQuery.isBlank()) {
            BuiltinQuranData.SURAH_LIST
        } else {
            val q = searchQuery.trim().lowercase()
            BuiltinQuranData.SURAH_LIST.filter {
                it.number.toString() == q ||
                    it.nameTr.lowercase().contains(q) ||
                    it.nameKu.lowercase().contains(q) ||
                    it.nameArabic.contains(q)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 28.dp, bottom = 16.dp, start = 12.dp, end = 12.dp)
                .clip(RoundedCornerShape(24.dp))
                .testTag("full_quran_audio_dialog"),
            color = DarkBackground,
            border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.8f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Top Action Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss) {
                        Icon(
                            imageVector = Icons.Filled.Close,
                            contentDescription = "Kapat",
                            tint = GoldBright
                        )
                    }

                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(
                            text = if (isKurmanji) "Guhdarîkirina Qur'anê" else "Kur'an-ı Kerim Tilavet & Hatim",
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isKurmanji) "114 Sûre • Çevrimdışı ${downloadedSurahs.size}/114" else "114 Sure • Çevrimdışı Paket ${downloadedSurahs.size}/114",
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }

                    Row {
                        IconButton(
                            onClick = { showOfflineManager = !showOfflineManager },
                            modifier = Modifier.testTag("toggle_offline_manager_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.DownloadForOffline,
                                contentDescription = "Çevrimdışı İndir",
                                tint = if (showOfflineManager || downloadState.isDownloading) GoldWarm else GoldBright
                            )
                        }
                        IconButton(onClick = { showReciterPicker = !showReciterPicker }) {
                            Icon(
                                imageVector = Icons.Filled.Person,
                                contentDescription = "Okuyucu Seç",
                                tint = if (showReciterPicker) GoldWarm else GoldBright
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Reciter + Offline Download Strip
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkCard,
                        border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .weight(1f)
                            .clickable { showReciterPicker = !showReciterPicker }
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                modifier = Modifier.weight(1f),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.RecordVoiceOver,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Column {
                                    Text(
                                        text = if (isKurmanji) "Qari" else "Hafız (Kari)",
                                        color = TextMutedEmerald,
                                        fontSize = 12.sp
                                    )
                                    Text(
                                        text = currentReciter.getDisplayName(language),
                                        color = GoldBright,
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            Icon(
                                imageVector = if (showReciterPicker) Icons.Filled.KeyboardArrowUp else Icons.Filled.KeyboardArrowDown,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(18.dp)
                            )
                        }
                    }

                    // Toggle Offline Download Hub
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (showOfflineManager || downloadState.isDownloading) EmeraldContainer else DarkCard,
                        border = BorderStroke(0.8.dp, GoldBright),
                        modifier = Modifier
                            .clickable { showOfflineManager = !showOfflineManager }
                            .testTag("offline_pack_pill")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Filled.OfflinePin,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Column {
                                Text(
                                    text = if (isKurmanji) "Bê Înternet" else "Çevrimdışı",
                                    color = TextMutedEmerald,
                                    fontSize = 12.sp
                                )
                                Text(
                                    text = if (downloadState.isDownloading) {
                                        "%${(downloadState.overallProgress * 100).toInt()}"
                                    } else {
                                        "${downloadedSurahs.size}/114"
                                    },
                                    color = GoldBright,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }

                // Expandable Offline Download Manager Panel
                if (showOfflineManager || downloadState.isDownloading) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = DarkSurfaceVariant,
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.7f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isKurmanji) "Pakêta Bê Înternet (114 Sûre)" else "İnternetsiz Kur'an Ses Paketi",
                                        color = GoldBright,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = if (isKurmanji)
                                            "${downloadedSurahs.size}/114 sûre li ser cîhazê ne • ${QuranOfflineAudioManager.formatStorageSize(totalStorageBytes)}"
                                        else
                                            "${downloadedSurahs.size}/114 sure cihazda kayıtlı • ${QuranOfflineAudioManager.formatStorageSize(totalStorageBytes)}",
                                        color = TextMutedEmerald,
                                        fontSize = 14.sp
                                    )
                                }

                                if (downloadedSurahs.isNotEmpty() && !downloadState.isDownloading) {
                                    TextButton(
                                        onClick = onDeleteReciterDownloads,
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp)
                                    ) {
                                        Text(
                                            text = if (isKurmanji) "Jê bibe" else "Temizle",
                                            color = Color(0xFFFF8A80),
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }
                            }

                            if (downloadState.isDownloading) {
                                Spacer(modifier = Modifier.height(8.dp))
                                val dlSurah = BuiltinQuranData.SURAH_LIST.find { it.number == downloadState.currentSurahNumber }
                                Text(
                                    text = if (isKurmanji)
                                        "Tê daxistin: ${dlSurah?.getDisplayName(language) ?: ""} (${downloadState.completedCount}/${downloadState.totalCount})"
                                    else
                                        "İndiriliyor: ${dlSurah?.getDisplayName(language) ?: ""} (${downloadState.completedCount}/${downloadState.totalCount})",
                                    color = TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                LinearProgressIndicator(
                                    progress = { downloadState.overallProgress },
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(6.dp)
                                        .clip(RoundedCornerShape(4.dp)),
                                    color = GoldBright,
                                    trackColor = DarkSurface
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                OutlinedButton(
                                    onClick = onCancelDownload,
                                    border = BorderStroke(1.dp, Color(0xFFFF8A80)),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 42.dp),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Filled.Stop, contentDescription = null, tint = Color(0xFFFF8A80), modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isKurmanji) "Daxistinê Bisekine" else "İndirmeyi Durdur",
                                        color = Color(0xFFFF8A80),
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            } else {
                                Spacer(modifier = Modifier.height(8.dp))
                                Button(
                                    onClick = onDownloadAllSurahs,
                                    enabled = downloadedSurahs.size < 114,
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = GoldBright,
                                        contentColor = DarkBackground,
                                        disabledContainerColor = EmeraldContainer,
                                        disabledContentColor = GoldBright
                                    ),
                                    shape = RoundedCornerShape(10.dp),
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .heightIn(min = 44.dp)
                                        .testTag("download_all_114_surahs_button")
                                ) {
                                    Icon(
                                        imageVector = if (downloadedSurahs.size >= 114) Icons.Filled.CheckCircle else Icons.Filled.CloudDownload,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (downloadedSurahs.size >= 114) {
                                            if (isKurmanji) "Hemû 114 Sûre Amade ne (Bê Înternet)" else "Bütün Kur'an (114 Sure) Çevrimdışı Hazır"
                                        } else {
                                            if (isKurmanji) "Hemû Qur'anê Daxe (114 Sûre)" else "Bütün Kur'an'ı İndir (114 Sure - Çevrimdışı)"
                                        },
                                        fontSize = 14.sp,
                                        maxLines = 2,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }

                            downloadState.errorMessage?.let { err ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = err,
                                    color = GoldWarm,
                                    fontSize = 14.sp
                                )
                            }
                        }
                    }
                }

                // Expandable Reciter List
                if (showReciterPicker) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant,
                        border = BorderStroke(1.dp, EmeraldBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(6.dp)) {
                            QuranReciter.entries.forEach { reciter ->
                                val isSelected = reciter == currentReciter
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isSelected) EmeraldContainer else Color.Transparent,
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            onSelectReciter(reciter)
                                            showReciterPicker = false
                                        }
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 8.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(
                                                text = reciter.getDisplayName(language),
                                                color = if (isSelected) GoldBright else TextWhite,
                                                fontSize = 16.sp,
                                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                            )
                                            Text(
                                                text = reciter.nameArabic,
                                                color = GoldWarm,
                                                fontSize = 14.sp
                                            )
                                        }

                                        if (isSelected) {
                                            Icon(
                                                imageVector = Icons.Filled.Check,
                                                contentDescription = null,
                                                tint = GoldBright,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Hero Player Card
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = DarkCard,
                    border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.6f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(
                                Brush.verticalGradient(
                                    listOf(EmeraldPrimary.copy(alpha = 0.35f), DarkCard)
                                )
                            )
                            .padding(14.dp)
                    ) {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            // Offline / Source status pill + Voice Mode Toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                val sourceText = when (playbackSource) {
                                    AudioPlaybackSource.LOCAL_MP3 ->
                                        if (isKurmanji) "Bê Înternet (Ji Cîhazê)" else "Çevrimdışı Hafız (Cihazdan)"
                                    AudioPlaybackSource.OFFLINE_RECITATION ->
                                        if (isKurmanji) "Xwendina Bê Înternet ${currentAyahLabel ?: ""}"
                                        else "Çevrimdışı Ses ${currentAyahLabel ?: ""}"
                                    AudioPlaybackSource.ONLINE_STREAM ->
                                        if (isKurmanji) "Serhêl (Tê tomarkirin)" else "Çevrimiçi (Kaydediliyor)"
                                    AudioPlaybackSource.NONE ->
                                        if (downloadedSurahs.contains(currentSurahNumber))
                                            (if (isKurmanji) "Bê Înternet Amade ye" else "Çevrimdışı Hazır")
                                        else
                                            (if (isKurmanji) "Bê Înternet / Serhêl" else "Çevrimdışı & Çevrimiçi")
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = EmeraldContainer,
                                    border = BorderStroke(0.6.dp, GoldClassic.copy(alpha = 0.6f))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.OfflinePin,
                                            contentDescription = null,
                                            tint = GoldBright,
                                            modifier = Modifier.size(12.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = sourceText,
                                            color = GoldBright,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }
                                }

                                // Offline Voice Mode chip (Arapça vs Meal)
                                val isMealMode = offlineVoiceMode == OfflineVoiceMode.TURKISH_MEAL
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = if (isMealMode) GoldContainer else DarkSurface,
                                    border = BorderStroke(0.6.dp, if (isMealMode) GoldBright else EmeraldBorder),
                                    modifier = Modifier.clickable {
                                        onSetOfflineVoiceMode(
                                            if (isMealMode) OfflineVoiceMode.AUTO_ARABIC else OfflineVoiceMode.TURKISH_MEAL
                                        )
                                    }
                                ) {
                                    Text(
                                        text = if (isMealMode) {
                                            if (isKurmanji) "Meal (Bê Înternet)" else "Meal Sesli (Çevrimdışı)"
                                        } else {
                                            if (isKurmanji) "Mod: Tilavet" else "Mod: Tilavet"
                                        },
                                        color = if (isMealMode) GoldBright else TextMutedEmerald,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            if (surahInfo != null) {
                                Text(
                                    text = surahInfo.nameArabic,
                                    color = GoldBright,
                                    fontSize = 32.sp,
                                    fontWeight = FontWeight.Bold,
                                    letterSpacing = 1.sp
                                )

                                Spacer(modifier = Modifier.height(2.dp))

                                Text(
                                    text = "${surahInfo.number}. ${surahInfo.getDisplayName(language)} - ${surahInfo.getMeaning(language)}",
                                    color = TextWhite,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )

                                Text(
                                    text = "${surahInfo.versesCount} Ayet • Cüz ${surahInfo.startJuz} • Sayfa ${surahInfo.startPage}",
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp
                                )
                            }

                            audioErrorMessage?.let { err ->
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = err,
                                    color = GoldWarm,
                                    fontSize = 14.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            Slider(
                                value = progress.coerceIn(0f, 1f),
                                onValueChange = onSeek,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(24.dp),
                                colors = SliderDefaults.colors(
                                    thumbColor = GoldBright,
                                    activeTrackColor = GoldBright,
                                    inactiveTrackColor = EmeraldBorder
                                )
                            )

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = if (playbackSource == AudioPlaybackSource.OFFLINE_RECITATION && currentAyahLabel != null) {
                                        currentAyahLabel
                                    } else {
                                        formatTime(currentTimeMs)
                                    },
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = if (playbackSource == AudioPlaybackSource.OFFLINE_RECITATION) {
                                        "${surahInfo?.versesCount ?: 0} Ayet"
                                    } else {
                                        formatTime(durationMs)
                                    },
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp
                                )
                            }

                            Spacer(modifier = Modifier.height(8.dp))

                            // Central Playback Controls
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceEvenly,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                IconButton(
                                    onClick = onPrevious,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.SkipPrevious,
                                        contentDescription = "Önceki Sure",
                                        tint = GoldBright,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }

                                IconButton(
                                    onClick = onSeekBackward10,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Replay10,
                                        contentDescription = "10sn Geri",
                                        tint = TextWhite,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                IconButton(
                                    onClick = onTogglePlayPause,
                                    modifier = Modifier
                                        .size(54.dp)
                                        .background(GoldBright, CircleShape)
                                ) {
                                    if (isBuffering) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(24.dp),
                                            color = DarkBackground,
                                            strokeWidth = 2.5.dp
                                        )
                                    } else {
                                        Icon(
                                            imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                            contentDescription = "Oynat/Durdur",
                                            tint = DarkBackground,
                                            modifier = Modifier.size(32.dp)
                                        )
                                    }
                                }

                                IconButton(
                                    onClick = onSeekForward10,
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Forward10,
                                        contentDescription = "10sn İleri",
                                        tint = TextWhite,
                                        modifier = Modifier.size(24.dp)
                                    )
                                }

                                IconButton(
                                    onClick = onNext,
                                    modifier = Modifier.size(42.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.SkipNext,
                                        contentDescription = "Sonraki Sure",
                                        tint = GoldBright,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Settings Bar: Auto-Advance & Playback Speed & Open Page
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier
                                        .weight(1f)
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable { onToggleAutoAdvance() }
                                        .padding(4.dp)
                                ) {
                                    Switch(
                                        checked = isAutoAdvance,
                                        onCheckedChange = { onToggleAutoAdvance() },
                                        colors = SwitchDefaults.colors(
                                            checkedThumbColor = GoldBright,
                                            checkedTrackColor = EmeraldPrimary,
                                            uncheckedThumbColor = TextMutedEmerald,
                                            uncheckedTrackColor = DarkSurface
                                        ),
                                        modifier = Modifier.size(width = 36.dp, height = 24.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (isKurmanji) "Berdewamî (Hatim)" else "Kesintisiz Hatim",
                                        color = if (isAutoAdvance) GoldBright else TextMutedEmerald,
                                        fontSize = 13.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    listOf(1.0f, 1.25f, 1.5f).forEach { speed ->
                                        val isCurrentSpeed = playbackSpeed == speed
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (isCurrentSpeed) EmeraldContainer else DarkSurface,
                                            border = BorderStroke(0.6.dp, if (isCurrentSpeed) GoldBright else DarkCardBorder),
                                            modifier = Modifier.clickable { onSetPlaybackSpeed(speed) }
                                        ) {
                                            Text(
                                                text = "${speed}x",
                                                color = if (isCurrentSpeed) GoldBright else TextMutedEmerald,
                                                fontSize = 12.sp,
                                                softWrap = false,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)
                                            )
                                        }
                                    }
                                }

                                if (surahInfo != null) {
                                    OutlinedButton(
                                        onClick = {
                                            onOpenMushafPage(surahInfo.startPage)
                                            onDismiss()
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        border = BorderStroke(0.8.dp, GoldClassic),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                        modifier = Modifier.heightIn(min = 36.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Filled.MenuBook,
                                            contentDescription = null,
                                            tint = GoldBright,
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(
                                            text = if (isKurmanji) "Rûpel" else "Sayfayı Aç",
                                            color = GoldBright,
                                            fontSize = 13.sp,
                                            softWrap = false,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isKurmanji) "Hemû Sûreyên Qur'anê (114 Sûre)" else "Bütün Sureler (114 Sureden Birini Başlat veya İndir)",
                    color = GoldBright,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(6.dp))

                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    placeholder = {
                        Text(
                            text = if (isKurmanji) "Sûre lêbigere..." else "Sure adı veya numarası ile ara...",
                            fontSize = 15.sp
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = null, tint = GoldBright, modifier = Modifier.size(18.dp))
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 52.dp),
                    shape = RoundedCornerShape(10.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldBright,
                        unfocusedBorderColor = EmeraldBorder,
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedContainerColor = DarkSurface,
                        unfocusedContainerColor = DarkSurface
                    ),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(8.dp))

                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    items(filteredSurahs) { s ->
                        val isCurrent = s.number == currentSurahNumber
                        val isDownloaded = downloadedSurahs.contains(s.number)
                        val isCurrentlyDownloading = downloadState.isDownloading && downloadState.currentSurahNumber == s.number

                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = if (isCurrent) EmeraldContainer else DarkCard,
                            border = BorderStroke(
                                1.dp,
                                if (isCurrent) GoldBright else DarkCardBorder
                            ),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { onSelectSurah(s.number) }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(
                                    modifier = Modifier.weight(1f),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = if (isCurrent) GoldBright else DarkSurface,
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = "${s.number}",
                                                color = if (isCurrent) DarkBackground else TextWhite,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    Column {
                                        Text(
                                            text = s.getDisplayName(language),
                                            color = if (isCurrent) GoldBright else TextWhite,
                                            fontSize = 16.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                        Text(
                                            text = "${s.versesCount} Ayet • Sayfa ${s.startPage}",
                                            color = TextMutedEmerald,
                                            fontSize = 14.sp
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = s.nameArabic,
                                        color = GoldWarm,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))

                                    // Per-Surah Offline Download / Downloaded Badge
                                    if (isCurrentlyDownloading) {
                                        CircularProgressIndicator(
                                            modifier = Modifier.size(20.dp),
                                            color = GoldBright,
                                            strokeWidth = 2.dp
                                        )
                                    } else if (isDownloaded) {
                                        Icon(
                                            imageVector = Icons.Filled.OfflinePin,
                                            contentDescription = "Cihazda Kayıtlı (Çevrimdışı)",
                                            tint = Color(0xFF69F0AE),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    } else {
                                        IconButton(
                                            onClick = { onDownloadSurah(s.number) },
                                            modifier = Modifier.size(28.dp)
                                        ) {
                                            Icon(
                                                imageVector = Icons.Filled.Download,
                                                contentDescription = "Çevrimdışı İndir",
                                                tint = TextMutedEmerald,
                                                modifier = Modifier.size(18.dp)
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    Icon(
                                        imageVector = if (isCurrent && isPlaying) Icons.Filled.GraphicEq else Icons.Filled.PlayArrow,
                                        contentDescription = "Dinle",
                                        tint = if (isCurrent) GoldBright else GoldWarm,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(millis: Int): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
