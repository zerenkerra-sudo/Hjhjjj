package com.example.ui.dialogs

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.AppStrings
import com.example.data.local.QuranDuasData
import com.example.data.model.AppLanguage
import com.example.data.model.QuranDua
import com.example.ui.theme.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AllDuasDialog(
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }

    val filteredDuas = remember(searchQuery, language) {
        if (searchQuery.isBlank()) {
            QuranDuasData.DUAS_LIST
        } else {
            val q = searchQuery.lowercase().trim()
            QuranDuasData.DUAS_LIST.filter { dua ->
                dua.getTitle(language).lowercase().contains(q) ||
                        dua.getSurah(language).lowercase().contains(q) ||
                        dua.getTranslation(language).lowercase().contains(q) ||
                        dua.arabicText.contains(q) ||
                        dua.ayahReference.contains(q)
            }
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, IslamicGold.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
            color = IslamicGreenDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = AppStrings.allDuasTitle(language),
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold,
                            color = IslamicGold
                        )
                        Text(
                            text = if (language == AppLanguage.KURMANJI) {
                                "${QuranDuasData.DUAS_LIST.size} duayên bijartî yên Qur'anê"
                            } else {
                                "${QuranDuasData.DUAS_LIST.size} seçkin Kur'an-ı Kerim duası"
                            },
                            fontSize = 15.sp,
                            color = TextWhite.copy(alpha = 0.7f)
                        )
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_all_duas_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = AppStrings.close(language),
                            tint = TextWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Search Bar
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("search_dua_input"),
                    placeholder = {
                        Text(
                            text = AppStrings.searchDua(language),
                            color = TextWhite.copy(alpha = 0.5f),
                            fontSize = 16.sp
                        )
                    },
                    leadingIcon = {
                        Icon(
                            imageVector = Icons.Default.Search,
                            contentDescription = null,
                            tint = IslamicGold
                        )
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(14.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = IslamicGreenSurface,
                        unfocusedContainerColor = IslamicGreenSurface,
                        focusedBorderColor = IslamicGold,
                        unfocusedBorderColor = IslamicGold.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    )
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Duas List
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    items(filteredDuas, key = { it.id }) { dua ->
                        DuaCard(
                            dua = dua,
                            language = language,
                            onCopy = {
                                val fullText = buildString {
                                    append(dua.getTitle(language)).append("\n")
                                    append("${dua.getSurah(language)} [${dua.ayahReference}]\n\n")
                                    append(dua.arabicText).append("\n\n")
                                    append(dua.getTranslation(language))
                                }
                                val clipboard =
                                    context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = ClipData.newPlainText("Quran Dua", fullText)
                                clipboard.setPrimaryClip(clip)
                                Toast.makeText(
                                    context,
                                    AppStrings.copiedToClipboard(language),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun DuaCard(
    dua: QuranDua,
    language: AppLanguage,
    onCopy: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .border(1.dp, IslamicGold.copy(alpha = 0.25f), RoundedCornerShape(16.dp)),
        colors = CardDefaults.cardColors(containerColor = IslamicGreenSurface),
        shape = RoundedCornerShape(16.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            // Title & Reference Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = dua.getTitle(language),
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        color = IslamicGold
                    )
                    Text(
                        text = "${dua.getSurah(language)} • ${dua.ayahReference}",
                        fontSize = 15.sp,
                        color = IslamicGold.copy(alpha = 0.8f)
                    )
                }

                IconButton(
                    onClick = onCopy,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ContentCopy,
                        contentDescription = AppStrings.copy(language),
                        tint = IslamicGold.copy(alpha = 0.8f),
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Arabic Text
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(
                        color = MushafPaperSurface,
                        shape = RoundedCornerShape(12.dp)
                    )
                    .padding(14.dp)
            ) {
                Text(
                    text = dua.arabicText,
                    fontSize = 23.sp,
                    lineHeight = 36.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = TextWhite,
                    textAlign = TextAlign.Right,
                    modifier = Modifier.fillMaxWidth()
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Translation (Current Language)
            Text(
                text = dua.getTranslation(language),
                fontSize = 17.sp,
                lineHeight = 26.sp,
                color = TextWhite.copy(alpha = 0.9f)
            )

            // If Turkish is selected, show Kurmanji below or vice-versa
            Spacer(modifier = Modifier.height(6.dp))
            val secondaryText = if (language == AppLanguage.TURKISH) {
                "Kurmancî: ${dua.translationKuLatin}"
            } else {
                "Türkçe: ${dua.translationTr}"
            }
            Text(
                text = secondaryText,
                fontSize = 15.sp,
                lineHeight = 22.sp,
                color = TextWhite.copy(alpha = 0.6f)
            )
        }
    }
}
