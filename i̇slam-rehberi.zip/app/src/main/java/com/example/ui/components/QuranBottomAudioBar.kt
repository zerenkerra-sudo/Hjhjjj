package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.BuiltinQuranData
import com.example.data.model.AppLanguage
import com.example.data.model.QuranReciter
import com.example.service.AudioPlaybackSource
import com.example.ui.theme.*

@Composable
fun QuranBottomAudioBar(
    isVisible: Boolean,
    surahNumber: Int,
    reciter: QuranReciter,
    isPlaying: Boolean,
    isBuffering: Boolean,
    progress: Float,
    currentTimeMs: Int,
    durationMs: Int,
    playbackSource: AudioPlaybackSource = AudioPlaybackSource.NONE,
    currentAyahLabel: String? = null,
    language: AppLanguage,
    onTogglePlayPause: () -> Unit,
    onNext: () -> Unit,
    onPrevious: () -> Unit,
    onOpenFullPlayer: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val surahInfo = BuiltinQuranData.SURAH_LIST.find { it.number == surahNumber }
    val surahTitle = if (surahInfo != null) {
        "${surahInfo.number}. ${surahInfo.getDisplayName(language)}"
    } else {
        if (isKurmanji) "Sûreya $surahNumber" else "$surahNumber. Sure"
    }

    val statusText = when {
        playbackSource == AudioPlaybackSource.OFFLINE_RECITATION && currentAyahLabel != null ->
            (if (isKurmanji) "Bê Înternet • $currentAyahLabel" else "Çevrimdışı Ses • $currentAyahLabel")
        playbackSource == AudioPlaybackSource.LOCAL_MP3 ->
            (if (isKurmanji) "Çevrimdışı • ${reciter.getDisplayName(language)} • ${formatTime(currentTimeMs)}"
            else "Çevrimdışı • ${reciter.getDisplayName(language)} • ${formatTime(currentTimeMs)} / ${formatTime(durationMs)}")
        else ->
            "${reciter.getDisplayName(language)} • ${formatTime(currentTimeMs)} / ${formatTime(durationMs)}"
    }

    AnimatedVisibility(
        visible = isVisible,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp)
                .clip(RoundedCornerShape(16.dp))
                .clickable { onOpenFullPlayer() }
                .testTag("quran_bottom_audio_bar"),
            color = DarkCard,
            border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.7f)),
            shadowElevation = 8.dp
        ) {
            Column(modifier = Modifier.fillMaxWidth()) {
                LinearProgressIndicator(
                    progress = { progress.coerceIn(0f, 1f) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(3.dp),
                    color = GoldBright,
                    trackColor = DarkSurfaceVariant
                )

                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = EmeraldContainer,
                            border = BorderStroke(1.dp, GoldBright),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = "$surahNumber",
                                    color = GoldBright,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = surahTitle,
                                    color = TextWhite,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f, fill = false)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                if (surahInfo != null) {
                                    Text(
                                        text = surahInfo.nameArabic,
                                        color = GoldWarm,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                if (playbackSource == AudioPlaybackSource.LOCAL_MP3 ||
                                    playbackSource == AudioPlaybackSource.OFFLINE_RECITATION
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.OfflinePin,
                                        contentDescription = "Çevrimdışı",
                                        tint = GoldBright,
                                        modifier = Modifier.size(12.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                }
                                Text(
                                    text = statusText,
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp,
                                    maxLines = 1,
                                    overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                                )
                            }
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = onPrevious,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("quran_mini_prev_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SkipPrevious,
                                contentDescription = "Önceki",
                                tint = GoldBright,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = onTogglePlayPause,
                            modifier = Modifier
                                .size(38.dp)
                                .background(GoldBright, CircleShape)
                                .testTag("quran_mini_play_pause_button")
                        ) {
                            if (isBuffering) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = DarkBackground,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                    contentDescription = "Oynat/Durdur",
                                    tint = DarkBackground,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }

                        IconButton(
                            onClick = onNext,
                            modifier = Modifier
                                .size(34.dp)
                                .testTag("quran_mini_next_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.SkipNext,
                                contentDescription = "Sonraki",
                                tint = GoldBright,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        IconButton(
                            onClick = onClose,
                            modifier = Modifier
                                .size(28.dp)
                                .testTag("quran_mini_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = "Kapat",
                                tint = TextMutedEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun formatTime(millis: Int): String {
    val totalSeconds = (millis / 1000).coerceAtLeast(0)
    val minutes = totalSeconds / 60
    val seconds = totalSeconds % 60
    return String.format("%02d:%02d", minutes, seconds)
}
