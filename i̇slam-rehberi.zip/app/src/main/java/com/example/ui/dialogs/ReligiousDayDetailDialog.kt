package com.example.ui.dialogs

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Celebration
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.alarm.EventNotificationScheduler
import com.example.data.local.AppPreferences
import com.example.data.local.AppStrings
import com.example.data.local.ReligiousDaysData
import com.example.data.model.AppLanguage
import com.example.data.model.ReligiousDay
import com.example.ui.theme.*

@Composable
fun ReligiousDayDetailDialog(
    day: ReligiousDay,
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val isKurmanji = language == AppLanguage.KURMANJI
    val daysLeft = remember(day) { ReligiousDaysData.getDaysDifference(day.gregorianDateStr) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.2.dp, GoldClassic.copy(alpha = 0.5f), RoundedCornerShape(24.dp)),
            color = DarkBackground
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = GoldBright.copy(alpha = 0.15f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.Celebration,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = day.getName(language),
                                color = GoldBright,
                                fontSize = 20.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "${day.getDisplayDate(language)} • ${day.hijriDate}",
                                color = TextMutedEmerald,
                                fontSize = 14.sp
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_religious_day_detail_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = AppStrings.close(language),
                            tint = TextWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Countdown Banner
                    if (daysLeft >= 0) {
                        Surface(
                            shape = RoundedCornerShape(12.dp),
                            color = GoldContainer,
                            border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.6f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (isKurmanji) "Dema mayî ya vê roja pîroz:" else "Bu mübarek güne kalan süre:",
                                    color = TextWhite,
                                    fontSize = 16.sp
                                )
                                Text(
                                    text = AppStrings.daysLeftFormat(daysLeft, language),
                                    color = GoldBright,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }

                    // 1. Günün Anlam ve Önemi (Significance)
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = DarkCard),
                        border = BorderStroke(0.8.dp, DarkCardBorder)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (isKurmanji) "Wate û Girîngiya Vê Rojê" else "Günün Anlam ve Önemi",
                                color = GoldBright,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = day.getSignificance(language).ifBlank { day.getDescription(language) },
                                color = TextWhite.copy(alpha = 0.9f),
                                fontSize = 16.sp,
                                lineHeight = 24.sp
                            )
                        }
                    }

                    // 2. Tavsiye Edilen İbadetler ve Dualar (Recommended Deeds)
                    val deeds = day.getRecommendedDeeds(language)
                    if (deeds.isNotBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = DarkSurface),
                            border = BorderStroke(0.8.dp, EmeraldBorder)
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Text(
                                    text = if (isKurmanji) "Îbadet û Duayên Têne Pêşniyarkirin" else "Tavsiye Edilen İbadetler ve Dualar",
                                    color = GoldWarm,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = deeds,
                                    color = TextWhite.copy(alpha = 0.9f),
                                    fontSize = 16.sp,
                                    lineHeight = 25.sp
                                )
                            }
                        }
                    }

                    // 3. Kutlama ve Tebrik Mesajı (Celebration Message with Copy Button)
                    val celebration = day.getCelebrationMessage(language)
                    if (celebration.isNotBlank()) {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(containerColor = EmeraldContainer),
                            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = if (isKurmanji) "Peyama Pîrozbahiyê" else "Kutlama & Tebrik Mesajı",
                                        color = GoldBright,
                                        fontSize = 17.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    IconButton(
                                        onClick = {
                                            val clipboard =
                                                context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Tebrik Mesaji", celebration)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(
                                                context,
                                                AppStrings.copiedToClipboard(language),
                                                Toast.LENGTH_SHORT
                                            ).show()
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            Icons.Filled.ContentCopy,
                                            contentDescription = "Kopyala",
                                            tint = GoldBright,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = celebration,
                                    color = TextWhite,
                                    fontSize = 16.sp,
                                    lineHeight = 24.sp
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Bottom Action: Test Notification on Phone!
                Button(
                    onClick = {
                        val scheduler = EventNotificationScheduler(context, AppPreferences(context))
                        scheduler.sendInstantTestReligiousDayNotification(day)
                        Toast.makeText(
                            context,
                            if (isKurmanji) "Agahdariya pîrozbahiyê hate şandin!" else "Kutlama bildirimi telefona gönderildi!",
                            Toast.LENGTH_SHORT
                        ).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("test_religious_day_notification_button"),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = GoldBright)
                ) {
                    Icon(
                        Icons.Filled.NotificationsActive,
                        contentDescription = null,
                        tint = DarkBackground,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isKurmanji) "Agahdariya Vê Rojê Ceribîne" else "Bu Günün Bildirimini Test Et",
                        color = DarkBackground,
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            }
        }
    }
}
