package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Air
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.EditLocationAlt
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WbSunny
import androidx.compose.material.icons.filled.NightsStay
import androidx.compose.material.icons.filled.Cloud
import androidx.compose.material.icons.filled.Thunderstorm
import androidx.compose.material.icons.filled.AcUnit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.data.model.DailyForecastDay
import com.example.data.model.HourlyForecastPoint
import com.example.data.model.WeatherConditionType
import com.example.data.model.WeatherInfo
import com.example.ui.theme.*
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun WeatherVisualCard(
    weather: WeatherInfo?,
    selectedCity: City,
    isLoading: Boolean,
    errorMessage: String?,
    language: AppLanguage,
    onChangeLocation: () -> Unit,
    onRefreshWeather: () -> Unit,
    todayIso: String? = null,
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val conditionType = weather?.conditionType ?: WeatherConditionType.PARTLY_CLOUDY
    var selectedDayIndex by remember(weather?.updatedAtMillis) { mutableStateOf<Int?>(null) }

    val gradientColors = when (conditionType) {
        WeatherConditionType.CLEAR_DAY -> listOf(Color(0xFF144E63), Color(0xFF0E2C3E), DarkCard)
        WeatherConditionType.CLEAR_NIGHT -> listOf(Color(0xFF111D3B), Color(0xFF0C172B), DarkCard)
        WeatherConditionType.PARTLY_CLOUDY -> listOf(Color(0xFF163D4E), Color(0xFF0F2631), DarkCard)
        WeatherConditionType.OVERCAST -> listOf(Color(0xFF22343E), Color(0xFF142129), DarkCard)
        WeatherConditionType.FOG -> listOf(Color(0xFF283C42), Color(0xFF162429), DarkCard)
        WeatherConditionType.DRIZZLE,
        WeatherConditionType.RAIN -> listOf(Color(0xFF153453), Color(0xFF0E2136), DarkCard)
        WeatherConditionType.SNOW -> listOf(Color(0xFF204561), Color(0xFF12283A), DarkCard)
        WeatherConditionType.THUNDERSTORM -> listOf(Color(0xFF251E46), Color(0xFF13132B), DarkCard)
    }

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(22.dp))
            .testTag("weather_visual_card"),
        color = DarkCard,
        border = BorderStroke(1.1.dp, GoldClassic.copy(alpha = 0.55f))
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(Brush.verticalGradient(gradientColors))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                // Header Row: Active İl/İlçe + Live indicator + Change Location + Refresh
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isKurmanji) "REWŞA HEWAYÊ" else "CANLI HAVA DURUMU",
                                color = GoldBright,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                letterSpacing = 0.8.sp
                            )
                            if (weather != null) {
                                val clock = weather.getUpdatedClockLabel()
                                Spacer(modifier = Modifier.width(6.dp))
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(if (weather.isOfflineCache) Color(0xFFFFB74D) else Color(0xFF4CAF50))
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when {
                                        weather.isOfflineCache && isKurmanji -> "Bê Înternet • $clock"
                                        weather.isOfflineCache -> "Önbellek • $clock"
                                        isKurmanji -> "Zindî • $clock"
                                        else -> "Canlı • $clock"
                                    },
                                    color = if (weather.isOfflineCache) Color(0xFFFFCC80) else Color(0xFFA5D6A7),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = selectedCity.getDisplayName(language),
                                color = TextWhite,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(10.dp))
                                .clickable(onClick = onChangeLocation)
                                .testTag("weather_change_location_button"),
                            color = EmeraldContainer.copy(alpha = 0.9f),
                            border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.7f))
                        ) {
                            Row(
                                modifier = Modifier
                                    .defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                                    .padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.EditLocationAlt,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(15.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (isKurmanji) "Bajar / Navçe" else "İl / İlçe",
                                    color = GoldBright,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        IconButton(
                            onClick = onRefreshWeather,
                            modifier = Modifier
                                .size(48.dp)
                                .testTag("refresh_weather_button")
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = GoldBright,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = if (isKurmanji) "Nû Bike" else "Hava Durumunu Yenile",
                                    tint = GoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                if (weather != null) {
                    // Main Visual Sky Canvas + Temperature & Condition Details
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            WeatherAtmosphereArt(
                                conditionType = conditionType,
                                modifier = Modifier.size(76.dp)
                            )

                            Spacer(modifier = Modifier.width(12.dp))

                            Column {
                                Text(
                                    text = "${weather.temperatureC.roundToInt()}°C",
                                    color = TextWhite,
                                    fontSize = 38.sp,
                                    fontWeight = FontWeight.ExtraBold
                                )
                                Text(
                                    text = weather.getConditionLabel(language),
                                    color = GoldBright,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = if (isKurmanji) {
                                        "Tê hîskirin ${weather.apparentTemperatureC.roundToInt()}° • ↓${weather.minTempC.roundToInt()}° ↑${weather.maxTempC.roundToInt()}°"
                                    } else {
                                        "Hissedilen ${weather.apparentTemperatureC.roundToInt()}° • ↓${weather.minTempC.roundToInt()}° ↑${weather.maxTempC.roundToInt()}°"
                                    },
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        // Right Stats Column: Humidity & Wind
                        Column(
                            horizontalAlignment = Alignment.End,
                            verticalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = DarkSurface.copy(alpha = 0.7f),
                                border = BorderStroke(0.6.dp, DarkCardBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.WaterDrop,
                                        contentDescription = null,
                                        tint = Color(0xFF64B5F6),
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "%${weather.humidityPercent}",
                                        color = TextWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = DarkSurface.copy(alpha = 0.7f),
                                border = BorderStroke(0.6.dp, DarkCardBorder)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Air,
                                        contentDescription = null,
                                        tint = GoldWarm,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = "${weather.windSpeedKmh.roundToInt()} km/s",
                                        color = TextWhite,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }

                    // Hourly visual forecast strip
                    if (weather.hourlyForecast.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(weather.hourlyForecast) { point ->
                                HourlyMiniChip(point = point)
                            }
                        }
                    }

                    // 7-Day Visual Forecast Section
                    if (weather.dailyForecast.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(14.dp))

                        val weekMin = weather.dailyForecast.minOf { it.minTempC }
                        val weekMax = weather.dailyForecast.maxOf { it.maxTempC }

                        Surface(
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("seven_day_forecast_panel"),
                            shape = RoundedCornerShape(16.dp),
                            color = DarkSurface.copy(alpha = 0.58f),
                            border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.35f))
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 10.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(
                                            imageVector = Icons.Filled.CalendarMonth,
                                            contentDescription = null,
                                            tint = GoldBright,
                                            modifier = Modifier.size(15.dp)
                                        )
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isKurmanji) "PÊŞBÎNIYA 7 ROJAN" else "7 GÜNLÜK HAVA TAHMİNİ",
                                            color = GoldBright,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold,
                                            letterSpacing = 0.5.sp
                                        )
                                    }

                                    Text(
                                        text = "↓${weekMin.roundToInt()}°  ↑${weekMax.roundToInt()}°",
                                        color = TextMutedEmerald,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                weather.dailyForecast.forEachIndexed { index, day ->
                                    val isExpanded = selectedDayIndex == index
                                    DailyForecastVisualRow(
                                        day = day,
                                        dayIndex = index,
                                        weekMin = weekMin,
                                        weekMax = weekMax,
                                        currentTempToday = if (index == 0) weather.temperatureC else null,
                                        language = language,
                                        todayIso = todayIso,
                                        isExpanded = isExpanded,
                                        onClick = {
                                            selectedDayIndex = if (isExpanded) null else index
                                        }
                                    )

                                    if (index < weather.dailyForecast.lastIndex) {
                                        HorizontalDivider(
                                            color = DarkCardBorder.copy(alpha = 0.45f),
                                            thickness = 0.6.dp
                                        )
                                    }
                                }
                            }
                        }
                    }

                    if (weather.isOfflineCache || !errorMessage.isNullOrBlank()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = when {
                                    !errorMessage.isNullOrBlank() && isKurmanji ->
                                        "Agahiya zindî nehate wergirtin — ji nû ve biceribînin."
                                    !errorMessage.isNullOrBlank() ->
                                        "Güncel hava durumu sunucusuna ulaşılamadı — yenilemeyi deneyin."
                                    isKurmanji ->
                                        "Ji bîrgeha bê înternet tê nîşandan — dema înternet vebe dê bixweber nû bibe"
                                    else ->
                                        "Çevrimdışı önbellekten gösteriliyor — internet açılınca otomatik güncellenir"
                                },
                                color = if (!errorMessage.isNullOrBlank()) Color(0xFFFFCC80) else TextMutedEmerald,
                                fontSize = 14.sp,
                                lineHeight = 19.sp,
                                modifier = Modifier.weight(1f)
                            )
                            if (!errorMessage.isNullOrBlank()) {
                                TextButton(onClick = onRefreshWeather) {
                                    Text(
                                        text = if (isKurmanji) "Nû Bike" else "Yenile",
                                        color = GoldBright,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                            }
                        }
                    }
                } else if (isLoading) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 18.dp),
                        horizontalArrangement = Arrangement.Center,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(22.dp),
                            color = GoldBright,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isKurmanji) "Rewşa hewayê ya 7 rojan tê barkirin..." else "7 günlük hava durumu güncelleniyor...",
                            color = TextWhite,
                            fontSize = 16.sp
                        )
                    }
                } else {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 10.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isKurmanji) {
                                "Ji bo dîtina rewşa hewayê ya 7 rojan înternet pêwîst e (dema vebe bixweber nû dibe)."
                            } else {
                                "7 günlük canlı hava durumu için internet gereklidir (açılınca otomatik güncellenir)."
                            },
                            color = TextMutedEmerald,
                            fontSize = 15.sp,
                            lineHeight = 21.sp,
                            modifier = Modifier.weight(1f)
                        )
                        TextButton(onClick = onRefreshWeather) {
                            Text(
                                text = if (isKurmanji) "Dîsa Biceribîne" else "Yenile",
                                color = GoldBright,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun DailyForecastVisualRow(
    day: DailyForecastDay,
    dayIndex: Int,
    weekMin: Double,
    weekMax: Double,
    currentTempToday: Double?,
    language: AppLanguage,
    todayIso: String?,
    isExpanded: Boolean,
    onClick: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val dayTitle = WeatherInfo.formatDayLabel(day.dateIso, dayIndex, language, todayIso = todayIso)
    val shortDate = WeatherInfo.formatShortDate(day.dateIso, language)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .defaultMinSize(minHeight = 48.dp)
            .padding(vertical = 6.dp)
            .testTag("daily_forecast_row_$dayIndex")
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Day Name & Short Date
            Column(modifier = Modifier.width(80.dp)) {
                Text(
                    text = dayTitle,
                    color = if (dayIndex == 0) GoldBright else TextWhite,
                    fontSize = 15.sp,
                    fontWeight = if (dayIndex == 0) FontWeight.Bold else FontWeight.SemiBold,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                if (shortDate.isNotEmpty()) {
                    Text(
                        text = shortDate,
                        color = TextMutedEmerald,
                        fontSize = 13.sp
                    )
                }
            }

            // Visual Mini Sky Art + Precipitation Badge
            Row(
                modifier = Modifier.width(78.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                WeatherAtmosphereArt(
                    conditionType = day.conditionType,
                    modifier = Modifier.size(32.dp)
                )
                if (day.precipitationChancePercent >= 15) {
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "%${day.precipitationChancePercent}",
                        color = Color(0xFF64B5F6),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            // Min Temp Label
            Text(
                text = "${day.minTempC.roundToInt()}°",
                color = Color(0xFF90CAF9),
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                modifier = Modifier.width(38.dp)
            )

            // Proportional Visual Temperature Range Bar across the 7-day span
            DailyTempRangeBar(
                dayMin = day.minTempC,
                dayMax = day.maxTempC,
                weekMin = weekMin,
                weekMax = weekMax,
                currentTemp = currentTempToday,
                modifier = Modifier
                    .weight(1f)
                    .height(10.dp)
            )

            Spacer(modifier = Modifier.width(8.dp))

            // Max Temp Label
            Text(
                text = "${day.maxTempC.roundToInt()}°",
                color = TextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.width(38.dp)
            )
        }

        AnimatedVisibility(visible = isExpanded) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 4.dp, bottom = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = day.getConditionLabel(language),
                    color = GoldBright,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = if (isKurmanji) {
                        "Îhtimala baranê: %${day.precipitationChancePercent}"
                    } else {
                        "Yağış ihtimali: %${day.precipitationChancePercent}"
                    },
                    color = TextMutedEmerald,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun DailyTempRangeBar(
    dayMin: Double,
    dayMax: Double,
    weekMin: Double,
    weekMax: Double,
    currentTemp: Double?,
    modifier: Modifier = Modifier
) {
    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val barHeight = h * 0.62f
        val barTop = (h - barHeight) / 2f
        val corner = CornerRadius(barHeight / 2f, barHeight / 2f)

        // Track background
        drawRoundRect(
            color = Color(0xFF1D2E38),
            topLeft = Offset(0f, barTop),
            size = Size(w, barHeight),
            cornerRadius = corner
        )

        val totalSpan = max(1.0, weekMax - weekMin)
        val startFrac = ((dayMin - weekMin) / totalSpan).toFloat().coerceIn(0f, 1f)
        val endFrac = ((dayMax - weekMin) / totalSpan).toFloat().coerceIn(startFrac, 1f)

        val segStart = startFrac * w
        val segWidth = max(barHeight, (endFrac - startFrac) * w)

        drawRoundRect(
            brush = Brush.horizontalGradient(
                colors = listOf(
                    Color(0xFF4FC3F7),
                    Color(0xFFFFD54F),
                    Color(0xFFFF8A65)
                ),
                startX = 0f,
                endX = w
            ),
            topLeft = Offset(segStart, barTop),
            size = Size(minOf(segWidth, w - segStart), barHeight),
            cornerRadius = corner
        )

        if (currentTemp != null) {
            val curFrac = ((currentTemp - weekMin) / totalSpan).toFloat().coerceIn(0f, 1f)
            val cx = curFrac * w
            drawCircle(
                color = Color.White,
                radius = h * 0.48f,
                center = Offset(cx.coerceIn(h * 0.5f, w - h * 0.5f), h / 2f)
            )
        }
    }
}

@Composable
private fun HourlyMiniChip(point: HourlyForecastPoint) {
    val cond = WeatherInfo.classifyWmoCode(point.weatherCode, point.isDay)
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = DarkSurface.copy(alpha = 0.65f),
        border = BorderStroke(0.6.dp, DarkCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = point.hourLabel,
                color = TextMutedEmerald,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(3.dp))
            Icon(
                imageVector = weatherMiniIcon(cond),
                contentDescription = null,
                tint = weatherMiniTint(cond),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.height(3.dp))
            Text(
                text = "${point.temperatureC.roundToInt()}°",
                color = TextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold
            )
        }
    }
}

private fun weatherMiniIcon(cond: WeatherConditionType): ImageVector = when (cond) {
    WeatherConditionType.CLEAR_DAY -> Icons.Filled.WbSunny
    WeatherConditionType.CLEAR_NIGHT -> Icons.Filled.NightsStay
    WeatherConditionType.SNOW -> Icons.Filled.AcUnit
    WeatherConditionType.THUNDERSTORM -> Icons.Filled.Thunderstorm
    WeatherConditionType.DRIZZLE, WeatherConditionType.RAIN -> Icons.Filled.WaterDrop
    else -> Icons.Filled.Cloud
}

private fun weatherMiniTint(cond: WeatherConditionType): Color = when (cond) {
    WeatherConditionType.CLEAR_DAY -> Color(0xFFFFD54F)
    WeatherConditionType.CLEAR_NIGHT -> Color(0xFFB3E5FC)
    WeatherConditionType.SNOW -> Color(0xFFE0F7FA)
    WeatherConditionType.THUNDERSTORM -> Color(0xFFFFCA28)
    WeatherConditionType.DRIZZLE, WeatherConditionType.RAIN -> Color(0xFF64B5F6)
    else -> Color(0xFFCFD8DC)
}

/**
 * Custom Canvas illustration matching the live sky condition (sun, moon & stars, clouds, rain, snow, storm).
 * Uses local DrawScope dimensions so it scales fluidly across all screen densities.
 */
@Composable
fun WeatherAtmosphereArt(
    conditionType: WeatherConditionType,
    modifier: Modifier = Modifier
) {
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(14.dp))
            .background(Color.Black.copy(alpha = 0.22f)),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            val cx = w * 0.5f

            when (conditionType) {
                WeatherConditionType.CLEAR_DAY -> {
                    drawCircle(
                        color = Color(0x33FFD54F),
                        radius = w * 0.34f,
                        center = Offset(cx, h * 0.5f)
                    )
                    drawCircle(
                        color = Color(0xFFFFCA28),
                        radius = w * 0.20f,
                        center = Offset(cx, h * 0.5f)
                    )
                    for (i in 0 until 8) {
                        val angle = i * (PI / 4.0)
                        val r1 = w * 0.25f
                        val r2 = w * 0.36f
                        drawLine(
                            color = Color(0xFFFFD54F),
                            start = Offset(
                                cx + (r1 * cos(angle)).toFloat(),
                                h * 0.5f + (r1 * sin(angle)).toFloat()
                            ),
                            end = Offset(
                                cx + (r2 * cos(angle)).toFloat(),
                                h * 0.5f + (r2 * sin(angle)).toFloat()
                            ),
                            strokeWidth = w * 0.045f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                WeatherConditionType.CLEAR_NIGHT -> {
                    val stars = listOf(
                        Offset(w * 0.22f, h * 0.26f),
                        Offset(w * 0.78f, h * 0.24f),
                        Offset(w * 0.75f, h * 0.68f),
                        Offset(w * 0.25f, h * 0.72f)
                    )
                    stars.forEach { pt ->
                        drawCircle(color = Color(0xFFFFF59D), radius = w * 0.025f, center = pt)
                    }
                    drawCircle(
                        color = Color(0xFFFFE082),
                        radius = w * 0.21f,
                        center = Offset(cx, h * 0.5f)
                    )
                    drawCircle(
                        color = Color(0xFF101C36),
                        radius = w * 0.17f,
                        center = Offset(cx + w * 0.09f, h * 0.44f)
                    )
                }

                WeatherConditionType.PARTLY_CLOUDY -> {
                    drawCircle(
                        color = Color(0xFFFFCA28),
                        radius = w * 0.16f,
                        center = Offset(w * 0.65f, h * 0.34f)
                    )
                    drawCloudShape(w, h, yOffset = h * 0.58f, color = Color(0xFFE3EDF3))
                }

                WeatherConditionType.OVERCAST,
                WeatherConditionType.FOG -> {
                    drawCloudShape(w, h, yOffset = h * 0.48f, color = Color(0xFFB0BEC5))
                    if (conditionType == WeatherConditionType.FOG) {
                        for (row in 0..1) {
                            val y = h * (0.72f + row * 0.11f)
                            drawLine(
                                color = Color(0xCCCFD8DC),
                                start = Offset(w * 0.22f, y),
                                end = Offset(w * 0.78f, y),
                                strokeWidth = w * 0.05f,
                                cap = StrokeCap.Round
                            )
                        }
                    }
                }

                WeatherConditionType.DRIZZLE,
                WeatherConditionType.RAIN -> {
                    drawCloudShape(w, h, yOffset = h * 0.42f, color = Color(0xFFCFD8DC))
                    val dropsX = listOf(0.32f, 0.50f, 0.68f)
                    dropsX.forEachIndexed { idx, xFrac ->
                        val startY = h * (0.64f + (idx % 2) * 0.04f)
                        drawLine(
                            color = Color(0xFF64B5F6),
                            start = Offset(w * xFrac, startY),
                            end = Offset(w * (xFrac - 0.05f), startY + h * 0.16f),
                            strokeWidth = w * 0.05f,
                            cap = StrokeCap.Round
                        )
                    }
                }

                WeatherConditionType.SNOW -> {
                    drawCloudShape(w, h, yOffset = h * 0.42f, color = Color(0xFFE0F2F1))
                    val flakes = listOf(
                        Offset(w * 0.32f, h * 0.70f),
                        Offset(w * 0.50f, h * 0.78f),
                        Offset(w * 0.68f, h * 0.70f),
                        Offset(w * 0.41f, h * 0.84f),
                        Offset(w * 0.59f, h * 0.84f)
                    )
                    flakes.forEach { pt ->
                        drawCircle(color = Color.White, radius = w * 0.036f, center = pt)
                    }
                }

                WeatherConditionType.THUNDERSTORM -> {
                    drawCloudShape(w, h, yOffset = h * 0.39f, color = Color(0xFF90A4AE))
                    val bolt = Path().apply {
                        moveTo(w * 0.53f, h * 0.54f)
                        lineTo(w * 0.42f, h * 0.70f)
                        lineTo(w * 0.52f, h * 0.70f)
                        lineTo(w * 0.46f, h * 0.87f)
                        lineTo(w * 0.62f, h * 0.65f)
                        lineTo(w * 0.52f, h * 0.65f)
                        close()
                    }
                    drawPath(path = bolt, color = Color(0xFFFFD54F))
                }
            }
        }
    }
}

private fun androidx.compose.ui.graphics.drawscope.DrawScope.drawCloudShape(
    w: Float,
    h: Float,
    yOffset: Float,
    color: Color
) {
    drawCircle(
        color = color,
        radius = w * 0.15f,
        center = Offset(w * 0.34f, yOffset)
    )
    drawCircle(
        color = color,
        radius = w * 0.19f,
        center = Offset(w * 0.50f, yOffset - h * 0.06f)
    )
    drawCircle(
        color = color,
        radius = w * 0.14f,
        center = Offset(w * 0.66f, yOffset + h * 0.01f)
    )
    drawLine(
        color = color,
        start = Offset(w * 0.33f, yOffset + h * 0.06f),
        end = Offset(w * 0.67f, yOffset + h * 0.06f),
        strokeWidth = w * 0.18f,
        cap = StrokeCap.Round
    )
}
