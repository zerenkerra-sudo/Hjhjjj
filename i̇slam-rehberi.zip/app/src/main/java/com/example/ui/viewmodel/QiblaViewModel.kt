package com.example.ui.viewmodel

import android.app.Application
import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.sensor.QiblaCompassState
import com.example.sensor.QiblaSensorManager
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class QiblaViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = AppPreferences(application)
    private val sensorManager = QiblaSensorManager(application)

    val compassState: StateFlow<QiblaCompassState> = sensorManager.compassState

    private val _selectedCity = MutableStateFlow(resolveActiveCity())
    val selectedCity: StateFlow<City> = _selectedCity.asStateFlow()

    private var wasFacingQibla = false

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = application.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        application.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    init {
        refreshCoordinates()

        // Observe alignment to trigger haptic feedback
        viewModelScope.launch {
            compassState.collect { state ->
                if (state.isFacingQibla && !wasFacingQibla) {
                    triggerHapticFeedback()
                }
                wasFacingQibla = state.isFacingQibla
            }
        }
    }

    private fun resolveActiveCity(): City {
        return preferences.getSelectedCity()
    }

    fun refreshCoordinates() {
        val city = resolveActiveCity()
        _selectedCity.value = city
        val lat = if (city.isGps) preferences.getLastLatitude() else city.latitude
        val lng = if (city.isGps) preferences.getLastLongitude() else city.longitude
        sensorManager.updateCoordinates(lat, lng)
    }

    fun selectCity(city: City) {
        preferences.saveSelectedCity(city)
        if (!city.isGps) {
            preferences.setLastCoordinates(city.latitude, city.longitude)
        }
        refreshCoordinates()
    }

    fun startSensors() {
        refreshCoordinates()
        sensorManager.startListening()
    }

    fun stopSensors() {
        sensorManager.stopListening()
    }

    fun getLocationLabel(language: AppLanguage): String {
        val city = _selectedCity.value
        return if (city.isGps) {
            val lat = String.format("%.2f", preferences.getLastLatitude())
            val lng = String.format("%.2f", preferences.getLastLongitude())
            val display = city.getDisplayName(language)
            "$display ($lat, $lng)"
        } else {
            "${city.getDisplayName(language)} • ${city.country}"
        }
    }

    private fun triggerHapticFeedback() {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vibrator?.vibrate(
                    VibrationEffect.createOneShot(120, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            } else {
                @Suppress("DEPRECATION")
                vibrator?.vibrate(120L)
            }
        } catch (_: Exception) {}
    }

    override fun onCleared() {
        super.onCleared()
        sensorManager.stopListening()
    }
}
