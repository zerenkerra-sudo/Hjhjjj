package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.data.model.AppTheme
import com.example.data.model.City
import com.example.data.model.PrayerType
import com.example.service.AdhanPlayerService
import com.example.ui.dialogs.BatteryGuideDialog
import com.example.ui.dialogs.CitySelectionDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.SettingsViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(
    viewModel: SettingsViewModel,
    selectedCity: City? = null,
    onSelectCity: (City) -> Unit = {},
    onRequestGps: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsState()
    val isPlaying by viewModel.isAdhanServicePlaying.collectAsState()
    val language = uiState.language

    val notificationPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ ->
        viewModel.refreshPermissions()
    }

    var showBatteryGuideDialog by remember { mutableStateOf(false) }
    var showCitySelectionDialog by remember { mutableStateOf(false) }

    LaunchedEffect(Unit) {
        viewModel.refreshPermissions()
    }

    val isKurmanji = language == AppLanguage.KURMANJI

    Scaffold(
        modifier = modifier.testTag("settings_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.navSettings(language),
                        color = GoldBright,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Worldwide Prayer & Weather Location Card (İl / İlçe)
            if (selectedCity != null) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_location_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkCard),
                    border = BorderStroke(1.dp, DarkCardBorder)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isKurmanji) "Cihê Nimêj û Hewayê (Bajar / Navçe)" else "Namaz Vakti ve Hava Durumu Konumu",
                                        color = GoldBright,
                                        fontSize = 18.sp,
                                        lineHeight = 24.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    Text(
                                        text = "${selectedCity.getDisplayName(language)} • ${selectedCity.country}",
                                        color = TextWhite,
                                        fontSize = 16.sp,
                                        lineHeight = 22.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Text(
                            text = if (isKurmanji) {
                                "Hûn dikarin her dem bajar û navçeya xwe ji bo hemû cîhanê biguherînin."
                            } else {
                                "Dünyanın her yerinden il ve ilçe seçerek namaz vakitlerini ve hava durumunu güncelleyebilirsiniz."
                            },
                            color = TextMutedEmerald,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        Button(
                            onClick = { showCitySelectionDialog = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(min = 48.dp)
                                .testTag("settings_change_city_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldContainer,
                                contentColor = GoldBright
                            ),
                            border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.7f)),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Filled.Public, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (isKurmanji) "Bajar / Navçe Biguherîne (Cîhan)" else "İl / İlçe Değiştir (Tüm Dünya)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // Language Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("language_selection_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Translate,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = AppStrings.languageSelection(language),
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        LanguageOptionButton(
                            modifier = Modifier.weight(1f),
                            title = "Türkçe",
                            subtitle = "Türkiye Türkçesi",
                            isSelected = language == AppLanguage.TURKISH,
                            onClick = { viewModel.setLanguage(AppLanguage.TURKISH) },
                            tag = "select_turkish_button"
                        )

                        LanguageOptionButton(
                            modifier = Modifier.weight(1f),
                            title = "Kurmancî",
                            subtitle = "Tîpên Latînî",
                            isSelected = language == AppLanguage.KURMANJI,
                            onClick = { viewModel.setLanguage(AppLanguage.KURMANJI) },
                            tag = "select_kurmanji_button"
                        )
                    }
                }
            }

            // 5 Theme Selection Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("theme_selection_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Palette,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isKurmanji) "5 Temayên Sepanê" else "Uygulama Temaları (5 Seçenek)",
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isKurmanji)
                            "Li gorî dîmenê temayê rengê tevahiya sepanê biguherînin:"
                        else
                            "Tema görseline dokunarak tüm uygulamanın rengini seçtiğiniz temaya geçirin:",
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (theme in AppTheme.entries) {
                            val isSelected = uiState.appTheme == theme
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { viewModel.setAppTheme(theme) }
                                    .testTag("theme_option_${theme.id}"),
                                color = if (isSelected) theme.surfaceVariant else DarkSurface,
                                border = BorderStroke(
                                    width = if (isSelected) 1.8.dp else 1.dp,
                                    color = if (isSelected) theme.accent else DarkCardBorder
                                )
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(12.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Mini App Theme Visual Preview Swatch (reflects exact app look)
                                    Box(
                                        modifier = Modifier
                                            .size(width = 52.dp, height = 40.dp)
                                            .clip(RoundedCornerShape(10.dp))
                                            .background(theme.background)
                                            .border(1.dp, theme.cardBorder, RoundedCornerShape(10.dp))
                                            .padding(4.dp)
                                    ) {
                                        Column(
                                            modifier = Modifier.fillMaxSize(),
                                            verticalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            // Top bar strip in theme primary
                                            Box(
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .height(9.dp)
                                                    .clip(RoundedCornerShape(3.dp))
                                                    .background(theme.primary)
                                            )
                                            // Card preview + accent dot
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Box(
                                                    modifier = Modifier
                                                        .weight(1f)
                                                        .height(16.dp)
                                                        .clip(RoundedCornerShape(4.dp))
                                                        .background(theme.cardBackground)
                                                        .border(0.6.dp, theme.cardBorder, RoundedCornerShape(4.dp))
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Box(
                                                    modifier = Modifier
                                                        .size(12.dp)
                                                        .clip(CircleShape)
                                                        .background(theme.accent)
                                                        .border(0.8.dp, theme.secondary, CircleShape)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(12.dp))

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = theme.getDisplayName(language),
                                            color = if (isSelected) theme.accent else TextWhite,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                                            fontSize = 17.sp
                                        )
                                        Text(
                                            text = theme.getDisplaySubtitle(language),
                                            color = if (isSelected) theme.textSecondary else TextMutedEmerald,
                                            fontSize = 14.sp,
                                            lineHeight = 19.sp
                                        )
                                    }

                                    if (isSelected) {
                                        Surface(
                                            shape = RoundedCornerShape(8.dp),
                                            color = theme.accent.copy(alpha = 0.18f),
                                            border = BorderStroke(0.8.dp, theme.accent)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    imageVector = Icons.Filled.CheckCircle,
                                                    contentDescription = if (isKurmanji) "Çalak" else "Aktif",
                                                    tint = theme.accent,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                                Spacer(modifier = Modifier.width(4.dp))
                                                Text(
                                                    text = if (isKurmanji) "Çalak" else "Aktif",
                                                    color = theme.accent,
                                                    fontSize = 13.sp,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Automatic Adhan Settings
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("adhan_settings_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.NotificationsActive,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isKurmanji) "Mîhengên Banga Otomatîk" else "Otomatik Ezan Bildirimleri",
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = AppStrings.autoAdhanDesc(language) +
                            if (isKurmanji) " (Muezzîn: Abdülkadir Şehitoğlu)" else " (Müezzin: Abdülkadir Şehitoğlu)",
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Adhan Toggles for the 5 prayers (skipping Sunrise as per religious tradition & instructions)
                    AdhanToggleRow(
                        prayerName = PrayerType.FAJR.getName(language),
                        subName = if (isKurmanji) "Banga sibê • Abdülkadir Şehitoğlu (Saba)" else "Sabah ezanı • Abdülkadir Şehitoğlu (Saba)",
                        isEnabled = uiState.adhanFajr,
                        onToggle = { viewModel.toggleAdhan(PrayerType.FAJR, it) },
                        tag = "adhan_toggle_fajr"
                    )

                    HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                    AdhanToggleRow(
                        prayerName = PrayerType.DHUHR.getName(language),
                        subName = if (isKurmanji) "Banga nîvro • Abdülkadir Şehitoğlu" else "Öğle ezanı • Abdülkadir Şehitoğlu",
                        isEnabled = uiState.adhanDhuhr,
                        onToggle = { viewModel.toggleAdhan(PrayerType.DHUHR, it) },
                        tag = "adhan_toggle_dhuhr"
                    )

                    HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                    AdhanToggleRow(
                        prayerName = PrayerType.ASR.getName(language),
                        subName = if (isKurmanji) "Banga esrê • Abdülkadir Şehitoğlu" else "İkindi ezanı • Abdülkadir Şehitoğlu",
                        isEnabled = uiState.adhanAsr,
                        onToggle = { viewModel.toggleAdhan(PrayerType.ASR, it) },
                        tag = "adhan_toggle_asr"
                    )

                    HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                    AdhanToggleRow(
                        prayerName = PrayerType.MAGHRIB.getName(language),
                        subName = if (isKurmanji) "Banga şamê • Abdülkadir Şehitoğlu" else "Akşam ezanı • Abdülkadir Şehitoğlu",
                        isEnabled = uiState.adhanMaghrib,
                        onToggle = { viewModel.toggleAdhan(PrayerType.MAGHRIB, it) },
                        tag = "adhan_toggle_maghrib"
                    )

                    HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                    AdhanToggleRow(
                        prayerName = PrayerType.ISHA.getName(language),
                        subName = if (isKurmanji) "Banga êşa • Abdülkadir Şehitoğlu" else "Yatsı ezanı • Abdülkadir Şehitoğlu",
                        isEnabled = uiState.adhanIsha,
                        onToggle = { viewModel.toggleAdhan(PrayerType.ISHA, it) },
                        tag = "adhan_toggle_isha"
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Notice that Sunrise has no adhan
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = DarkSurfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = if (isKurmanji) "Bala xwe bidinê: Di wextê rojhilatê de bang nayê xwendin." else "Bilgi: Güneş doğuşu vaktinde ezan okunmaz.",
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Media Volume Control Slider ("Ezan okununca zil sesi olarak çalışmasın medya sesi ile calissın sesi yukseltince yükselsin kısaltinca kısalsın")
                    val currentMediaVol by viewModel.mediaVolume.collectAsState()
                    val maxMediaVol = remember { viewModel.getMaxMediaVolume().coerceAtLeast(1) }
                    val volPercent = ((currentMediaVol.toFloat() / maxMediaVol) * 100).toInt()

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant.copy(alpha = 0.8f),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("adhan_media_volume_card")
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = when {
                                            currentMediaVol == 0 -> Icons.Filled.VolumeMute
                                            currentMediaVol < maxMediaVol / 2 -> Icons.Filled.VolumeDown
                                            else -> Icons.Filled.VolumeUp
                                        },
                                        contentDescription = null,
                                        tint = GoldBright,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (isKurmanji) "Dengê Medyayê (Banga Şerîf)" else "Medya Sesi Düzeyi (Ezan)",
                                        color = GoldBright,
                                        fontSize = 16.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }

                                Text(
                                    text = "%$volPercent",
                                    color = TextWhite,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))

                            Text(
                                text = if (isKurmanji)
                                    "Ezan bi dengê medyayê tê lîstin. Hûn dikarin bi bişkokên dengê telefonê an bi vî xêzikî dengê zêde an kêm bikin."
                                else
                                    "Ezan zil sesi olarak değil medya sesi ile okunur. Telefonun yan ses tuşları ile veya bu ayardan sesi dilediğiniz gibi yükseltip kısabilirsiniz.",
                                color = TextMutedEmerald,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )

                            Spacer(modifier = Modifier.height(6.dp))

                            Slider(
                                value = currentMediaVol.toFloat(),
                                onValueChange = { newVol ->
                                    viewModel.setMediaVolume(newVol.toInt())
                                },
                                valueRange = 0f..maxMediaVol.toFloat(),
                                steps = (maxMediaVol - 1).coerceAtLeast(0),
                                colors = SliderDefaults.colors(
                                    thumbColor = GoldBright,
                                    activeTrackColor = EmeraldPrimary,
                                    inactiveTrackColor = DarkSurface
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("media_volume_slider")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Test Adhan Buttons
                    if (isPlaying) {
                        Button(
                            onClick = { viewModel.stopAdhan() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stop_adhan_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFFC62828),
                                contentColor = TextWhite
                            ),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stop,
                                contentDescription = null,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.stopAdhan(language),
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp
                            )
                        }
                    } else {
                        Column(
                            modifier = Modifier.fillMaxWidth(),
                            verticalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.testAdhan("adhan.mp3") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("test_adhan_button"),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = EmeraldPrimary,
                                    contentColor = TextWhite
                                ),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.VolumeUp,
                                    contentDescription = null,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isKurmanji) "Banga Şerîf Bibihîze (Abdülkadir Şehitoğlu)" else "Ezanı Dinle (Abdülkadir Şehitoğlu)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp
                                )
                            }

                            OutlinedButton(
                                onClick = { viewModel.testAdhan("adhan_fajr.mp3") },
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("test_fajr_adhan_button"),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    containerColor = DarkSurfaceVariant,
                                    contentColor = GoldBright
                                ),
                                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.8f)),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.WbTwilight,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isKurmanji) "Banga Sibê Bibihîze (Abdülkadir Şehitoğlu)" else "Sabah Ezanını Dinle (Abdülkadir Şehitoğlu)",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }
                }
            }

            // Pre-Adhan 30 Minutes Approaching Reminder Card ("Her Ezana 30 dakika kaldığında otomatik bildirim")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("pre_adhan_reminder_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(
                                Icons.Filled.Schedule,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = AppStrings.preAdhanReminderTitle(language),
                                    color = GoldBright,
                                    fontSize = 19.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = if (isKurmanji) "Agahdariya 'Wextê Nimêjê Nêzîk Dibe'" else "Namaza Yaklaşıyor Bildirimi",
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp
                                )
                            }
                        }

                        Switch(
                            checked = uiState.preAdhanReminderEnabled,
                            onCheckedChange = { viewModel.togglePreAdhanReminder(it) },
                            modifier = Modifier.testTag("pre_adhan_master_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldBright,
                                checkedTrackColor = EmeraldPrimary,
                                uncheckedThumbColor = TextMutedEmerald,
                                uncheckedTrackColor = DarkSurface
                            )
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = AppStrings.preAdhanReminderDesc(language),
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )

                    if (uiState.preAdhanReminderEnabled) {
                        Spacer(modifier = Modifier.height(14.dp))

                        AdhanToggleRow(
                            prayerName = PrayerType.FAJR.getName(language),
                            subName = if (isKurmanji) "Berî banga sibê bi 30 xulekan" else "Sabah ezanına 30 dakika kala",
                            isEnabled = uiState.preAdhanFajr,
                            onToggle = { viewModel.togglePreAdhanForPrayer(PrayerType.FAJR, it) },
                            tag = "pre_adhan_toggle_fajr"
                        )

                        HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                        AdhanToggleRow(
                            prayerName = PrayerType.DHUHR.getName(language),
                            subName = if (isKurmanji) "Berî banga nîvro bi 30 xulekan" else "Öğle ezanına 30 dakika kala",
                            isEnabled = uiState.preAdhanDhuhr,
                            onToggle = { viewModel.togglePreAdhanForPrayer(PrayerType.DHUHR, it) },
                            tag = "pre_adhan_toggle_dhuhr"
                        )

                        HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                        AdhanToggleRow(
                            prayerName = PrayerType.ASR.getName(language),
                            subName = if (isKurmanji) "Berî banga esir bi 30 xulekan" else "İkindi ezanına 30 dakika kala",
                            isEnabled = uiState.preAdhanAsr,
                            onToggle = { viewModel.togglePreAdhanForPrayer(PrayerType.ASR, it) },
                            tag = "pre_adhan_toggle_asr"
                        )

                        HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                        AdhanToggleRow(
                            prayerName = PrayerType.MAGHRIB.getName(language),
                            subName = if (isKurmanji) "Berî banga şamê bi 30 xulekan" else "Akşam ezanına 30 dakika kala",
                            isEnabled = uiState.preAdhanMaghrib,
                            onToggle = { viewModel.togglePreAdhanForPrayer(PrayerType.MAGHRIB, it) },
                            tag = "pre_adhan_toggle_maghrib"
                        )

                        HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                        AdhanToggleRow(
                            prayerName = PrayerType.ISHA.getName(language),
                            subName = if (isKurmanji) "Berî banga êşa bi 30 xulekan" else "Yatsı ezanına 30 dakika kala",
                            isEnabled = uiState.preAdhanIsha,
                            onToggle = { viewModel.togglePreAdhanForPrayer(PrayerType.ISHA, it) },
                            tag = "pre_adhan_toggle_isha"
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        // Test 30-Min Notification Button
                        OutlinedButton(
                            onClick = { viewModel.testPreAdhanNotification() },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("test_pre_adhan_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, GoldClassic),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldBright)
                        ) {
                            Icon(
                                imageVector = Icons.Filled.NotificationsActive,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.testPreAdhanButton(language),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // Persistent Notification Bar Card ("Telefon Bildirim Yerinde Namaz Vakitleri")
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("notification_bar_prayer_times_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.NotificationsNone,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = AppStrings.persistentNotificationTitle(language),
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = AppStrings.persistentNotificationDesc(language),
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (isKurmanji) "Agahdariya Berdewam a Veqtan" else "Sürekli Vakit Bildirimi",
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = if (isKurmanji) "Di perdeya agahdariyê de nîşan bide" else "Bildirim çekmecesinde sabit göster",
                                color = TextMutedEmerald,
                                fontSize = 14.sp
                            )
                        }

                        Switch(
                            checked = uiState.prayerBarNotification,
                            onCheckedChange = { enabled ->
                                viewModel.togglePrayerBarNotification(enabled)
                                if (enabled && !uiState.hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                                    notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                                }
                            },
                            modifier = Modifier.testTag("prayer_bar_notification_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldBright,
                                checkedTrackColor = EmeraldPrimary,
                                uncheckedThumbColor = TextMutedEmerald,
                                uncheckedTrackColor = DarkSurface
                            )
                        )
                    }

                    if (!uiState.hasNotificationPermission && Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        Spacer(modifier = Modifier.height(12.dp))
                        OutlinedButton(
                            onClick = {
                                notificationPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
                            },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("grant_notification_permission_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, Color(0xFFFFB300)),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFFFB300))
                        ) {
                            Icon(Icons.Filled.Warning, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = AppStrings.grantNotificationPermission(language),
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // Friday & Religious Days Reminder Settings Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("islamic_reminders_settings_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.Campaign,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isKurmanji) "Agahdariyên Înê û Rojên Pîroz" else "Cuma & Dini Gün Hatırlatıcıları",
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Friday reminder toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = AppStrings.settingFridayReminderTitle(language),
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = AppStrings.settingFridayReminderDesc(language),
                                color = TextMutedEmerald,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Switch(
                            checked = uiState.fridayReminder,
                            onCheckedChange = { viewModel.toggleFridayReminder(it) },
                            modifier = Modifier.testTag("friday_reminder_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldBright,
                                checkedTrackColor = EmeraldPrimary,
                                uncheckedThumbColor = TextMutedEmerald,
                                uncheckedTrackColor = DarkSurface
                            )
                        )
                    }

                    HorizontalDivider(color = DarkCardBorder, thickness = 0.8.dp)

                    // Religious Days / Kandil toggle
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = AppStrings.settingReligiousDaysReminderTitle(language),
                                color = TextWhite,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 18.sp
                            )
                            Text(
                                text = AppStrings.settingReligiousDaysReminderDesc(language),
                                color = TextMutedEmerald,
                                fontSize = 14.sp,
                                lineHeight = 20.sp
                            )
                        }

                        Spacer(modifier = Modifier.width(10.dp))

                        Switch(
                            checked = uiState.religiousDaysReminder,
                            onCheckedChange = { viewModel.toggleReligiousDaysReminder(it) },
                            modifier = Modifier.testTag("religious_days_reminder_switch"),
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = GoldBright,
                                checkedTrackColor = EmeraldPrimary,
                                uncheckedThumbColor = TextMutedEmerald,
                                uncheckedTrackColor = DarkSurface
                            )
                        )
                    }
                }
            }

            // Battery Optimization & Exact Alarms System Card
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("battery_permission_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkCard),
                border = BorderStroke(1.dp, DarkCardBorder)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Filled.BatteryChargingFull,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = AppStrings.batteryOptimizationTitle(language),
                            color = GoldBright,
                            fontSize = 19.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = AppStrings.batteryOptimizationDesc(language),
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        OutlinedButton(
                            onClick = { showBatteryGuideDialog = true },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("open_battery_guide_dialog_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, GoldClassic),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = GoldBright)
                        ) {
                            Icon(Icons.Filled.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isKurmanji) "Rêbername" else "Nasıl Yapılır?",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = { viewModel.openBatterySettings(context) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("battery_system_settings_button"),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = EmeraldContainer,
                                contentColor = GoldBright
                            )
                        ) {
                            Icon(Icons.Filled.Settings, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (isKurmanji) "Mîhengên Pîlê" else "Pil Ayarları",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedButton(
                            onClick = { viewModel.openExactAlarmSettings(context) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("exact_alarm_system_settings_button"),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (uiState.isExactAlarmGranted) EmeraldBorder else Color(0xFFFF7043))
                        ) {
                            Icon(
                                imageVector = if (uiState.isExactAlarmGranted) Icons.Filled.CheckCircle else Icons.Filled.Warning,
                                contentDescription = null,
                                tint = if (uiState.isExactAlarmGranted) GoldBright else Color(0xFFFF7043),
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = if (uiState.isExactAlarmGranted)
                                    (if (isKurmanji) "Destûra Alarma Exact: Çalak e" else "Tam Zamanlı Alarm İzni: Açık")
                                else
                                    (if (isKurmanji) "Destûra Alarma Exact Veke" else "Tam Zamanlı Alarm İznini Aç"),
                                color = TextWhite,
                                fontSize = 16.sp
                            )
                        }
                    }
                }
            }

            // Zeren Teknoloji Footer Badge ("Zeren teknoloji uygulama da küçük bir ayarların köşesinde gözüksün")
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp)
                    .testTag("zeren_teknoloji_badge"),
                contentAlignment = Alignment.Center
            ) {
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = DarkSurfaceVariant.copy(alpha = 0.5f),
                    border = BorderStroke(0.6.dp, GoldClassic.copy(alpha = 0.3f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(6.dp)
                                .clip(CircleShape)
                                .background(GoldBright)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Zeren Teknoloji",
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Medium,
                            letterSpacing = 0.8.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(28.dp))
        }
    }

    if (showBatteryGuideDialog) {
        BatteryGuideDialog(
            language = language,
            onDismiss = { showBatteryGuideDialog = false },
            onOpenBatterySettings = { viewModel.openBatterySettings(context) }
        )
    }

    if (showCitySelectionDialog && selectedCity != null) {
        CitySelectionDialog(
            language = language,
            currentCity = selectedCity,
            onDismiss = { showCitySelectionDialog = false },
            onSelectCity = { city ->
                onSelectCity(city)
                showCitySelectionDialog = false
            },
            onRequestGps = {
                onRequestGps()
                showCitySelectionDialog = false
            }
        )
    }
}

@Composable
private fun LanguageOptionButton(
    modifier: Modifier = Modifier,
    title: String,
    subtitle: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(tag),
        color = if (isSelected) EmeraldPrimary else DarkSurface,
        border = BorderStroke(1.2.dp, if (isSelected) GoldBright else DarkCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = if (isSelected) GoldBright else TextWhite,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = TextMutedEmerald,
                fontSize = 14.sp
            )
        }
    }
}

@Composable
private fun AdhanToggleRow(
    prayerName: String,
    subName: String,
    isEnabled: Boolean,
    onToggle: (Boolean) -> Unit,
    tag: String
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = prayerName,
                color = TextWhite,
                fontWeight = FontWeight.SemiBold,
                fontSize = 18.sp
            )
            Text(
                text = subName,
                color = TextMutedEmerald,
                fontSize = 14.sp,
                lineHeight = 19.sp
            )
        }

        Switch(
            checked = isEnabled,
            onCheckedChange = onToggle,
            modifier = Modifier.testTag(tag),
            colors = SwitchDefaults.colors(
                checkedThumbColor = GoldBright,
                checkedTrackColor = EmeraldPrimary,
                uncheckedThumbColor = TextMutedEmerald,
                uncheckedTrackColor = DarkSurface
            )
        )
    }
}
