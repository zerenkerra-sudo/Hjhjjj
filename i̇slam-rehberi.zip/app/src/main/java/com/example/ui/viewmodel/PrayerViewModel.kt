package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.alarm.AdhanScheduler
import com.example.data.local.AppPreferences
import com.example.data.local.HutbeData
import com.example.data.model.City
import com.example.data.model.Hutbe
import com.example.data.model.NextPrayerInfo
import com.example.data.model.PrayerTimes
import com.example.data.model.PrayerType
import com.example.data.model.WeatherInfo
import com.example.data.repository.DiyanetHutbeRepository
import com.example.data.repository.PrayerRepository
import com.example.data.repository.WeatherRepository
import com.example.util.NetworkUtils
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

data class PrayerUiState(
    val prayerTimes: PrayerTimes? = null,
    val nextPrayer: NextPrayerInfo? = null,
    val activePrayer: PrayerType = PrayerType.FAJR,
    val selectedCity: City = City.DEFAULT_CITIES.find { it.id == "istanbul" } ?: City.DEFAULT_CITIES[5],
    val isLoading: Boolean = false,
    val errorMessage: String? = null,
    val isGpsActive: Boolean = false,
    val exactAlarmPermissionNeeded: Boolean = false,
    val weatherInfo: WeatherInfo? = null,
    val isWeatherLoading: Boolean = false,
    val weatherError: String? = null,
    val isNetworkOnline: Boolean = true,
    val currentHutbe: Hutbe = HutbeData.getCurrentWeekHutbe(),
    val hutbeArchive: List<Hutbe> = HutbeData.HUTBE_LIST,
    val isHutbeLoading: Boolean = false,
    val hutbeSyncError: String? = null,
    val hutbeLastUpdatedMillis: Long = 0L
)

class PrayerViewModel(application: Application) : AndroidViewModel(application) {

    val preferences = AppPreferences(application)
    private val repository = PrayerRepository(preferences, application)
    private val weatherRepository = WeatherRepository(preferences, application)
    private val hutbeRepository = DiyanetHutbeRepository(preferences, application)
    val scheduler = AdhanScheduler(application, preferences)

    private val _uiState = MutableStateFlow(PrayerUiState())
    val uiState: StateFlow<PrayerUiState> = _uiState.asStateFlow()

    private var countdownJob: Job? = null
    private var networkObserverJob: Job? = null
    private var weatherJob: Job? = null
    private var wasOffline = false

    init {
        val initialCity = preferences.getSelectedCity()
        val isGps = initialCity.isGps
        val initialOnline = NetworkUtils.isNetworkAvailable(application)
        wasOffline = !initialOnline

        val lat = if (isGps) preferences.getLastLatitude() else initialCity.latitude
        val lng = if (isGps) preferences.getLastLongitude() else initialCity.longitude
        val initialDisplayName = initialCity.getDisplayName(preferences.getLanguage())

        val initialHutbes = hutbeRepository.getAvailableHutbes()
        val validCachedWeather = WeatherRepository.getValidCachedWeather(
            preferences = preferences,
            latitude = lat,
            longitude = lng,
            locationName = initialDisplayName,
            country = initialCity.country
        )
        _uiState.value = _uiState.value.copy(
            selectedCity = initialCity,
            isGpsActive = isGps,
            exactAlarmPermissionNeeded = !scheduler.canScheduleExactAlarms(),
            weatherInfo = validCachedWeather,
            isNetworkOnline = initialOnline,
            hutbeArchive = initialHutbes,
            currentHutbe = initialHutbes.firstOrNull() ?: HutbeData.getCurrentWeekHutbe(),
            hutbeLastUpdatedMillis = preferences.getLastHutbeSyncMillis()
        )

        loadPrayerTimes(lat, lng, initialCity.nameTr, country = initialCity.country)
        loadWeather(lat, lng, initialDisplayName, country = initialCity.country, forceRefresh = false)
        syncWeeklyHutbe(forceRefresh = false)
        observeConnectivityChanges()
        startCountdownTimer()
    }

    private fun observeConnectivityChanges() {
        networkObserverJob?.cancel()
        networkObserverJob = viewModelScope.launch {
            NetworkUtils.observeNetworkAvailability(getApplication())
                .distinctUntilChanged()
                .collect { isOnline ->
                    _uiState.value = _uiState.value.copy(isNetworkOnline = isOnline)
                    if (!isOnline) {
                        wasOffline = true
                    } else {
                        val currentWeather = _uiState.value.weatherInfo
                        val needsWeatherSync = wasOffline ||
                            currentWeather == null ||
                            currentWeather.isOfflineCache ||
                            currentWeather.dailyForecast.size < 7
                        val needsPrayerSync = wasOffline || _uiState.value.prayerTimes?.isOffline == true
                        val needsHutbeSync = wasOffline || hutbeRepository.shouldAutoSync()
                        wasOffline = false
                        if (needsWeatherSync || needsPrayerSync || needsHutbeSync) {
                            // Brief settle delay so active network DNS/routes are ready right as Wi-Fi/Cellular comes up
                            delay(450L)
                            if (NetworkUtils.isNetworkAvailable(getApplication())) {
                                if (needsWeatherSync || needsPrayerSync) {
                                    refreshAll()
                                }
                                if (needsHutbeSync) {
                                    syncWeeklyHutbe(forceRefresh = false)
                                }
                            }
                        }
                    }
                }
        }
    }

    fun onAppResumed() {
        val currentTimes = _uiState.value.prayerTimes
        val city = _uiState.value.selectedCity
        val lat = if (city.isGps) preferences.getLastLatitude() else city.latitude
        val lng = if (city.isGps) preferences.getLastLongitude() else city.longitude
        val expectedIso = currentDateIsoForCity(lat, lng, city.nameTr, city.country, currentTimes?.timezone ?: "")

        if (currentTimes == null || currentTimes.dateIso != expectedIso) {
            loadPrayerTimes(lat, lng, city.nameTr, forceRefresh = false, country = city.country)
        }

        val online = NetworkUtils.isNetworkAvailable(getApplication())
        _uiState.value = _uiState.value.copy(isNetworkOnline = online)
        if (!online) return

        val weather = _uiState.value.weatherInfo
        val fiveMinutesMs = 5 * 60 * 1000L
        val coordMismatch = weather != null && (
            kotlin.math.abs(weather.latitude - lat) > WeatherRepository.MAX_CACHE_COORD_DELTA ||
                kotlin.math.abs(weather.longitude - lng) > WeatherRepository.MAX_CACHE_COORD_DELTA
            )
        val isStaleOrMissing = weather == null ||
            coordMismatch ||
            weather.isOfflineCache ||
            weather.dailyForecast.size < 7 ||
            (System.currentTimeMillis() - weather.updatedAtMillis) > fiveMinutesMs

        if (isStaleOrMissing && !_uiState.value.isWeatherLoading) {
            refreshAll()
        }
        if (hutbeRepository.shouldAutoSync() && !_uiState.value.isHutbeLoading) {
            syncWeeklyHutbe(forceRefresh = false)
        }
    }

    private fun currentDateIsoForCity(
        lat: Double,
        lng: Double,
        cityName: String,
        country: String,
        preferredTz: String = ""
    ): String {
        val tzId = com.example.data.repository.DiyanetCalculator.resolveTimeZoneId(
            latitude = lat,
            longitude = lng,
            cityName = cityName,
            country = country,
            preferredTz = preferredTz
        )
        val tz = com.example.data.repository.DiyanetCalculator.getTimeZoneForId(tzId)
        return java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).apply {
            timeZone = tz
        }.format(java.util.Date())
    }

    fun syncWeeklyHutbe(forceRefresh: Boolean = false) {
        if (_uiState.value.isHutbeLoading) return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isHutbeLoading = true, hutbeSyncError = null)
            val result = hutbeRepository.syncLatestHutbes(forceRefresh = forceRefresh)
            result.onSuccess { updatedList ->
                val activeSelectedId = _uiState.value.currentHutbe.id
                val preservedSelection = if (forceRefresh) {
                    updatedList.firstOrNull()
                } else {
                    updatedList.find { it.id == activeSelectedId } ?: updatedList.firstOrNull()
                }
                _uiState.value = _uiState.value.copy(
                    hutbeArchive = updatedList,
                    currentHutbe = preservedSelection ?: HutbeData.getCurrentWeekHutbe(),
                    isHutbeLoading = false,
                    hutbeSyncError = null,
                    hutbeLastUpdatedMillis = preferences.getLastHutbeSyncMillis()
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isHutbeLoading = false,
                    hutbeSyncError = err.localizedMessage
                )
            }
        }
    }

    fun selectHutbe(hutbe: Hutbe) {
        _uiState.value = _uiState.value.copy(currentHutbe = hutbe)
    }

    fun checkExactAlarmPermission() {
        _uiState.value = _uiState.value.copy(
            exactAlarmPermissionNeeded = !scheduler.canScheduleExactAlarms()
        )
    }

    fun loadPrayerTimes(
        latitude: Double,
        longitude: Double,
        cityName: String,
        forceRefresh: Boolean = false,
        country: String = _uiState.value.selectedCity.country
    ) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, errorMessage = null)
            val result = repository.getPrayerTimes(
                latitude = latitude,
                longitude = longitude,
                cityName = cityName,
                forceRefresh = forceRefresh,
                country = country
            )
            result.onSuccess { times ->
                val next = repository.calculateNextPrayer(times)
                val active = repository.getCurrentActivePrayer(times)
                _uiState.value = _uiState.value.copy(
                    prayerTimes = times,
                    nextPrayer = next,
                    activePrayer = active,
                    isLoading = false
                )
                // Schedule exact adhan alarms for all enabled prayers
                scheduler.scheduleAllAlarms(times)
                // Update persistent prayer notification in the phone's notification drawer
                com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                    getApplication(),
                    times,
                    _uiState.value.selectedCity,
                    preferences.getLanguage()
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = err.localizedMessage
                )
            }
        }
    }

    fun loadWeather(
        latitude: Double,
        longitude: Double,
        locationName: String,
        country: String = _uiState.value.selectedCity.country,
        forceRefresh: Boolean = false
    ) {
        weatherJob?.cancel()
        val existing = _uiState.value.weatherInfo
        val mismatch = existing != null && (
            kotlin.math.abs(existing.latitude - latitude) > WeatherRepository.MAX_CACHE_COORD_DELTA ||
                kotlin.math.abs(existing.longitude - longitude) > WeatherRepository.MAX_CACHE_COORD_DELTA
            )
        weatherJob = viewModelScope.launch {
            _uiState.value = _uiState.value.copy(
                weatherInfo = if (mismatch) null else existing,
                isWeatherLoading = true,
                weatherError = null
            )
            val result = weatherRepository.getWeatherForLocation(
                latitude = latitude,
                longitude = longitude,
                locationName = locationName,
                country = country,
                forceRefresh = forceRefresh
            )
            result.onSuccess { weather ->
                _uiState.value = _uiState.value.copy(
                    weatherInfo = weather,
                    isWeatherLoading = false,
                    weatherError = null
                )
            }.onFailure { err ->
                _uiState.value = _uiState.value.copy(
                    isWeatherLoading = false,
                    weatherError = err.localizedMessage
                )
            }
        }
    }

    fun refreshAll() {
        val city = _uiState.value.selectedCity
        val lat = if (city.isGps) preferences.getLastLatitude() else city.latitude
        val lng = if (city.isGps) preferences.getLastLongitude() else city.longitude
        val lang = preferences.getLanguage()
        loadPrayerTimes(lat, lng, city.nameTr, forceRefresh = true, country = city.country)
        loadWeather(lat, lng, city.getDisplayName(lang), country = city.country, forceRefresh = true)
        syncWeeklyHutbe(forceRefresh = true)
    }

    fun selectCity(city: City) {
        preferences.saveSelectedCity(city)
        val lang = preferences.getLanguage()
        if (city.isGps) {
            _uiState.value = _uiState.value.copy(selectedCity = city, isGpsActive = true)
            val lat = preferences.getLastLatitude()
            val lng = preferences.getLastLongitude()
            loadPrayerTimes(lat, lng, city.nameTr, forceRefresh = true, country = city.country)
            loadWeather(lat, lng, city.getDisplayName(lang), country = city.country, forceRefresh = true)
        } else {
            _uiState.value = _uiState.value.copy(selectedCity = city, isGpsActive = false)
            preferences.setLastCoordinates(city.latitude, city.longitude)
            loadPrayerTimes(city.latitude, city.longitude, city.nameTr, forceRefresh = true, country = city.country)
            loadWeather(city.latitude, city.longitude, city.getDisplayName(lang), country = city.country, forceRefresh = true)
        }
    }

    fun updateGpsCoordinates(lat: Double, lng: Double, addressName: String = "GPS Konumu") {
        preferences.setLastCoordinates(lat, lng)
        val gpsCity = City.GPS.copy(latitude = lat, longitude = lng, nameTr = addressName, nameKu = addressName)
        preferences.saveSelectedCity(gpsCity)
        _uiState.value = _uiState.value.copy(selectedCity = gpsCity, isGpsActive = true)
        loadPrayerTimes(lat, lng, addressName, forceRefresh = true, country = "")
        loadWeather(lat, lng, addressName, country = "", forceRefresh = true)
    }

    fun toggleAdhan(prayer: PrayerType, enabled: Boolean) {
        preferences.setAdhanEnabled(prayer, enabled)
        val times = _uiState.value.prayerTimes
        if (times != null) {
            if (enabled) {
                scheduler.schedulePrayerAlarm(prayer, times)
            } else {
                scheduler.cancelPrayerAlarm(prayer)
            }
        }
    }

    fun togglePrayerBarNotification(enabled: Boolean) {
        preferences.setPrayerBarNotificationEnabled(enabled)
        val times = _uiState.value.prayerTimes
        if (enabled && times != null) {
            com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                getApplication(),
                times,
                _uiState.value.selectedCity,
                preferences.getLanguage()
            )
        } else if (!enabled) {
            com.example.notification.PrayerNotificationManager.cancelPrayerNotification(getApplication())
        }
    }

    private fun startCountdownTimer() {
        countdownJob?.cancel()
        countdownJob = viewModelScope.launch {
            var lastNotifPrayer: PrayerType? = null
            var lastNotifSubHour: Boolean? = null
            var lastNotifMinuteBucket: Long = -1L
            while (isActive) {
                delay(1000L)
                val times = _uiState.value.prayerTimes ?: continue
                val city = _uiState.value.selectedCity
                val lat = if (city.isGps) preferences.getLastLatitude() else city.latitude
                val lng = if (city.isGps) preferences.getLastLongitude() else city.longitude
                val expectedIso = currentDateIsoForCity(lat, lng, city.nameTr, city.country, times.timezone)
                if (times.dateIso.isNotBlank() && times.dateIso != expectedIso && !_uiState.value.isLoading) {
                    loadPrayerTimes(lat, lng, city.nameTr, forceRefresh = true, country = city.country)
                    continue
                }
                val next = repository.calculateNextPrayer(times)
                val active = repository.getCurrentActivePrayer(times)
                _uiState.value = _uiState.value.copy(
                    nextPrayer = next,
                    activePrayer = active
                )

                val isSubHour = next.millisRemaining < 3_600_000L
                val minuteBucket = next.millisRemaining / 60_000L
                if (lastNotifPrayer != next.type || lastNotifSubHour != isSubHour || lastNotifMinuteBucket != minuteBucket) {
                    lastNotifPrayer = next.type
                    lastNotifSubHour = isSubHour
                    lastNotifMinuteBucket = minuteBucket
                    com.example.notification.PrayerNotificationManager.updatePrayerNotification(
                        getApplication(),
                        times,
                        city,
                        preferences.getLanguage()
                    )
                }
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        countdownJob?.cancel()
        networkObserverJob?.cancel()
    }
}
