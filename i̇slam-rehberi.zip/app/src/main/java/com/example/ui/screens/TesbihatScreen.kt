package com.example.ui.screens

import android.content.Context
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppPreferences
import com.example.data.local.AppStrings
import com.example.data.local.TesbihatData
import com.example.data.local.TesbihatStep
import com.example.data.model.AppLanguage
import com.example.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TesbihatScreen(
    language: AppLanguage,
    preferences: AppPreferences,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isKurmanji = language == AppLanguage.KURMANJI
    val coroutineScope = rememberCoroutineScope()

    var selectedTab by remember { mutableIntStateOf(0) } // 0 = Namaz Tesbihatı, 1 = Zikirmatik
    var vibrationEnabled by remember { mutableStateOf(preferences.isTesbihatVibrationEnabled()) }
    var dailyTotal by remember { mutableIntStateOf(preferences.getTesbihatDailyTotal()) }
    var lifetimeTotal by remember { mutableLongStateOf(preferences.getTesbihatLifetimeTotal()) }

    // Guided Namaz Tesbihatı State
    val steps = TesbihatData.NAMAZ_TESBIHATI_STEPS
    var currentStepIdx by remember {
        mutableIntStateOf(preferences.getTesbihatStepIndex().coerceIn(0, steps.lastIndex))
    }
    var currentStepCount by remember { mutableIntStateOf(preferences.getTesbihatStepCount()) }
    var completedRounds by remember { mutableIntStateOf(preferences.getTesbihatCompletedRounds()) }
    var showTesbihatCompleteBanner by remember { mutableStateOf(false) }

    // Zikirmatik State
    var selectedPresetId by remember { mutableStateOf(preferences.getZikirSelectedId()) }
    var zikirCount by remember { mutableIntStateOf(preferences.getZikirCurrentCount()) }
    var zikirTarget by remember { mutableIntStateOf(preferences.getZikirTarget()) }
    var customZikirTitle by remember { mutableStateOf(preferences.getCustomZikirTitle()) }
    var showMeaningDetails by remember { mutableStateOf(true) }
    var showCustomDialog by remember { mutableStateOf(false) }

    val currentStep = steps[currentStepIdx]
    val activePreset = remember(selectedPresetId) {
        TesbihatData.ZIKIR_PRESETS.find { it.id == selectedPresetId }
    }

    fun performTapVibration(isRoundComplete: Boolean) {
        if (vibrationEnabled) {
            triggerTesbihatVibration(context, isRoundComplete)
        }
    }

    fun selectGuidedStep(newIndex: Int) {
        val clamped = newIndex.coerceIn(0, steps.lastIndex)
        currentStepIdx = clamped
        currentStepCount = 0
        showTesbihatCompleteBanner = false
        preferences.setTesbihatStepIndex(clamped)
        preferences.setTesbihatStepCount(0)
    }

    fun handleGuidedTap() {
        val nextVal = currentStepCount + 1
        val (newDaily, newLife) = preferences.recordTesbihatTap(1)
        dailyTotal = newDaily
        lifetimeTotal = newLife

        if (nextVal >= currentStep.targetCount) {
            performTapVibration(isRoundComplete = true)
            if (currentStepIdx < steps.lastIndex) {
                currentStepCount = currentStep.targetCount
                preferences.setTesbihatStepCount(currentStepCount)
                coroutineScope.launch {
                    delay(220L)
                    selectGuidedStep(currentStepIdx + 1)
                }
            } else {
                currentStepCount = currentStep.targetCount
                preferences.setTesbihatStepCount(currentStepCount)
                completedRounds = preferences.incrementTesbihatCompletedRounds()
                showTesbihatCompleteBanner = true
            }
        } else {
            performTapVibration(isRoundComplete = false)
            currentStepCount = nextVal
            preferences.setTesbihatStepCount(nextVal)
        }
    }

    fun handleGuidedUndo() {
        if (currentStepCount > 0) {
            val nextVal = currentStepCount - 1
            currentStepCount = nextVal
            showTesbihatCompleteBanner = false
            preferences.setTesbihatStepCount(nextVal)
        } else if (currentStepIdx > 0) {
            val prevIdx = currentStepIdx - 1
            currentStepIdx = prevIdx
            currentStepCount = (steps[prevIdx].targetCount - 1).coerceAtLeast(0)
            showTesbihatCompleteBanner = false
            preferences.setTesbihatStepIndex(prevIdx)
            preferences.setTesbihatStepCount(currentStepCount)
        }
    }

    fun handleZikirTap() {
        val next = zikirCount + 1
        val (newDaily, newLife) = preferences.recordTesbihatTap(1)
        dailyTotal = newDaily
        lifetimeTotal = newLife

        val reachedTarget = zikirTarget > 0 && next >= zikirTarget
        performTapVibration(isRoundComplete = reachedTarget)

        if (reachedTarget) {
            // Completed 1 full cycle; keep visual at target briefly OR roll over seamlessly
            zikirCount = if (next > zikirTarget) 1 else next
        } else {
            zikirCount = next
        }
        preferences.setZikirCurrentCount(zikirCount)
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("tesbihat_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Text(
                        text = AppStrings.tesbihatScreenTitle(language),
                        color = GoldBright,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tesbihat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isKurmanji) "Vegere" else "Geri",
                            tint = GoldBright
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = { showMeaningDetails = !showMeaningDetails },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tesbihat_toggle_meaning_button")
                    ) {
                        Icon(
                            imageVector = if (showMeaningDetails) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                            contentDescription = if (isKurmanji) "Wate Nîşan Bide" else "Meali Göster/Gizle",
                            tint = GoldWarm
                        )
                    }
                    IconButton(
                        onClick = {
                            val next = !vibrationEnabled
                            vibrationEnabled = next
                            preferences.setTesbihatVibrationEnabled(next)
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("tesbihat_vibration_toggle")
                    ) {
                        Icon(
                            imageVector = if (vibrationEnabled) Icons.Filled.Vibration else Icons.Filled.NotificationsOff,
                            contentDescription = if (isKurmanji) "Lerizîn" else "Titreşim",
                            tint = if (vibrationEnabled) GoldBright else TextMutedEmerald
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Stats Banner (Daily & Lifetime & Completed Tesbihat Rounds)
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = EmeraldContainer,
                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.55f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    TesbihatStatBadge(
                        label = if (isKurmanji) "Îro" else "Bugün",
                        value = dailyTotal.toString()
                    )
                    VerticalDivider(
                        modifier = Modifier.height(26.dp),
                        color = GoldClassic.copy(alpha = 0.35f)
                    )
                    TesbihatStatBadge(
                        label = if (isKurmanji) "Giştî" else "Toplam",
                        value = lifetimeTotal.toString()
                    )
                    VerticalDivider(
                        modifier = Modifier.height(26.dp),
                        color = GoldClassic.copy(alpha = 0.35f)
                    )
                    TesbihatStatBadge(
                        label = if (isKurmanji) "Tesbîhat" else "Tamamlanan",
                        value = completedRounds.toString()
                    )
                }
            }

            // Mode Tabs: Namaz Tesbihatı vs Zikirmatik
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .background(DarkCard)
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                val tabModifier = Modifier
                    .weight(1f)
                    .minimumInteractiveComponentSize()
                ModeTabPill(
                    title = AppStrings.tesbihatGuidedTab(language),
                    selected = selectedTab == 0,
                    onClick = { selectedTab = 0 },
                    modifier = tabModifier.testTag("tesbihat_mode_guided")
                )
                ModeTabPill(
                    title = AppStrings.tesbihatZikirTab(language),
                    selected = selectedTab == 1,
                    onClick = { selectedTab = 1 },
                    modifier = tabModifier.testTag("tesbihat_mode_zikir")
                )
            }

            if (selectedTab == 0) {
                GuidedTesbihatContent(
                    steps = steps,
                    currentStepIdx = currentStepIdx,
                    currentStepCount = currentStepCount,
                    showCompleteBanner = showTesbihatCompleteBanner,
                    showMeaningDetails = showMeaningDetails,
                    language = language,
                    onSelectStep = { selectGuidedStep(it) },
                    onTap = { handleGuidedTap() },
                    onUndo = { handleGuidedUndo() },
                    onResetAll = {
                        selectGuidedStep(0)
                    },
                    onPrevStep = { selectGuidedStep(currentStepIdx - 1) },
                    onNextStep = { selectGuidedStep(currentStepIdx + 1) }
                )
            } else {
                ZikirmatikContent(
                    presets = TesbihatData.ZIKIR_PRESETS,
                    selectedPresetId = selectedPresetId,
                    activePreset = activePreset,
                    customTitle = customZikirTitle,
                    currentCount = zikirCount,
                    target = zikirTarget,
                    showMeaningDetails = showMeaningDetails,
                    language = language,
                    onSelectPreset = { preset ->
                        selectedPresetId = preset.id
                        zikirCount = 0
                        zikirTarget = preset.defaultTarget
                        preferences.setZikirSelectedId(preset.id)
                        preferences.setZikirCurrentCount(0)
                        preferences.setZikirTarget(preset.defaultTarget)
                    },
                    onSelectTarget = { newTarget ->
                        zikirTarget = newTarget
                        preferences.setZikirTarget(newTarget)
                    },
                    onOpenCustomDialog = { showCustomDialog = true },
                    onTap = { handleZikirTap() },
                    onUndo = {
                        if (zikirCount > 0) {
                            zikirCount -= 1
                            preferences.setZikirCurrentCount(zikirCount)
                        }
                    },
                    onReset = {
                        zikirCount = 0
                        preferences.setZikirCurrentCount(0)
                    }
                )
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }

    if (showCustomDialog) {
        CustomZikirDialog(
            language = language,
            initialTitle = customZikirTitle,
            initialTarget = if (zikirTarget > 0) zikirTarget else 33,
            onDismiss = { showCustomDialog = false },
            onSave = { title, target ->
                customZikirTitle = title
                selectedPresetId = "custom"
                zikirCount = 0
                zikirTarget = target
                preferences.setCustomZikirTitle(title)
                preferences.setZikirSelectedId("custom")
                preferences.setZikirCurrentCount(0)
                preferences.setZikirTarget(target)
                showCustomDialog = false
            }
        )
    }
}

@Composable
private fun TesbihatStatBadge(
    label: String,
    value: String
) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = value,
            color = GoldBright,
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )
        Text(
            text = label,
            color = TextMutedEmerald,
            fontSize = 14.sp
        )
    }
}

@Composable
private fun ModeTabPill(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick),
        shape = RoundedCornerShape(10.dp),
        color = if (selected) GoldBright else Color.Transparent
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 8.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                color = if (selected) DarkBackground else TextWhite,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun GuidedTesbihatContent(
    steps: List<TesbihatStep>,
    currentStepIdx: Int,
    currentStepCount: Int,
    showCompleteBanner: Boolean,
    showMeaningDetails: Boolean,
    language: AppLanguage,
    onSelectStep: (Int) -> Unit,
    onTap: () -> Unit,
    onUndo: () -> Unit,
    onResetAll: () -> Unit,
    onPrevStep: () -> Unit,
    onNextStep: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val step = steps[currentStepIdx]

    // Total cumulative progress across all steps (104 total)
    val totalTargetUnits = remember(steps) { steps.sumOf { it.targetCount } }
    val completedUnits = remember(currentStepIdx, currentStepCount, steps) {
        steps.take(currentStepIdx).sumOf { it.targetCount } + currentStepCount.coerceAtMost(step.targetCount)
    }
    val overallProgress = (completedUnits.toFloat() / totalTargetUnits.coerceAtLeast(1).toFloat()).coerceIn(0f, 1f)

    // Horizontal Step Pills
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        steps.forEachIndexed { idx, s ->
            val isDone = idx < currentStepIdx || (idx == steps.lastIndex && showCompleteBanner)
            val isActive = idx == currentStepIdx
            Surface(
                modifier = Modifier
                    .clip(RoundedCornerShape(10.dp))
                    .clickable { onSelectStep(idx) }
                    .testTag("tesbihat_step_chip_${idx + 1}"),
                shape = RoundedCornerShape(10.dp),
                color = when {
                    isActive -> GoldBright
                    isDone -> EmeraldContainer
                    else -> DarkCard
                },
                border = BorderStroke(
                    width = 1.dp,
                    color = when {
                        isActive -> GoldBright
                        isDone -> AdhanActiveGreen
                        else -> GoldClassic.copy(alpha = 0.35f)
                    }
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    if (isDone) {
                        Icon(
                            imageVector = Icons.Filled.CheckCircle,
                            contentDescription = null,
                            tint = if (isActive) DarkBackground else AdhanActiveGreen,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                    Text(
                        text = if (s.targetCount > 1) "${s.stepNumber}. (${s.targetCount}×)" else "${s.stepNumber}.",
                        color = if (isActive) DarkBackground else TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Overall progress bar
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (isKurmanji) "Gav ${step.stepNumber} / ${steps.size}" else "Adım ${step.stepNumber} / ${steps.size}",
                color = GoldWarm,
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold
            )
            Text(
                text = "$completedUnits / $totalTargetUnits",
                color = TextMutedEmerald,
                fontSize = 15.sp
            )
        }
        LinearProgressIndicator(
            progress = { overallProgress },
            modifier = Modifier
                .fillMaxWidth()
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = GoldBright,
            trackColor = DarkCard
        )
    }

    // Completion Celebration Card
    AnimatedVisibility(visible = showCompleteBanner) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .testTag("tesbihat_complete_banner"),
            shape = RoundedCornerShape(16.dp),
            color = if (LocalIsDarkTheme.current) Color(0xFF0E3A28) else Color(0xFFE6F4EC),
            border = BorderStroke(1.5.dp, AdhanActiveGreen)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Filled.Verified,
                    contentDescription = null,
                    tint = AdhanActiveGreen,
                    modifier = Modifier.size(34.dp)
                )
                Text(
                    text = if (isKurmanji) "Tesbîhata Nimêjê Temam Bû! Xwedê Qebûl Bike." else "Namaz Tesbihatı Tamamlandı! Allah Kabul Etsin.",
                    color = TextWhite,
                    fontSize = 18.sp,
                    lineHeight = 25.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center
                )
                Button(
                    onClick = onResetAll,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldBright,
                        contentColor = DarkBackground
                    ),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.testTag("tesbihat_restart_button")
                ) {
                    Text(
                        text = if (isKurmanji) "Ji Nû Ve Dest Pê Bike" else "Yeni Tesbihata Başla",
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Recitation Card (Arabic + Transliteration + Meaning)
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(20.dp),
        color = DarkCard,
        border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.7f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = step.getTitle(language),
                    color = GoldBright,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = EmeraldContainer,
                    border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.6f))
                ) {
                    Text(
                        text = "${step.targetCount}×",
                        color = GoldWarm,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                    )
                }
            }

            // Arabic text strictly with DiyanetMushafFontFamily, RTL, 0.sp letterSpacing
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = MushafPaperSurface,
                border = BorderStroke(0.8.dp, EmeraldBorder.copy(alpha = 0.5f))
            ) {
                Text(
                    text = step.arabicText,
                    style = TextStyle(
                        fontFamily = DiyanetMushafFontFamily,
                        fontSize = if (step.arabicText.length > 180) 27.sp else 35.sp,
                        lineHeight = if (step.arabicText.length > 180) 48.sp else 58.sp,
                        letterSpacing = 0.sp,
                        textDirection = TextDirection.Rtl,
                        color = TextWhite,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 16.dp)
                )
            }

            // Transliteration
            Text(
                text = step.transliteration,
                color = GoldWarm,
                fontSize = 17.sp,
                lineHeight = 25.sp,
                fontWeight = FontWeight.Medium
            )

            AnimatedVisibility(visible = showMeaningDetails) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurface
                ) {
                    Text(
                        text = step.getMeaning(language),
                        color = TextMutedEmerald,
                        fontSize = 16.sp,
                        lineHeight = 23.sp,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        }
    }

    // Circular Tactile Counter Zone + Step Controls
    CounterRingPanel(
        count = currentStepCount,
        target = step.targetCount,
        subLabel = if (step.targetCount == 1) {
            if (isKurmanji) "Bixwîne & Derbas Bibe" else "Okundu / Sonraki Adım"
        } else {
            step.transliteration
        },
        tapTestTag = "guided_tesbihat_tap_button",
        onTap = onTap
    )

    // Action Bar: Prev, Undo, Reset, Next
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        OutlinedButton(
            onClick = onPrevStep,
            enabled = currentStepIdx > 0,
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("tesbihat_prev_step_button"),
            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                contentDescription = null,
                tint = GoldBright,
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = if (isKurmanji) "Paş" else "Önceki",
                color = TextWhite,
                fontSize = 15.sp,
                maxLines = 1
            )
        }

        OutlinedButton(
            onClick = onUndo,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("tesbihat_undo_button"),
            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Undo,
                contentDescription = if (isKurmanji) "Paşve Bîne" else "Geri Al (-1)",
                tint = GoldWarm,
                modifier = Modifier.size(18.dp)
            )
        }

        OutlinedButton(
            onClick = onResetAll,
            modifier = Modifier
                .minimumInteractiveComponentSize()
                .testTag("tesbihat_reset_button"),
            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = if (isKurmanji) "Sifir Bike" else "Baştan Sıfırla",
                tint = GoldWarm,
                modifier = Modifier.size(18.dp)
            )
        }

        Button(
            onClick = onNextStep,
            enabled = currentStepIdx < steps.lastIndex,
            colors = ButtonDefaults.buttonColors(
                containerColor = EmeraldContainer,
                contentColor = GoldBright
            ),
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("tesbihat_next_step_button"),
            shape = RoundedCornerShape(12.dp)
        ) {
            Text(
                text = if (isKurmanji) "Pêş" else "Sonraki",
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1
            )
            Spacer(modifier = Modifier.width(4.dp))
            Icon(
                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                contentDescription = null,
                modifier = Modifier.size(16.dp)
            )
        }
    }
}

@Composable
private fun ZikirmatikContent(
    presets: List<com.example.data.local.ZikirPreset>,
    selectedPresetId: String,
    activePreset: com.example.data.local.ZikirPreset?,
    customTitle: String,
    currentCount: Int,
    target: Int,
    showMeaningDetails: Boolean,
    language: AppLanguage,
    onSelectPreset: (com.example.data.local.ZikirPreset) -> Unit,
    onSelectTarget: (Int) -> Unit,
    onOpenCustomDialog: () -> Unit,
    onTap: () -> Unit,
    onUndo: () -> Unit,
    onReset: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    // Preset Horizontal Picker + Custom Zikir Trigger
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .horizontalScroll(rememberScrollState()),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        presets.forEach { preset ->
            val selected = selectedPresetId == preset.id
            FilterChip(
                selected = selected,
                onClick = { onSelectPreset(preset) },
                label = {
                    Text(
                        text = preset.getTitle(language),
                        fontSize = 15.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
                    )
                },
                colors = FilterChipDefaults.filterChipColors(
                    selectedContainerColor = GoldBright,
                    selectedLabelColor = DarkBackground,
                    containerColor = DarkCard,
                    labelColor = TextWhite
                ),
                border = FilterChipDefaults.filterChipBorder(
                    enabled = true,
                    selected = selected,
                    borderColor = GoldClassic.copy(alpha = 0.45f),
                    selectedBorderColor = GoldBright
                ),
                modifier = Modifier.testTag("zikir_preset_${preset.id}")
            )
        }

        AssistChip(
            onClick = onOpenCustomDialog,
            label = {
                Text(
                    text = if (isKurmanji) "+ Zikrê Taybet" else "+ Özel Zikir",
                    color = GoldBright,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            leadingIcon = {
                Icon(
                    imageVector = Icons.Filled.Edit,
                    contentDescription = null,
                    tint = GoldBright,
                    modifier = Modifier.size(16.dp)
                )
            },
            colors = AssistChipDefaults.assistChipColors(containerColor = EmeraldContainer),
            border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.7f)),
            modifier = Modifier.testTag("zikir_custom_button")
        )
    }

    // Active Zikir Display Card
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        color = DarkCard,
        border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.65f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            val titleText = if (selectedPresetId == "custom" && customTitle.isNotBlank()) {
                customTitle
            } else {
                activePreset?.getTitle(language) ?: "Sübhânallâh"
            }

            Text(
                text = titleText,
                color = GoldBright,
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center
            )

            if (activePreset != null && selectedPresetId != "custom") {
                Text(
                    text = activePreset.arabicText,
                    style = TextStyle(
                        fontFamily = DiyanetMushafFontFamily,
                        fontSize = 33.sp,
                        lineHeight = 54.sp,
                        letterSpacing = 0.sp,
                        textDirection = TextDirection.Rtl,
                        color = TextWhite,
                        textAlign = TextAlign.Center
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
                Text(
                    text = activePreset.transliteration,
                    color = GoldWarm,
                    fontSize = 16.sp,
                    lineHeight = 23.sp,
                    textAlign = TextAlign.Center
                )
                AnimatedVisibility(visible = showMeaningDetails) {
                    Text(
                        text = activePreset.getMeaning(language),
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }

    // Target Count Selector
    val targetOptions = listOf(33, 99, 100, 1000, 0)
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (isKurmanji) "Armanc:" else "Hedef:",
            color = TextMutedEmerald,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold
        )
        targetOptions.forEach { opt ->
            val selected = target == opt
            Surface(
                modifier = Modifier
                    .weight(1f)
                    .clip(RoundedCornerShape(8.dp))
                    .clickable { onSelectTarget(opt) }
                    .testTag("zikir_target_$opt"),
                shape = RoundedCornerShape(8.dp),
                color = if (selected) GoldBright else DarkCard,
                border = BorderStroke(1.dp, if (selected) GoldBright else GoldClassic.copy(alpha = 0.4f))
            ) {
                Box(
                    modifier = Modifier.padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (opt == 0) "∞" else opt.toString(),
                        color = if (selected) DarkBackground else TextWhite,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }

    // Circular Tap Button
    CounterRingPanel(
        count = currentCount,
        target = target,
        subLabel = if (isKurmanji) "Ji bo zikir bitikîne" else "Zikir çekmek için dokunun",
        tapTestTag = "zikir_tap_button",
        onTap = onTap
    )

    // Undo & Reset Controls
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedButton(
            onClick = onUndo,
            enabled = currentCount > 0,
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("zikir_undo_button"),
            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.AutoMirrored.Filled.Undo,
                contentDescription = null,
                tint = GoldWarm,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isKurmanji) "1 Kêm Bike" else "Geri Al (-1)",
                color = TextWhite,
                fontWeight = FontWeight.SemiBold
            )
        }

        OutlinedButton(
            onClick = onReset,
            modifier = Modifier
                .weight(1f)
                .minimumInteractiveComponentSize()
                .testTag("zikir_reset_button"),
            border = BorderStroke(1.dp, Color(0xFFE57373).copy(alpha = 0.6f)),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(
                imageVector = Icons.Filled.Refresh,
                contentDescription = null,
                tint = Color(0xFFFF8A80),
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = if (isKurmanji) "Sifir Bike" else "Sıfırla",
                color = TextWhite,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
private fun CounterRingPanel(
    count: Int,
    target: Int,
    subLabel: String,
    tapTestTag: String,
    onTap: () -> Unit
) {
    val targetFraction = if (target > 0) {
        (count.toFloat() / target.toFloat()).coerceIn(0f, 1f)
    } else {
        ((count % 33).toFloat() / 33f)
    }
    val animatedSweep by animateFloatAsState(
        targetValue = targetFraction * 360f,
        animationSpec = spring(stiffness = 500f),
        label = "tesbihat_ring_sweep"
    )
    val trackColor = EmeraldContainer
    val activeColor = if (target > 0 && count >= target) AdhanActiveGreen else GoldBright

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Surface(
            modifier = Modifier
                .size(216.dp)
                .clip(CircleShape)
                .clickable(onClick = onTap)
                .testTag(tapTestTag),
            shape = CircleShape,
            color = DarkCard,
            shadowElevation = 6.dp
        ) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(
                        Brush.radialGradient(
                            listOf(EmeraldPrimary.copy(alpha = 0.45f), DarkCard)
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Canvas(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(10.dp)
                ) {
                    val strokeWidth = 10.dp.toPx()
                    drawArc(
                        color = trackColor,
                        startAngle = 0f,
                        sweepAngle = 360f,
                        useCenter = false,
                        style = Stroke(width = strokeWidth)
                    )
                    drawArc(
                        color = activeColor,
                        startAngle = -90f,
                        sweepAngle = animatedSweep,
                        useCenter = false,
                        style = Stroke(width = strokeWidth, cap = StrokeCap.Round)
                    )
                }

                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.Center,
                    modifier = Modifier.padding(24.dp)
                ) {
                    Text(
                        text = count.toString(),
                        color = activeColor,
                        fontSize = 48.sp,
                        fontWeight = FontWeight.ExtraBold
                    )
                    Text(
                        text = if (target > 0) "/ $target" else "∞",
                        color = TextWhite,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = subLabel,
                        color = TextMutedEmerald,
                        fontSize = 14.sp,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun CustomZikirDialog(
    language: AppLanguage,
    initialTitle: String,
    initialTarget: Int,
    onDismiss: () -> Unit,
    onSave: (String, Int) -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    var titleInput by remember { mutableStateOf(initialTitle) }
    var targetInput by remember { mutableStateOf(initialTarget.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkCard,
        title = {
            Text(
                text = if (isKurmanji) "Zikrê Taybet Zêde Bike" else "Özel Zikir Oluştur",
                color = GoldBright,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedTextField(
                    value = titleInput,
                    onValueChange = { titleInput = it },
                    label = {
                        Text(if (isKurmanji) "Navê Zikrê (Mînak: Ya Fettah)" else "Zikir Adı (Örn: Yâ Fettâh)")
                    },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldBright,
                        unfocusedBorderColor = GoldClassic.copy(alpha = 0.5f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedLabelColor = GoldBright,
                        unfocusedLabelColor = TextMutedEmerald
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_zikir_title_input")
                )

                OutlinedTextField(
                    value = targetInput,
                    onValueChange = { text ->
                        targetInput = text.filter { it.isDigit() }.take(5)
                    },
                    label = {
                        Text(if (isKurmanji) "Hejmara Armanc (0 = Bêsînor)" else "Hedef Sayısı (0 = Sınırsız)")
                    },
                    singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldBright,
                        unfocusedBorderColor = GoldClassic.copy(alpha = 0.5f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedLabelColor = GoldBright,
                        unfocusedLabelColor = TextMutedEmerald
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("custom_zikir_target_input")
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val cleanTitle = titleInput.trim().ifBlank {
                        if (isKurmanji) "Zikrê Taybet" else "Özel Zikir"
                    }
                    val cleanTarget = targetInput.toIntOrNull()?.coerceAtLeast(0) ?: 33
                    onSave(cleanTitle, cleanTarget)
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = DarkBackground
                ),
                modifier = Modifier.testTag("custom_zikir_save_button")
            ) {
                Text(
                    text = if (isKurmanji) "Tomar Bike" else "Başla",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (isKurmanji) "Betal" else "İptal",
                    color = TextMutedEmerald
                )
            }
        }
    )
}

@Suppress("DEPRECATION")
private fun triggerTesbihatVibration(context: Context, isCompletion: Boolean) {
    try {
        val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val manager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            manager?.defaultVibrator
        } else {
            context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
        }
        if (vibrator?.hasVibrator() != true) return

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            if (isCompletion) {
                vibrator.vibrate(
                    VibrationEffect.createWaveform(
                        longArrayOf(0L, 55L, 65L, 95L),
                        -1
                    )
                )
            } else {
                vibrator.vibrate(
                    VibrationEffect.createOneShot(24L, VibrationEffect.DEFAULT_AMPLITUDE)
                )
            }
        } else {
            if (isCompletion) {
                vibrator.vibrate(longArrayOf(0L, 55L, 65L, 95L), -1)
            } else {
                vibrator.vibrate(24L)
            }
        }
    } catch (_: Exception) {
    }
}
