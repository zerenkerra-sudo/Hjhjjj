package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Book
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.QuranNavigationData
import com.example.data.model.AppLanguage
import com.example.data.model.JuzInfo
import com.example.ui.theme.*

@Composable
fun JuzListView(
    language: AppLanguage,
    onSelectJuz: (JuzInfo) -> Unit,
    onPlayJuz: ((JuzInfo) -> Unit)? = null,
    onDownloadJuz: ((JuzInfo) -> Unit)? = null,
    downloadedSurahs: Set<Int> = emptySet(),
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(vertical = 12.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = DarkCard,
                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.MenuBook, contentDescription = null, tint = GoldBright, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = if (isKurmanji) "30 Cizên Qur'ana Pîroz" else "Kur'an-ı Kerim 30 Cüz",
                            color = GoldBright,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isKurmanji) "Ji bo vekirina sûreya serê cizê bikirtînin" else "Her bir cüz 20 sayfadan oluşur. Sureye gitmek ve dinlemek için tıklayın.",
                            color = TextMutedEmerald,
                            fontSize = 15.sp,
                            lineHeight = 21.sp
                        )
                    }
                }
            }
        }

        items(QuranNavigationData.JUZ_LIST) { juz ->
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectJuz(juz) }
                    .testTag("juz_item_${juz.number}"),
                color = DarkSurface,
                border = BorderStroke(0.8.dp, DarkCardBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        modifier = Modifier.weight(1f),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = EmeraldContainer,
                            border = BorderStroke(1.dp, GoldBright),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text(
                                    text = juz.number.toString(),
                                    color = GoldBright,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = juz.getDisplayName(language),
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = juz.getRangeDescription(language),
                                color = TextMutedEmerald,
                                fontSize = 15.sp,
                                lineHeight = 21.sp
                            )
                        }
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = DarkSurfaceVariant
                        ) {
                            Text(
                                text = "${juz.startPage} - ${juz.endPage}",
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }

                        if (onDownloadJuz != null) {
                            val juzSurahs = (juz.startSurahNumber..juz.endSurahNumber)
                            val isJuzDownloaded = juzSurahs.all { downloadedSurahs.contains(it) }
                            Spacer(modifier = Modifier.width(6.dp))
                            if (isJuzDownloaded) {
                                Icon(
                                    imageVector = Icons.Filled.OfflinePin,
                                    contentDescription = "Cüz Çevrimdışı Hazır",
                                    tint = Color(0xFF69F0AE),
                                    modifier = Modifier.size(20.dp)
                                )
                            } else {
                                IconButton(
                                    onClick = { onDownloadJuz(juz) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.Download,
                                        contentDescription = "Cüzü Çevrimdışı İndir",
                                        tint = TextMutedEmerald,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                            }
                        }

                        if (onPlayJuz != null) {
                            Spacer(modifier = Modifier.width(6.dp))
                            IconButton(
                                onClick = { onPlayJuz(juz) },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.PlayArrow,
                                    contentDescription = "Cüzü Dinle",
                                    tint = GoldBright,
                                    modifier = Modifier.size(22.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PageNavigatorView(
    language: AppLanguage,
    onJumpToPage: (page: Int, surahNumber: Int) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedPage by remember { mutableIntStateOf(1) }
    val isKurmanji = language == AppLanguage.KURMANJI

    val juz = remember(selectedPage) { QuranNavigationData.getJuzForPage(selectedPage) }
    val surahNum = remember(selectedPage) { QuranNavigationData.getSurahNumberForPage(selectedPage) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Page Info Card
        Surface(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(20.dp),
            color = DarkCard,
            border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = if (isKurmanji) "Rûpelê Bibijêre (1 - 604)" else "Sayfa Seçimi (1 - 604)",
                    color = TextMutedEmerald,
                    fontSize = 16.sp
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "$selectedPage / 604",
                    color = GoldBright,
                    fontSize = 40.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Surface(shape = RoundedCornerShape(8.dp), color = EmeraldContainer) {
                        Text(
                            text = if (isKurmanji) "Ciz $juz" else "$juz. Cüz",
                            color = GoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                    Surface(shape = RoundedCornerShape(8.dp), color = DarkSurfaceVariant) {
                        Text(
                            text = if (isKurmanji) "Sûre $surahNum" else "$surahNum. Sure",
                            color = TextWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                Slider(
                    value = selectedPage.toFloat(),
                    onValueChange = { selectedPage = it.toInt().coerceIn(1, 604) },
                    valueRange = 1f..604f,
                    steps = 603,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldBright,
                        activeTrackColor = GoldBright,
                        inactiveTrackColor = DarkCardBorder
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = { onJumpToPage(selectedPage, surahNum) },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldBright,
                        contentColor = DarkBackground
                    ),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("jump_to_page_button")
                ) {
                    Icon(Icons.Filled.AutoStories, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isKurmanji) "Vê Rûpelê / Sûreyê Veke" else "Bu Sayfadaki Sureyi Aç",
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        Text(
            text = if (isKurmanji) "Rûpelên Girîng Yên Sûreyan" else "Önemli Sure Başlangıç Sayfaları",
            color = GoldBright,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Quick page cards
        val quickPages = listOf(
            Pair(1, "Fâtiha (s. 1)"),
            Pair(2, "Bakara (s. 2)"),
            Pair(50, "Âl-i İmrân (s. 50)"),
            Pair(77, "Nisâ (s. 77)"),
            Pair(106, "Mâide (s. 106)"),
            Pair(208, "Yûnus (s. 208)"),
            Pair(293, "Kehf (s. 293)"),
            Pair(440, "Yâsîn (s. 440)"),
            Pair(531, "Rahmân (s. 531)"),
            Pair(562, "Mülk (s. 562)"),
            Pair(582, "Nebe (Cüz 30)"),
            Pair(604, "İhlâs & Nâs (s. 604)")
        )

        LazyVerticalGrid(
            columns = GridCells.Fixed(3),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(quickPages) { (p, label) ->
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable {
                            selectedPage = p
                            val targetSurah = QuranNavigationData.getSurahNumberForPage(p)
                            onJumpToPage(p, targetSurah)
                        },
                    color = DarkSurface,
                    border = BorderStroke(0.8.dp, DarkCardBorder)
                ) {
                    Text(
                        text = label,
                        color = TextWhite,
                        fontSize = 14.sp,
                        lineHeight = 19.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 10.dp)
                    )
                }
            }
        }
    }
}
