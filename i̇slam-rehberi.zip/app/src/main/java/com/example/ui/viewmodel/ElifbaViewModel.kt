package com.example.ui.viewmodel

import android.app.Application
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.local.DiyanetElifbaData
import com.example.data.local.Elifba60Data
import com.example.data.local.ElifbaPageInfo
import com.example.data.model.ElifbaItem
import com.example.data.model.ElifbaLesson
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale

data class ElifbaUiState(
    val currentPageNumber: Int = 1,
    val totalPages: Int = 60,
    val is60PagesMode: Boolean = true,
    val lessons: List<ElifbaLesson> = DiyanetElifbaData.lessons,
    val selectedLessonId: String = "lesson_1",
    val playingItemId: String? = null,
    val isTtsReady: Boolean = false,
    val isArabicTtsAvailable: Boolean = true,
    val isRtlMode: Boolean = true // Default: Sağdan Sola (RTL) Elifba yönü
) {
    val currentPage: ElifbaPageInfo
        get() = Elifba60Data.getPage(currentPageNumber)

    val currentLesson: ElifbaLesson
        get() = lessons.find { it.id == selectedLessonId } ?: lessons.first()
}

class ElifbaViewModel(application: Application) : AndroidViewModel(application), TextToSpeech.OnInitListener {

    private val preferences = AppPreferences(application)
    private val _uiState = MutableStateFlow(
        ElifbaUiState(
            currentPageNumber = preferences.getLastElifbaPage(),
            isRtlMode = preferences.isElifbaRtlMode()
        )
    )
    val uiState: StateFlow<ElifbaUiState> = _uiState.asStateFlow()

    private var textToSpeech: TextToSpeech? = null
    private var hasArabicTts: Boolean = false

    init {
        textToSpeech = TextToSpeech(application, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val tts = textToSpeech
            if (tts != null) {
                hasArabicTts = configureArabicLanguage(tts)
                if (!hasArabicTts) {
                    tts.setLanguage(Locale("tr", "TR"))
                }
                // Clear, unhurried articulation rate so short harakat vowels & letters are never clipped
                tts.setSpeechRate(0.75f)
                tts.setPitch(1.0f)

                tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {
                        _uiState.value = _uiState.value.copy(playingItemId = utteranceId)
                    }

                    override fun onDone(utteranceId: String?) {
                        if (_uiState.value.playingItemId == utteranceId) {
                            _uiState.value = _uiState.value.copy(playingItemId = null)
                        }
                    }

                    override fun onStop(utteranceId: String?, interrupted: Boolean) {
                        if (_uiState.value.playingItemId == utteranceId) {
                            _uiState.value = _uiState.value.copy(playingItemId = null)
                        }
                    }

                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) {
                        if (_uiState.value.playingItemId == utteranceId) {
                            _uiState.value = _uiState.value.copy(playingItemId = null)
                        }
                    }
                })

                _uiState.value = _uiState.value.copy(
                    isTtsReady = true,
                    isArabicTtsAvailable = hasArabicTts
                )
            }
        }
    }

    private fun configureArabicLanguage(tts: TextToSpeech): Boolean {
        return try {
            val saResult = tts.setLanguage(Locale("ar", "SA"))
            if (saResult != TextToSpeech.LANG_MISSING_DATA && saResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                return true
            }
            val arResult = tts.setLanguage(Locale("ar"))
            if (arResult != TextToSpeech.LANG_MISSING_DATA && arResult != TextToSpeech.LANG_NOT_SUPPORTED) {
                return true
            }
            val arabicVoice = tts.voices?.firstOrNull { voice ->
                voice.locale?.language in listOf("ar", "ara") && !voice.isNetworkConnectionRequired
            } ?: tts.voices?.firstOrNull { voice ->
                voice.locale?.language in listOf("ar", "ara")
            }
            if (arabicVoice != null) {
                tts.voice = arabicVoice
                true
            } else {
                false
            }
        } catch (_: Exception) {
            false
        }
    }

    fun setPage(pageNumber: Int) {
        stopAudio()
        val clamped = pageNumber.coerceIn(1, 60)
        preferences.setLastElifbaPage(clamped)
        _uiState.value = _uiState.value.copy(currentPageNumber = clamped)
    }

    fun nextPage() {
        if (_uiState.value.currentPageNumber < 60) {
            setPage(_uiState.value.currentPageNumber + 1)
        }
    }

    fun prevPage() {
        if (_uiState.value.currentPageNumber > 1) {
            setPage(_uiState.value.currentPageNumber - 1)
        }
    }

    fun toggleRtlMode() {
        val newMode = !_uiState.value.isRtlMode
        preferences.setElifbaRtlMode(newMode)
        _uiState.value = _uiState.value.copy(isRtlMode = newMode)
    }

    fun toggleMode(is60Pages: Boolean) {
        stopAudio()
        _uiState.value = _uiState.value.copy(is60PagesMode = is60Pages)
    }

    fun selectLesson(lessonId: String) {
        stopAudio()
        _uiState.value = _uiState.value.copy(selectedLessonId = lessonId)
    }

    /**
     * Reads every Arabic letter, harakat syllable, and Quranic exercise 1-to-1 in authentic Arabic.
     */
    fun playItemAudio(item: ElifbaItem, language: com.example.data.model.AppLanguage = com.example.data.model.AppLanguage.TURKISH) {
        viewModelScope.launch {
            val tts = textToSpeech ?: return@launch

            // If same item is already playing, stop it
            if (_uiState.value.playingItemId == item.id) {
                stopAudio()
                return@launch
            }

            _uiState.value = _uiState.value.copy(playingItemId = item.id)

            // Re-check Arabic voice availability if it wasn't ready during init
            if (!hasArabicTts) {
                hasArabicTts = configureArabicLanguage(tts)
                _uiState.value = _uiState.value.copy(isArabicTtsAvailable = hasArabicTts)
            }

            val speechPayload = getSpeechPayload(item, arabicAvailable = hasArabicTts)
            try {
                if (speechPayload.useArabic) {
                    configureArabicLanguage(tts)
                } else {
                    tts.setLanguage(Locale("tr", "TR"))
                }
                tts.setSpeechRate(0.75f)
                tts.setPitch(1.0f)
            } catch (_: Exception) {
                tts.setLanguage(Locale.getDefault())
            }

            val params = Bundle()
            tts.speak(speechPayload.textToSpeak, TextToSpeech.QUEUE_FLUSH, params, item.id)
        }
    }

    data class SpeechPayload(val textToSpeak: String, val useArabic: Boolean)

    fun stopAudio() {
        textToSpeech?.stop()
        _uiState.value = _uiState.value.copy(playingItemId = null)
    }

    override fun onCleared() {
        super.onCleared()
        textToSpeech?.stop()
        textToSpeech?.shutdown()
        textToSpeech = null
    }

    companion object {
        // Vocalized classical Arabic names for all 28 isolated letters so ar-SA TTS reads each 1-to-1
        private val ARABIC_LETTER_NAMES: Map<Char, String> = mapOf(
            'ا' to "أَلِفْ",
            'ب' to "بَاءْ",
            'ت' to "تَاءْ",
            'ث' to "ثَاءْ",
            'ج' to "جِيمْ",
            'ح' to "حَاءْ",
            'خ' to "خَاءْ",
            'د' to "دَالْ",
            'ذ' to "ذَالْ",
            'ر' to "رَاءْ",
            'ز' to "زَايْ",
            'س' to "سِينْ",
            'ش' to "شِينْ",
            'ص' to "صَادْ",
            'ض' to "ضَادْ",
            'ط' to "طَاءْ",
            'ظ' to "ظَاءْ",
            'ع' to "عَيْنْ",
            'غ' to "غَيْنْ",
            'ف' to "فَاءْ",
            'ق' to "قَافْ",
            'ك' to "كَافْ",
            'ل' to "لَامْ",
            'م' to "مِيمْ",
            'ن' to "نُونْ",
            'و' to "وَاوْ",
            'ه' to "هَاءْ",
            'ي' to "يَاءْ"
        )

        /**
         * Converts any Elifba Arabic display string (isolated letter, joined letter forms with tatweel,
         * harakat syllables, or Quranic words/ayahs) into clean, fully vocalized Arabic text for accurate TTS.
         */
        fun toAuthenticArabicSpeech(rawArabic: String): String {
            val trimmed = rawArabic.trim()
            if (trimmed.isEmpty()) return ""

            // 1. Single isolated Arabic letter -> full vocalized Arabic letter name (e.g., ث -> ثَاءْ)
            if (trimmed.length == 1) {
                ARABIC_LETTER_NAMES[trimmed[0]]?.let { return it }
            }

            // 2. Letter joining forms (e.g., "بـ ـبـ ـب") or space-separated bare letters (e.g., "ا د ذ ر ز و")
            val noTatweelTokens = trimmed
                .replace("\u0640", "")
                .split(Regex("\\s+"))
                .filter { it.isNotEmpty() }

            if (noTatweelTokens.isNotEmpty() && noTatweelTokens.all { it == "لا" }) {
                return "لَامْ أَلِفْ"
            }

            if (noTatweelTokens.isNotEmpty() && noTatweelTokens.all { it.length == 1 && ARABIC_LETTER_NAMES.containsKey(it[0]) }) {
                val distinctChars = noTatweelTokens.map { it[0] }.distinct()
                return if (distinctChars.size == 1) {
                    ARABIC_LETTER_NAMES.getValue(distinctChars[0])
                } else {
                    noTatweelTokens.joinToString("، ") { token ->
                        ARABIC_LETTER_NAMES.getValue(token[0])
                    }
                }
            }

            // 3. Words, harakat syllables, and verses: normalize Uthmani glyphs & Hamzatul-Qat for Arabic TTS
            return trimmed
                .replace("\u0640", "")
                // Normalize Quranic dagger-alif spellings so Arabic TTS pronounces them accurately
                .replace("لِلّٰهِ", "لِلَّهِ")
                .replace("لِلّٰه", "لِلَّه")
                .replace("اللّٰهُ", "اللَّهُ")
                .replace("اللّٰهِ", "اللَّهِ")
                .replace("اَللّٰهُ", "اللَّهُ")
                .replace("اَللّٰهِ", "اللَّهِ")
                .replace("الرَّحْمٰنِ", "الرَّحْمَانِ")
                .replace("الصَّلٰوةُ", "الصَّلَاةُ")
                .replace("الزَّكٰوةُ", "الزَّكَاةُ")
                .replace("الْهُدٰى", "الْهُدَى")
                .replace("\u0670", "ا")
                // Normalize bare Alif + Kasra -> Hamza below Alif + Kasra (e.g., اِ -> إِ, اِنَّ -> إِنَّ)
                .replace(Regex("(^|\\s)اِ"), "$1إِ")
                // Normalize bare Alif + Fatha/Damma (except definite article اَلْ / اَلّ) -> Hamza above Alif
                .replace(Regex("(^|\\s)اَ(?!ل[ّْ])"), "$1أَ")
                .replace(Regex("(^|\\s)اُ"), "$1أُ")
                .replace(Regex("\\s+"), " ")
                .trim()
        }

        fun getSpeechPayload(item: ElifbaItem, arabicAvailable: Boolean = true): SpeechPayload {
            val arabicSpeech = toAuthenticArabicSpeech(item.arabicText)
            if (arabicAvailable && arabicSpeech.isNotBlank()) {
                return SpeechPayload(arabicSpeech, useArabic = true)
            }
            val rawFallback = item.pronunciationTr.ifBlank { item.letterNameTr }
            val cleanedFallback = rawFallback.replace(Regex("\\s*\\([^)]*\\)"), "")
                .substringBefore("/")
                .replace("-", " ")
                .replace("•", " ")
                .replace(Regex("\\s+"), " ")
                .trim()
            return SpeechPayload(
                textToSpeak = cleanedFallback.ifBlank { item.letterNameTr },
                useArabic = false
            )
        }

        fun formatSpeechText(
            item: ElifbaItem,
            language: com.example.data.model.AppLanguage = com.example.data.model.AppLanguage.TURKISH
        ): String {
            return getSpeechPayload(item, arabicAvailable = true).textToSpeak
        }
    }
}
