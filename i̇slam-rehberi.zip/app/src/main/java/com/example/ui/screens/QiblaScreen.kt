package com.example.ui.screens

import android.hardware.SensorManager
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.OfflinePin
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.drawText
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.rememberTextMeasurer
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.ui.dialogs.CitySelectionDialog
import com.example.ui.theme.*
import com.example.ui.viewmodel.QiblaViewModel
import kotlin.math.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun QiblaScreen(
    viewModel: QiblaViewModel,
    language: AppLanguage,
    onSelectCity: (City) -> Unit = { viewModel.selectCity(it) },
    onRequestGps: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val compassState by viewModel.compassState.collectAsState()
    val selectedCity by viewModel.selectedCity.collectAsState()
    var showCityDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        viewModel.startSensors()
        onDispose {
            viewModel.stopSensors()
        }
    }

    val isKurmanji = language == AppLanguage.KURMANJI
    val needsCalibration = compassState.hasSensor &&
        (compassState.sensorAccuracy == SensorManager.SENSOR_STATUS_UNRELIABLE ||
            compassState.sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW)

    Scaffold(
        modifier = modifier.testTag("qibla_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = AppStrings.navQibla(language),
                            color = GoldBright,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        val locationText = remember(selectedCity, language, compassState.qiblaBearing) {
                            viewModel.getLocationLabel(language)
                        }
                        Text(
                            text = locationText,
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                actions = {
                    Surface(
                        modifier = Modifier
                            .widthIn(max = 165.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .clickable { showCityDialog = true }
                            .testTag("qibla_select_city_chip"),
                        color = EmeraldContainer,
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.6f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (selectedCity.isGps) Icons.Filled.MyLocation else Icons.Filled.LocationOn,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(5.dp))
                            Text(
                                text = selectedCity.getDisplayName(language),
                                color = TextWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.weight(1f, fill = false)
                            )
                            Icon(
                                Icons.Filled.ArrowDropDown,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.width(4.dp))
                    IconButton(
                        onClick = onRequestGps,
                        modifier = Modifier.testTag("qibla_gps_refresh_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MyLocation,
                            contentDescription = AppStrings.useGps(language),
                            tint = GoldBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 20.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // 100% Offline Ready Pill Badge
            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 10.dp)
                    .testTag("qibla_offline_badge"),
                shape = RoundedCornerShape(12.dp),
                color = EmeraldContainer.copy(alpha = 0.7f),
                border = BorderStroke(1.dp, EmeraldBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = Icons.Filled.OfflinePin,
                        contentDescription = null,
                        tint = GoldBright,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isKurmanji)
                            "Bê Înternet Dixebite • Sensor & Hesabê Navxweyî"
                        else
                            "Çevrimdışı Hazır • İnternet Olmadan Doğru Çalışır",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
            }

            if (!compassState.hasSensor) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 12.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFF3E2723),
                    border = BorderStroke(1.dp, GoldWarm)
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = GoldBright)
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = if (isKurmanji)
                                "Li ser vê cîhazê sensora pûsûlayê (manyetometre) nehat dîtin. Pîleya Qibleyê ji Bakurê Rast ${compassState.qiblaBearing.roundToInt()}° ye."
                            else
                                "Bu cihazda manyetik pusula sensörü bulunamadı. Bulunduğunuz konumun Kıble açısı Gerçek Kuzeyden ${compassState.qiblaBearing.roundToInt()}° dir.",
                            color = TextWhite,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    }
                }
            } else if (needsCalibration) {
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 10.dp),
                    shape = RoundedCornerShape(14.dp),
                    color = GoldContainer,
                    border = BorderStroke(1.dp, GoldBright)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.Warning, contentDescription = null, tint = GoldBright, modifier = Modifier.size(20.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isKurmanji)
                                "Hestiyariya pûsûlayê kêm e. Ji bo kalîbrasyonê telefonê di hewayê de wekî '8' bigerînin."
                            else
                                "Pusula hassasiyeti düşük. Doğru yön için telefonu havada '8' çizerek kalibre edin.",
                            color = TextWhite,
                            fontSize = 15.sp,
                            lineHeight = 22.sp
                        )
                    }
                }
            }

            // Alignment Banner (Shines gold when phone points to Qibla)
            val isAligned = compassState.hasSensor && compassState.isFacingQibla
            val bannerBg by animateColorAsState(
                targetValue = if (isAligned) GoldBright else DarkSurface,
                animationSpec = tween(300),
                label = "bannerBg"
            )
            val bannerTextColor by animateColorAsState(
                targetValue = if (isAligned) DarkBackground else TextWhite,
                label = "bannerText"
            )

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .testTag("qibla_alignment_status_card"),
                color = bannerBg,
                border = BorderStroke(
                    1.5.dp,
                    if (isAligned) GoldWarm else EmeraldBorder
                )
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center
                ) {
                    Icon(
                        imageVector = if (isAligned) Icons.Filled.CheckCircle else Icons.Filled.Explore,
                        contentDescription = null,
                        tint = if (isAligned) DarkBackground else GoldBright,
                        modifier = Modifier.size(24.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = when {
                            !compassState.hasSensor -> {
                                if (isKurmanji)
                                    "Pîleya Qibleyê: ${compassState.qiblaBearing.roundToInt()}° (Ji Bakur)"
                                else
                                    "Kıble Açısı: ${compassState.qiblaBearing.roundToInt()}° (Kuzeyden)"
                            }
                            isAligned -> AppStrings.alignedWithQibla(language)
                            else -> {
                                val diff = compassState.qiblaAngleOffset.roundToInt()
                                if (diff > 0) {
                                    if (isKurmanji) "${abs(diff)}° ber bi rastê ve bizivirînin" else "${abs(diff)}° Sağa Çevirin"
                                } else {
                                    if (isKurmanji) "${abs(diff)}° ber bi çepê ve bizivirînin" else "${abs(diff)}° Sola Çevirin"
                                }
                            }
                        },
                        color = bannerTextColor,
                        fontWeight = FontWeight.Bold,
                        fontSize = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // The Compass Rose Canvas
            Box(
                modifier = Modifier
                    .size(296.dp)
                    .testTag("qibla_compass_canvas_container"),
                contentAlignment = Alignment.Center
            ) {
                QiblaCompassCanvas(
                    deviceHeading = compassState.deviceHeading,
                    qiblaBearing = compassState.qiblaBearing,
                    isFacingQibla = isAligned,
                    language = language
                )
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Measurement Telemetry Cards
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                TelemetryCard(
                    modifier = Modifier.weight(1f),
                    title = AppStrings.qiblaAngle(language),
                    value = "${compassState.qiblaBearing.roundToInt()}°",
                    subtitle = if (isKurmanji) "Ji Bakurê Rast ve" else "Gerçek Kuzeyden Açısı"
                )

                TelemetryCard(
                    modifier = Modifier.weight(1f),
                    title = AppStrings.deviceHeading(language),
                    value = if (compassState.hasSensor) "${compassState.deviceHeading.roundToInt()}°" else "—",
                    subtitle = if (isKurmanji)
                        "Cudahiya Manyetîk (${String.format("%+.1f", compassState.magneticDeclination)}°)"
                    else
                        "Manyetik Sapma Düzeltildi (${String.format("%+.1f", compassState.magneticDeclination)}°)"
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Distance to Kaaba Card
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                color = DarkCard,
                border = BorderStroke(1.dp, EmeraldBorder)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp, vertical = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = EmeraldContainer,
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Filled.LocationOn,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = AppStrings.distanceToKaaba(language),
                                color = TextMutedEmerald,
                                fontSize = 15.sp
                            )
                            Text(
                                text = if (isKurmanji) "Mekke / Kabe" else "Mekke-i Mükerreme / Kâbe",
                                color = TextWhite,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }

                    Text(
                        text = "${String.format("%,d", compassState.distanceKm.roundToInt())} km",
                        color = GoldBright,
                        fontSize = 21.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Sensor Calibration Hint
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = DarkSurfaceVariant
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Filled.Info,
                        contentDescription = null,
                        tint = GoldWarm,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = AppStrings.calibrateCompass(language),
                        color = TextMutedEmerald,
                        fontSize = 15.sp,
                        lineHeight = 22.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    if (showCityDialog) {
        CitySelectionDialog(
            language = language,
            currentCity = selectedCity,
            onDismiss = { showCityDialog = false },
            onSelectCity = { city ->
                onSelectCity(city)
                showCityDialog = false
            },
            onRequestGps = {
                onRequestGps()
                showCityDialog = false
            }
        )
    }
}

@Composable
private fun TelemetryCard(
    modifier: Modifier = Modifier,
    title: String,
    value: String,
    subtitle: String
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        color = DarkCard,
        border = BorderStroke(1.dp, DarkCardBorder)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = TextMutedEmerald,
                fontSize = 15.sp,
                fontWeight = FontWeight.Medium
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                color = GoldBright,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                color = TextSecondary,
                fontSize = 13.sp,
                lineHeight = 18.sp
            )
        }
    }
}

@Composable
private fun QiblaCompassCanvas(
    deviceHeading: Float,
    qiblaBearing: Float,
    isFacingQibla: Boolean,
    language: AppLanguage
) {
    // Synchronous continuous unwrapped angle so crossing 359° -> 0° rotates smoothly without coroutine churn
    val continuousHeadingState = remember { mutableFloatStateOf(deviceHeading) }
    val targetHeading = remember(deviceHeading) {
        val currentMod = ((continuousHeadingState.floatValue % 360f) + 360f) % 360f
        var delta = deviceHeading - currentMod
        if (delta > 180f) delta -= 360f
        if (delta < -180f) delta += 360f
        continuousHeadingState.floatValue += delta
        continuousHeadingState.floatValue
    }

    val animatedHeading by animateFloatAsState(
        targetValue = targetHeading,
        animationSpec = tween(80),
        label = "heading"
    )

    val textMeasurer = rememberTextMeasurer()
    val cardinalLabels = remember(language) {
        if (language == AppLanguage.KURMANJI) {
            listOf(0 to "Bk", 90 to "Rh", 180 to "Bş", 270 to "Rj")
        } else {
            listOf(0 to "K", 90 to "D", 180 to "G", 270 to "B")
        }
    }

    val dialBg = DarkCard
    val accentColor = GoldBright
    val accentWarmColor = GoldWarm
    val accentDarkColor = GoldDark
    val ringBorderColor = EmeraldBorder
    val mutedColor = TextMutedEmerald
    val dialTextColor = TextWhite
    val pivotCenterColor = DarkBackground
    val idleMarkerColor = LocalAppTheme.current.lightTint

    Canvas(modifier = Modifier.fillMaxSize()) {
        val center = Offset(size.width / 2f, size.height / 2f)
        val radius = size.width / 2f - 16.dp.toPx()

        // Outer Glow Ring
        if (isFacingQibla) {
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(accentColor.copy(alpha = 0.45f), Color.Transparent),
                    center = center,
                    radius = radius + 22.dp.toPx()
                ),
                radius = radius + 16.dp.toPx(),
                center = center
            )
        }

        // Fixed Top Alignment Marker (Phone top edge / forward viewing direction)
        val lubberPath = Path().apply {
            moveTo(center.x, center.y - radius - 10.dp.toPx())
            lineTo(center.x - 7.dp.toPx(), center.y - radius - 2.dp.toPx())
            lineTo(center.x + 7.dp.toPx(), center.y - radius - 2.dp.toPx())
            close()
        }
        drawPath(lubberPath, color = if (isFacingQibla) accentColor else idleMarkerColor)

        // Outer Golden Bezel
        drawCircle(
            color = if (isFacingQibla) accentColor else ringBorderColor,
            radius = radius,
            center = center,
            style = Stroke(width = 3.dp.toPx())
        )

        // Inner Dial (Rotates negatively with device heading so True North stays aligned with real North)
        rotate(degrees = -animatedHeading, pivot = center) {
            // Draw dial background
            drawCircle(
                color = dialBg,
                radius = radius - 4.dp.toPx(),
                center = center
            )

            // Degree ticks
            for (angle in 0 until 360 step 15) {
                val isMajor = angle % 90 == 0
                val isMedium = angle % 30 == 0
                val tickLength = if (isMajor) 14.dp.toPx() else if (isMedium) 9.dp.toPx() else 5.dp.toPx()
                val tickWidth = if (isMajor) 2.5.dp.toPx() else 1.2.dp.toPx()
                val tickColor = if (isMajor) accentColor else mutedColor.copy(alpha = 0.5f)

                val angleRad = Math.toRadians(angle.toDouble())
                val startX = center.x + (radius - 6.dp.toPx() - tickLength) * sin(angleRad).toFloat()
                val startY = center.y - (radius - 6.dp.toPx() - tickLength) * cos(angleRad).toFloat()
                val endX = center.x + (radius - 6.dp.toPx()) * sin(angleRad).toFloat()
                val endY = center.y - (radius - 6.dp.toPx()) * cos(angleRad).toFloat()

                drawLine(
                    color = tickColor,
                    start = Offset(startX, startY),
                    end = Offset(endX, endY),
                    strokeWidth = tickWidth
                )
            }

            // Cardinal Direction Labels (N / E / S / W)
            val labelRadius = radius - 38.dp.toPx()
            for ((deg, label) in cardinalLabels) {
                val isNorth = deg == 0
                val measured = textMeasurer.measure(
                    text = label,
                    style = TextStyle(
                        color = if (isNorth) Color(0xFFEF5350) else dialTextColor.copy(alpha = 0.85f),
                        fontSize = if (isNorth) 16.sp else 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                )
                val rad = Math.toRadians(deg.toDouble())
                val lx = center.x + labelRadius * sin(rad).toFloat() - measured.size.width / 2f
                val ly = center.y - labelRadius * cos(rad).toFloat() - measured.size.height / 2f
                drawText(measured, topLeft = Offset(lx, ly))
            }

            // North Pointer on Dial (Red)
            val northPath = Path().apply {
                moveTo(center.x, center.y - radius + 14.dp.toPx())
                lineTo(center.x - 5.5.dp.toPx(), center.y - radius + 24.dp.toPx())
                lineTo(center.x + 5.5.dp.toPx(), center.y - radius + 24.dp.toPx())
                close()
            }
            drawPath(northPath, color = Color(0xFFE53935))

            // South Pointer on Dial (White)
            val southPath = Path().apply {
                moveTo(center.x, center.y + radius - 14.dp.toPx())
                lineTo(center.x - 5.5.dp.toPx(), center.y + radius - 24.dp.toPx())
                lineTo(center.x + 5.5.dp.toPx(), center.y + radius - 24.dp.toPx())
                close()
            }
            drawPath(southPath, color = dialTextColor.copy(alpha = 0.65f))

            // Qibla Pointer on Dial (Points towards Kaaba True North bearing)
            rotate(degrees = qiblaBearing, pivot = center) {
                val needlePath = Path().apply {
                    moveTo(center.x, center.y - radius + 16.dp.toPx()) // Tip
                    lineTo(center.x - 9.dp.toPx(), center.y) // Left waist
                    lineTo(center.x, center.y + 24.dp.toPx()) // Bottom tip
                    lineTo(center.x + 9.dp.toPx(), center.y) // Right waist
                    close()
                }
                drawPath(
                    needlePath,
                    brush = Brush.linearGradient(
                        colors = listOf(accentColor, accentWarmColor, accentDarkColor),
                        start = Offset(center.x, center.y - radius),
                        end = Offset(center.x, center.y + radius)
                    )
                )

                // Kaaba Cube Symbol at needle tip
                val cubeSize = 18.dp.toPx()
                val cubeTopY = center.y - radius + 22.dp.toPx()
                drawRoundRect(
                    color = Color.Black,
                    topLeft = Offset(center.x - cubeSize / 2f, cubeTopY),
                    size = androidx.compose.ui.geometry.Size(cubeSize, cubeSize),
                    cornerRadius = androidx.compose.ui.geometry.CornerRadius(3.dp.toPx())
                )
                // Gold band on Kaaba
                drawRect(
                    color = accentColor,
                    topLeft = Offset(center.x - cubeSize / 2f, cubeTopY + 3.dp.toPx()),
                    size = androidx.compose.ui.geometry.Size(cubeSize, 3.dp.toPx())
                )
            }
        }

        // Center Pivot Pin
        drawCircle(color = accentColor, radius = 9.dp.toPx(), center = center)
        drawCircle(color = pivotCenterColor, radius = 4.dp.toPx(), center = center)
    }
}
