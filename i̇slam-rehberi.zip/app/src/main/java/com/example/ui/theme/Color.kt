package com.example.ui.theme

import androidx.compose.runtime.Composable
import androidx.compose.runtime.ReadOnlyComposable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import com.example.data.model.AppTheme

object ThemePalette {

    fun backgroundFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.background
        } else {
            lerp(Color(0xFFF6F8F6), appTheme.primary, 0.06f)
        }
    }

    fun surfaceFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.surface
        } else {
            lerp(Color(0xFFFFFFFF), appTheme.primary, 0.03f)
        }
    }

    fun surfaceVariantFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.surfaceVariant
        } else {
            lerp(Color(0xFFFFFFFF), appTheme.primary, 0.10f)
        }
    }

    fun cardFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.cardBackground
        } else {
            lerp(Color(0xFFFFFFFF), appTheme.primary, 0.035f)
        }
    }

    fun cardBorderFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.cardBorder
        } else {
            lerp(Color(0xFFD0DDD6), appTheme.primary, 0.24f)
        }
    }

    fun deepTintFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.deepTint
        } else {
            lerp(Color(0xFFEAF2EE), appTheme.primary, 0.10f)
        }
    }

    fun darkTintFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.darkTint
        } else {
            lerp(Color(0xFFDCE9E3), appTheme.primary, 0.18f)
        }
    }

    fun containerTintFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.containerTint
        } else {
            lerp(Color(0xFFFFFFFF), appTheme.primary, 0.12f)
        }
    }

    fun strongBorderFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.strongBorder
        } else {
            lerp(appTheme.primary, Color(0xFF98B2A7), 0.35f)
        }
    }

    fun accentFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        if (darkTheme) return appTheme.accent
        return when (appTheme) {
            AppTheme.EMERALD_GOLD -> Color(0xFF8B6914)
            AppTheme.MIDNIGHT_BLUE -> Color(0xFF1A5694)
            AppTheme.KAABA_BLACK_GOLD -> Color(0xFF846200)
            AppTheme.ROSE_BURGUNDY -> Color(0xFF8E243B)
            AppTheme.SELJUK_TURQUOISE -> Color(0xFF006B7D)
        }
    }

    fun secondaryFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.secondary
        } else {
            lerp(accentFor(appTheme, false), appTheme.primary, 0.30f)
        }
    }

    fun accentWarmFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.accentWarm
        } else {
            lerp(accentFor(appTheme, false), Color(0xFF242424), 0.12f)
        }
    }

    fun accentDarkFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.accentDark
        } else {
            lerp(appTheme.primary, Color(0xFFFFFFFF), 0.80f)
        }
    }

    fun accentContainerFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.accentContainer
        } else {
            lerp(Color(0xFFFFFFFF), accentFor(appTheme, false), 0.14f)
        }
    }

    fun accentMutedFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.accentMuted
        } else {
            lerp(Color(0xFF4C635B), appTheme.primary, 0.25f)
        }
    }

    fun textPrimaryFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.textPrimary
        } else {
            lerp(Color(0xFF0E1D17), appTheme.primary, 0.20f)
        }
    }

    fun textSecondaryFor(appTheme: AppTheme, darkTheme: Boolean): Color {
        return if (darkTheme) {
            appTheme.textSecondary
        } else {
            lerp(Color(0xFF425A51), appTheme.primary, 0.22f)
        }
    }

    fun mushafSurfaceFor(darkTheme: Boolean): Color {
        return if (darkTheme) Color(0xFF06110D) else Color(0xFFFFFDF7)
    }
}

// Dynamic Primary Palette (switches with LocalAppTheme.current & LocalIsDarkTheme.current)
val EmeraldDeep: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.deepTintFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val EmeraldDark: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.darkTintFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val EmeraldPrimary: Color
    @Composable @ReadOnlyComposable get() = LocalAppTheme.current.primary
val EmeraldMedium: Color
    @Composable @ReadOnlyComposable get() = LocalAppTheme.current.primary
val EmeraldLight: Color
    @Composable @ReadOnlyComposable get() = LocalAppTheme.current.lightTint
val EmeraldContainer: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.containerTintFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val EmeraldBorder: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.strongBorderFor(LocalAppTheme.current, LocalIsDarkTheme.current)

// Dynamic Accent Palette
val GoldClassic: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.secondaryFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val GoldBright: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val GoldWarm: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentWarmFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val GoldDark: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentDarkFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val GoldContainer: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentContainerFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val GoldMuted: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentMutedFor(LocalAppTheme.current, LocalIsDarkTheme.current)

// Dynamic Surfaces & Neutrals
val DarkBackground: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.backgroundFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val DarkSurface: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.surfaceFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val DarkSurfaceVariant: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.surfaceVariantFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val DarkCard: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.cardFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val DarkCardBorder: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.cardBorderFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val MushafPaperSurface: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.mushafSurfaceFor(LocalIsDarkTheme.current)

val LightBackground = Color(0xFFF7F8F5)
val LightSurface = Color(0xFFFFFFFF)
val LightSurfaceVariant = Color(0xFFEBF1EE)
val LightCard = Color(0xFFFFFFFF)
val LightCardBorder = Color(0xFFD8E4DE)

// Dynamic Text Colors
val TextWhite: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.textPrimaryFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val TextGold: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val TextMutedEmerald: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.textSecondaryFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val TextSecondary: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.textSecondaryFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val TextDarkPrimary = Color(0xFF0A2E24)
val TextDarkSecondary = Color(0xFF4A6860)

// Status Colors
val AdhanActiveGreen = Color(0xFF2ECC71)
val AdhanGoldRing = Color(0xFFFFD700)

// Islamic Theme Aliases (Dynamically bound)
val IslamicGold: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.accentFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val IslamicGreenDark: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.backgroundFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val IslamicGreenSurface: Color
    @Composable @ReadOnlyComposable get() = ThemePalette.surfaceFor(LocalAppTheme.current, LocalIsDarkTheme.current)
val IslamicGreenPrimary: Color
    @Composable @ReadOnlyComposable get() = LocalAppTheme.current.primary
