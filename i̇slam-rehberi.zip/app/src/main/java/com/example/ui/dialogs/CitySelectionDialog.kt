package com.example.ui.dialogs

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.AppStrings
import com.example.data.local.WorldDistrictsData
import com.example.data.model.AppLanguage
import com.example.data.model.City
import com.example.ui.theme.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.abs

@Composable
fun CitySelectionDialog(
    language: AppLanguage,
    currentCity: City,
    onDismiss: () -> Unit,
    onSelectCity: (City) -> Unit,
    onRequestGps: () -> Unit
) {
    val context = LocalContext.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("ALL") } // ALL, TR, KURD, EU, ME, WORLD
    var selectedProvince by remember { mutableStateOf<City?>(null) }
    var liveGeocodedCities by remember { mutableStateOf<List<City>>(emptyList()) }
    var provinceRemoteDistricts by remember { mutableStateOf<List<City>>(emptyList()) }
    var isGeocodingLoading by remember { mutableStateOf(false) }

    val isKurmanji = language == AppLanguage.KURMANJI

    // Live worldwide geocoding debounced search for ANY province, city, or district (İl / İlçe) on Earth
    LaunchedEffect(searchQuery, language) {
        val q = searchQuery.trim()
        if (q.length < 2) {
            liveGeocodedCities = emptyList()
            isGeocodingLoading = false
            return@LaunchedEffect
        }

        delay(350L)
        isGeocodingLoading = true
        val results = withContext(Dispatchers.IO) {
            City.searchWorldCitiesOnline(context, q, language)
        }
        liveGeocodedCities = results
        isGeocodingLoading = false
    }

    // If user drills into a province that doesn't have built-in districts, query worldwide geocoding for its towns/districts
    LaunchedEffect(selectedProvince, language) {
        val prov = selectedProvince
        if (prov == null) {
            provinceRemoteDistricts = emptyList()
            return@LaunchedEffect
        }
        val builtin = WorldDistrictsData.getDistrictsForCity(prov.id)
        if (builtin.isNotEmpty()) {
            provinceRemoteDistricts = emptyList()
        } else {
            isGeocodingLoading = true
            val queryTerm = prov.nameTr.substringBefore(" (").trim()
            val remote = withContext(Dispatchers.IO) {
                City.searchWorldCitiesOnline(context, queryTerm, language)
                    .filter { !(abs(it.latitude - prov.latitude) < 0.01 && abs(it.longitude - prov.longitude) < 0.01) }
            }
            provinceRemoteDistricts = remote
            isGeocodingLoading = false
        }
    }

    val offlineDistrictsFiltered = remember(searchQuery, selectedProvince, language) {
        val prov = selectedProvince
        if (prov != null) {
            val builtin = WorldDistrictsData.getDistrictsForCity(prov.id)
            val combined = if (builtin.isNotEmpty()) builtin else provinceRemoteDistricts
            if (searchQuery.isNotBlank()) {
                val q = searchQuery.trim().lowercase()
                combined.filter {
                    it.nameTr.lowercase().contains(q) || it.nameKu.lowercase().contains(q)
                }
            } else {
                combined
            }
        } else if (searchQuery.trim().length >= 2) {
            val q = searchQuery.trim().lowercase()
            WorldDistrictsData.ALL_DISTRICTS.filter {
                it.nameTr.lowercase().contains(q) ||
                    it.nameKu.lowercase().contains(q) ||
                    it.provinceTr.lowercase().contains(q) ||
                    it.provinceKu.lowercase().contains(q)
            }
        } else {
            emptyList()
        }
    }

    val predefinedFiltered = remember(searchQuery, selectedCategory, language) {
        var list = City.DEFAULT_CITIES.filter { !it.isGps }

        list = when (selectedCategory) {
            "TR" -> list.filter { it.country == "Türkiye" }
            "KURD" -> list.filter {
                it.country in listOf("Irak", "Suriye", "İran") ||
                    it.nameKu.contains("(") ||
                    it.id in listOf(
                        "diyarbakir", "van", "mardin", "batman", "sirnak", "hakkari",
                        "siirt", "mus", "agri", "bingol", "tunceli", "erbil",
                        "sulaymaniyah", "duhok", "kirkuk", "zakho", "qamishli",
                        "kobani", "afrin", "urmia", "sanandaj", "mahabad"
                    )
            }
            "EU" -> list.filter {
                it.country in listOf(
                    "Almanya", "Fransa", "İngiltere", "Hollanda", "Belçika",
                    "Avusturya", "İsviçre", "İsveç", "Norveç", "Danimarka",
                    "Bosna-Hersek", "Kuzey Makedonya", "Kosova", "Arnavutluk"
                )
            }
            "ME" -> list.filter {
                it.country in listOf(
                    "Suudi Arabistan", "Filistin", "Birleşik Arap Emirlikleri",
                    "Katar", "Kuveyt", "Mısır", "Ürdün", "Lübnan", "Fas",
                    "Cezayir", "Tunus", "Libya"
                )
            }
            "WORLD" -> list.filter { it.country !in listOf("Türkiye", "Almanya", "Fransa", "Hollanda") }
            else -> list
        }

        if (searchQuery.isNotBlank()) {
            val q = searchQuery.trim().lowercase()
            list.filter {
                it.nameTr.lowercase().contains(q) ||
                    it.nameKu.lowercase().contains(q) ||
                    it.country.lowercase().contains(q)
            }
        } else {
            list
        }
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .testTag("city_selection_dialog"),
            color = DarkCard,
            border = BorderStroke(1.2.dp, GoldClassic.copy(alpha = 0.6f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(18.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isKurmanji) "Hilbijartina Bajar û Navçeyên Cîhanê" else "Dünya İl ve İlçe Seçimi",
                            color = GoldBright,
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isKurmanji) "Namaz û rewşa hewayê li gorî cihê we tê nûkirin" else "Namaz vakitleri ve hava durumu seçtiğiniz yerle güncellenir",
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            lineHeight = 19.sp
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_city_dialog_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = TextWhite)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // GPS Auto Location Button
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .clickable {
                            onRequestGps()
                            onDismiss()
                        }
                        .testTag("use_gps_button"),
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, GoldBright)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MyLocation,
                            contentDescription = "GPS",
                            tint = GoldBright,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = AppStrings.useGps(language),
                                color = TextWhite,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = if (isKurmanji) "Bi GPS cihê xwe yê niha bixweber bibîne" else "Cihazınızın GPS'i ile anlık il/ilçe konumunu al",
                                color = TextMutedEmerald,
                                fontSize = 13.sp,
                                lineHeight = 18.sp
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Active Province Drill-down Bar
                val activeProvince = selectedProvince
                if (activeProvince != null) {
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(bottom = 8.dp),
                        shape = RoundedCornerShape(12.dp),
                        color = GoldContainer,
                        border = BorderStroke(1.dp, GoldBright)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        selectedProvince = null
                                        searchQuery = ""
                                    }
                                    .padding(horizontal = 6.dp, vertical = 6.dp)
                                    .testTag("back_to_all_cities_button"),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isKurmanji) "Hemû Bajar" else "Tüm İller",
                                    color = GoldBright,
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Text(
                                text = "${activeProvince.getDisplayName(language)} • ${if (isKurmanji) "Navçe" else "İlçeler"}",
                                color = TextWhite,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                }

                // Search field for ANY province, city, or district (İl / İlçe) on Earth
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("city_search_input"),
                    placeholder = {
                        Text(
                            text = if (activeProvince != null) {
                                if (isKurmanji) "Navçeyê binivîse..." else "İlçe adı yazın..."
                            } else {
                                if (isKurmanji) "Bajar, navçe an welatekî cîhanê binivîse..." else "Dünyadan il, ilçe, kasaba veya ülke yazın..."
                            },
                            color = TextMutedEmerald,
                            fontSize = 16.sp
                        )
                    },
                    leadingIcon = {
                        Icon(Icons.Filled.Search, contentDescription = null, tint = GoldBright)
                    },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Filled.Close, contentDescription = "Temizle", tint = TextMutedEmerald)
                            }
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite,
                        focusedBorderColor = GoldBright,
                        unfocusedBorderColor = EmeraldBorder,
                        focusedContainerColor = DarkSurfaceVariant,
                        unfocusedContainerColor = DarkSurfaceVariant
                    ),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )

                if (selectedProvince == null) {
                    Spacer(modifier = Modifier.height(8.dp))

                    // Category Filter Chips
                    LazyRow(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        val categories = listOf(
                            "ALL" to (if (isKurmanji) "Hemû" else "Tümü"),
                            "TR" to (if (isKurmanji) "Tirkiye (81)" else "Türkiye (81 İl)"),
                            "KURD" to (if (isKurmanji) "Kurdistan & Îraq" else "Kürdistan & Irak"),
                            "EU" to (if (isKurmanji) "Ewropa" else "Avrupa"),
                            "ME" to (if (isKurmanji) "Cihên Pîroz & Rojhilat" else "Kutsal Yerler & Orta Doğu"),
                            "WORLD" to (if (isKurmanji) "Cîhan" else "Dünya")
                        )

                        items(categories) { (catKey, label) ->
                            val isCatSelected = selectedCategory == catKey
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(16.dp))
                                    .clickable { selectedCategory = catKey },
                                color = if (isCatSelected) GoldBright else DarkSurface,
                                border = BorderStroke(0.8.dp, if (isCatSelected) GoldBright else EmeraldBorder)
                            ) {
                                Text(
                                    text = label,
                                    color = if (isCatSelected) DarkBackground else TextWhite,
                                    fontSize = 14.sp,
                                    fontWeight = if (isCatSelected) FontWeight.Bold else FontWeight.Normal,
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // City / District List
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (activeProvince != null) {
                        // First item: Select the Province Center itself
                        item {
                            CityItemCard(
                                city = activeProvince,
                                isSelected = currentCity.id == activeProvince.id,
                                language = language,
                                badgeLabel = if (isKurmanji) "Navend" else "İl Merkezi",
                                onClick = {
                                    onSelectCity(activeProvince)
                                    onDismiss()
                                }
                            )
                        }

                        items(offlineDistrictsFiltered, key = { it.id }) { district ->
                            CityItemCard(
                                city = district,
                                isSelected = currentCity.id == district.id ||
                                    (abs(currentCity.latitude - district.latitude) < 0.01 && abs(currentCity.longitude - district.longitude) < 0.01),
                                language = language,
                                badgeLabel = if (isKurmanji) "Navçe" else "İlçe",
                                onClick = {
                                    onSelectCity(district)
                                    onDismiss()
                                }
                            )
                        }
                    } else {
                        // Offline matching districts during search
                        if (offlineDistrictsFiltered.isNotEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = EmeraldContainer,
                                    border = BorderStroke(0.8.dp, GoldClassic)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.LocationOn, contentDescription = null, tint = GoldBright, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isKurmanji) "Navçeyên Hatine Dîtin:" else "Bulunan İlçeler:",
                                            color = GoldBright,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            items(offlineDistrictsFiltered, key = { "off_${it.id}" }) { district ->
                                CityItemCard(
                                    city = district,
                                    isSelected = currentCity.id == district.id,
                                    language = language,
                                    badgeLabel = if (isKurmanji) "Navçe" else "İlçe",
                                    onClick = {
                                        onSelectCity(district)
                                        onDismiss()
                                    }
                                )
                            }
                        }

                        // Live Worldwide Geocoded Results Section (ANY city / district on Earth)
                        if (liveGeocodedCities.isNotEmpty()) {
                            item {
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = GoldContainer,
                                    border = BorderStroke(0.8.dp, GoldBright)
                                ) {
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 10.dp, vertical = 6.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(Icons.Filled.Language, contentDescription = null, tint = GoldBright, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isKurmanji) "Cihên Cîhanê (Bajar û Navçe):" else "Dünya Genelinde Bulunan İl / İlçeler:",
                                            color = GoldBright,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                }
                            }

                            items(liveGeocodedCities, key = { "live_${it.id}_${it.latitude}" }) { geoCity ->
                                CityItemCard(
                                    city = geoCity,
                                    isSelected = currentCity.id == geoCity.id ||
                                        (abs(currentCity.latitude - geoCity.latitude) < 0.01 && abs(currentCity.longitude - geoCity.longitude) < 0.01),
                                    language = language,
                                    badgeLabel = geoCity.country,
                                    onClick = {
                                        onSelectCity(geoCity)
                                        onDismiss()
                                    }
                                )
                            }

                            item {
                                HorizontalDivider(
                                    color = EmeraldBorder.copy(alpha = 0.5f),
                                    modifier = Modifier.padding(vertical = 6.dp)
                                )
                            }
                        }
                    }

                    if (isGeocodingLoading) {
                        item {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 6.dp),
                                horizontalArrangement = Arrangement.Center,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = GoldBright,
                                    strokeWidth = 2.dp
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (isKurmanji) "Li seranserê cîhanê digere..." else "Dünya genelinde aranıyor...",
                                    color = TextMutedEmerald,
                                    fontSize = 15.sp
                                )
                            }
                        }
                    }

                    if (activeProvince == null) {
                        // Predefined Cities / Provinces List (each with option to browse its İlçeler!)
                        items(predefinedFiltered, key = { it.id }) { city ->
                            val isSelected = currentCity.id == city.id
                            val hasBuiltinDistricts = WorldDistrictsData.getDistrictsForCity(city.id).isNotEmpty()
                            CityItemCard(
                                city = city,
                                isSelected = isSelected,
                                language = language,
                                badgeLabel = city.country,
                                showDistrictsAction = true,
                                hasBuiltinDistricts = hasBuiltinDistricts,
                                onOpenDistricts = {
                                    selectedProvince = city
                                    searchQuery = ""
                                },
                                onClick = {
                                    onSelectCity(city)
                                    onDismiss()
                                }
                            )
                        }
                    }

                    if (activeProvince == null &&
                        predefinedFiltered.isEmpty() &&
                        offlineDistrictsFiltered.isEmpty() &&
                        liveGeocodedCities.isEmpty() &&
                        !isGeocodingLoading
                    ) {
                        item {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Filled.LocationOn, contentDescription = null, tint = TextMutedEmerald, modifier = Modifier.size(36.dp))
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = if (isKurmanji) "Bajar an navçe nehat dîtin. Ji kerema xwe navê cihê rast binivîsin." else "Konum bulunamadı. Lütfen il veya ilçe adını yazarak arayın.",
                                    color = TextMutedEmerald,
                                    fontSize = 16.sp,
                                    lineHeight = 22.sp
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CityItemCard(
    city: City,
    isSelected: Boolean,
    language: AppLanguage,
    badgeLabel: String = city.country,
    showDistrictsAction: Boolean = false,
    hasBuiltinDistricts: Boolean = false,
    onOpenDistricts: (() -> Unit)? = null,
    onClick: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag("city_item_${city.id}"),
        color = if (isSelected) EmeraldPrimary else DarkSurface,
        border = if (isSelected) BorderStroke(1.2.dp, GoldBright) else BorderStroke(0.6.dp, EmeraldBorder.copy(alpha = 0.5f))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 12.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(
                modifier = Modifier.weight(1f),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Filled.LocationOn,
                    contentDescription = null,
                    tint = if (isSelected) GoldBright else TextMutedEmerald,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                    Text(
                        text = city.getDisplayName(language),
                        color = if (isSelected) GoldBright else TextWhite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.SemiBold,
                        fontSize = 17.sp,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    val altName = if (language == AppLanguage.TURKISH) city.nameKu else city.nameTr
                    if (altName.isNotBlank() && altName != city.getDisplayName(language)) {
                        Text(
                            text = altName,
                            color = TextMutedEmerald,
                            fontSize = 14.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.width(6.dp))

            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = if (isSelected) GoldBright.copy(alpha = 0.2f) else DarkSurfaceVariant
                ) {
                    Text(
                        text = badgeLabel,
                        color = if (isSelected) GoldBright else TextMutedEmerald,
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 4.dp)
                    )
                }

                if (showDistrictsAction && onOpenDistricts != null) {
                    Surface(
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable(onClick = onOpenDistricts)
                            .testTag("districts_button_${city.id}"),
                        color = if (hasBuiltinDistricts) EmeraldContainer else DarkSurfaceVariant,
                        border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (isKurmanji) "Navçe" else "İlçeler",
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Icon(
                                imageVector = Icons.Filled.ChevronRight,
                                contentDescription = null,
                                tint = GoldBright,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
