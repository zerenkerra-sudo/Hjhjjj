package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import android.content.Intent
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.local.Elifba60Data
import com.example.data.local.ElifbaPageInfo
import com.example.data.model.AppLanguage
import com.example.data.model.ElifbaItem
import com.example.data.model.ElifbaLesson
import com.example.ui.theme.*
import com.example.ui.viewmodel.ElifbaViewModel

enum class ElifbaDisplayMode {
    PAGES_60,
    SECTION_INDEX,
    LESSONS_CURRICULUM
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ElifbaScreen(
    viewModel: ElifbaViewModel,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val isKurmanji = language == AppLanguage.KURMANJI
    var displayMode by remember { mutableStateOf(ElifbaDisplayMode.PAGES_60) }
    var showJumpDialog by remember { mutableStateOf(false) }

    val currentPage = uiState.currentPage

    Scaffold(
        modifier = modifier.testTag("elifba_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = CircleShape,
                            color = GoldBright.copy(alpha = 0.15f),
                            modifier = Modifier.size(36.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Filled.School,
                                    contentDescription = null,
                                    tint = GoldBright,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = AppStrings.elifbaTitle(language),
                                    color = GoldBright,
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = GoldContainer,
                                    border = BorderStroke(0.6.dp, GoldBright)
                                ) {
                                    Text(
                                        text = "60 Yaprak",
                                        color = GoldBright,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Text(
                                text = if (isKurmanji) "60 Rûpel Elîfbaya Temam a bi Deng" else "Eksiksiz 60 Yaprak Sesli Elifba",
                                color = TextMutedEmerald,
                                fontSize = 14.sp,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }
                    }
                },
                actions = {
                    // Jump to Page / Leaf button
                    IconButton(
                        onClick = { showJumpDialog = true },
                        modifier = Modifier.testTag("elifba_jump_dialog_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.MenuBook,
                            contentDescription = "Yaprağa Git",
                            tint = GoldBright
                        )
                    }

                    if (uiState.playingItemId != null) {
                        IconButton(
                            onClick = { viewModel.stopAudio() },
                            modifier = Modifier.testTag("elifba_stop_audio_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Stop,
                                contentDescription = "Durdur",
                                tint = Color(0xFFFF7043)
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = DarkBackground)
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            // Display Mode Tabs (60 Yaprak Kitap | 10 Ana Bölüm | Müfredat Dersleri)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ElifbaModeTab(
                    modifier = Modifier.weight(1f),
                    title = if (isKurmanji) "60 Rûpel Kitêb" else "60 Yaprak Kitap",
                    badge = "${uiState.currentPageNumber} / 60",
                    isSelected = displayMode == ElifbaDisplayMode.PAGES_60,
                    onClick = { displayMode = ElifbaDisplayMode.PAGES_60 },
                    testTag = "mode_60_pages"
                )

                ElifbaModeTab(
                    modifier = Modifier.weight(1f),
                    title = if (isKurmanji) "10 Beş Fihrîst" else "10 Ana Bölüm",
                    badge = "Fihrist",
                    isSelected = displayMode == ElifbaDisplayMode.SECTION_INDEX,
                    onClick = { displayMode = ElifbaDisplayMode.SECTION_INDEX },
                    testTag = "mode_sections"
                )

                ElifbaModeTab(
                    modifier = Modifier.weight(1f),
                    title = if (isKurmanji) "Dersên Tecwîdê" else "Konu Anlatımı",
                    badge = "7 Ders",
                    isSelected = displayMode == ElifbaDisplayMode.LESSONS_CURRICULUM,
                    onClick = { displayMode = ElifbaDisplayMode.LESSONS_CURRICULUM },
                    testTag = "mode_lessons"
                )
            }

            // Show compact helper banner only if device lacks Arabic TTS voice pack
            if (uiState.isTtsReady && !uiState.isArabicTtsAvailable) {
                val context = LocalContext.current
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp),
                    shape = RoundedCornerShape(12.dp),
                    color = GoldContainer,
                    border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.6f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.RecordVoiceOver,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isKurmanji) {
                                "Ji bo xwendina Erebî ya resen dengê Erebî (ar-SA) di mîhengên TTS de çalak bikin."
                            } else {
                                "Harflerin Arapça aslıyla birebir okunması için cihaz TTS ayarlarından Arapça ses paketini yükleyin."
                            },
                            color = TextWhite,
                            fontSize = 14.sp,
                            lineHeight = 20.sp,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        TextButton(
                            onClick = {
                                try {
                                    val intent = Intent("com.android.settings.TTS_SETTINGS").apply {
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                } catch (_: Exception) {
                                }
                            },
                            modifier = Modifier.defaultMinSize(minWidth = 48.dp, minHeight = 48.dp)
                        ) {
                            Text(
                                text = if (isKurmanji) "Mîheng" else "Ayarlar",
                                color = GoldBright,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }

            // Body content based on selected display mode
            when (displayMode) {
                ElifbaDisplayMode.PAGES_60 -> {
                    Elifba60LeafReader(
                        page = currentPage,
                        playingItemId = uiState.playingItemId,
                        language = language,
                        isRtlMode = uiState.isRtlMode,
                        onPrevPage = { viewModel.prevPage() },
                        onNextPage = { viewModel.nextPage() },
                        onOpenJumpDialog = { showJumpDialog = true },
                        onToggleRtlMode = { viewModel.toggleRtlMode() },
                        onPlayItem = { viewModel.playItemAudio(it, language) }
                    )
                }

                ElifbaDisplayMode.SECTION_INDEX -> {
                    ElifbaSectionIndexList(
                        language = language,
                        currentPageNumber = uiState.currentPageNumber,
                        onSelectSectionPage = { startPage ->
                            viewModel.setPage(startPage)
                            displayMode = ElifbaDisplayMode.PAGES_60
                        }
                    )
                }

                ElifbaDisplayMode.LESSONS_CURRICULUM -> {
                    ElifbaCurriculumView(
                        viewModel = viewModel,
                        language = language
                    )
                }
            }
        }
    }

    // 60-Page / Leaf Jump Dialog
    if (showJumpDialog) {
        ElifbaJumpDialog(
            currentPage = uiState.currentPageNumber,
            language = language,
            onDismiss = { showJumpDialog = false },
            onSelectPage = { page ->
                viewModel.setPage(page)
                displayMode = ElifbaDisplayMode.PAGES_60
                showJumpDialog = false
            }
        )
    }
}

@Composable
private fun ElifbaModeTab(
    title: String,
    badge: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = ""
) {
    Surface(
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        color = if (isSelected) EmeraldPrimary else DarkSurface,
        border = BorderStroke(
            width = 1.dp,
            color = if (isSelected) GoldBright else DarkCardBorder
        )
    ) {
        Column(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = title,
                color = if (isSelected) GoldBright else TextWhite,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 13.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = badge,
                color = if (isSelected) TextWhite else TextMutedEmerald,
                fontSize = 12.sp,
                maxLines = 1
            )
        }
    }
}

@Composable
private fun Elifba60LeafReader(
    page: ElifbaPageInfo,
    playingItemId: String?,
    language: AppLanguage,
    isRtlMode: Boolean = true,
    onPrevPage: () -> Unit,
    onNextPage: () -> Unit,
    onOpenJumpDialog: () -> Unit,
    onToggleRtlMode: () -> Unit = {},
    onPlayItem: (ElifbaItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    Column(modifier = modifier.fillMaxSize()) {
        // Top Page Navigation Bar
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 4.dp),
            shape = RoundedCornerShape(14.dp),
            color = DarkSurface,
            border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.4f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                // Leaf Number & Jump Action
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(10.dp))
                        .clickable(onClick = onOpenJumpDialog)
                        .testTag("elifba_leaf_indicator_chip"),
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, GoldBright)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            Icons.Filled.School,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${if (isKurmanji) "Rûpel" else "Yaprak"} ${page.pageNumber} / 60",
                            color = GoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(
                            Icons.Filled.ArrowDropDown,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                // Reading Direction Badge (Sağdan Sola / Soldan Sağa)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(0.8.dp, if (isRtlMode) GoldClassic.copy(alpha = 0.6f) else DarkCardBorder),
                    modifier = Modifier
                        .clip(RoundedCornerShape(8.dp))
                        .clickable(onClick = onToggleRtlMode)
                        .testTag("elifba_direction_toggle")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Filled.SwapHoriz,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isRtlMode) {
                                if (isKurmanji) "Rast bo Çep" else "Sağdan Sola"
                            } else {
                                if (isKurmanji) "Çep bo Rast" else "Soldan Sağa"
                            },
                            color = GoldBright,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }

        // Main Leaf Body with Horizontal Touch Swiping and Animated Leaf Transition (Sağdan Sola)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .pointerInput(page.pageNumber, isRtlMode) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragAccumulator = 0f },
                        onDragEnd = {
                            if (isRtlMode) {
                                // Sağdan Sola Arapça Kitap Çevirme:
                                // Sayfayı sağa doğru çevirince (dragAccumulator > 30f) sonraki yaprağa geçer!
                                // Sayfayı sola doğru çevirince (dragAccumulator < -30f) önceki yaprağa döner!
                                if (dragAccumulator > 30f && page.pageNumber < 60) {
                                    onNextPage()
                                } else if (dragAccumulator < -30f && page.pageNumber > 1) {
                                    onPrevPage()
                                }
                            } else {
                                if (dragAccumulator < -30f && page.pageNumber < 60) {
                                    onNextPage()
                                } else if (dragAccumulator > 30f && page.pageNumber > 1) {
                                    onPrevPage()
                                }
                            }
                            dragAccumulator = 0f
                        },
                        onDragCancel = { dragAccumulator = 0f },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            dragAccumulator += dragAmount
                        }
                    )
                }
        ) {
            AnimatedContent(
                targetState = page.pageNumber,
                transitionSpec = {
                    if (targetState > initialState) {
                        (slideInHorizontally { width -> if (isRtlMode) -width else width } + fadeIn())
                            .togetherWith(slideOutHorizontally { width -> if (isRtlMode) width else -width } + fadeOut())
                    } else {
                        (slideInHorizontally { width -> if (isRtlMode) width else -width } + fadeIn())
                            .togetherWith(slideOutHorizontally { width -> if (isRtlMode) -width else width } + fadeOut())
                    }
                },
                label = "elifba_leaf_transition"
            ) { _ ->
                // Sağdan Sola okuma düzeni için LazyVerticalGrid LayoutDirection.Rtl ile sarılır
                CompositionLocalProvider(
                    LocalLayoutDirection provides if (isRtlMode) LayoutDirection.Rtl else LayoutDirection.Ltr
                ) {
                    LazyVerticalGrid(
                        columns = GridCells.Adaptive(minSize = 150.dp),
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = 14.dp),
                        contentPadding = PaddingValues(top = 6.dp, bottom = 14.dp),
                        verticalArrangement = Arrangement.spacedBy(12.dp),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        // Leaf Header Banner
                        item(span = { GridItemSpan(maxLineSpan) }) {
                            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                                Surface(
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(16.dp),
                                    color = EmeraldContainer,
                                    border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.6f))
                                ) {
                                    Column(
                                        modifier = Modifier.padding(14.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text(
                                            text = if (isKurmanji) page.titleKu else page.titleTr,
                                            color = GoldBright,
                                            fontSize = 18.sp,
                                            lineHeight = 24.sp,
                                            fontWeight = FontWeight.Bold,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Text(
                                            text = if (isKurmanji) page.subtitleKu else page.subtitleTr,
                                            color = TextWhite.copy(alpha = 0.9f),
                                            fontSize = 14.sp,
                                            textAlign = TextAlign.Center
                                        )
                                        Spacer(modifier = Modifier.height(6.dp))
                                        Text(
                                            text = if (isKurmanji) page.ruleNoteKu else page.ruleNoteTr,
                                            color = TextMutedEmerald,
                                            fontSize = 14.sp,
                                            lineHeight = 20.sp,
                                            textAlign = TextAlign.Center
                                        )
                                    }
                                }
                            }
                        }

                        // Items on this page (Arabic glyph, Latin pronunciation, audio button)
                        items(page.items, key = { it.id }) { item ->
                            val isPlaying = playingItemId == item.id
                            ElifbaItemCard(
                                item = item,
                                language = language,
                                isPlaying = isPlaying,
                                onPlayAudio = { onPlayItem(item) }
                            )
                        }
                    }
                }
            }
        }

        // Bottom Leaf Flipping Controls (Matching Quran Mushaf Page Flipping Controls)
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            border = BorderStroke(1.dp, DarkCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isRtlMode) {
                    // Sağdan Sola (Arapça Elifba) Sayfa Düzeni:
                    // Sol taraf: Sonraki Yaprak (<), Orta: Yaprak No, Sağ taraf: Önceki Yaprak (>)
                    Button(
                        onClick = onNextPage,
                        enabled = page.pageNumber < 60,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("elifba_next_leaf_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isKurmanji) "Rûpela Pêş" else "Sonraki Yaprak",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    // Orta: Yaprak Numarası (Dokunarak Atla)
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldContainer,
                        border = BorderStroke(0.8.dp, GoldBright),
                        modifier = Modifier.clickable { onOpenJumpDialog() }
                    ) {
                        Text(
                            text = "${page.pageNumber} / 60",
                            color = GoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    // Sağ Taraf: Önceki Yaprak
                    Button(
                        onClick = onPrevPage,
                        enabled = page.pageNumber > 1,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("elifba_prev_leaf_button")
                    ) {
                        Text(
                            text = if (isKurmanji) "Rûpela Berê" else "Önceki Yaprak",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                } else {
                    // Soldan Sağa (LTR) Düzeni
                    Button(
                        onClick = onPrevPage,
                        enabled = page.pageNumber > 1,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("elifba_prev_leaf_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = if (isKurmanji) "Rûpela Berê" else "Önceki Yaprak",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldContainer,
                        border = BorderStroke(0.8.dp, GoldBright),
                        modifier = Modifier.clickable { onOpenJumpDialog() }
                    ) {
                        Text(
                            text = "${page.pageNumber} / 60",
                            color = GoldBright,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }

                    Button(
                        onClick = onNextPage,
                        enabled = page.pageNumber < 60,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(10.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier.testTag("elifba_next_leaf_button")
                    ) {
                        Text(
                            text = if (isKurmanji) "Rûpela Pêş" else "Sonraki Yaprak",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ElifbaSectionIndexList(
    language: AppLanguage,
    currentPageNumber: Int,
    onSelectSectionPage: (Int) -> Unit,
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 14.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
        contentPadding = PaddingValues(top = 8.dp, bottom = 28.dp)
    ) {
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                color = EmeraldContainer,
                border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = if (isKurmanji) "Fihrîsta 60 Rûpelên Elîfbayê (10 Beş)" else "60 Yaprak Kur'an Elifbası Fihristi (10 Bölüm)",
                        color = GoldBright,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = if (isKurmanji) "Her beşek ji 6 rûpelan pêk tê. Li ser beşa xwestî bixin." else "Her bölüm 6 yapraktan oluşur. Çalışmak istediğiniz bölümün üzerine tıklayarak ilgili yaprağa geçebilirsiniz.",
                        color = TextWhite.copy(alpha = 0.85f),
                        fontSize = 14.sp,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        itemsIndexed(Elifba60Data.SECTIONS) { index, pair ->
            val titleTr = pair.first
            val titleKu = pair.second
            val startPage = index * 6 + 1
            val endPage = startPage + 5
            val isCurrentSection = currentPageNumber in startPage..endPage

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(14.dp))
                    .clickable { onSelectSectionPage(startPage) }
                    .testTag("elifba_section_item_$index"),
                color = if (isCurrentSection) DarkSurfaceVariant else DarkCard,
                border = BorderStroke(
                    width = if (isCurrentSection) 1.5.dp else 1.dp,
                    color = if (isCurrentSection) GoldBright else GoldClassic.copy(alpha = 0.3f)
                )
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        shape = CircleShape,
                        color = if (isCurrentSection) GoldBright else EmeraldContainer,
                        modifier = Modifier.size(38.dp)
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = "${index + 1}",
                                color = if (isCurrentSection) DarkBackground else GoldBright,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isKurmanji) titleKu else titleTr,
                            color = GoldBright,
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "${if (isKurmanji) "Rûpelên" else "Yaprak"} $startPage - $endPage",
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    Icon(
                        Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = GoldBright,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ElifbaCurriculumView(
    viewModel: ElifbaViewModel,
    language: AppLanguage,
    modifier: Modifier = Modifier
) {
    val uiState by viewModel.uiState.collectAsState()
    val currentLesson = uiState.currentLesson

    Column(modifier = modifier.fillMaxSize()) {
        LazyRow(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(uiState.lessons) { lesson ->
                val isSelected = lesson.id == uiState.selectedLessonId
                Surface(
                    modifier = Modifier
                        .clip(RoundedCornerShape(12.dp))
                        .clickable { viewModel.selectLesson(lesson.id) }
                        .testTag("curriculum_chip_${lesson.id}"),
                    color = if (isSelected) GoldBright else DarkSurface,
                    border = BorderStroke(1.dp, if (isSelected) GoldBright else DarkCardBorder)
                ) {
                    Text(
                        text = "${lesson.lessonNumber}. ${lesson.getTitle(language).substringAfter(":")}",
                        color = if (isSelected) DarkBackground else TextWhite,
                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        }

        CompositionLocalProvider(
            LocalLayoutDirection provides if (uiState.isRtlMode) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(minSize = 150.dp),
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 14.dp),
                contentPadding = PaddingValues(top = 6.dp, bottom = 28.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            color = EmeraldContainer,
                            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = currentLesson.getTitle(language),
                                    color = GoldBright,
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = currentLesson.getSubtitle(language),
                                    color = TextWhite,
                                    fontSize = 15.sp
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = currentLesson.getDescription(language),
                                    color = TextMutedEmerald,
                                    fontSize = 14.sp,
                                    lineHeight = 20.sp
                                )
                            }
                        }
                    }
                }

                items(currentLesson.items, key = { it.id }) { item ->
                    val isPlaying = uiState.playingItemId == item.id
                    ElifbaItemCard(
                        item = item,
                        language = language,
                        isPlaying = isPlaying,
                        onPlayAudio = { viewModel.playItemAudio(item, language) }
                    )
                }
            }
        }
    }
}

@Composable
private fun ElifbaItemCard(
    item: ElifbaItem,
    language: AppLanguage,
    isPlaying: Boolean,
    onPlayAudio: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "audio_anim")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(600),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulse_scale"
    )

    val cardBorderColor by animateColorAsState(
        targetValue = if (isPlaying) GoldBright else GoldClassic.copy(alpha = 0.25f),
        label = "card_border"
    )

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Surface(
            modifier = modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(16.dp))
                .clickable(onClick = onPlayAudio)
                .testTag("elifba_item_card_${item.id}"),
            color = DarkCard,
            border = BorderStroke(if (isPlaying) 1.5.dp else 1.dp, cardBorderColor)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Arabic Text Display Box (Always RTL text direction for authentic Arabic order)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 92.dp)
                        .clip(RoundedCornerShape(12.dp)),
                    color = DarkSurface,
                    border = BorderStroke(0.8.dp, GoldClassic.copy(alpha = 0.2f))
                ) {
                    Box(
                        modifier = Modifier.fillMaxSize(),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = item.arabicText,
                            color = GoldBright,
                            fontSize = if (item.arabicText.length > 5) 28.sp else 40.sp,
                            fontWeight = FontWeight.Bold,
                            textAlign = TextAlign.Center,
                            fontFamily = FontFamily.Serif,
                            style = LocalTextStyle.current.copy(textDirection = TextDirection.Rtl),
                            modifier = Modifier.scale(if (isPlaying) pulseScale else 1f)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Latin Pronunciation As-Read Display Box
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("elifba_pronunciation_${item.id}"),
                    shape = RoundedCornerShape(10.dp),
                    color = DarkSurfaceVariant,
                    border = BorderStroke(0.6.dp, DarkCardBorder)
                ) {
                    Text(
                        text = item.getPronunciation(language),
                        color = TextWhite,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center,
                        lineHeight = 22.sp,
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Prominent "Dinle" (Listen) Button
                Button(
                    onClick = onPlayAudio,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("listen_button_${item.id}"),
                    shape = RoundedCornerShape(10.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isPlaying) GoldBright else EmeraldContainer,
                        contentColor = if (isPlaying) DarkBackground else GoldBright
                    ),
                    border = BorderStroke(
                        width = 1.dp,
                        color = if (isPlaying) GoldBright else GoldClassic.copy(alpha = 0.5f)
                    ),
                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Filled.VolumeUp else Icons.Filled.PlayArrow,
                        contentDescription = null,
                        modifier = Modifier
                            .size(16.dp)
                            .scale(if (isPlaying) pulseScale else 1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = if (isPlaying) {
                            if (language == AppLanguage.KURMANJI) "Dixwîne..." else "Okunuyor..."
                        } else {
                            AppStrings.listenPronunciation(language)
                        },
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun ElifbaJumpDialog(
    currentPage: Int,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSelectPage: (Int) -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    var targetPage by remember { mutableFloatStateOf(currentPage.toFloat()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (isKurmanji) "Biçe Rûpela Elîfbayê (1 - 60)" else "Elifba Yaprağına Git (1 - 60)",
                color = GoldBright,
                fontWeight = FontWeight.Bold,
                fontSize = 20.sp
            )
        },
        text = {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text(
                    text = "${if (isKurmanji) "Rûpela Hilbijartî" else "Seçilen Yaprak"}: ${targetPage.toInt()} / 60",
                    color = TextWhite,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(14.dp))

                Slider(
                    value = targetPage,
                    onValueChange = { targetPage = it },
                    valueRange = 1f..60f,
                    steps = 59,
                    colors = SliderDefaults.colors(
                        thumbColor = GoldBright,
                        activeTrackColor = GoldBright,
                        inactiveTrackColor = DarkCardBorder
                    ),
                    modifier = Modifier.testTag("elifba_page_slider")
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = if (isKurmanji) "Beşên Sereke:" else "Başlıca Bölümler:",
                    color = TextMutedEmerald,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.SemiBold
                )

                Spacer(modifier = Modifier.height(6.dp))

                // Quick Section Jump Buttons (1, 7, 13, 19, 25, 31, 37, 43, 49, 55)
                val quickPages = listOf(1, 7, 13, 19, 25, 31, 37, 43, 49, 55)
                LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(quickPages) { p ->
                        Surface(
                            modifier = Modifier
                                .clip(RoundedCornerShape(8.dp))
                                .clickable { targetPage = p.toFloat() },
                            color = if (targetPage.toInt() == p) GoldBright else DarkSurface,
                            border = BorderStroke(0.6.dp, GoldBright)
                        ) {
                            Text(
                                text = "Y.$p",
                                color = if (targetPage.toInt() == p) DarkBackground else GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = { onSelectPage(targetPage.toInt()) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = DarkBackground
                ),
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.testTag("confirm_elifba_jump_button")
            ) {
                Text(
                    text = if (isKurmanji) "Biçe" else "Git",
                    fontWeight = FontWeight.Bold
                )
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(
                    text = if (isKurmanji) "Betal Bike" else "İptal",
                    color = TextMutedEmerald
                )
            }
        },
        containerColor = DarkCard,
        shape = RoundedCornerShape(18.dp)
    )
}
