package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import com.example.data.model.AppTheme

val LocalAppTheme = staticCompositionLocalOf { AppTheme.EMERALD_GOLD }
val LocalIsDarkTheme = staticCompositionLocalOf { true }

@Composable
fun IslamRehberiTheme(
    appTheme: AppTheme = AppTheme.EMERALD_GOLD,
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        darkColorScheme(
            primary = appTheme.accent,
            onPrimary = appTheme.background,
            primaryContainer = appTheme.primary,
            onPrimaryContainer = appTheme.accent,
            secondary = appTheme.secondary,
            onSecondary = appTheme.background,
            secondaryContainer = appTheme.cardBackground,
            onSecondaryContainer = appTheme.accent,
            tertiary = appTheme.secondary,
            onTertiary = appTheme.textPrimary,
            background = appTheme.background,
            onBackground = appTheme.textPrimary,
            surface = appTheme.surface,
            onSurface = appTheme.textPrimary,
            surfaceVariant = appTheme.surfaceVariant,
            onSurfaceVariant = appTheme.textSecondary,
            outline = appTheme.cardBorder,
            outlineVariant = appTheme.cardBorder
        )
    } else {
        val lightBg = ThemePalette.backgroundFor(appTheme, darkTheme = false)
        val lightSurface = ThemePalette.surfaceFor(appTheme, darkTheme = false)
        val lightVariant = ThemePalette.surfaceVariantFor(appTheme, darkTheme = false)
        val lightCard = ThemePalette.cardFor(appTheme, darkTheme = false)
        val lightBorder = ThemePalette.cardBorderFor(appTheme, darkTheme = false)
        val lightAccent = ThemePalette.accentFor(appTheme, darkTheme = false)
        val lightText = ThemePalette.textPrimaryFor(appTheme, darkTheme = false)
        val lightTextSec = ThemePalette.textSecondaryFor(appTheme, darkTheme = false)

        lightColorScheme(
            primary = lightAccent,
            onPrimary = Color.White,
            primaryContainer = ThemePalette.containerTintFor(appTheme, darkTheme = false),
            onPrimaryContainer = lightText,
            secondary = ThemePalette.secondaryFor(appTheme, darkTheme = false),
            onSecondary = Color.White,
            secondaryContainer = lightCard,
            onSecondaryContainer = lightText,
            tertiary = lightAccent,
            onTertiary = Color.White,
            background = lightBg,
            onBackground = lightText,
            surface = lightSurface,
            onSurface = lightText,
            surfaceVariant = lightVariant,
            onSurfaceVariant = lightTextSec,
            outline = lightBorder,
            outlineVariant = lightBorder
        )
    }

    CompositionLocalProvider(
        LocalAppTheme provides appTheme,
        LocalIsDarkTheme provides darkTheme
    ) {
        MaterialTheme(
            colorScheme = colorScheme,
            typography = Typography,
            content = content
        )
    }
}
