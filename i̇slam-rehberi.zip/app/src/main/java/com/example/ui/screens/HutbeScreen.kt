package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.HutbeData
import com.example.data.model.AppLanguage
import com.example.data.model.Hutbe
import com.example.data.repository.DiyanetHutbeRepository
import com.example.ui.components.HutbeArabicHeaderCard
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private enum class HutbeScriptMode {
    TURKISH_OFFICIAL,
    ARABIC_OFFICIAL
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HutbeScreen(
    language: AppLanguage,
    onBack: () -> Unit,
    currentHutbe: Hutbe = HutbeData.getCurrentWeekHutbe(language),
    hutbeArchive: List<Hutbe> = HutbeData.HUTBE_LIST,
    isLoading: Boolean = false,
    syncError: String? = null,
    lastUpdatedMillis: Long = 0L,
    isOnline: Boolean = true,
    onSelectHutbe: (Hutbe) -> Unit = {},
    onRefreshHutbe: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val isKurmanji = language == AppLanguage.KURMANJI

    var scriptMode by remember { mutableStateOf(HutbeScriptMode.TURKISH_OFFICIAL) }
    var fontScale by remember { mutableFloatStateOf(1.0f) }

    // Inline Official Diyanet Audio Player State
    var isAudioPlaying by remember { mutableStateOf(false) }
    var isAudioBuffering by remember { mutableStateOf(false) }
    val mediaPlayerHolder = remember { mutableStateOf<MediaPlayer?>(null) }

    fun releaseAudioPlayer() {
        try {
            mediaPlayerHolder.value?.apply {
                if (isPlaying) stop()
                release()
            }
        } catch (_: Exception) {
        } finally {
            mediaPlayerHolder.value = null
            isAudioPlaying = false
            isAudioBuffering = false
        }
    }

    // Stop audio whenever user switches Hutbe week or leaves HutbeScreen
    LaunchedEffect(currentHutbe.id) {
        releaseAudioPlayer()
        if (scriptMode == HutbeScriptMode.ARABIC_OFFICIAL && currentHutbe.arabicFullText.isBlank()) {
            scriptMode = HutbeScriptMode.TURKISH_OFFICIAL
        }
    }
    DisposableEffect(Unit) {
        onDispose { releaseAudioPlayer() }
    }

    fun toggleAudioPlayback() {
        val rawAudioUrl = currentHutbe.audioUrl
        if (rawAudioUrl.isBlank()) return
        if (isAudioPlaying || isAudioBuffering) {
            releaseAudioPlayer()
            return
        }
        val encodedUrl = DiyanetHutbeRepository.encodeDiyanetUrl(rawAudioUrl) ?: rawAudioUrl
        isAudioBuffering = true
        try {
            val mp = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .build()
                )
                setDataSource(encodedUrl)
                setOnPreparedListener { player ->
                    isAudioBuffering = false
                    isAudioPlaying = true
                    player.start()
                }
                setOnCompletionListener {
                    releaseAudioPlayer()
                }
                setOnErrorListener { _, _, _ ->
                    releaseAudioPlayer()
                    Toast.makeText(
                        context,
                        if (isKurmanji) "Dengê xutbeyê venebû (Înternetê kontrol bike)" else "Sesli hutbe açılamadı (İnterneti kontrol edin)",
                        Toast.LENGTH_SHORT
                    ).show()
                    true
                }
                prepareAsync()
            }
            mediaPlayerHolder.value = mp
        } catch (_: Exception) {
            releaseAudioPlayer()
            Toast.makeText(
                context,
                if (isKurmanji) "Dengê xutbeyê venebû" else "Sesli hutbe oynatılamadı",
                Toast.LENGTH_SHORT
            ).show()
        }
    }

    BackHandler {
        onBack()
    }

    val displayedTitle = if (isKurmanji && currentHutbe.titleKu.isNotBlank() && currentHutbe.titleKu != currentHutbe.titleTr) {
        "${currentHutbe.titleTr} (${currentHutbe.titleKu})"
    } else {
        currentHutbe.titleTr
    }

    val isArabicView = scriptMode == HutbeScriptMode.ARABIC_OFFICIAL && currentHutbe.arabicFullText.isNotBlank()
    val rawBodyText = if (isArabicView) currentHutbe.arabicFullText else currentHutbe.fullTextTr
    val cleanBodyText = HutbeData.cleanHutbeBodyText(rawBodyText)
    val needsArabicIntro = !cleanBodyText.trimStart().startsWith("اَلْحَمْدُ") &&
        !cleanBodyText.trimStart().startsWith("الحمد")
    val fullSharePayload = buildString {
        append(displayedTitle).append("\n")
        append(currentHutbe.date).append("\n\n")
        if (currentHutbe.arabicVerseOrHadith.isNotBlank()) {
            append(currentHutbe.arabicVerseOrHadith).append("\n\n")
        }
        if (needsArabicIntro) {
            append(HutbeData.DIYANET_ARABIC_HUTBE_INTRO).append("\n")
            append(HutbeData.DIYANET_ARABIC_BESMELE).append("\n\n")
        }
        append(cleanBodyText)
    }

    Scaffold(
        modifier = modifier.testTag("hutbe_screen"),
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = if (isKurmanji) "Xutbeya Înê" else "Cuma Hutbesi",
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = 22.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (isKurmanji) "Metna Temam" else "Haftalık Tam Metin",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 14.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hutbe_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isKurmanji) "Vegere" else "Geri",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = onRefreshHutbe,
                        enabled = !isLoading,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hutbe_refresh_button")
                    ) {
                        if (isLoading) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(18.dp),
                                strokeWidth = 2.dp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Filled.Refresh,
                                contentDescription = if (isKurmanji) "Nû Bike" else "Güncelle",
                                tint = MaterialTheme.colorScheme.primary
                            )
                        }
                    }
                    IconButton(
                        onClick = { if (fontScale > 0.85f) fontScale -= 0.1f },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hutbe_font_decrease")
                    ) {
                        Text(
                            text = "A-",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }
                    IconButton(
                        onClick = { if (fontScale < 1.45f) fontScale += 0.1f },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hutbe_font_increase")
                    ) {
                        Text(
                            text = "A+",
                            color = MaterialTheme.colorScheme.primary,
                            fontWeight = FontWeight.Bold,
                            fontSize = 18.sp
                        )
                    }
                    IconButton(
                        onClick = {
                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, displayedTitle)
                                putExtra(Intent.EXTRA_TEXT, fullSharePayload)
                            }
                            context.startActivity(Intent.createChooser(shareIntent, displayedTitle))
                        },
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("hutbe_share_button")
                    ) {
                        Icon(
                            imageVector = Icons.Filled.Share,
                            contentDescription = if (isKurmanji) "Parve bike" else "Paylaş",
                            tint = MaterialTheme.colorScheme.primary
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.background
                )
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // 1. Official Diyanet Verification + Date + Script Toggle Header Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hutbe_date_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.45f))
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        // Verified Official Source Badge + Sync Status
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f)
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Filled.MenuBook,
                                        contentDescription = null,
                                        tint = MaterialTheme.colorScheme.primary,
                                        modifier = Modifier.size(14.dp)
                                    )
                                    Spacer(modifier = Modifier.width(5.dp))
                                    Text(
                                        text = if (isKurmanji) "Xutbeya Hefteyê" else "Haftanın Hutbesi",
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            val statusLabel = when {
                                isLoading -> if (isKurmanji) "Tê nûkirin..." else "Güncelleniyor..."
                                currentHutbe.isSyncedFromDiyanet && lastUpdatedMillis > 0L -> {
                                    val timeStr = SimpleDateFormat("dd.MM HH:mm", Locale.getDefault())
                                        .format(Date(lastUpdatedMillis))
                                    if (isKurmanji) "Nûjen • $timeStr" else "Güncel • $timeStr"
                                }
                                !isOnline -> if (isKurmanji) "Bê înternet (Qeydkirî)" else "Çevrimdışı Önbellek"
                                else -> if (isKurmanji) "Guncel" else "Güncel"
                            }
                            Text(
                                text = statusLabel,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Medium
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f),
                                    modifier = Modifier.size(36.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            Icons.Filled.CalendarMonth,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = currentHutbe.date,
                                        color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 18.sp
                                    )
                                }
                            }

                            if (currentHutbe.arabicFullText.isNotBlank()) {
                                Row(
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(20.dp))
                                        .background(MaterialTheme.colorScheme.surfaceVariant)
                                        .border(
                                            0.8.dp,
                                            MaterialTheme.colorScheme.outline,
                                            RoundedCornerShape(20.dp)
                                        )
                                        .padding(2.dp)
                                ) {
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(18.dp))
                                            .clickable { scriptMode = HutbeScriptMode.TURKISH_OFFICIAL }
                                            .testTag("hutbe_lang_tr"),
                                        color = if (!isArabicView) MaterialTheme.colorScheme.primary else Color.Transparent
                                    ) {
                                        Text(
                                            text = "TR",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            color = if (!isArabicView) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                    Surface(
                                        modifier = Modifier
                                            .clip(RoundedCornerShape(18.dp))
                                            .clickable { scriptMode = HutbeScriptMode.ARABIC_OFFICIAL }
                                            .testTag("hutbe_lang_ar"),
                                        color = if (isArabicView) MaterialTheme.colorScheme.primary else Color.Transparent
                                    ) {
                                        Text(
                                            text = "AR",
                                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp),
                                            color = if (isArabicView) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                            }
                        }

                        if (!syncError.isNullOrBlank()) {
                            Text(
                                text = if (isKurmanji) "Nûkirina otomatîk li bendê ye: $syncError" else "Güncelleme uyarısı: $syncError",
                                color = MaterialTheme.colorScheme.error,
                                fontSize = 14.sp
                            )
                        }
                    }
                }
            }

            // 2. Recent Official Fridays Selector (Smart Archive)
            if (hutbeArchive.size > 1) {
                item {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = if (isKurmanji) "Xutbeyên Înê yên Dawîn" else "Son Cuma Hutbeleri",
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.SemiBold,
                            modifier = Modifier.padding(horizontal = 2.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.testTag("hutbe_archive_row")
                        ) {
                            items(hutbeArchive, key = { it.id }) { item ->
                                val selected = item.id == currentHutbe.id
                                FilterChip(
                                    selected = selected,
                                    onClick = { onSelectHutbe(item) },
                                    label = {
                                        val labelDate = item.dateIso.ifBlank { item.date }
                                        val shortDate = if (labelDate.length == 10 && labelDate[4] == '-') {
                                            "${labelDate.substring(8, 10)}.${labelDate.substring(5, 7)}"
                                        } else {
                                            item.date
                                        }
                                        Text(
                                            text = "$shortDate • ${item.titleTr}",
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis,
                                            fontSize = 15.sp,
                                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    modifier = Modifier.widthIn(max = 220.dp),
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = MaterialTheme.colorScheme.primary,
                                        selectedLabelColor = MaterialTheme.colorScheme.onPrimary,
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        labelColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    border = FilterChipDefaults.filterChipBorder(
                                        enabled = true,
                                        selected = selected,
                                        borderColor = MaterialTheme.colorScheme.outline
                                    )
                                )
                            }
                        }
                    }
                }
            }

            // 3. Official Diyanet Audio Player ("Sesli Hutbe") if available
            if (currentHutbe.audioUrl.isNotBlank()) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hutbe_audio_card"),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = MaterialTheme.colorScheme.primary.copy(alpha = 0.14f),
                                    modifier = Modifier.size(38.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            imageVector = Icons.Filled.RecordVoiceOver,
                                            contentDescription = null,
                                            tint = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = if (isKurmanji) "Xutbeya Bi Deng" else "Sesli Hutbe",
                                        color = MaterialTheme.colorScheme.onSurface,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = when {
                                            isAudioBuffering -> if (isKurmanji) "Tê barkirin..." else "Ses yükleniyor..."
                                            isAudioPlaying -> if (isKurmanji) "Tê xwendin..." else "Dinleniyor..."
                                            else -> if (isKurmanji) "Li xutbeya hefteyê guhdarî bike" else "Haftanın hutbesini sesli dinle"
                                        },
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                            }

                            FilledTonalButton(
                                onClick = { toggleAudioPlayback() },
                                modifier = Modifier
                                    .heightIn(min = 48.dp)
                                    .testTag("hutbe_audio_toggle_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.filledTonalButtonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                if (isAudioBuffering) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        strokeWidth = 2.dp,
                                        color = MaterialTheme.colorScheme.onPrimary
                                    )
                                } else {
                                    Icon(
                                        imageVector = if (isAudioPlaying) Icons.Filled.Stop else Icons.Filled.PlayArrow,
                                        contentDescription = null,
                                        modifier = Modifier.size(18.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = when {
                                        isAudioBuffering -> if (isKurmanji) "Bisekine" else "Bekle"
                                        isAudioPlaying -> if (isKurmanji) "Rawestîne" else "Durdur"
                                        else -> if (isKurmanji) "Guhdarî Bike" else "Dinle"
                                    },
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            // 4. Main Complete Unabridged Sermon Card
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("hutbe_page_reader_card"),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    ),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(20.dp)
                    ) {
                        // Week-specific Official Arabic Header (Besmele + Quran Ayah + Hadith) right above Title
                        HutbeArabicHeaderCard(
                            hutbe = currentHutbe,
                            isKurmanji = isKurmanji,
                            fontScale = fontScale
                        )

                        Spacer(modifier = Modifier.height(14.dp))

                        Text(
                            text = displayedTitle,
                            color = MaterialTheme.colorScheme.primary,
                            fontSize = (22f * fontScale).sp,
                            fontWeight = FontWeight.ExtraBold,
                            textAlign = TextAlign.Start,
                            lineHeight = (30f * fontScale).sp,
                            modifier = Modifier.testTag("hutbe_title")
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline,
                            thickness = 1.dp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Diyanet Official Arabic Minber Intro ("Arapça Hutbe Girişi")
                        if (needsArabicIntro) {
                            Surface(
                                shape = RoundedCornerShape(16.dp),
                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.08f),
                                border = BorderStroke(
                                    1.dp,
                                    MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("hutbe_arabic_intro_card")
                            ) {
                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(14.dp),
                                    verticalArrangement = Arrangement.spacedBy(8.dp)
                                ) {
                                    Text(
                                        text = if (isKurmanji) {
                                            "Destpêka Xutbeyê ya bi Erebî"
                                        } else {
                                            "Arapça Hutbe Girişi"
                                        },
                                        color = MaterialTheme.colorScheme.primary,
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                                        Column(
                                            modifier = Modifier.fillMaxWidth(),
                                            verticalArrangement = Arrangement.spacedBy(8.dp)
                                        ) {
                                            Text(
                                                text = HutbeData.DIYANET_ARABIC_HUTBE_INTRO,
                                                color = MaterialTheme.colorScheme.onSurface,
                                                fontSize = (20f * fontScale).sp,
                                                lineHeight = (33f * fontScale).sp,
                                                textAlign = TextAlign.Right,
                                                fontWeight = FontWeight.Medium,
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .testTag("hutbe_arabic_intro_text")
                                            )
                                            HorizontalDivider(
                                                color = MaterialTheme.colorScheme.primary.copy(alpha = 0.22f),
                                                thickness = 0.8.dp
                                            )
                                            Text(
                                                text = HutbeData.DIYANET_ARABIC_BESMELE,
                                                color = MaterialTheme.colorScheme.primary,
                                                fontSize = (18.5f * fontScale).sp,
                                                lineHeight = (30f * fontScale).sp,
                                                textAlign = TextAlign.Center,
                                                fontWeight = FontWeight.Bold,
                                                modifier = Modifier.fillMaxWidth()
                                            )
                                        }
                                    }
                                }
                            }
                            Spacer(modifier = Modifier.height(14.dp))
                        }

                        val paragraphs = cleanBodyText
                            .split("\n\n")
                            .map { it.trim() }
                            .filter { it.isNotBlank() }

                        val textLayoutDir = if (isArabicView) LayoutDirection.Rtl else LayoutDirection.Ltr
                        CompositionLocalProvider(LocalLayoutDirection provides textLayoutDir) {
                            Column(modifier = Modifier.fillMaxWidth()) {
                                paragraphs.forEachIndexed { pIndex, paragraph ->
                                    val isSalutation = pIndex == 0 ||
                                        paragraph.endsWith("!") && paragraph.length < 48
                                    Text(
                                        text = paragraph,
                                        color = if (isSalutation) {
                                            MaterialTheme.colorScheme.primary
                                        } else {
                                            MaterialTheme.colorScheme.onSurface
                                        },
                                        fontSize = (if (isArabicView) 21f * fontScale else 18f * fontScale).sp,
                                        lineHeight = (if (isArabicView) 34f * fontScale else 28f * fontScale).sp,
                                        textAlign = if (isArabicView) TextAlign.Right else TextAlign.Justify,
                                        fontWeight = if (isSalutation) FontWeight.Bold else FontWeight.Normal,
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 6.dp)
                                            .testTag("hutbe_paragraph_$pIndex")
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(
                            color = MaterialTheme.colorScheme.outline,
                            thickness = 1.dp
                        )
                        Spacer(modifier = Modifier.height(14.dp))

                        // Action Buttons: Copy Full Text & Finish Reading
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            OutlinedButton(
                                onClick = {
                                    val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                    val clip = ClipData.newPlainText("Cuma Hutbesi", fullSharePayload)
                                    clipboard.setPrimaryClip(clip)
                                    Toast.makeText(
                                        context,
                                        if (isKurmanji) "Metna xutbeyê hat kopîkirin" else "Tam hutbe metni kopyalandı",
                                        Toast.LENGTH_SHORT
                                    ).show()
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hutbe_copy_button"),
                                shape = RoundedCornerShape(12.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary),
                                colors = ButtonDefaults.outlinedButtonColors(
                                    contentColor = MaterialTheme.colorScheme.primary
                                )
                            ) {
                                Icon(Icons.Filled.ContentCopy, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isKurmanji) "Kopî bike" else "Metni Kopyala",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = onBack,
                                modifier = Modifier
                                    .weight(1f)
                                    .heightIn(min = 48.dp)
                                    .testTag("hutbe_finish_button"),
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = MaterialTheme.colorScheme.primary,
                                    contentColor = MaterialTheme.colorScheme.onPrimary
                                )
                            ) {
                                Icon(Icons.Filled.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (isKurmanji) "Qediya" else "Okundu",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}
