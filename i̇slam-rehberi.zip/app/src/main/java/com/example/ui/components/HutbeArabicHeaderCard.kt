package com.example.ui.components

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Hutbe

/**
 * Displays the authentic week-specific Arabic header block (Besmele + Quranic Ayah + Prophetic Hadith)
 * extracted verbatim from the official hutbe document, with crisp text fallback when no bitmap is attached.
 */
@Composable
fun HutbeArabicHeaderCard(
    hutbe: Hutbe,
    isKurmanji: Boolean,
    fontScale: Float = 1f,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val headerBitmap: ImageBitmap? = remember(hutbe.id, hutbe.arabicHeaderImageBase64) {
        loadHutbeHeaderBitmap(context, hutbe)
    }
    val hasTextFallback = hutbe.arabicVerseOrHadith.isNotBlank()

    if (headerBitmap == null && !hasTextFallback) return

    Surface(
        modifier = modifier
            .fillMaxWidth()
            .testTag("hutbe_arabic_header_card"),
        shape = RoundedCornerShape(14.dp),
        color = if (headerBitmap != null) {
            // Crisp warm-ivory paper backdrop so official blue calligraphy renders cleanly in every dark/light theme
            Color(0xFFFCFBF7)
        } else {
            MaterialTheme.colorScheme.primary.copy(alpha = 0.08f)
        },
        border = BorderStroke(
            width = 1.dp,
            color = MaterialTheme.colorScheme.primary.copy(alpha = 0.35f)
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp)
        ) {
            Text(
                text = if (isKurmanji) "Sernavê Xutbeyê yê bi Erebî" else "Arapça Hutbe Başlığı",
                color = if (headerBitmap != null) {
                    Color(0xFF1E3A5F)
                } else {
                    MaterialTheme.colorScheme.primary
                },
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )

            Spacer(modifier = Modifier.height(8.dp))

            if (headerBitmap != null) {
                Image(
                    bitmap = headerBitmap,
                    contentDescription = hutbe.arabicVerseOrHadith.ifBlank {
                        if (isKurmanji) "Sernavê Xutbeyê yê bi Erebî" else "Arapça Hutbe Başlığı"
                    },
                    contentScale = ContentScale.FillWidth,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .testTag("hutbe_arabic_header_image")
                )
            } else {
                CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
                    Text(
                        text = hutbe.arabicVerseOrHadith,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = (20f * fontScale).sp,
                        lineHeight = (33f * fontScale).sp,
                        textAlign = TextAlign.Right,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("hutbe_arabic_header_text")
                    )
                }
            }
        }
    }
}

private fun loadHutbeHeaderBitmap(context: Context, hutbe: Hutbe): ImageBitmap? {
    if (hutbe.arabicHeaderImageBase64.isNotBlank()) {
        try {
            val decoded = Base64.decode(hutbe.arabicHeaderImageBase64, Base64.DEFAULT)
            val bmp = BitmapFactory.decodeByteArray(decoded, 0, decoded.size)
            if (bmp != null) return bmp.asImageBitmap()
        } catch (_: Exception) {
        }
    }

    val candidatePaths = listOf(
        "hutbe_headers/${hutbe.id}.jpg",
        "hutbe_headers/${hutbe.id}.png"
    )
    for (assetPath in candidatePaths) {
        try {
            context.assets.open(assetPath).use { stream ->
                val bmp = BitmapFactory.decodeStream(stream)
                if (bmp != null) return bmp.asImageBitmap()
            }
        } catch (_: Exception) {
        }
    }
    return null
}
