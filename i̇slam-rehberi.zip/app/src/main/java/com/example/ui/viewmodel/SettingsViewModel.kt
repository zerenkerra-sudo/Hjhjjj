package com.example.ui.viewmodel

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.PowerManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import com.example.alarm.AdhanScheduler
import com.example.data.local.AppPreferences
import com.example.data.model.AppLanguage
import com.example.data.model.PrayerType
import com.example.notification.PrayerNotificationManager
import com.example.service.AdhanPlayerService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

import com.example.data.model.AppTheme

data class SettingsUiState(
    val language: AppLanguage = AppLanguage.TURKISH,
    val appTheme: AppTheme = AppTheme.EMERALD_GOLD,
    val adhanFajr: Boolean = true,
    val adhanDhuhr: Boolean = true,
    val adhanAsr: Boolean = true,
    val adhanMaghrib: Boolean = true,
    val adhanIsha: Boolean = true,
    val preAdhanReminderEnabled: Boolean = true,
    val preAdhanFajr: Boolean = true,
    val preAdhanDhuhr: Boolean = true,
    val preAdhanAsr: Boolean = true,
    val preAdhanMaghrib: Boolean = true,
    val preAdhanIsha: Boolean = true,
    val fridayReminder: Boolean = true,
    val religiousDaysReminder: Boolean = true,
    val prayerBarNotification: Boolean = true,
    val hasNotificationPermission: Boolean = true,
    val isExactAlarmGranted: Boolean = true,
    val isIgnoringBatteryOptimizations: Boolean = true
)

class SettingsViewModel(application: Application) : AndroidViewModel(application) {

    val preferences = AppPreferences(application)
    val scheduler = AdhanScheduler(application, preferences)
    val eventScheduler = com.example.alarm.EventNotificationScheduler(application, preferences)

    private val _uiState = MutableStateFlow(
        SettingsUiState(
            language = preferences.getLanguage(),
            appTheme = preferences.getAppTheme(),
            adhanFajr = preferences.isAdhanEnabled(PrayerType.FAJR),
            adhanDhuhr = preferences.isAdhanEnabled(PrayerType.DHUHR),
            adhanAsr = preferences.isAdhanEnabled(PrayerType.ASR),
            adhanMaghrib = preferences.isAdhanEnabled(PrayerType.MAGHRIB),
            adhanIsha = preferences.isAdhanEnabled(PrayerType.ISHA),
            preAdhanReminderEnabled = preferences.isPreAdhanReminderEnabled(),
            preAdhanFajr = preferences.isPreAdhanForPrayer(PrayerType.FAJR),
            preAdhanDhuhr = preferences.isPreAdhanForPrayer(PrayerType.DHUHR),
            preAdhanAsr = preferences.isPreAdhanForPrayer(PrayerType.ASR),
            preAdhanMaghrib = preferences.isPreAdhanForPrayer(PrayerType.MAGHRIB),
            preAdhanIsha = preferences.isPreAdhanForPrayer(PrayerType.ISHA),
            fridayReminder = preferences.isFridayReminderEnabled(),
            religiousDaysReminder = preferences.isReligiousDaysReminderEnabled(),
            prayerBarNotification = preferences.isPrayerBarNotificationEnabled(),
            hasNotificationPermission = checkNotificationPermission(application),
            isExactAlarmGranted = scheduler.canScheduleExactAlarms(),
            isIgnoringBatteryOptimizations = checkBatteryOptimization(application)
        )
    )
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    val isAdhanServicePlaying = AdhanPlayerService.isPlayingFlow
    val currentAdhanPrayerName = AdhanPlayerService.currentPrayerNameFlow

    private val audioManager = application.getSystemService(Context.AUDIO_SERVICE) as? android.media.AudioManager

    private val _mediaVolume = MutableStateFlow(getMediaVolume())
    val mediaVolume: StateFlow<Int> = _mediaVolume.asStateFlow()

    fun getMediaVolume(): Int {
        return audioManager?.getStreamVolume(android.media.AudioManager.STREAM_MUSIC) ?: 8
    }

    fun getMaxMediaVolume(): Int {
        return audioManager?.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC) ?: 15
    }

    fun setMediaVolume(volume: Int) {
        val max = getMaxMediaVolume()
        val clamped = volume.coerceIn(0, max)
        audioManager?.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, clamped, 0)
        _mediaVolume.value = clamped
    }

    fun refreshMediaVolume() {
        _mediaVolume.value = getMediaVolume()
    }

    fun setLanguage(language: AppLanguage) {
        preferences.setLanguage(language)
        _uiState.value = _uiState.value.copy(language = language)
    }

    fun setAppTheme(theme: AppTheme) {
        preferences.setAppTheme(theme)
        _uiState.value = _uiState.value.copy(appTheme = theme)
    }

    fun toggleFridayReminder(enabled: Boolean) {
        preferences.setFridayReminderEnabled(enabled)
        _uiState.value = _uiState.value.copy(fridayReminder = enabled)
        if (enabled) {
            eventScheduler.scheduleNextFridayReminder()
        } else {
            eventScheduler.cancelFridayReminder()
        }
    }

    fun toggleReligiousDaysReminder(enabled: Boolean) {
        preferences.setReligiousDaysReminderEnabled(enabled)
        _uiState.value = _uiState.value.copy(religiousDaysReminder = enabled)
        if (enabled) {
            eventScheduler.scheduleUpcomingReligiousDays()
        } else {
            eventScheduler.cancelReligiousDays()
        }
    }

    fun toggleAdhan(prayer: PrayerType, enabled: Boolean) {
        preferences.setAdhanEnabled(prayer, enabled)
        _uiState.value = when (prayer) {
            PrayerType.FAJR -> _uiState.value.copy(adhanFajr = enabled)
            PrayerType.DHUHR -> _uiState.value.copy(adhanDhuhr = enabled)
            PrayerType.ASR -> _uiState.value.copy(adhanAsr = enabled)
            PrayerType.MAGHRIB -> _uiState.value.copy(adhanMaghrib = enabled)
            PrayerType.ISHA -> _uiState.value.copy(adhanIsha = enabled)
            PrayerType.SUNRISE -> _uiState.value
        }
    }

    private var currentTestAsset: String? = null

    fun testAdhan(soundAsset: String = "adhan.mp3") {
        if (isAdhanServicePlaying.value && currentTestAsset == soundAsset) {
            AdhanPlayerService.stopAdhan(getApplication())
            currentTestAsset = null
        } else {
            currentTestAsset = soundAsset
            AdhanPlayerService.testAdhan(getApplication(), soundAsset)
        }
    }

    fun stopAdhan() {
        currentTestAsset = null
        AdhanPlayerService.stopAdhan(getApplication())
    }

    fun togglePrayerBarNotification(enabled: Boolean) {
        preferences.setPrayerBarNotificationEnabled(enabled)
        _uiState.value = _uiState.value.copy(prayerBarNotification = enabled)
        if (!enabled) {
            PrayerNotificationManager.cancelPrayerNotification(getApplication())
        }
    }

    // Pre-Adhan 30 Minutes Approaching Reminders
    fun togglePreAdhanReminder(enabled: Boolean) {
        preferences.setPreAdhanReminderEnabled(enabled)
        _uiState.value = _uiState.value.copy(preAdhanReminderEnabled = enabled)
        val freshTimes = com.example.data.repository.PrayerRepository.resolveCurrentPrayerTimesForAlarms(preferences)
        scheduler.scheduleAllAlarms(freshTimes)
    }

    fun togglePreAdhanForPrayer(prayer: PrayerType, enabled: Boolean) {
        preferences.setPreAdhanForPrayer(prayer, enabled)
        _uiState.value = when (prayer) {
            PrayerType.FAJR -> _uiState.value.copy(preAdhanFajr = enabled)
            PrayerType.DHUHR -> _uiState.value.copy(preAdhanDhuhr = enabled)
            PrayerType.ASR -> _uiState.value.copy(preAdhanAsr = enabled)
            PrayerType.MAGHRIB -> _uiState.value.copy(preAdhanMaghrib = enabled)
            PrayerType.ISHA -> _uiState.value.copy(preAdhanIsha = enabled)
            PrayerType.SUNRISE -> _uiState.value
        }
        val freshTimes = com.example.data.repository.PrayerRepository.resolveCurrentPrayerTimesForAlarms(preferences)
        if (enabled && _uiState.value.preAdhanReminderEnabled) {
            scheduler.schedulePreAdhanAlarm(prayer, freshTimes)
        } else {
            scheduler.cancelPreAdhanAlarm(prayer)
        }
    }

    fun testPreAdhanNotification() {
        PrayerNotificationManager.showPreAdhanNotification(
            context = getApplication(),
            prayer = PrayerType.DHUHR,
            time = "12:45",
            language = preferences.getLanguage()
        )
    }

    fun refreshPermissions() {
        val app = getApplication<Application>()
        refreshMediaVolume()
        _uiState.value = _uiState.value.copy(
            hasNotificationPermission = checkNotificationPermission(app),
            isExactAlarmGranted = scheduler.canScheduleExactAlarms(),
            isIgnoringBatteryOptimizations = checkBatteryOptimization(app)
        )
    }

    private fun checkNotificationPermission(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            ContextCompat.checkSelfPermission(
                context,
                Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED
        } else {
            true
        }
    }

    fun openExactAlarmSettings(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            try {
                val intent = Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM).apply {
                    data = Uri.parse("package:${context.packageName}")
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            } catch (e: Exception) {
                val fallbackIntent = Intent(Settings.ACTION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(fallbackIntent)
            }
        }
    }

    fun openBatterySettings(context: Context) {
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val intent = Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(intent)
            }
        } catch (e: Exception) {
            val fallback = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
                data = Uri.parse("package:${context.packageName}")
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(fallback)
        }
    }

    private fun checkBatteryOptimization(context: Context): Boolean {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
            powerManager?.isIgnoringBatteryOptimizations(context.packageName) ?: true
        } else {
            true
        }
    }
}
