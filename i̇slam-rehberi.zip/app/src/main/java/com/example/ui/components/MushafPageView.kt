package com.example.ui.components

import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AppLanguage
import com.example.data.model.PageAyah
import com.example.data.model.QuranPageDetail
import com.example.ui.theme.*

data class MushafPageSection(
    val surahNumber: Int,
    val surahNameArabic: String,
    val surahNameTr: String,
    val surahNameKu: String,
    val startsSurah: Boolean,
    val ayahs: List<PageAyah>
)

fun groupAyahsIntoMushafSections(ayahs: List<PageAyah>): List<MushafPageSection> {
    if (ayahs.isEmpty()) return emptyList()
    val sections = mutableListOf<MushafPageSection>()
    var currentBucket = mutableListOf<PageAyah>()
    var currentSurah = ayahs.first().surahNumber

    for (ayah in ayahs) {
        if (ayah.surahNumber != currentSurah && currentBucket.isNotEmpty()) {
            val first = currentBucket.first()
            sections.add(
                MushafPageSection(
                    surahNumber = first.surahNumber,
                    surahNameArabic = first.surahNameArabic,
                    surahNameTr = first.surahNameTr,
                    surahNameKu = first.surahNameKu,
                    startsSurah = first.numberInSurah == 1,
                    ayahs = currentBucket.toList()
                )
            )
            currentBucket = mutableListOf()
            currentSurah = ayah.surahNumber
        }
        currentBucket.add(ayah)
    }

    if (currentBucket.isNotEmpty()) {
        val first = currentBucket.first()
        sections.add(
            MushafPageSection(
                surahNumber = first.surahNumber,
                surahNameArabic = first.surahNameArabic,
                surahNameTr = first.surahNameTr,
                surahNameKu = first.surahNameKu,
                startsSurah = first.numberInSurah == 1,
                ayahs = currentBucket.toList()
            )
        )
    }

    return sections
}

@Composable
fun MushafPageView(
    pageDetail: QuranPageDetail?,
    isLoading: Boolean,
    language: AppLanguage,
    translationMode: String,
    fontSize: Float,
    isRtlMode: Boolean = true,
    isFullScreen: Boolean = false,
    onPreviousPage: () -> Unit,
    onNextPage: () -> Unit,
    onJumpToPage: (Int) -> Unit,
    onToggleTranslationMode: (String) -> Unit,
    onToggleRtlMode: () -> Unit = {},
    onToggleFullScreen: () -> Unit = {},
    onIncreaseFontSize: () -> Unit = {},
    onDecreaseFontSize: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    var showJumpDialog by remember { mutableStateOf(false) }

    val currentPage = pageDetail?.pageNumber ?: 1
    val currentJuz = pageDetail?.juzNumber ?: 1
    var dragAccumulator by remember { mutableFloatStateOf(0f) }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground)
    ) {
        // Single Compact Top Control Bar in both normal & full-screen modes to maximize page height
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            border = BorderStroke(0.6.dp, GoldClassic.copy(alpha = 0.35f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 4.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(3.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(7.dp),
                    color = GoldContainer,
                    border = BorderStroke(0.8.dp, GoldBright),
                    modifier = Modifier
                        .heightIn(min = 38.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .clickable { showJumpDialog = true }
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isKurmanji) "R.$currentPage" else "S.$currentPage",
                            color = GoldBright,
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            softWrap = false
                        )
                        Icon(
                            Icons.Filled.ArrowDropDown,
                            contentDescription = if (isKurmanji) "Here rûpelê" else "Sayfaya git",
                            tint = GoldBright,
                            modifier = Modifier.size(14.dp)
                        )
                    }
                }

                TranslationChip(
                    label = if (isKurmanji) "Erebî" else "Arapça",
                    isSelected = translationMode == "AR",
                    onClick = { onToggleTranslationMode("AR") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mushaf_lang_chip_ar")
                )
                TranslationChip(
                    label = if (isKurmanji) "Kurmancî" else "Kürtçe",
                    isSelected = translationMode == "KU",
                    onClick = { onToggleTranslationMode("KU") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mushaf_lang_chip_ku")
                )
                TranslationChip(
                    label = "Türkçe",
                    isSelected = translationMode == "TR",
                    onClick = { onToggleTranslationMode("TR") },
                    modifier = Modifier
                        .weight(1f)
                        .testTag("mushaf_lang_chip_tr")
                )

                FontZoomButton(
                    label = "A-",
                    enabled = fontSize > 32f,
                    contentDescription = if (isKurmanji) "Nivîsê biçûk bike" else "Yazıyı küçült",
                    onClick = onDecreaseFontSize,
                    modifier = Modifier.testTag("mushaf_font_decrease")
                )
                FontZoomButton(
                    label = "A+",
                    enabled = fontSize < 92f,
                    contentDescription = if (isKurmanji) "Nivîsê mezin bike" else "Yazıyı büyüt",
                    onClick = onIncreaseFontSize,
                    modifier = Modifier.testTag("mushaf_font_increase")
                )

                Surface(
                    shape = RoundedCornerShape(7.dp),
                    color = if (isFullScreen) GoldBright else EmeraldContainer,
                    border = BorderStroke(0.9.dp, GoldBright),
                    modifier = Modifier
                        .heightIn(min = 38.dp)
                        .clip(RoundedCornerShape(7.dp))
                        .clickable(onClick = onToggleFullScreen)
                        .testTag("mushaf_fullscreen_toggle")
                ) {
                    Box(
                        contentAlignment = Alignment.Center,
                        modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp)
                    ) {
                        Icon(
                            imageVector = if (isFullScreen) Icons.Filled.FullscreenExit else Icons.Filled.Fullscreen,
                            contentDescription = if (isFullScreen) {
                                if (isKurmanji) "Dîmendera tam bigire" else "Tam ekrandan çık"
                            } else {
                                if (isKurmanji) "Dîmendera tam" else "Tam ekran"
                            },
                            tint = if (isFullScreen) DarkBackground else GoldBright,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }

        // Main Mushaf Reading Surface (Edge-to-edge width & maximum height)
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
                .padding(0.dp)
                .pointerInput(currentPage, isRtlMode) {
                    detectHorizontalDragGestures(
                        onDragStart = { dragAccumulator = 0f },
                        onDragEnd = {
                            if (isRtlMode) {
                                if (dragAccumulator > 35f && currentPage < 604) {
                                    onNextPage()
                                } else if (dragAccumulator < -35f && currentPage > 1) {
                                    onPreviousPage()
                                }
                            } else {
                                if (dragAccumulator < -35f && currentPage < 604) {
                                    onNextPage()
                                } else if (dragAccumulator > 35f && currentPage > 1) {
                                    onPreviousPage()
                                }
                            }
                            dragAccumulator = 0f
                        },
                        onDragCancel = { dragAccumulator = 0f },
                        onHorizontalDrag = { change, dragAmount ->
                            change.consume()
                            dragAccumulator += dragAmount
                        }
                    )
                }
        ) {
            if (isLoading) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        CircularProgressIndicator(color = GoldBright)
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (isKurmanji) "Rûpel tê barkirin..." else "Sayfa yükleniyor...",
                            color = TextMutedEmerald,
                            fontSize = 16.sp
                        )
                    }
                }
            } else if (pageDetail != null) {
                AnimatedContent(
                    targetState = currentPage,
                    transitionSpec = {
                        if (targetState > initialState) {
                            (slideInHorizontally { width -> if (isRtlMode) -width else width } + fadeIn())
                                .togetherWith(slideOutHorizontally { width -> if (isRtlMode) width else -width } + fadeOut())
                        } else {
                            (slideInHorizontally { width -> if (isRtlMode) width else -width } + fadeIn())
                                .togetherWith(slideOutHorizontally { width -> if (isRtlMode) -width else width } + fadeOut())
                        }
                    },
                    label = "mushaf_page_transition"
                ) { pageNum ->
                    val pageListState = remember(pageNum) { LazyListState() }
                    val sections = remember(pageDetail.pageNumber, pageDetail.ayahs) {
                        groupAyahsIntoMushafSections(pageDetail.ayahs)
                    }

                    // Large High-Contrast Illuminated Mushaf Page Container
                    Surface(
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(RoundedCornerShape(if (isFullScreen) 0.dp else 4.dp))
                            .testTag("mushaf_page_frame_$currentPage"),
                        color = MushafPaperSurface,
                        border = BorderStroke(
                            width = if (isFullScreen) 0.5.dp else 0.8.dp,
                            brush = Brush.linearGradient(listOf(GoldBright, GoldDark, EmeraldBorder))
                        )
                    ) {
                        LazyColumn(
                            state = pageListState,
                            modifier = Modifier.fillMaxSize(),
                            contentPadding = PaddingValues(
                                horizontal = 4.dp,
                                vertical = 4.dp
                            ),
                            verticalArrangement = Arrangement.spacedBy(
                                if (translationMode == "AR") 6.dp else 4.dp
                            )
                        ) {
                            if (sections.firstOrNull()?.startsSurah != true) {
                                item(key = "mushaf_sub_info_${pageDetail.pageNumber}") {
                                    val surahLabel = if (isKurmanji) pageDetail.mainSurahNameKu else pageDetail.mainSurahNameTr
                                    val juzLabel = if (isKurmanji) "Ciz $currentJuz" else "$currentJuz. Cüz"
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(horizontal = 4.dp, vertical = 1.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text(
                                            text = "$juzLabel • $surahLabel",
                                            color = TextMutedEmerald,
                                            fontSize = 14.sp,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                        Text(
                                            text = pageDetail.mainSurahNameArabic,
                                            style = TextStyle(
                                                fontFamily = DiyanetMushafFontFamily,
                                                color = GoldBright,
                                                fontSize = 24.sp,
                                                letterSpacing = 0.sp,
                                                textDirection = TextDirection.Rtl
                                            )
                                        )
                                    }
                                }
                            }

                            sections.forEach { section ->
                                if (section.startsSurah) {
                                    item(key = "banner_${pageDetail.pageNumber}_${section.surahNumber}") {
                                        SurahTitleBanner(
                                            surahNumber = section.surahNumber,
                                            surahNameArabic = section.surahNameArabic,
                                            surahNameTr = section.surahNameTr,
                                            surahNameKu = section.surahNameKu,
                                            translationMode = translationMode,
                                            language = language,
                                            fontSize = fontSize
                                        )
                                    }
                                }

                                if (translationMode == "AR") {
                                    // Authentic continuous Mushaf page flow for crystal-clear reading
                                    item(
                                        key = "ar_flow_${pageDetail.pageNumber}_${section.surahNumber}_${section.ayahs.firstOrNull()?.numberInSurah ?: 0}"
                                    ) {
                                        ContinuousArabicMushafSection(
                                            ayahs = section.ayahs,
                                            fontSize = fontSize
                                        )
                                    }
                                } else {
                                    items(
                                        items = section.ayahs,
                                        key = { ayah -> "${pageDetail.pageNumber}_${ayah.surahNumber}_${ayah.numberInSurah}" }
                                    ) { ayah ->
                                        MushafAyahItem(
                                            ayah = ayah,
                                            translationMode = translationMode,
                                            fontSize = fontSize
                                        )
                                    }
                                }
                            }

                            item(key = "page_footer_${pageDetail.pageNumber}") {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp, bottom = 4.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Surface(
                                        shape = CircleShape,
                                        color = EmeraldContainer,
                                        border = BorderStroke(1.dp, GoldClassic),
                                        modifier = Modifier.size(38.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = currentPage.toString(),
                                                color = GoldBright,
                                                fontSize = 14.sp,
                                                fontWeight = FontWeight.Bold
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Ultra-Compact Bottom Page Navigation Bar
        Surface(
            modifier = Modifier.fillMaxWidth(),
            color = DarkSurface,
            border = BorderStroke(0.6.dp, DarkCardBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp, vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (isRtlMode) {
                    Button(
                        onClick = onNextPage,
                        enabled = currentPage < 604,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .heightIn(min = 36.dp)
                            .testTag("mushaf_next_page_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isKurmanji) "Rûpela Pêş" else "Sonraki Sayfa",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldContainer,
                        border = BorderStroke(0.8.dp, GoldBright),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showJumpDialog = true }
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) {
                            Text(
                                text = "$currentPage / 604",
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = onPreviousPage,
                        enabled = currentPage > 1,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .testTag("mushaf_prev_page_button")
                    ) {
                        Text(
                            text = if (isKurmanji) "Rûpela Berê" else "Önceki Sayfa",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                } else {
                    Button(
                        onClick = onPreviousPage,
                        enabled = currentPage > 1,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .testTag("mushaf_prev_page_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = if (isKurmanji) "Rûpela Berê" else "Önceki Sayfa",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = GoldContainer,
                        border = BorderStroke(0.8.dp, GoldBright),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { showJumpDialog = true }
                    ) {
                        Box(contentAlignment = Alignment.Center, modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)) {
                            Text(
                                text = "$currentPage / 604",
                                color = GoldBright,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Button(
                        onClick = onNextPage,
                        enabled = currentPage < 604,
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = EmeraldContainer,
                            contentColor = GoldBright,
                            disabledContainerColor = DarkSurfaceVariant,
                            disabledContentColor = TextMutedEmerald.copy(alpha = 0.3f)
                        ),
                        shape = RoundedCornerShape(9.dp),
                        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .heightIn(min = 38.dp)
                            .testTag("mushaf_next_page_button")
                    ) {
                        Text(
                            text = if (isKurmanji) "Rûpela Pêş" else "Sonraki Sayfa",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }

    if (showJumpDialog) {
        PageJumpDialog(
            currentPage = currentPage,
            language = language,
            onDismiss = { showJumpDialog = false },
            onSelectPage = {
                onJumpToPage(it)
                showJumpDialog = false
            }
        )
    }
}

@Composable
private fun ContinuousArabicMushafSection(
    ayahs: List<PageAyah>,
    fontSize: Float
) {
    val markerColor = GoldBright
    val arabicParagraph = remember(ayahs, fontSize, markerColor) {
        buildAnnotatedString {
            ayahs.forEachIndexed { index, ayah ->
                append(ayah.textArabic)
                withStyle(
                    SpanStyle(
                        color = markerColor,
                        fontFamily = DiyanetMushafFontFamily,
                        fontWeight = FontWeight.Normal,
                        fontSize = (fontSize * 0.82f).sp,
                        letterSpacing = 0.sp
                    )
                ) {
                    append("\u00A0\uFD3F${ayah.numberInSurah}\uFD3E")
                }
                if (index < ayahs.lastIndex) {
                    append(" ")
                }
            }
        }
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        Text(
            text = arabicParagraph,
            style = TextStyle(
                fontFamily = DiyanetMushafFontFamily,
                color = TextWhite,
                fontSize = fontSize.sp,
                lineHeight = (fontSize * 1.90f).sp,
                letterSpacing = 0.sp,
                textAlign = TextAlign.Start,
                textDirection = TextDirection.Rtl,
                fontWeight = FontWeight.Normal
            ),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 2.dp, vertical = 2.dp)
        )
    }
}

@Composable
private fun FontZoomButton(
    label: String,
    enabled: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 38.dp)
            .clip(RoundedCornerShape(7.dp))
            .clickable(enabled = enabled, onClickLabel = contentDescription, onClick = onClick),
        color = DarkSurfaceVariant,
        border = BorderStroke(
            0.9.dp,
            if (enabled) GoldClassic.copy(alpha = 0.6f) else DarkCardBorder.copy(alpha = 0.4f)
        )
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 7.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                color = if (enabled) GoldBright else TextMutedEmerald.copy(alpha = 0.4f),
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                softWrap = false
            )
        }
    }
}

@Composable
private fun TranslationChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier
            .heightIn(min = 38.dp)
            .clip(RoundedCornerShape(7.dp))
            .clickable(onClick = onClick),
        color = if (isSelected) GoldBright else DarkSurfaceVariant,
        border = BorderStroke(1.dp, if (isSelected) GoldWarm else DarkCardBorder)
    ) {
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier.padding(horizontal = 3.dp, vertical = 6.dp)
        ) {
            Text(
                text = label,
                color = if (isSelected) DarkBackground else TextWhite,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                fontSize = 12.5.sp,
                textAlign = TextAlign.Center,
                maxLines = 1,
                softWrap = false,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun SurahTitleBanner(
    surahNumber: Int,
    surahNameArabic: String,
    surahNameTr: String,
    surahNameKu: String,
    translationMode: String,
    language: AppLanguage,
    fontSize: Float
) {
    val basmalaSize = (fontSize * 0.80f).coerceIn(32f, 56f)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 3.dp),
        shape = RoundedCornerShape(10.dp),
        color = EmeraldContainer,
        border = BorderStroke(1.dp, GoldClassic)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 8.dp, vertical = 7.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = surahNameArabic,
                style = TextStyle(
                    fontFamily = DiyanetMushafFontFamily,
                    color = GoldBright,
                    fontSize = 36.sp,
                    letterSpacing = 0.sp,
                    textAlign = TextAlign.Center,
                    textDirection = TextDirection.Rtl
                )
            )
            Text(
                text = when (translationMode) {
                    "KU" -> "$surahNumber. $surahNameKu"
                    "TR" -> "$surahNumber. $surahNameTr"
                    else -> "$surahNumber. ${if (language == AppLanguage.KURMANJI) surahNameKu else surahNameTr}"
                },
                color = TextWhite,
                fontSize = 17.sp,
                fontWeight = FontWeight.SemiBold,
                textAlign = TextAlign.Center
            )
            if (surahNumber != 1 && surahNumber != 9) {
                Spacer(modifier = Modifier.height(5.dp))
                Text(
                    text = "بِسْمِ اللّٰهِ الرَّحْمٰنِ الرَّحٖیمِ",
                    style = TextStyle(
                        fontFamily = DiyanetMushafFontFamily,
                        color = GoldBright.copy(alpha = 0.98f),
                        fontSize = basmalaSize.sp,
                        lineHeight = (basmalaSize * 1.72f).sp,
                        letterSpacing = 0.sp,
                        fontWeight = FontWeight.Normal,
                        textAlign = TextAlign.Center,
                        textDirection = TextDirection.Rtl
                    )
                )
                if (translationMode == "KU") {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Bi Navê Xwedayê Reḥman ê Reḥîm.",
                        color = TextWhite.copy(alpha = 0.94f),
                        fontSize = 19.sp,
                        lineHeight = 26.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                } else if (translationMode == "TR") {
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "Rahmân ve rahîm olan Allah’ın adıyla",
                        color = TextWhite.copy(alpha = 0.94f),
                        fontSize = 19.sp,
                        lineHeight = 26.sp,
                        fontWeight = FontWeight.Medium,
                        textAlign = TextAlign.Center
                    )
                }
            }
        }
    }
}

@Composable
private fun MushafAyahItem(
    ayah: PageAyah,
    translationMode: String,
    fontSize: Float
) {
    val mealTextSize = (fontSize * 0.48f).coerceIn(20f, 36f)
    val markerColor = GoldBright
    val arabicWithMarker = remember(ayah.textArabic, ayah.numberInSurah, fontSize, markerColor) {
        buildAnnotatedString {
            append(ayah.textArabic)
            withStyle(
                SpanStyle(
                    color = markerColor,
                    fontFamily = DiyanetMushafFontFamily,
                    fontWeight = FontWeight.Normal,
                    fontSize = (fontSize * 0.82f).sp,
                    letterSpacing = 0.sp
                )
            ) {
                append("\u00A0\uFD3F${ayah.numberInSurah}\uFD3E")
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 2.dp, vertical = 8.dp)
    ) {
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
            Text(
                text = arabicWithMarker,
                style = TextStyle(
                    fontFamily = DiyanetMushafFontFamily,
                    color = TextWhite,
                    fontSize = fontSize.sp,
                    lineHeight = (fontSize * 1.90f).sp,
                    letterSpacing = 0.sp,
                    textAlign = TextAlign.Start,
                    textDirection = TextDirection.Rtl,
                    fontWeight = FontWeight.Normal
                ),
                modifier = Modifier.fillMaxWidth()
            )
        }

        if (translationMode == "KU" || translationMode == "TR") {
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.Top
            ) {
                Surface(
                    shape = CircleShape,
                    color = if (translationMode == "KU") GoldContainer else EmeraldContainer,
                    border = BorderStroke(0.8.dp, GoldBright),
                    modifier = Modifier
                        .padding(top = 3.dp)
                        .size(30.dp)
                ) {
                    Box(contentAlignment = Alignment.Center) {
                        Text(
                            text = ayah.numberInSurah.toString(),
                            color = GoldBright,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (translationMode == "KU") ayah.translationKuLatin else ayah.translationTr,
                    color = TextWhite.copy(alpha = 0.96f),
                    fontSize = mealTextSize.sp,
                    lineHeight = (mealTextSize * 1.48f).sp,
                    modifier = Modifier.weight(1f)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            HorizontalDivider(
                color = GoldClassic.copy(alpha = 0.2f),
                thickness = 0.7.dp
            )
        }
    }
}

@Composable
private fun PageJumpDialog(
    currentPage: Int,
    language: AppLanguage,
    onDismiss: () -> Unit,
    onSelectPage: (Int) -> Unit
) {
    var pageInput by remember { mutableStateOf(currentPage.toString()) }
    var sliderValue by remember { mutableFloatStateOf(currentPage.toFloat()) }
    val isKurmanji = language == AppLanguage.KURMANJI

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
                Text(
                    text = if (isKurmanji) "Here Rûpelê (1 - 604)" else "Sayfaya Git (1 - 604)",
                    color = GoldBright,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Text(
                        text = "${sliderValue.toInt()} / 604",
                        color = GoldBright,
                        fontSize = 34.sp,
                        fontWeight = FontWeight.ExtraBold
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Slider(
                        value = sliderValue,
                        onValueChange = {
                            sliderValue = it
                            pageInput = it.toInt().toString()
                        },
                        valueRange = 1f..604f,
                        colors = SliderDefaults.colors(
                            thumbColor = GoldBright,
                            activeTrackColor = GoldBright,
                            inactiveTrackColor = DarkCardBorder
                        ),
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = pageInput,
                        onValueChange = { str ->
                            pageInput = str
                            str.toIntOrNull()?.let {
                                if (it in 1..604) sliderValue = it.toFloat()
                            }
                        },
                        label = { Text(if (isKurmanji) "Hejmara Rûpelê" else "Sayfa Numarası", color = TextMutedEmerald, fontSize = 15.sp) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite,
                            focusedBorderColor = GoldBright,
                            unfocusedBorderColor = EmeraldBorder
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.width(170.dp)
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (isKurmanji) "Rûpelên Girîng:" else "Hızlı Sayfalar:",
                        color = GoldWarm,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val quickChips = listOf(
                        1 to "Fâtiha (1)",
                        2 to "Bakara (2)",
                        42 to "Ayetel-Kürsi (42)",
                        440 to "Yâsîn (440)",
                        562 to "Mülk (562)",
                        604 to "İhlâs (604)"
                    )
                    quickChips.chunked(3).forEach { rowChips ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 3.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp, Alignment.CenterHorizontally)
                        ) {
                            rowChips.forEach { (pg, lbl) ->
                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = DarkSurface,
                                    border = BorderStroke(0.6.dp, GoldWarm.copy(alpha = 0.5f)),
                                    modifier = Modifier.clickable { onSelectPage(pg) }
                                ) {
                                    Text(
                                        text = lbl,
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            },
        confirmButton = {
            Button(
                onClick = {
                    val p = pageInput.toIntOrNull()?.coerceIn(1, 604) ?: sliderValue.toInt()
                    onSelectPage(p)
                },
                colors = ButtonDefaults.buttonColors(containerColor = GoldBright, contentColor = DarkBackground)
            ) {
                Text(if (isKurmanji) "Here" else "Git", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (isKurmanji) "Betal bike" else "İptal", color = TextMutedEmerald)
            }
        },
        containerColor = DarkCard
    )
}
