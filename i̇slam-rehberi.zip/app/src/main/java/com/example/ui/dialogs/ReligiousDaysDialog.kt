package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CalendarMonth
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.local.AppStrings
import com.example.data.local.ReligiousDaysData
import com.example.data.model.AppLanguage
import com.example.data.model.ReligiousDay
import com.example.ui.theme.*

@Composable
fun ReligiousDaysDialog(
    language: AppLanguage,
    onDismiss: () -> Unit
) {
    var selectedDayForDetail by remember { mutableStateOf<ReligiousDay?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.95f)
                .fillMaxHeight(0.90f)
                .clip(RoundedCornerShape(24.dp))
                .border(1.dp, IslamicGold.copy(alpha = 0.4f), RoundedCornerShape(24.dp)),
            color = IslamicGreenDark
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .background(IslamicGold.copy(alpha = 0.15f), RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CalendarMonth,
                                contentDescription = null,
                                tint = IslamicGold
                            )
                        }
                        Column {
                            Text(
                                text = AppStrings.allReligiousDaysTitle(language),
                                fontSize = 21.sp,
                                fontWeight = FontWeight.Bold,
                                color = IslamicGold
                            )
                            Text(
                                text = if (language == AppLanguage.KURMANJI) "Salnameya Rojên Pîroz a 1446-1447" else "1446-1447 Dini Günler Takvimi",
                                fontSize = 15.sp,
                                color = TextWhite.copy(alpha = 0.7f)
                            )
                        }
                    }

                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_religious_days_dialog")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = AppStrings.close(language),
                            tint = TextWhite
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // List of Religious Days
                LazyColumn(
                    modifier = Modifier
                        .fillMaxWidth()
                        .weight(1f),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(ReligiousDaysData.RELIGIOUS_DAYS, key = { it.id }) { item ->
                        val daysDiff = ReligiousDaysData.getDaysDifference(item.gregorianDateStr)
                        ReligiousDayItemCard(
                            day = item,
                            daysDiff = daysDiff,
                            language = language,
                            onClick = { selectedDayForDetail = item }
                        )
                    }
                }
            }
        }
    }

    selectedDayForDetail?.let { day ->
        ReligiousDayDetailDialog(
            day = day,
            language = language,
            onDismiss = { selectedDayForDetail = null }
        )
    }
}

@Composable
private fun ReligiousDayItemCard(
    day: ReligiousDay,
    daysDiff: Long,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val isUpcoming = daysDiff in 0..60
    val isToday = daysDiff == 0L

    val borderColor = when {
        isToday -> IslamicGold
        isUpcoming -> IslamicGold.copy(alpha = 0.6f)
        else -> IslamicGold.copy(alpha = 0.15f)
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .border(1.dp, borderColor, RoundedCornerShape(14.dp)),
        colors = CardDefaults.cardColors(
            containerColor = if (isToday) IslamicGold.copy(alpha = 0.15f) else IslamicGreenSurface
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = day.getName(language),
                    fontSize = 19.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isToday) IslamicGold else TextWhite,
                    modifier = Modifier.weight(1f)
                )

                if (daysDiff >= 0) {
                    val badgeText = AppStrings.daysLeftFormat(daysDiff, language)
                    Box(
                        modifier = Modifier
                            .background(
                                color = if (isToday) IslamicGold else IslamicGold.copy(alpha = 0.2f),
                                shape = RoundedCornerShape(8.dp)
                            )
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text(
                            text = badgeText,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isToday) IslamicGreenDark else IslamicGold
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Dates: Gregorian & Hijri
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = day.getDisplayDate(language),
                    fontSize = 15.sp,
                    color = IslamicGold.copy(alpha = 0.9f),
                    fontWeight = FontWeight.Medium
                )

                Text(
                    text = day.hijriDate,
                    fontSize = 15.sp,
                    color = TextWhite.copy(alpha = 0.6f)
                )
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Description
            Text(
                text = day.getDescription(language),
                fontSize = 16.sp,
                lineHeight = 23.sp,
                color = TextWhite.copy(alpha = 0.8f)
            )
        }
    }
}
