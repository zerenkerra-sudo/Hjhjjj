package com.example.ui.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CompassCalibration
import androidx.compose.material.icons.filled.Grain
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Campaign
import androidx.compose.material.icons.outlined.CompassCalibration
import androidx.compose.material.icons.outlined.Grain
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Schedule
import androidx.compose.material.icons.outlined.School
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.GoldBright
import com.example.ui.theme.TextMutedEmerald

sealed class NavScreen(
    val route: String,
    val filledIcon: ImageVector,
    val outlinedIcon: ImageVector
) {
    data object Prayer : NavScreen("prayer", Icons.Filled.Schedule, Icons.Outlined.Schedule)
    data object Quran : NavScreen("quran", Icons.Filled.MenuBook, Icons.Outlined.MenuBook)
    data object Elifba : NavScreen("elifba", Icons.Filled.School, Icons.Outlined.School)
    data object Qibla : NavScreen("qibla", Icons.Filled.CompassCalibration, Icons.Outlined.CompassCalibration)
    data object Settings : NavScreen("settings", Icons.Filled.NotificationsActive, Icons.Outlined.NotificationsActive)
    data object Hutbe : NavScreen("hutbe", Icons.Filled.Campaign, Icons.Outlined.Campaign)
    data object Tesbihat : NavScreen("tesbihat", Icons.Filled.Grain, Icons.Outlined.Grain)
    data object EsmaUlHusna : NavScreen("esma_ul_husna", Icons.Filled.AutoAwesome, Icons.Outlined.AutoAwesome)
}

@Composable
fun AppBottomNavBar(
    currentRoute: String,
    language: AppLanguage,
    onNavigate: (NavScreen) -> Unit,
    modifier: Modifier = Modifier
) {
    val items = listOf(
        NavScreen.Prayer to AppStrings.navPrayer(language),
        NavScreen.Quran to AppStrings.navQuran(language),
        NavScreen.Elifba to AppStrings.navElifba(language),
        NavScreen.Qibla to AppStrings.navQibla(language)
    )

    NavigationBar(
        modifier = modifier.testTag("bottom_nav_bar"),
        containerColor = DarkSurface,
        tonalElevation = 8.dp
    ) {
        items.forEach { (screen, label) ->
            val selected = currentRoute == screen.route
            NavigationBarItem(
                selected = selected,
                onClick = { onNavigate(screen) },
                icon = {
                    Icon(
                        imageVector = if (selected) screen.filledIcon else screen.outlinedIcon,
                        contentDescription = label
                    )
                },
                label = {
                    Text(
                        text = label,
                        fontSize = 13.sp,
                        fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                        maxLines = 1,
                        softWrap = false,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = DarkSurface,
                    selectedTextColor = GoldBright,
                    indicatorColor = GoldBright,
                    unselectedIconColor = TextMutedEmerald,
                    unselectedTextColor = TextMutedEmerald
                )
            )
        }
    }
}
