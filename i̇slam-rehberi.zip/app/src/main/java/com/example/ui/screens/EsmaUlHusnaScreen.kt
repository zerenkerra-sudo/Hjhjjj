package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.local.AppStrings
import com.example.data.local.EsmaUlHusnaData
import com.example.data.local.EsmaUlHusnaItem
import com.example.data.model.AppLanguage
import com.example.ui.theme.*
import java.util.Calendar
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun EsmaUlHusnaScreen(
    language: AppLanguage,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    val clipboardManager = LocalClipboardManager.current
    var searchQuery by remember { mutableStateOf("") }
    var selectedItem by remember { mutableStateOf<EsmaUlHusnaItem?>(null) }
    var copiedFeedback by remember { mutableStateOf(false) }

    val allNames = EsmaUlHusnaData.ESMA_LIST
    val dailyHighlight = remember(allNames) {
        val dayOfYear = Calendar.getInstance().get(Calendar.DAY_OF_YEAR)
        allNames[(dayOfYear - 1).coerceAtLeast(0) % allNames.size]
    }

    val filteredNames = remember(searchQuery, allNames) {
        val q = normalizeSearchText(searchQuery)
        if (q.isBlank()) {
            allNames
        } else {
            allNames.filter { item ->
                item.number.toString() == q ||
                    normalizeSearchText(item.nameTr).contains(q) ||
                    normalizeSearchText(item.nameKu).contains(q) ||
                    normalizeSearchText(item.meaningTr).contains(q) ||
                    normalizeSearchText(item.meaningKu).contains(q) ||
                    item.arabicName.contains(searchQuery.trim())
            }
        }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .testTag("esma_ul_husna_screen"),
        containerColor = DarkBackground,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            text = AppStrings.esmaScreenTitle(language),
                            color = GoldBright,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            text = if (isKurmanji) "99 Navên Bedew ên Xwedê û Wateyên Wan" else "Allah'ın 99 Güzel İsmi ve Anlamları",
                            color = TextMutedEmerald,
                            fontSize = 14.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = onBack,
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .testTag("esma_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = if (isKurmanji) "Vegere" else "Geri",
                            tint = GoldBright
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = DarkBackground
                )
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // Search Box
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = {
                    Text(
                        text = AppStrings.esmaSearchHint(language),
                        color = TextMutedEmerald,
                        fontSize = 16.sp
                    )
                },
                leadingIcon = {
                    Icon(
                        imageVector = Icons.Filled.Search,
                        contentDescription = null,
                        tint = GoldBright
                    )
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(
                            onClick = { searchQuery = "" },
                            modifier = Modifier
                                .minimumInteractiveComponentSize()
                                .testTag("esma_clear_search_button")
                        ) {
                            Icon(
                                imageVector = Icons.Filled.Close,
                                contentDescription = if (isKurmanji) "Paqij bike" else "Temizle",
                                tint = GoldWarm
                            )
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(14.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldBright,
                    unfocusedBorderColor = GoldClassic.copy(alpha = 0.45f),
                    focusedContainerColor = DarkCard,
                    unfocusedContainerColor = DarkCard,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("esma_search_input")
            )

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                if (searchQuery.isBlank()) {
                    item {
                        DailyEsmaHighlightCard(
                            item = dailyHighlight,
                            language = language,
                            onClick = { selectedItem = dailyHighlight }
                        )
                    }
                }

                if (filteredNames.isEmpty()) {
                    item {
                        Surface(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp),
                            color = DarkCard,
                            border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.4f))
                        ) {
                            Column(
                                modifier = Modifier.padding(24.dp),
                                horizontalAlignment = Alignment.CenterHorizontally,
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Search,
                                    contentDescription = null,
                                    tint = GoldWarm,
                                    modifier = Modifier.size(32.dp)
                                )
                                Text(
                                    text = if (isKurmanji) "Encam nehat dîtin." else "Aramanızla eşleşen isim bulunamadı.",
                                    color = TextWhite,
                                    fontSize = 17.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                            }
                        }
                    }
                } else {
                    items(filteredNames, key = { it.number }) { item ->
                        EsmaNameCard(
                            item = item,
                            language = language,
                            onClick = { selectedItem = item }
                        )
                    }
                }
            }
        }
    }

    selectedItem?.let { item ->
        EsmaDetailDialog(
            item = item,
            language = language,
            copied = copiedFeedback,
            onCopy = {
                val text = "${item.number}. ${item.arabicName} — ${item.getName(language)}: ${item.getMeaning(language)}"
                clipboardManager.setText(AnnotatedString(text))
                copiedFeedback = true
            },
            onDismiss = {
                copiedFeedback = false
                selectedItem = null
            }
        )
    }
}

@Composable
private fun DailyEsmaHighlightCard(
    item: EsmaUlHusnaItem,
    language: AppLanguage,
    onClick: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(18.dp))
            .clickable(onClick = onClick)
            .testTag("esma_daily_highlight_card"),
        shape = RoundedCornerShape(18.dp),
        color = DarkCard,
        border = BorderStroke(1.3.dp, GoldBright)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .background(
                    Brush.linearGradient(
                        listOf(EmeraldPrimary.copy(alpha = 0.55f), DarkCard)
                    )
                )
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Filled.AutoAwesome,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = if (isKurmanji) "Navê Îro • #${item.number}" else "Günün İsmi • #${item.number}",
                            color = GoldWarm,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Text(
                        text = item.arabicName,
                        style = TextStyle(
                            fontFamily = DiyanetMushafFontFamily,
                            fontSize = 34.sp,
                            lineHeight = 48.sp,
                            letterSpacing = 0.sp,
                            textDirection = TextDirection.Rtl,
                            color = TextWhite
                        )
                    )
                }

                Text(
                    text = item.getName(language),
                    color = GoldBright,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.ExtraBold
                )

                Text(
                    text = item.getMeaning(language),
                    color = TextWhite.copy(alpha = 0.92f),
                    fontSize = 16.sp,
                    lineHeight = 23.sp
                )
            }
        }
    }
}

@Composable
private fun EsmaNameCard(
    item: EsmaUlHusnaItem,
    language: AppLanguage,
    onClick: () -> Unit
) {
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("esma_card_${item.number}"),
        shape = RoundedCornerShape(16.dp),
        color = DarkCard,
        border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.45f))
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 12.dp),
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Surface(
                        modifier = Modifier.size(38.dp),
                        shape = CircleShape,
                        color = EmeraldContainer,
                        border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.75f))
                    ) {
                        Box(contentAlignment = Alignment.Center) {
                            Text(
                                text = item.number.toString(),
                                color = GoldBright,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Text(
                        text = item.getName(language),
                        color = GoldBright,
                        fontSize = 19.sp,
                        fontWeight = FontWeight.Bold,
                        maxLines = 2,
                        overflow = TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = MushafPaperSurface,
                    border = BorderStroke(0.8.dp, EmeraldBorder.copy(alpha = 0.45f))
                ) {
                    Text(
                        text = item.arabicName,
                        style = TextStyle(
                            fontFamily = DiyanetMushafFontFamily,
                            fontSize = 26.sp,
                            lineHeight = 38.sp,
                            letterSpacing = 0.sp,
                            textDirection = TextDirection.Rtl,
                            color = TextWhite,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                    )
                }
            }

            Text(
                text = item.getMeaning(language),
                color = TextWhite.copy(alpha = 0.88f),
                fontSize = 16.sp,
                lineHeight = 23.sp
            )
        }
    }
}

@Composable
private fun EsmaDetailDialog(
    item: EsmaUlHusnaItem,
    language: AppLanguage,
    copied: Boolean,
    onCopy: () -> Unit,
    onDismiss: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI
    var zikirTapCount by remember(item.number) { mutableIntStateOf(0) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkCard,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "${item.number}. ${item.getName(language)}",
                    color = GoldBright,
                    fontSize = 21.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.weight(1f)
                )
                IconButton(
                    onClick = onCopy,
                    modifier = Modifier
                        .minimumInteractiveComponentSize()
                        .testTag("esma_copy_button")
                ) {
                    Icon(
                        imageVector = Icons.Filled.ContentCopy,
                        contentDescription = AppStrings.copy(language),
                        tint = if (copied) AdhanActiveGreen else GoldWarm
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Surface(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    color = MushafPaperSurface,
                    border = BorderStroke(1.dp, GoldClassic.copy(alpha = 0.55f))
                ) {
                    Text(
                        text = item.arabicName,
                        style = TextStyle(
                            fontFamily = DiyanetMushafFontFamily,
                            fontSize = 44.sp,
                            lineHeight = 68.sp,
                            letterSpacing = 0.sp,
                            textDirection = TextDirection.Rtl,
                            color = TextWhite,
                            textAlign = TextAlign.Center
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 14.dp, horizontal = 12.dp)
                    )
                }

                Text(
                    text = item.getMeaning(language),
                    color = TextWhite,
                    fontSize = 17.sp,
                    lineHeight = 25.sp,
                    textAlign = TextAlign.Center
                )

                if (copied) {
                    Text(
                        text = AppStrings.copiedToClipboard(language),
                        color = AdhanActiveGreen,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }

                // Quick Esma Zikir Tap Button
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { zikirTapCount += 1 }
                        .testTag("esma_dialog_zikir_tap"),
                    shape = RoundedCornerShape(14.dp),
                    color = EmeraldContainer,
                    border = BorderStroke(1.dp, GoldBright.copy(alpha = 0.7f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 14.dp, vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = if (isKurmanji) "Zikir Bikê (Bitikîne)" else "Zikir Sayacı (Dokun)",
                                color = GoldBright,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "Yâ ${item.getName(language).substringAfter("-")}",
                                color = TextMutedEmerald,
                                fontSize = 14.sp
                            )
                        }

                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Text(
                                text = "$zikirTapCount / 99",
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold
                            )
                            IconButton(
                                onClick = { zikirTapCount = 0 },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Filled.Refresh,
                                    contentDescription = if (isKurmanji) "Sifir Bike" else "Sıfırla",
                                    tint = GoldWarm,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onDismiss,
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldBright,
                    contentColor = DarkBackground
                ),
                modifier = Modifier.testTag("esma_dialog_close_button")
            ) {
                Text(
                    text = AppStrings.close(language),
                    fontWeight = FontWeight.Bold
                )
            }
        }
    )
}

private fun normalizeSearchText(input: String): String {
    return input.trim()
        .lowercase(Locale("tr", "TR"))
        .replace('â', 'a')
        .replace('î', 'i')
        .replace('û', 'u')
        .replace("'", "")
        .replace("’", "")
}
