package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.AppPreferences
import com.example.data.local.OfflineDownloadState
import com.example.data.local.QuranOfflineAudioManager
import com.example.data.model.QuranPageDetail
import com.example.data.model.QuranReciter
import com.example.data.model.SurahDetail
import com.example.data.model.SurahInfo
import com.example.data.repository.QuranRepository
import com.example.service.AudioPlaybackSource
import com.example.service.OfflineVoiceMode
import com.example.service.QuranAudioService
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

data class QuranUiState(
    val surahs: List<SurahInfo> = emptyList(),
    val searchQuery: String = "",
    val selectedSurah: SurahDetail? = null,
    val selectedPage: Int = 1,
    val currentPageDetail: QuranPageDetail? = null,
    val isPageLoading: Boolean = false,
    val translationMode: String = "AR", // "AR" (Arapça), "KU" (Kürtçe), "TR" (Türkçe)
    val fontSize: Float = 58f,
    val isRtlMode: Boolean = true,

    // Audio Playback State (Unified via QuranAudioService for continuous full Quran listening)
    val isAudioPlaying: Boolean = false,
    val isAudioBuffering: Boolean = false,
    val isAudioActive: Boolean = false,
    val activeAudioSurah: Int = 1,
    val activeReciter: QuranReciter = QuranReciter.ALAFASY,
    val audioProgress: Float = 0f,
    val audioCurrentTimeMs: Int = 0,
    val audioDurationMs: Int = 0,
    val isAutoAdvance: Boolean = true,
    val playbackSpeed: Float = 1.0f,
    val playbackSource: AudioPlaybackSource = AudioPlaybackSource.NONE,
    val currentAyahLabel: String? = null,
    val offlineVoiceMode: OfflineVoiceMode = OfflineVoiceMode.AUTO_ARABIC,
    val audioErrorMessage: String? = null,

    // Offline Audio Cache / Download State
    val downloadedSurahsByReciter: Map<String, Set<Int>> = emptyMap(),
    val totalAudioStorageBytes: Long = 0L,
    val downloadState: OfflineDownloadState = OfflineDownloadState()
) {
    val activeReciterDownloadedSurahs: Set<Int>
        get() = downloadedSurahsByReciter[activeReciter.id] ?: emptySet()
}

class QuranViewModel(application: Application) : AndroidViewModel(application) {

    private val preferences = AppPreferences(application)
    private val repository = QuranRepository(application)

    private val _uiState = MutableStateFlow(
        QuranUiState(
            translationMode = preferences.getQuranTranslationMode(),
            fontSize = preferences.getQuranFontSize(),
            isRtlMode = preferences.isQuranRtlMode()
        )
    )
    val uiState: StateFlow<QuranUiState> = _uiState.asStateFlow()

    init {
        loadSurahs("")
        // Pre-select Surah Al-Fatiha and Page 1 (100% from local assets)
        selectSurah(1)
        loadPage(1)

        // Scan locally cached/downloaded MP3s
        QuranOfflineAudioManager.refreshInventory(application)

        // Observe central audio and offline download flows
        observeAudioService()
        observeOfflineDownloads()
    }

    private fun observeAudioService() {
        viewModelScope.launch {
            QuranAudioService.isPlayingFlow.collect { playing ->
                _uiState.value = _uiState.value.copy(
                    isAudioPlaying = playing,
                    isAudioActive = playing || _uiState.value.isAudioBuffering || _uiState.value.audioCurrentTimeMs > 0
                )
            }
        }
        viewModelScope.launch {
            QuranAudioService.isBufferingFlow.collect { buffering ->
                _uiState.value = _uiState.value.copy(
                    isAudioBuffering = buffering,
                    isAudioActive = _uiState.value.isAudioPlaying || buffering || _uiState.value.audioCurrentTimeMs > 0
                )
            }
        }
        viewModelScope.launch {
            QuranAudioService.currentSurahNumberFlow.collect { surah ->
                _uiState.value = _uiState.value.copy(activeAudioSurah = surah)
            }
        }
        viewModelScope.launch {
            QuranAudioService.currentReciterFlow.collect { reciter ->
                _uiState.value = _uiState.value.copy(activeReciter = reciter)
            }
        }
        viewModelScope.launch {
            QuranAudioService.progressFlow.collect { prog ->
                _uiState.value = _uiState.value.copy(audioProgress = prog)
            }
        }
        viewModelScope.launch {
            QuranAudioService.currentTimeMsFlow.collect { time ->
                _uiState.value = _uiState.value.copy(
                    audioCurrentTimeMs = time,
                    isAudioActive = _uiState.value.isAudioPlaying || _uiState.value.isAudioBuffering || time > 0
                )
            }
        }
        viewModelScope.launch {
            QuranAudioService.durationMsFlow.collect { dur ->
                _uiState.value = _uiState.value.copy(audioDurationMs = dur)
            }
        }
        viewModelScope.launch {
            QuranAudioService.isAutoAdvanceFlow.collect { auto ->
                _uiState.value = _uiState.value.copy(isAutoAdvance = auto)
            }
        }
        viewModelScope.launch {
            QuranAudioService.playbackSpeedFlow.collect { speed ->
                _uiState.value = _uiState.value.copy(playbackSpeed = speed)
            }
        }
        viewModelScope.launch {
            QuranAudioService.playbackSourceFlow.collect { source ->
                _uiState.value = _uiState.value.copy(playbackSource = source)
            }
        }
        viewModelScope.launch {
            QuranAudioService.currentAyahLabelFlow.collect { label ->
                _uiState.value = _uiState.value.copy(currentAyahLabel = label)
            }
        }
        viewModelScope.launch {
            QuranAudioService.offlineVoiceModeFlow.collect { mode ->
                _uiState.value = _uiState.value.copy(offlineVoiceMode = mode)
            }
        }
        viewModelScope.launch {
            QuranAudioService.errorMessageFlow.collect { err ->
                _uiState.value = _uiState.value.copy(audioErrorMessage = err)
            }
        }
    }

    private fun observeOfflineDownloads() {
        viewModelScope.launch {
            QuranOfflineAudioManager.downloadedSurahsByReciterFlow.collect { map ->
                _uiState.value = _uiState.value.copy(downloadedSurahsByReciter = map)
            }
        }
        viewModelScope.launch {
            QuranOfflineAudioManager.totalStorageBytesFlow.collect { bytes ->
                _uiState.value = _uiState.value.copy(totalAudioStorageBytes = bytes)
            }
        }
        viewModelScope.launch {
            QuranOfflineAudioManager.downloadStateFlow.collect { dlState ->
                _uiState.value = _uiState.value.copy(downloadState = dlState)
            }
        }
    }

    fun loadSurahs(query: String) {
        viewModelScope.launch {
            val list = repository.getSurahs(query)
            _uiState.value = _uiState.value.copy(surahs = list, searchQuery = query)
        }
    }

    fun selectSurah(number: Int) {
        viewModelScope.launch {
            val detail = repository.getSurahDetail(number)
            _uiState.value = _uiState.value.copy(selectedSurah = detail)
            detail?.info?.startPage?.let { page ->
                loadPage(page)
            }
        }
    }

    fun loadPage(pageNumber: Int) {
        val safePage = pageNumber.coerceIn(1, 604)
        _uiState.value = _uiState.value.copy(
            selectedPage = safePage,
            isPageLoading = true
        )
        viewModelScope.launch {
            val pageDetail = repository.getPageDetail(safePage)
            _uiState.value = _uiState.value.copy(
                currentPageDetail = pageDetail,
                isPageLoading = false
            )
        }
    }

    fun nextPage() {
        val next = (_uiState.value.selectedPage + 1).coerceAtMost(604)
        loadPage(next)
    }

    fun previousPage() {
        val prev = (_uiState.value.selectedPage - 1).coerceAtLeast(1)
        loadPage(prev)
    }

    fun selectJuz(juzNumber: Int) {
        val juz = com.example.data.local.QuranNavigationData.JUZ_LIST.find { it.number == juzNumber }
        if (juz != null) {
            loadPage(juz.startPage)
            selectSurah(juz.startSurahNumber)
        }
    }

    fun setTranslationMode(mode: String) {
        val normalized = if (mode in setOf("AR", "KU", "TR")) mode else "AR"
        preferences.setQuranTranslationMode(normalized)
        _uiState.value = _uiState.value.copy(translationMode = normalized)
    }

    fun setFontSize(size: Float) {
        val clamped = size.coerceIn(32f, 92f)
        preferences.setQuranFontSize(clamped)
        _uiState.value = _uiState.value.copy(fontSize = clamped)
    }

    fun increaseFontSize() {
        setFontSize(_uiState.value.fontSize + 4f)
    }

    fun decreaseFontSize() {
        setFontSize(_uiState.value.fontSize - 4f)
    }

    fun toggleRtlMode() {
        val newMode = !_uiState.value.isRtlMode
        preferences.setQuranRtlMode(newMode)
        _uiState.value = _uiState.value.copy(isRtlMode = newMode)
    }

    // Audio Playback Controls (Connected to QuranAudioService)
    fun toggleAudioPlayback(surahNumber: Int = _uiState.value.activeAudioSurah) {
        val app = getApplication<Application>()
        if (_uiState.value.activeAudioSurah == surahNumber && _uiState.value.isAudioPlaying) {
            QuranAudioService.pause(app)
        } else if (_uiState.value.activeAudioSurah == surahNumber &&
            (_uiState.value.audioCurrentTimeMs > 0 || _uiState.value.playbackSource != AudioPlaybackSource.NONE)
        ) {
            QuranAudioService.resume(app)
        } else {
            QuranAudioService.playSurah(app, surahNumber, _uiState.value.activeReciter)
        }
    }

    fun playSurahAudio(
        surahNumber: Int,
        reciter: QuranReciter = _uiState.value.activeReciter,
        forceOfflineRecitation: Boolean = false
    ) {
        val app = getApplication<Application>()
        QuranAudioService.playSurah(app, surahNumber, reciter, forceOfflineRecitation)
    }

    fun pauseAudio() {
        QuranAudioService.pause(getApplication())
    }

    fun resumeAudio() {
        QuranAudioService.resume(getApplication())
    }

    fun nextAudioSurah() {
        QuranAudioService.next(getApplication())
    }

    fun previousAudioSurah() {
        QuranAudioService.previous(getApplication())
    }

    fun seekAudio(fraction: Float) {
        QuranAudioService.seekTo(getApplication(), fraction)
    }

    fun seekForward10s() {
        QuranAudioService.seekForward10s(getApplication())
    }

    fun seekBackward10s() {
        QuranAudioService.seekBackward10s(getApplication())
    }

    fun setReciter(reciter: QuranReciter) {
        QuranAudioService.setReciter(getApplication(), reciter)
    }

    fun toggleAutoAdvance() {
        val newMode = !_uiState.value.isAutoAdvance
        QuranAudioService.setAutoAdvance(getApplication(), newMode)
    }

    fun setPlaybackSpeed(speed: Float) {
        QuranAudioService.setSpeed(getApplication(), speed)
    }

    fun setOfflineVoiceMode(mode: OfflineVoiceMode) {
        QuranAudioService.setOfflineVoiceMode(getApplication(), mode)
    }

    fun stopAudio() {
        QuranAudioService.stop(getApplication())
    }

    // Offline Download Manager Controls
    fun downloadSurahAudio(surahNumber: Int, reciter: QuranReciter = _uiState.value.activeReciter) {
        QuranOfflineAudioManager.downloadSurah(getApplication(), reciter, surahNumber)
    }

    fun downloadJuzAudio(juzNumber: Int, reciter: QuranReciter = _uiState.value.activeReciter) {
        QuranOfflineAudioManager.downloadJuz(getApplication(), reciter, juzNumber)
    }

    fun downloadAllSurahsAudio(reciter: QuranReciter = _uiState.value.activeReciter) {
        QuranOfflineAudioManager.downloadAllSurahs(getApplication(), reciter)
    }

    fun cancelAudioDownload() {
        QuranOfflineAudioManager.cancelDownload()
    }

    fun deleteSurahAudio(surahNumber: Int, reciter: QuranReciter = _uiState.value.activeReciter) {
        QuranOfflineAudioManager.deleteSurah(getApplication(), reciter, surahNumber)
    }

    fun deleteReciterAudio(reciter: QuranReciter = _uiState.value.activeReciter) {
        QuranOfflineAudioManager.deleteReciterDownloads(getApplication(), reciter)
    }
}
