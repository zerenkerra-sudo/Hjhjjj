package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.BatteryAlert
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.data.local.AppStrings
import com.example.data.model.AppLanguage
import com.example.ui.theme.*

@Composable
fun BatteryGuideDialog(
    language: AppLanguage,
    onDismiss: () -> Unit,
    onOpenBatterySettings: () -> Unit
) {
    val isKurmanji = language == AppLanguage.KURMANJI

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.85f)
                .clip(RoundedCornerShape(24.dp))
                .testTag("battery_guide_dialog"),
            color = DarkCard,
            border = androidx.compose.foundation.BorderStroke(1.dp, GoldClassic.copy(alpha = 0.5f))
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Filled.BatteryAlert,
                            contentDescription = null,
                            tint = GoldBright,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (isKurmanji) "Rêbernameya Pîlê" else "Pil ve Arka Plan Rehberi",
                            color = GoldBright,
                            fontSize = 21.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_battery_dialog_button")
                    ) {
                        Icon(Icons.Filled.Close, contentDescription = "Kapat", tint = TextWhite)
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    // Transparent Notice Card
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldBorder)
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.Top
                        ) {
                            Icon(
                                Icons.Filled.Info,
                                contentDescription = null,
                                tint = GoldWarm,
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = if (isKurmanji)
                                    "Ji kerema xwe bala xwe bidinê: Ji ber sînorên pergala Android û polîtîkayên ewlehiyê yên çêkerên telefonan, destûra fermî hewce ye da ku ezan di paşperdeyê de bê qutbûn bixwîne."
                                else
                                    "Android işletim sistemi ve cihaz üreticileri (Xiaomi, Samsung, Huawei, Oppo vb.) pil tasarrufu için arka plan uygulamalarını zorla uyutabilir. Ezanın vaktinde okunabilmesi için sistem izinlerinin açık olması zorunludur.",
                                color = TextWhite,
                                fontSize = 16.sp,
                                lineHeight = 23.sp
                            )
                        }
                    }

                    // Steps
                    Text(
                        text = if (isKurmanji) "Gavên Pêşniyarkirî:" else "Sorunsuz Ezan İçin Yapılması Gerekenler:",
                        color = GoldBright,
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold
                    )

                    GuidelineItem(
                        number = "1",
                        title = if (isKurmanji) "Kêmkirina Pîlê Rakin (Unrestricted)" else "Pil Tasarrufunu Kaldırın (Kısıtlamasız)",
                        desc = if (isKurmanji)
                            "Mîhengên sepanê vekin > Bikaranîna Pîlê > Vebijarka 'Bê sînor' (Unrestricted) hilbijêrin."
                        else
                            "Uygulama Bilgisi > Pil kullanımı bölümünden 'Kısıtlanmamış' (Unrestricted) seçeneğini işaretleyin."
                    )

                    GuidelineItem(
                        number = "2",
                        title = if (isKurmanji) "Destûra Alarma Tam Wext (Exact Alarm)" else "Tam Zamanlı Alarm İznini Onaylayın",
                        desc = if (isKurmanji)
                            "Android 12 û nûtir destûra alarma exact dixwaze da ku di dema deqîq de bang bide."
                        else
                            "Android 12 ve üzeri sürümlerde ezanın saniyesi saniyesine çalabilmesi için 'Alarmlar ve Hatırlatıcılar' izni verilmelidir."
                    )

                    GuidelineItem(
                        number = "3",
                        title = if (isKurmanji) "Xebata Otomatîk (Autostart - Xiaomi / Huawei)" else "Otomatik Başlatma (Xiaomi / Huawei / Vivo)",
                        desc = if (isKurmanji)
                            "Di telefonên Xiaomi û Huawei de ji Mîhengên Ewlehiyê 'Otomatik Başlatma' ji bo vê sepanê çalak bikin."
                        else
                            "Xiaomi MIUI/HyperOS, Huawei ve Vivo cihazlarda 'Otomatik Başlat' (Autostart) iznini açın ve pil tasarrufunu 'Kısıtlama Yok' yapın."
                    )

                    GuidelineItem(
                        number = "4",
                        title = if (isKurmanji) "Dengê Alarma Telefonê Kontrol Bikin" else "Alarm Ses Seviyesini Kontrol Edin",
                        desc = if (isKurmanji)
                            "Dengê bangê wekî alarma pergala Androidê tê lêxistin. Bawer bin ku dengê alarma telefonê vekirî ye."
                        else
                            "Ezan sesi Android'in yüksek öncelikli Alarm kanalı üzerinden duyulur. Telefonunuzun Alarm ses seviyesinin açık olduğundan emin olun."
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Action button to open battery settings
                Button(
                    onClick = {
                        onOpenBatterySettings()
                        onDismiss()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("open_battery_settings_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = GoldBright,
                        contentColor = DarkBackground
                    ),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Filled.OpenInNew, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = AppStrings.openBatterySettings(language),
                        fontWeight = FontWeight.Bold,
                        fontSize = 17.sp
                    )
                }
            }
        }
    }
}

@Composable
private fun GuidelineItem(
    number: String,
    title: String,
    desc: String
) {
    Surface(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        color = DarkSurface
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = EmeraldPrimary,
                modifier = Modifier.size(28.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text(number, color = GoldBright, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                }
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
                Text(title, color = TextWhite, fontWeight = FontWeight.SemiBold, fontSize = 17.sp, lineHeight = 23.sp)
                Spacer(modifier = Modifier.height(2.dp))
                Text(desc, color = TextMutedEmerald, fontSize = 15.sp, lineHeight = 22.sp)
            }
        }
    }
}
